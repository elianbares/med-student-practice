# Med Student Practice AI

**Heavily inspired by Dartmouth's AI Patient Actor.** An independent project, not affiliated with or endorsed by Dartmouth College.

Practice clinical interviews with AI patients by text, voice or emotive voice, then get rubric-based feedback the moment you finish. Educators write the cases; the AI only plays the patient.

It runs entirely on free tiers: Cloudflare Workers and D1 for hosting and data, the Google Gemini API free tier for the AI, and Cloudflare Workers AI (plus Groq, if you add a free key) when Google is busy.

## Put it online for free (about 3 minutes)

You need Node.js 20 or newer (nodejs.org, LTS) and a free Google AI key from https://aistudio.google.com/apikey.

```bash
npm install
npm run launch
```

The launch script:

1. tests your Google key with a real call before anything goes online, and stops with a plain reason if the key is invalid, restricted or out of today's allowance,
2. offers to add a free Groq key for extra capacity (optional, press Enter to skip),
3. signs you in to Cloudflare (free account, opens your browser once),
4. creates the free database and saves its ID in `wrangler.jsonc`,
5. asks for your email (you become the admin), makes an educator key, and asks whether to limit sign-ups to your school's email domains,
6. uploads the app with your keys stored as encrypted Cloudflare secrets, plus the free Workers AI overflow and a daily cleanup job,
7. prints your link (`https://med-student-practice-ai.<your-name>.workers.dev`) and waits until the live app reports that the AI is connected.

Run `npm run launch` again any time to ship changes. It reuses the same database, link and settings. Settings and the app's own secrets (the session and encryption keys) are kept in `.launch.json`, which is never uploaded or committed. Keep that file private, and keep it: sign-ins and saved AI keys depend on it.

**Why Cloudflare and not Streamlit:** the app never sleeps (Streamlit Community Cloud apps go to sleep and make the first visitor wait), it has a real database for accounts and transcripts, it serves over https so the microphone works, and the free plan covers 100,000 requests a day.

## Run it on this computer

```bash
npm install
npm run dev
```

Then open http://localhost:5173. Local secrets live in `.dev.vars` (start from `.dev.vars.example`): your Google key, the educator key and the admin email. It is never uploaded. Local development needs no Cloudflare account; the online version adds Workers AI and the daily cleanup (the `production` environment in `wrangler.jsonc`).

- **Students:** sign up. New students land in the demo course (code `MEDSIM`) while it is open, or in your course when they use its join link.
- **Educators:** choose Educator at sign-up and enter the educator key.
- **Admin:** an educator who signs up with the admin email gets the Admin page (AI status, capacity and daily usage).

## Join links

Every course has a code. Instead of reading it out, send students a join link:

```
https://med-student-practice-ai.<your-name>.workers.dev/join/CODE
```

A new student signs up and lands straight in the course; a student who already has an account signs in and joins it. The course code is on the course's page in the educator view, and the launch script prints your link at the end. Students can also sign up first and type the code in.

## Running a class of 100

One free Google key is enough for a class that practices across the week, but not for 100 students at the same moment.

- **What one free key handles.** Roughly 10 to 15 students practicing at the same time, and a few hundred patient replies a day (an encounter is about 20 replies plus one grading) before Google's free daily limits are reached. A class of 100 doing one case a week needs about 15 encounters a day, which fits. These are estimates: Google sets the limits, changes them from time to time, and shows your exact numbers in AI Studio. The Admin page (and each course's settings) shows today's usage and what your current setup can handle.
- **Voice is the tight spot.** Natural and emotive voice use Google's much smaller audio allowances. On one free key, plan for only a few students in voice modes at the same time; text mode, course keys or student keys cover the rest.
- **Students add their own free keys.** In Settings, a student can paste a free key from https://aistudio.google.com/apikey (one minute, no card). Each key brings its own allowance, so that student skips the shared daily limit and leaves the shared key for others.
- **Course keys.** An educator can add a key in a course's settings. Everyone in that course then uses it instead of the shared key.
- **A paid key for a live lab.** For 100 students at once, turn on billing for the Google Cloud project behind a key and use it as the course key (or as the main key: put it in `.dev.vars` as `GEMINI_API_KEY` and run `npm run launch` again). Paid keys have much higher per-minute limits. With Flash-Lite, a text encounter costs roughly one to three cents, so a class of 100 doing one case costs a few dollars. Voice modes cost more because audio is priced higher. Check current prices at https://ai.google.dev/pricing and set a budget alert in Google Cloud.
- **Overflow.** When every Gemini and Gemma model on a key is busy, the app moves on to Groq (if you added a free Groq key at launch) and then to Cloudflare Workers AI (Llama 3.3 70B, free allowance of 10,000 "neurons" a day, a few encounters' worth). Workers AI runs only online, not in local development.
- **Fair use of the shared key.** Students without their own key or a course key can start up to 15 encounters a day on the shared key, so no one can use up everyone's allowance. An admin can close the public demo course while a class runs.

What students see when a limit is hit: the app first retries a few times on its own. If the AI is still busy, a plain message asks them to try again in a minute, and nothing they typed is lost. If they reach the 15 a day on the shared key, the app says when more open up and how to add their own key. If grading fails, the transcript is kept and a Try again button on the feedback page grades it later. In voice modes, when the natural voices are busy, the patient switches to the device's own voice and a note says so.

## Privacy

- **What goes to Google.** The case (written by educators), the conversation, tests ordered, and the diagnosis and note for grading. In voice modes, the patient's lines go to Google's text-to-speech, and recordings of what the student says go to Gemini for the tone listen-back, emotive voice and speech-to-text in Firefox. In Chrome and Safari, the browser's own speech recognition turns speech into text, which uses Google's or Apple's servers.
- **What does not.** Email addresses, passwords and full names are never sent to the AI. The AI only sees a student's first name, and if a student types their full name in the conversation, it is cut to the first name before it is sent.
- **The free tier.** On Google's free tier, Google may use prompts and answers to improve its products, and people at Google may read them. Use made-up cases only, and never enter real patient information.
- **For institutions.** Use a paid key (billing turned on), as the main key or as course keys. Google does not use paid-tier prompts to improve its products. Check with your privacy office before using it with a whole class.
- **Your data.** In Settings, anyone can download everything stored about them as a file, or delete their account along with their encounters, comments and notifications. Educators first archive courses that still have students.
- **Retention.** Each course has a setting for how many days to keep encounters (1 to 3650, or 0 to keep them). A daily cleanup at 03:00 UTC deletes older encounters with their comments and notifications. The cleanup runs online only, not in local development.
- **Where it lives.** Everything is stored in the D1 database in your own Cloudflare account. AI keys that students and courses add are encrypted with a key that lives in Cloudflare secrets, not in the database.

## Security

- **Sessions.** Signing out ends the session on the server, not just in the browser, and on your other devices too. Changing or resetting a password signs out every other device. Session cookies are http-only and last up to 30 days.
- **Passwords.** Passwords are stretched in the browser and stored only as salted hashes.
- **Throttling.** Sign-in allows 10 wrong passwords per email and 30 per network every 15 minutes. Each network can sign up 5 accounts an hour, with a much larger allowance for students who use a course's join link, so a class on one campus network can sign up together. Password resets, sign-up checks and joining courses are limited too. The counts are kept in the database, so they hold across Cloudflare's servers.
- **Allowed email domains (optional).** The launch script asks once whether to limit sign-ups (for example to `dartmouth.edu`; subdomains count, and the admin email always works). To change it later, edit `allowedEmailDomains` in `.launch.json` (a comma list, or `""` for anyone) and run `npm run launch` again.
- **Turnstile (optional).** Cloudflare Turnstile adds a free, mostly invisible bot check to sign-up. In the Cloudflare dashboard, open Turnstile, add a widget for your `workers.dev` hostname, and copy its site key and secret key. Add them to `.launch.json` as `"turnstileSiteKey"` and `"turnstileSecret"`, then run `npm run launch` again; they are sent as the `TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET` secrets. Remove both lines and launch again to turn it off.
- **Demo course switch.** The public demo course (`MEDSIM`) is open to anyone who signs up. On the Admin page, an admin can close it so that only students in your own courses use the shared key.
- **Secrets.** The session-signing secret and the encryption key are made once by the launch script, kept in `.launch.json` and sent as Cloudflare secrets (`SESSION_SECRET`, `ENC_KEY`). Local development generates its own in the local database.

## What's included

| Area | Features |
|---|---|
| Students | Sign-up, join links and course codes, case brief, text, voice and emotive-voice encounters, Tasks, Exams and Notes panel, diagnosis and SOAP note at the end, instant feedback, skill meters and history, retry any case, download or delete your data |
| Patients | Educator-written history, personality and communication style; illustrated face with 9 expressions that follow the conversation; natural human voices with emotional delivery; authored test results (never invented) |
| Feedback | Rubric scores with quotes from your conversation, strengths first, focus areas, diagnosis check, missed questions, exam and test review, note feedback, voice metrics plus an AI listen-back of your tone |
| Educators | Library of patient profiles (AI drafting assistant, appearance and voice editor with preview), configurations (tasks, rubric, role-play, feedback style, time limit), cases; courses with codes and join links, roster, password-reset codes, results, comments, CSV export, per-course AI key, retention setting |

## AI models (free tier, measured October 2026)

| Job | Models, in fallback order |
|---|---|
| Patient replies | Gemini Flash-Lite (about 1 s), 3.1 Flash-Lite, Gemma 4 |
| Patient voice | Gemini Flash-Lite TTS and other Gemini TTS models, with the delivery matched to the patient's mood; the device voice only if all are busy |
| Emotive voice | Gemini 3.8 Live, 3.1 Flash Live, 2.5 Flash Native Audio |
| Grading | Gemini Flash-Lite for everyone, so grades are comparable (fast, with a large free daily allowance), then 3.1 Flash-Lite, 3.6 Flash and others |
| Speech-to-text (Firefox) and voice analysis | Gemini Flash-Lite |
| Overflow when Google is busy | Groq (if you added a key), then Cloudflare Workers AI (Llama 3.3 70B, online only) |

A model that is busy or out of its daily quota is skipped until Google says it resets, so students do not wait on it. Each Google key has its own quota; see Running a class of 100.

## Checks

```bash
npm run typecheck
npm test
node tests/smoke.mjs
node tests/voice-check.mjs tests/fixtures/doctor.wav
node tests/tts-check.mjs
node tests/e2e.mjs
node tests/grader-check.mjs
```

- `npm test`: unit tests.
- `tests/smoke.mjs`: end-to-end API walkthrough: sign-up and sessions, library, courses, encounters and grading, data download, account deletion and the admin demo switch (about 4 AI calls). It deletes everything it creates, but closes the demo course for a moment, so don't run it while others sign up on the same local server.
- `tests/voice-check.mjs`: emotive voice, speech-to-text and voice analysis. A clip under 30 seconds must come back unrated; a longer one is built from the same clip and rated, with the pace the browser measured (about 6 AI calls).
- `tests/tts-check.mjs`: natural voice for every demo patient.
- `tests/e2e.mjs`: real Chrome, fake microphone; text, voice and emotive encounters, educator flow, dark mode and phone layouts. Screenshots land in `tests/screens/`.
- `tests/fidelity.mjs`: Dartmouth-style patient fidelity evaluation.
- `tests/grader-check.mjs`: grader sanity check. A thorough interviewer and a guesser see the same case; the guess must be called unsupported and score lower (about 12 AI calls).

## Design

`DESIGN.md` is the style system: tokens, type, spacing, components and copy rules, following Apple's Human Interface Guidelines.

## Credits

Heavily inspired by the published design of Dartmouth Geisel School of Medicine's AI Patient Actor (Thesen et al., *Medical Science Educator*, 2024 and 2025). This project is independent, and its cases, prompts and rubrics are original.

Patient illustrations: [Avataaars](https://avataaars.com/) by Pablo Stanley (free for personal and commercial use), via [DiceBear](https://www.dicebear.com/) (MIT). Icons: [Lucide](https://lucide.dev/) (ISC). Headings: [Newsreader](https://fonts.google.com/specimen/Newsreader) (SIL Open Font License).
