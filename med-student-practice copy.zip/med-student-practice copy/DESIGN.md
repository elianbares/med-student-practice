# Med Student Practice AI: design system

This file is the source of truth for the interface. Every screen follows it. If a change breaks a rule here, change the rule here first. `src/client/styles.css` implements it, and the shared React pieces live in `src/client/ui.tsx` and `src/client/components/Visuals.tsx`.

## Intent

**Purpose.** A calm, serious practice room for clinical conversations. It should feel like a well-made medical school tool, not a startup landing page.

**Emotion to evoke:** composure and focus. The student is nervous about interviews, so the product should lower the temperature.

**References:**
- Apple Human Interface Guidelines: clarity, deference, hierarchy, familiar controls.
- Apple Developer and Health app layouts: white space, grouped lists, quiet color.
- Dartmouth's AI Patient Actor (forest green, plain forms, sidebar encounter layout).

## Color (exact tokens)

| Token | Light | Dark | Use |
|---|---|---|---|
| `--bg` | `#ffffff` | `#000000` | Page background |
| `--bg-grouped` | `#f5f5f7` | `#1c1c1e` | Grouped sections, sidebars, input fills, read-only fields |
| `--fill` | `#ececf0` | `#2c2c2e` | Segmented control track, neutral badges, empty meter segments |
| `--separator` | `#e3e3e8` | `#38383a` | Hairlines, card borders |
| `--separator-strong` | `#d2d2d7` | `#48484a` | Input borders |
| `--label` | `#1d1d1f` | `#f5f5f7` | Primary text |
| `--label-2` | `#424245` | `#d1d1d6` | Secondary text |
| `--label-3` | `#6e6e73` | `#98989d` | Tertiary text, captions, nonverbal cues |
| `--accent` | `#1d6b46` | `#4cb27f` | Primary actions, links, active states. One accent only |
| `--accent-hover` | `#16573a` | `#5cc28f` | Hover on primary actions |
| `--accent-ink` | `#ffffff` | `#04140b` | Text on an accent fill |
| `--accent-tint` | `#eaf3ee` | `#16271e` | Selected rows, focus halo, text selection |
| `--info` / `--info-tint` | `#0066cc` / `#eef5fc` | `#4ea1ff` / `#10213a` | Exam and test results only |
| `--good` / `--good-tint` | `#1e7a4c` / `#e6f3ec` | `#57c58a` / `#13281c` | Rubric top level |
| `--mid` / `--mid-tint` | `#9a6200` / `#fbf1dc` | `#e0b04a` / `#2c2410` | Rubric middle level, warnings |
| `--low` / `--low-tint` | `#b3401a` / `#fbebe4` | `#ff8a65` / `#33190f` | Rubric lowest level, errors, destructive |
| `--doctor-bubble` / `--doctor-ink` | `#1d6b46` / `#ffffff` | `#1f5c3d` / `#ffffff` | The clinician's chat bubble |
| `--patient-bubble` | `#f0f0f3` | `#2c2c2e` | The patient's chat bubble |
| `--segment-on` | `#ffffff` | `#636366` | The selected segment |
| `--nav-glass` | white at 80% | `#161617` at 80% | Translucent nav and sticky editor bar |
| `--shadow-modal`, `--shadow-menu` | | | The only two shadows: dialogs and row menus |

`--muted` is an alias of `--label-3`, kept so older inline styles still resolve. New code uses `--label-3`.

Rules:
- No gradients (none in swatches either: "automatic" is a text chip). No beige or cream backgrounds. No purple, lavender, magenta, or teal-and-orange pairings.
- Status colors (`good`, `mid`, `low`) appear only on rubric levels, warnings and errors, never as decoration. A status such as "In progress" is a neutral badge, never green.
- Course colors are muted solids (forest, navy, slate, oxblood, ochre, graphite), shown only as a 6 px bar or swatch.
- Every color is a token defined for light and dark in `:root`. No raw colors in pages.

## Typography

There are two families, used with clear contrast:

- **Display: Newsreader** (serif, optical sizes), for page titles, section titles and big numbers. Weight 600, tracking -0.01em.
- **Text: the system UI font** (SF Pro on Apple devices, Segoe UI on Windows), for everything else: body, labels, buttons, tables.
- **Mono: the system monospace font,** for course codes only.

Scale (px / line-height):

| Role | Spec |
|---|---|
| Display XL | 52/1.05, landing only |
| Title 1 | 34/1.15, also big numbers (`.stat-value`) |
| Title 2 | 24/1.2 |
| Title 3 | 19/1.3 |
| Headline (text font) | 17/1.35 semibold |
| Body | 16/1.5 |
| Callout | 15/1.45 |
| Footnote | 13/1.4, hints, field errors, level bar captions |
| Caption | 12/1.35, small caps label with 0.06em tracking |

Never set headings and body in the same family at the same weight.

## Space, shape, depth

- **Spacing scale:** 4, 8, 12, 16, 24, 32, 48, 64, 96. Nothing in between. Offsets under 4 px are optical nudges (a 2 px segment inset, a 1 px border overlap), not spacing.
- **Page width:** `--page-max` 1120 px; side padding 24 px (16 px under 600 px). The nav is `--nav-h` 56 px tall.
- **Radii (tokens only):** `--r-control` 10 px for buttons, inputs and the segmented track; `--r-card` 14 px for cards, lists and tables; `--r-sheet` 20 px for modals, the landing preview, chat bubbles and the composer; `--r-badge` 6 px for badges, swatches and menu items; `--r-pill` 999 px only for thin bars (meters, progress, the level bar, color bars). Circles (50%) only for avatars, initials and the send button.
- **Depth:**
  - Cards are flat, with a 1 px `--separator` border and no shadow.
  - Only modals, row menus and the floating nav cast shadows.
  - The nav is translucent white with a backdrop blur, like Apple's web nav.
- **Negative space:** about 60% of any screen stays empty. Sections are separated by 64 to 96 px, not by boxes.
- **Layout:**
  - One left edge. The wordmark, page titles, editors, results and the encounter all start at the same x. `.page` is the container; `.page.narrow` (content up to 712 px) and `.page.form` (content up to 880 px) narrow the content but keep it left-aligned. Never set `maxWidth` inline on a page.
  - Asymmetric where it helps (hero 7/5, settings 4/8 with `.split`). Multi-line text is always left-aligned; centered text is limited to single short lines.
  - Lists over card grids for collections of similar items (courses, encounters, roster). Card grids are used only when each item carries a face or image (patients).

## Phones (600 px and under)

- Side padding 16 px; modal padding 24 px.
- The editors' save bar (`.sticky-actions`) stops being sticky and scrolls with the page, so it never covers the field being typed in.
- **Tables never clip.** Every `.table` turns into a list: the header row is hidden (kept for screen readers), each row is a two-column grid. The first cell is the title, middle cells stack under it as 13 px meta lines, the last cell sits on the right. `td.wide` spans the full row below; empty cells disappear; `td[data-label]` prefixes its label. Add `.no-stack` to opt out.
- **The nav stays one row at every width.** The user name truncates at 220 px (120 px under 900 px) and hides under 860 px; the wordmark text hides under 760 px when signed in; the initials hide under 400 px; on public pages the "Sign in" text link hides and the wordmark text hides under 360 px. Nav links stay text only and scroll sideways only on the narrowest phones.
- **Encounter:** one compact header line (`.enc-head`: case name truncates, the configuration and `.enc-mode` hide, the timer drops to 13 px, End encounter stays on the line), a short stage (`.stage` padding 8 px 16 px, avatar 40 px through `--avatar-size`), the chat panel `calc(100dvh - 112px)` tall, and the sidebar's brief card (`.enc-brief`) hidden.
- `.hide-phone` hides anything else that is secondary on a phone.

## Components

### Classes (styles.css)

- **Buttons** (`.btn`): 40 px tall; `.small` 32 px; `.lg` 48 px; all use `--r-control`. `.primary` is filled with accent; the default is a plain bordered button; `.plain` is an accent text button; `.ghost` has no border; `.danger` uses `--low` text; `.icon` is square; `.block` is full width. Icon plus label only when the icon aids recognition (microphone, send, back).
- **Fields:** `label.field` (14 px semibold label, 24 px below each field; field grids `.grid-2` and `.two-col` have no row gap). `.hint` below an input. `.field-error` (13 px, `--low`) below an input, with `aria-invalid="true"` on the input, which turns its border `--low`. Read-only inputs, read-only textareas and disabled selects sit on `--bg-grouped` with no border, so they read as text.
- **Toolbar** (`.toolbar`): a row of filters or inline actions where inputs, selects and buttons are all 40 px tall. Filters get a visible label: wrap each label and control in `.toolbar-field` (13 px semibold label 4 px above the control) and add `.labeled` to the toolbar so checkboxes and buttons line up with the controls' bottom edge.
- **Editor sections** (`.editor-section`): sections separated by space and a hairline, not boxes: each section after the first has a 64 px top margin, 32 px top padding and a 1 px separator. Never nest cards in editors.
- **Segmented control:** Apple style, for mutually exclusive modes (Text / Voice / Emotive voice) and sidebar tabs.
- **Tabs** (`.tabs`, `.tab`): underlined page tabs.
- **Lists:** `.list` with `.list-row` rows (hairline separators, trailing chevron for navigation).
- **Tables** (`.table`): small-caps header, hairline rows. `.end` right-aligns a column. Put `a.row-link` in the first cell to make the whole row a real, keyboard-reachable link. `.truncate` ellipsizes a long value (240 px, full width on phones).
- **Badges** (`.badge`): neutral by default (`--fill`, `--label-2`), for statuses such as "In progress". `.low`, `.mid`, `.high` are rubric levels with tinted backgrounds. `.pill` is an alias for older markup; use `.badge`.
- **Level cell** (`.level-cell`): a meter and its badge in one right-aligned cell, 12 px apart.
- **Skill meter** (`.meter`): a segmented bar filled to the level reached, in the level color. It replaces decorative rings.
- **Level bar** (`.levelbar-block`, `.levelbar`, `.levelbar-caption`): a 240 x 8 px stacked bar, lowest level first in `--low`, `--mid`, `--good`, with a 13 px caption such as "50% · 50% · 0%". Educator results use it per rubric skill.
- **Stats** (`.stats` holding `.stat`): a big Newsreader number (`.stat-value`) over a 13 px label (`.stat-label`). Under 600 px they sit in three equal columns so a set of three never wraps two and one.
- **Sparkline** (`.sparkline`): a 96 x 24 px trend line in accent with a dot on the latest value.
- **Notices** (`.notice`, `.error`, `.warn`, `.ok`, `.info`): inline messages above the content they concern. `.banner` is the full-width strip under the nav for app messages ("Your session ended. Sign in again.").
- **Flash** (`.flash`): a short confirmation ("Saved", "Copied") next to the button that caused it, gone after 2 seconds.
- **Modal** (`.modal`, `.modal.wide`, `.modal-head`, `.modal-body`): 32 px padding, `--r-sheet`.
- **Row menu** (`.row-menu`, `.row-menu-list`): one "More" button per row instead of repeated bordered buttons; destructive items are `--low` text.
- **Exams and tests** (`.test-row`): a full-width button row with the test name and a trailing accent label (`.trail`, "Order" or "Perform"); done or disabled rows show a grey label. Results appear in `.test-result` with an `--info` left rule.
- **Chat:** the clinician speaks on the right in accent green; the patient speaks on the left in `--patient-bubble`. Exam results appear as `.record` rows with an `--info` left rule and a small-caps label. Nonverbal cues ("*fidgets with bag strap*") render as `<em class="action">` in italic `--label-3`, at 80% opacity inside the clinician's bubble; `ActionText` does this for bubbles and transcripts, so raw asterisks and dashes never show. The composer textarea grows with its text up to 160 px and has no resize grip.
- **Swatches** (`.swatches`, `.swatch-btn`): solid squares; the automatic choice is a text chip (`.swatch-btn.auto`, "Auto").
- **Encounter layout:** `.encounter` (sidebar 320 px and chat, aligned with the page container, padding 16 px 24px), `.enc-side`, `.enc-brief`, `.enc-main`, `.enc-head`, `.enc-mode`, `.timer` (`.warn` near the end), `.stage`, `.chat`, `.composer`.

### React pieces

From `src/client/ui.tsx`:
- `Modal` moves focus into the dialog, keeps Tab inside, makes the page behind inert, closes on Escape and the backdrop, and returns focus to the control that opened it. `closable={false}` while busy hides the close button and ignores Escape and the backdrop.
- `Tabs` and `Segmented` use arrow keys, Home and End (roving tab index). With `idBase`, tabs point to their panels; wrap each panel in `TabPanel`. `Segmented as="tabs"` for sidebar tabs; the default is a radio group for modes.
- `RowMenu` for per-row actions.
- `Loaded` renders a `useLoad` result: the skeleton while loading, an error with "Try again" when it failed, otherwise the content. An error and an empty state never show together.
- `FieldError` with `invalidProps` for inline field errors; `useFlash` with `Flash` for short confirmations; `copyText` resolves true once the clipboard has the text, so "Copied" only shows when it is true.
- `LevelPill`, `levelClass`, `levelValue`, `levelIndex` match level names regardless of case and show them in sentence case.
- `RequireRole` sends signed-out people to `/signin?next=<page>`; `readNext` and `useNextPath` read it back after sign-in. A 401 on any signed-in request signs the person out, returns them to sign-in with the same `next`, and shows the session banner.
- `useBack(fallback)` goes back in the app, or to `fallback` when the page was opened directly. `useUnsavedChanges(dirty)` warns before closing the tab, and `confirmDiscard()` asks before leaving through an in-app link or button (the nav already asks).
- `useAutoGrow` grows a textarea up to 160 px.
- `ActionText` renders chat and transcript text: `*actions*` become `<em class="action">`, unpaired asterisks drop, and em or en dashes read as commas (`noDashes`).

From `src/client/components/Visuals.tsx`: `SkillMeter`, `LevelBar`, `Sparkline`, `Stat`, `Wordmark`, `Footer`.

From `src/client/api.ts`: `api(path, { retry: true, onRetry })` retries a busy AI (503 or 429 with a short Retry-After, or a "busy" error) up to 3 times after 1, 2 and 4 seconds, never waiting more than 8. GET requests retry on their own; pass `retry: true` only for a POST that is safe to repeat. `onRetry(attempt, waitMs)` lets the page say "The AI is busy. Trying again." `streamReply` retries the same way, and a 401 fires `apa:unauthorized` (`UNAUTHORIZED_EVENT`).

## Accessibility

- "Skip to content" is the first focusable element on every page and moves focus to the content.
- Every interactive element shows a 2 px accent focus ring (`:focus-visible`).
- Field errors sit under their field, linked with `aria-describedby`, and the field gets `aria-invalid`. A banner at the top of a form is not enough on its own.
- Live regions announce short, whole messages (a reply once it has finished, "Saved"). Never put `aria-live` on a container that receives streamed text.
- Rows that open something are real links (`a.row-link`), not clickable rows.

## Iconography

- Lucide outline icons at 1.75 stroke, 16 to 18 px, and only for actions people recognize by shape (mic, send, back, copy, print, close, play, more).
- Banned: sparkles, magic wands, lightbulbs, gears as decoration, flames, trophies, rocket ships, and icons inside colored circles.

## Copy

- Plain and short, in sentence case, including rubric levels ("Needs improvement"), headings and test categories. Say what happens: "Start conversation", "End and get feedback".
- No em dashes or en dashes, no exclamation marks, and no emoji in the interface. Separate metadata with a middle dot: "Oct 26, 9:37 PM · 2 min · Text".
- Feedback speaks to the student as "you", never "the trainee" or "the clinician".
- No "AI-powered", "seamless", "unlock", "supercharge", or "journey".
- Never call this product "AI Patient Actor". The credit "Heavily inspired by Dartmouth's AI Patient Actor" stays.
- Say what the product does and doesn't do, especially about data and AI.

## Motion

- 150 to 250 ms ease-out for state changes. Message bubbles fade in 120 ms.
- No looping decorative motion. The only repeating animations are the speaking indicator and the listening dot, and both stop with reduced motion.

## Attribution

Every page footer shows: "Med Student Practice AI. Heavily inspired by Dartmouth's AI Patient Actor (Geisel School of Medicine). Independent project, not affiliated with or endorsed by Dartmouth College."
