import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { cloudflare } from "@cloudflare/vite-plugin";

export default defineConfig({
  plugins: [react(), cloudflare()],
  // 127.0.0.1 is reachable from every browser whether you type "localhost" or "127.0.0.1",
  // while staying private to this computer.
  server: { host: "127.0.0.1", port: 5173, strictPort: true },
  // The single app bundle is about 170 KB gzipped (mostly the avatar artwork), which is fine for this app.
  build: { chunkSizeWarningLimit: 700 },
});
