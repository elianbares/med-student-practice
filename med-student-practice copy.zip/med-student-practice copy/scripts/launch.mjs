#!/usr/bin/env node
// Puts Med Student Practice AI online for free on Cloudflare (Workers + D1), in one command:
//   npm run launch
// Safe to run again: it reuses your database and settings, and just ships the latest code.
// It deploys the "production" environment in wrangler.jsonc; `npm run dev` keeps using the top level.
import { spawnSync } from "node:child_process";
import { chmodSync, existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import { createInterface } from "node:readline/promises";

const WORKER = "med-student-practice-ai";
const DB_NAME = "med-student-practice-ai";
const PLACEHOLDER = "00000000-0000-0000-0000-000000000000";
const STATE = ".launch.json";
const DEV_VARS = ".dev.vars";
const CF_ENV = "production";
const GOOGLE = "https://generativelanguage.googleapis.com/v1beta";
const WIN = process.platform === "win32";
// Secrets that are only sent when set; if one is turned off later, it is removed from Cloudflare too.
const OPTIONAL_SECRETS = ["GROQ_API_KEY", "ALLOWED_EMAIL_DOMAINS", "TURNSTILE_SECRET", "TURNSTILE_SITE_KEY"];

const bold = (s) => `\x1b[1m${s}\x1b[0m`;
const green = (s) => `\x1b[32m${s}\x1b[0m`;
const red = (s) => `\x1b[31m${s}\x1b[0m`;
let stepNo = 0;
const step = (s) => console.log(`\n${bold(`${++stepNo}. ${s}`)}`);
const die = (s) => {
  console.error(`\n${red("Stopped:")} ${s}`);
  process.exit(1);
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Windows runs npx through a shell, which splits arguments on spaces unless they are quoted.
const quote = (a) => (/[\s"]/.test(a) ? `"${a.replace(/"/g, '\\"')}"` : a);

/** Runs a command. Interactive commands share this terminal; captured ones return their output. */
function sh(cmd, args, { capture = false, env } = {}) {
  const opts = { stdio: capture ? ["inherit", "pipe", "pipe"] : "inherit", encoding: "utf8", env: { ...process.env, ...env } };
  // On Windows the command goes to the shell as one string, which also avoids Node's warning about shell arguments.
  const r = WIN ? spawnSync([cmd, ...args].map(quote).join(" "), { ...opts, shell: true }) : spawnSync(cmd, args, opts);
  return { ok: r.status === 0, out: `${r.stdout ?? ""}${r.stderr ?? ""}` };
}
const wrangler = (args, opts) => sh("npx", ["wrangler", ...args], opts);

// A prompt is opened only while asking, so it never holds the terminal while Cloudflare's own tools run.
async function ask(q) {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    return (await rl.question(q)).trim();
  } finally {
    rl.close();
  }
}

// ---------- .dev.vars (local secrets, never uploaded as a file) ----------
const devVars = () => (existsSync(DEV_VARS) ? readFileSync(DEV_VARS, "utf8") : "");
// [ \t] rather than \s, so an empty value never picks up the next line.
const readVar = (name) => new RegExp(`^${name}[ \\t]*=[ \\t]*"?([^"\\r\\n]*)"?`, "m").exec(devVars())?.[1]?.trim() ?? "";
function saveVar(name, value) {
  const text = devVars();
  const line = `${name}=${value}`;
  const re = new RegExp(`^${name}[ \\t]*=.*$`, "m");
  writeFileSync(DEV_VARS, re.test(text) ? text.replace(re, () => line) : `${text}${text && !text.endsWith("\n") ? "\n" : ""}${line}\n`, { mode: 0o600 });
}

// ---------- AI key checks (real calls, so a bad key stops us before anything goes online) ----------
async function googleCall(path, key, body) {
  try {
    const res = await fetch(`${GOOGLE}/${path}`, {
      method: body ? "POST" : "GET",
      headers: { "x-goog-api-key": key, ...(body ? { "content-type": "application/json" } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(30_000),
    });
    return { status: res.status, text: res.ok ? "" : await res.text() };
  } catch (err) {
    return { status: 0, text: err instanceof Error ? err.message : String(err) };
  }
}

/** A plain-language reason for a failed Google call. */
function googleProblem({ status, text }) {
  if (status === 0) return "Couldn't reach Google. Check your internet connection and run this again.";
  if (/API_KEY_INVALID|API key not valid|API key expired/i.test(text))
    return "Google says this key is not valid. Copy the whole key again from https://aistudio.google.com/apikey and run this again.";
  if (/location is not supported/i.test(text)) return "Google's free AI isn't offered in your region, so this key can't be used from here.";
  if (/leaked/i.test(text)) return "Google blocked this key because it was found in public. Create a new key at https://aistudio.google.com/apikey and run this again.";
  if (status === 401 || status === 403)
    return "Google refused this key. It may be restricted to other apps or websites, or the Gemini API is turned off for its project. Create a new key with no restrictions at https://aistudio.google.com/apikey and run this again.";
  if (status === 429 && /per ?day|daily/i.test(text)) return "This key has used up today's free AI allowance. Try again tomorrow or use another key.";
  if (status === 429) return "This key is getting too many requests right now. Wait a minute and run this again.";
  if (status === 404) return "This key can't use the Flash-Lite models the app needs. Create a new key at https://aistudio.google.com/apikey and run this again.";
  return `Google answered with an error (${status}): ${text.replace(/\s+/g, " ").slice(0, 200)}`;
}

/** Lists the key's models, then asks Flash-Lite for one token. Returns { ok, error?, warn? }. */
async function verifyGoogleKey(key) {
  const listed = await googleCall("models?pageSize=50", key);
  if (listed.status !== 200) return { ok: false, error: googleProblem(listed) };
  let last;
  for (const model of ["gemini-flash-lite-latest", "gemini-3.1-flash-lite"]) {
    last = await googleCall(`models/${model}:generateContent`, key, {
      contents: [{ role: "user", parts: [{ text: "Reply with OK." }] }],
      generationConfig: { maxOutputTokens: 1 },
    });
    if (last.status === 200) return { ok: true };
    // A bad key fails the same way on every model; a busy, used-up or retired model is worth one more try.
    if (![404, 429, 500, 503].includes(last.status)) return { ok: false, error: googleProblem(last) };
  }
  // The key itself works (it listed its models); Google is just overloaded for a moment.
  if (last.status >= 500) return { ok: true, warn: "Google's models are busy right now, so the test answer didn't come back. The key itself works." };
  return { ok: false, error: googleProblem(last) };
}

async function groqKeyWorks(key) {
  try {
    const r = await fetch("https://api.groq.com/openai/v1/models", { headers: { authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(20_000) });
    return r.ok;
  } catch {
    return false;
  }
}

console.log(bold("\nMed Student Practice AI: free launch on Cloudflare"));
console.log("Heavily inspired by Dartmouth's AI Patient Actor. This takes about 3 minutes.\n");

// ---------- 1. Basics ----------
step("Checking this computer");
const major = Number(process.versions.node.split(".")[0]);
if (major < 20) die(`Node.js 20 or newer is needed (you have ${process.versions.node}). Install the LTS version from nodejs.org and run this again.`);
if (!existsSync("node_modules")) {
  console.log("Installing packages (first run only)...");
  if (!sh("npm", ["install"]).ok) die("npm install failed. Check your internet connection and try again.");
}
console.log(green("OK"));

let state = {};
try {
  state = existsSync(STATE) ? JSON.parse(readFileSync(STATE, "utf8")) : {};
} catch {
  die(`${STATE} is damaged. Fix it (it is plain JSON) or restore it from a backup, then run this again.`);
}
const saveState = () => {
  writeFileSync(STATE, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 });
  try {
    chmodSync(STATE, 0o600); // it holds secrets, so only you can read it
  } catch {
    /* not supported on every system */
  }
};

// ---------- 2. Google AI key ----------
step("Google AI key (free, powers the patients)");
let googleKey = readVar("GEMINI_API_KEY");
const keyFromFile = Boolean(googleKey);
if (keyFromFile) console.log("Found in .dev.vars.");
else {
  console.log("Get one free at https://aistudio.google.com/apikey (Create API key, then copy it).");
  googleKey = await ask("Paste your Google AI key: ");
  if (googleKey.length < 30) die("That doesn't look like a Google AI key. Copy the whole key and run this again.");
}
console.log("Testing the key with Google...");
const check = await verifyGoogleKey(googleKey);
if (!check.ok) die(`${check.error}${keyFromFile ? " (The key is read from GEMINI_API_KEY in .dev.vars.)" : ""}`);
if (!keyFromFile) saveVar("GEMINI_API_KEY", googleKey);
console.log(check.warn ?? green("The key works."));

// ---------- 3. Extra capacity (optional) ----------
step("Extra AI capacity (optional)");
let groqKey = readVar("GROQ_API_KEY");
if (groqKey) console.log(green("Groq key found in .dev.vars. It takes over when Google is busy."));
else if (state.groqAsked) console.log("Skipped. To add a free Groq key later, put GROQ_API_KEY=... in .dev.vars and run this again.");
else {
  console.log("A free Groq key (https://console.groq.com/keys) adds a second AI that takes over when Google is busy.");
  const pasted = await ask("Optional: paste a free Groq key for extra capacity (press Enter to skip): ");
  state.groqAsked = true;
  saveState();
  if (!pasted) console.log("Skipped.");
  else if (!(await groqKeyWorks(pasted))) console.log(red("Groq didn't accept that key, so it was skipped. You can add it to .dev.vars later."));
  else {
    groqKey = pasted;
    saveVar("GROQ_API_KEY", groqKey);
    console.log(green("Saved to .dev.vars."));
  }
}

// ---------- 4. Cloudflare account ----------
step("Cloudflare account (free)");
let who = wrangler(["whoami", "--json"], { capture: true });
if (!who.ok) {
  console.log("A browser window will open. Sign up for free (or log in), then click Allow.");
  if (!wrangler(["login"]).ok) die("Cloudflare login didn't finish. Run this again.");
  who = wrangler(["whoami", "--json"], { capture: true });
  if (!who.ok) die("Still not logged in to Cloudflare. Run: npx wrangler login");
}
let accounts = [];
try {
  accounts = JSON.parse(who.out.slice(who.out.indexOf("{"))).accounts ?? [];
} catch {
  /* older output format: wrangler will ask which account if there are several */
}
let accountId = process.env.CLOUDFLARE_ACCOUNT_ID ?? "";
if (!accountId && accounts.length === 1) accountId = accounts[0].id;
if (!accountId && accounts.length > 1) {
  accounts.forEach((a, i) => console.log(`  ${i + 1}. ${a.name}`));
  const pick = Number(await ask(`Which Cloudflare account should host the app? (1-${accounts.length}): `));
  accountId = accounts[pick - 1]?.id ?? die("No account picked.");
}
const cfEnv = accountId ? { CLOUDFLARE_ACCOUNT_ID: accountId } : {};
console.log(green(`Logged in${accounts.length ? ` (${accounts.find((a) => a.id === accountId)?.name ?? accounts[0].name})` : ""}`));

// ---------- 5. Database ----------
step("Database (Cloudflare D1, free)");
let config = readFileSync("wrangler.jsonc", "utf8");
// The ID goes in both the top level and the production environment; preview_database_id stays local.
const ids = [...config.matchAll(/"database_id":\s*"([^"]+)"/g)].map((m) => m[1]);
let dbId = ids.find((id) => id !== PLACEHOLDER) ?? PLACEHOLDER;
const isNew = dbId === PLACEHOLDER;
if (isNew) {
  const list = wrangler(["d1", "list", "--json"], { capture: true, env: cfEnv });
  try {
    dbId = JSON.parse(list.out.slice(list.out.indexOf("["))).find((d) => d.name === DB_NAME)?.uuid ?? PLACEHOLDER;
  } catch {
    /* fall through to create */
  }
  if (dbId === PLACEHOLDER) {
    const made = wrangler(["d1", "create", DB_NAME], { capture: true, env: cfEnv });
    dbId = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i.exec(made.out)?.[0] ?? die(`Couldn't create the database:\n${made.out}`);
  }
}
if (ids.some((id) => id !== dbId)) {
  config = config.replace(/"database_id":\s*"[^"]+"/g, `"database_id": "${dbId}"`);
  writeFileSync("wrangler.jsonc", config);
}
console.log(green(isNew ? `Ready and saved to wrangler.jsonc (${dbId})` : `Using your database (${dbId})`));

// ---------- 6. Your settings ----------
step("Your educator settings");
if (!state.adminEmail) {
  state.adminEmail = await ask("Your email (sign up with it later and you become the admin): ");
  if (!/^\S+@\S+\.\S+$/.test(state.adminEmail)) die("That email doesn't look right. Run this again.");
}
state.educatorKey ||= randomBytes(9).toString("base64url");
// Made once and kept, so sign-ins and saved AI keys keep working across launches.
state.sessionSecret ||= randomBytes(32).toString("base64url");
state.encKey ||= randomBytes(32).toString("base64url");
if (state.allowedEmailDomains === undefined) {
  console.log("You can limit sign-ups to your school's email addresses (subdomains count, and your own email always works).");
  for (let tries = 0; state.allowedEmailDomains === undefined; tries++) {
    if (tries === 3) die("No email domains were set. Run this again.");
    const answer = await ask("Limit sign-ups to certain email domains? Type them separated by commas (for example dartmouth.edu), or press Enter for anyone: ");
    const domains = answer
      .toLowerCase()
      .split(/[\s,;]+/)
      .map((d) => d.replace(/^@/, ""))
      .filter(Boolean);
    const bad = domains.find((d) => !/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(d));
    if (bad) console.log(red(`"${bad}" doesn't look like an email domain (for example dartmouth.edu).`));
    else state.allowedEmailDomains = domains.join(",");
  }
}
saveState();
console.log(green(`Admin: ${state.adminEmail}. Sign-ups: ${state.allowedEmailDomains ? `${state.allowedEmailDomains.split(",").join(", ")} emails only` : "anyone"}. Saved in ${STATE}.`));

// ---------- 7. Build and deploy ----------
step("Building the app");
// CLOUDFLARE_ENV picks the production environment; the build writes the config that wrangler deploys.
const prodEnv = { ...cfEnv, CLOUDFLARE_ENV: CF_ENV };
if (!sh("npx", ["vite", "build"], { env: prodEnv }).ok) die("The build failed. The error is printed above.");
// The build copies local dev secrets next to the worker for `vite preview`; they must never ship.
for (const d of existsSync("dist") ? readdirSync("dist", { withFileTypes: true }) : []) if (d.isDirectory()) rmSync(join("dist", d.name, ".dev.vars"), { force: true });

step("Putting it online");
const secrets = {
  GEMINI_API_KEY: googleKey,
  EDUCATOR_ACCESS_KEY: state.educatorKey,
  ADMIN_EMAILS: state.adminEmail,
  SESSION_SECRET: state.sessionSecret,
  ENC_KEY: state.encKey,
};
if (groqKey) secrets.GROQ_API_KEY = groqKey;
if (state.allowedEmailDomains) secrets.ALLOWED_EMAIL_DOMAINS = state.allowedEmailDomains;
if (state.turnstileSecret && state.turnstileSiteKey) {
  secrets.TURNSTILE_SECRET = state.turnstileSecret;
  secrets.TURNSTILE_SITE_KEY = state.turnstileSiteKey;
}
const dir = mkdtempSync(join(tmpdir(), "mspa-"));
const secretsFile = join(dir, "secrets.json");
writeFileSync(secretsFile, JSON.stringify(secrets), { mode: 0o600 });
let deployed;
try {
  console.log("If Cloudflare asks to register a workers.dev subdomain, answer yes and pick any name (it becomes part of your link).");
  deployed = wrangler(["deploy", "--secrets-file", secretsFile], { env: prodEnv });
} finally {
  rmSync(dir, { recursive: true, force: true });
}
if (!deployed.ok) die("Cloudflare didn't accept the upload. The reason is printed above. Fix it and run npm run launch again.");
// Settings you turned off since the last launch (for example, the email domain limit) are removed online too.
for (const name of (state.sentSecrets ?? []).filter((n) => !(n in secrets))) {
  if (!wrangler(["secret", "delete", name, "--name", WORKER], { capture: true, env: cfEnv }).ok) console.log(red(`Couldn't remove ${name}. Run: npx wrangler secret delete ${name} --name ${WORKER}`));
}
state.sentSecrets = OPTIONAL_SECRETS.filter((n) => n in secrets);
saveState();

// ---------- 8. Find the link and check it works ----------
step("Checking your live app");
let url = "";
try {
  // Cloudflare's API knows the account's workers.dev name; wrangler's login is borrowed for this one call.
  const tok = wrangler(["auth", "token", "--json"], { capture: true });
  const auth = JSON.parse(tok.out.slice(tok.out.indexOf("{")));
  const headers = auth.token ? { authorization: `Bearer ${auth.token}` } : { "x-auth-email": auth.email, "x-auth-key": auth.key };
  const res = await fetch(`https://api.cloudflare.com/client/v4/accounts/${accountId}/workers/subdomain`, { headers, signal: AbortSignal.timeout(20_000) });
  const sub = (await res.json()).result?.subdomain;
  if (sub) url = `https://${WORKER}.${sub}.workers.dev`;
} catch {
  /* the link is also printed by wrangler above */
}

/** Waits for the new link to answer, then reads /api/health, where the server tests its Google key. */
async function checkHealth() {
  let last = null;
  const deadline = Date.now() + 120_000;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(`${url}/api/health`, { signal: AbortSignal.timeout(20_000) });
      const j = await r.json().catch(() => null);
      if (j) last = j;
      if (j?.ok === true && j.ai?.google === "ok") return { ok: true };
      // A missing key or one Google rejects won't fix itself. Anything else (the old version still answering,
      // a passing Google hiccup) gets more tries: the server checks Google again every minute.
      if (j?.ai?.google === "missing" || /answered 4(?!29)\d\d/.test(String(j?.ai?.detail ?? ""))) break;
    } catch {
      /* a brand-new workers.dev name can take a minute to appear */
    }
    await sleep(5000);
  }
  return { ok: false, last };
}

/** Explains a failed health check in plain words. */
function healthProblem(last) {
  if (!last) return "The link didn't answer within 2 minutes. New links can take a few minutes to appear: open it in a minute and refresh. If it still doesn't load, run npm run launch again.";
  const google = last.ai?.google;
  const detail = String(last.ai?.detail ?? last.error ?? "").replace(/\s+/g, " ").slice(0, 200);
  if (google === "missing") return "The app is online but has no Google key. Put your key in .dev.vars as GEMINI_API_KEY and run npm run launch again.";
  if (google === "error" && /could not reach google/i.test(detail)) return `The app couldn't reach Google (${detail}). Wait a few minutes, then open ${url}/api/health to check again.`;
  if (google === "error" && /per ?day|quota|429/i.test(detail)) return `Google says the key is out of today's free allowance (${detail}). Try again tomorrow or use another key: put it in .dev.vars as GEMINI_API_KEY and run npm run launch again.`;
  if (google === "error")
    return `The app couldn't use your Google key (${detail}). It worked from this computer, so it may be limited to certain websites or IP addresses: remove that limit in Google Cloud, or put a new key from https://aistudio.google.com/apikey in .dev.vars as GEMINI_API_KEY, and run npm run launch again.`;
  return `The app answered, but its AI check didn't come back (${detail || "no AI status"}). Wait a minute and open ${url}/api/health: it should show "google":"ok". If not, run npm run launch again.`;
}

if (url) console.log(`Waiting for ${url} to answer and reach Google (up to 2 minutes)...`);
const health = url ? await checkHealth() : { ok: false, last: null };

console.log(`\n${"-".repeat(64)}`);
if (health.ok) console.log(green(bold("Your app is live and the AI is connected.")));
else if (!url) console.log(bold("Uploaded. Your link is printed above by Cloudflare (it ends in .workers.dev). Open it and check that a patient answers."));
else console.log(`${bold("Uploaded, but the final check didn't pass.")}\n${healthProblem(health.last)}`);
const link = url || "https://med-student-practice-ai.<your-name>.workers.dev";
console.log(`
  Link: ${bold(url || "printed above by Cloudflare, ending in .workers.dev")}

  Make yourself the educator:
    1. Open the link and choose Sign up, then Educator.
    2. Use ${bold(state.adminEmail)} and this educator key: ${bold(state.educatorKey)}
       (share it only with other teachers)

  Students:
    Create a course, then send students its join link:
      ${bold(`${link}/join/<COURSECODE>`)}
    It signs them up straight into your course. They can also sign up
    at the link and enter the course code, or try the demo course with
    code ${bold("MEDSIM")} (an admin can close it on the Admin page).

  Big class? See "Running a class of 100" in README.md.

  Your settings and secrets are in ${STATE}. Keep it private, and keep
  it: sign-ins and saved AI keys depend on it.

  Update later: change the code and run npm run launch again.
${"-".repeat(64)}
`);
process.exit(health.ok || !url ? 0 : 1);
