# Med Student Practice AI: project summary

## The goal

Build a free, working replica of Dartmouth Geisel School of Medicine's **AI Patient Actor**: a web app where medical students practice clinical interviews with AI patients and get instant, rubric-based feedback. It had to:

- run entirely on free services so anyone can use it,
- carry the name **Med Student Practice AI** with "Heavily inspired by Dartmouth's AI Patient Actor" credit (and a "not affiliated" line),
- have human-sounding patient voices,
- look like a polished product, not AI-generated (Apple design principles, a locked style guide in `DESIGN.md`),
- pass every test and score **90+ from five independent graders**: a doctor/teacher, a medical student, a head designer, a human QA tester and an AI company CEO. The bar was 95 and was lowered to 90 on Oct 30, with no launch blockers allowed.

## It is live

**https://med-student-practice-ai.medstudentpracticeai.workers.dev**

Hosted free on Cloudflare (Workers + D1 database). Patients and grading use Google Gemini's free tier, with Groq and Cloudflare Workers AI as backups when Google is busy.

## What the app does

**Students**
- One-screen sign-up; new students land in a demo course (code MEDSIM) or the course from a join link (`/join/CODE`).
- Read a case brief with an OSCE-style door note (vitals), then interview the patient by **text**, **voice** (natural Gemini voices) or **emotive voice** (live speech-to-speech).
- Patients have faces with 9 expressions that follow the conversation, stay in character and never reveal the diagnosis.
- Type exams and tests to order them (no menu that hints at the answer). A countdown shows when there's a time limit.
- End with a diagnosis (and a SOAP note where required), then get feedback right away:
  - skill-by-skill levels with quotes from the conversation, tagged "Well done" or "Try differently";
  - whether the diagnosis was correct **and** supported by what was asked;
  - missed questions and tests;
  - tone of voice in voice modes.
- A Progress page with a "Next up" recommendation, stats and skill trends.
- Settings to download or delete their data and change their password. A privacy page explains what goes to Google.

**Educators and admins**
- Author patient profiles (with an AI drafting helper), configurations (tasks, rubric with level descriptions, time limit, test ordering), cases and courses.
- Course results with charts per skill, diagnosis accuracy, CSV export, comments, roster and reset codes, and data retention settings.
- Admin page: AI capacity guidance, today's usage, and a switch to close the public demo course.

**Safety and security**
- Sessions really end on sign-out.
- Repeated wrong passwords and mass sign-ups are blocked.
- The AI only ever sees students' first names.
- Optional bot check and email-domain limits are available.
- Secrets are stored as encrypted Cloudflare secrets.

## How it was built (Oct 25 to 30)

1. **Research and plan:** studied Dartmouth's published design (`BLUEPRINT.md`), chose a free stack.
2. **First build:** full app, demo cases, voices, avatars, tests, one-command deploy (`npm run launch`).
3. **Rename and redesign:** new name and credit, human voices, design rebuilt to `DESIGN.md`.
4. **Grading round 1:** scores 71 to 80. All findings are in `docs/review/FINDINGS_ROUND1.md`.
5. **Three fix waves**, by teams of parallel AI workers:
   - **Server:** evidence-based grading, security, privacy, capacity.
   - **Pages:** student, encounter, feedback and educator screens.
   - **Polish:** remaining fixes, plus rewritten browser tests.
6. **Deployed** on Oct 30.
7. **Grading round 2** (in progress):

| Grader | Round 1 | Round 2 | Blockers |
|---|---|---|---|
| Medical student | 79 | **91** | none |
| AI CEO | 71 | **91** | none |
| Doctor/teacher | 80 | 88 | none |
| Head designer | 79 | 87 | none |
| Human QA tester | 74 | waiting | |

## Test status (Oct 30)

- **Typecheck:** clean.
- **Unit tests:** 228/228.
- **API smoke test:** all checks passed.
- **Browser tests in real Chrome:** 17/17, including voice and emotive voice.

## What's left

- **Grading accuracy** (doctor and student): don't praise note findings that weren't obtained, cap test-ordering scores when key tests are missed, and remove contradictions.
- **Six small design fixes** (designer): results table width, course header alignment, repeated feedback filler, input heights, editor details, and test results shown twice.
- **Free-quota handling** (CEO): recognize Google's daily-limit errors, and lower the per-student daily cap.
- **QA tester:** apply their findings once their report arrives.
- **Then:** redeploy with `npm run launch`, and re-grade the graders who were below 90.

## How to update the live site

From this project folder, run `npm run launch`. It rebuilds, re-uploads and checks the site. Keep `.launch.json` safe and private: it holds the site's secrets and educator key, and sign-ins depend on it.

Recommended housekeeping:
- **Regenerate your Google key:** it was pasted in chat. Get a new one at aistudio.google.com/apikey, put it in `.dev.vars`, and run `npm run launch` again.
- **Move this folder somewhere permanent.** It currently lives in a temporary folder tied to this chat session.

## Key files

| File | What it is |
|---|---|
| `README.md` | Setup, launch, capacity, privacy, security |
| `DESIGN.md` | The style system |
| `BLUEPRINT.md` | Original research and plan |
| `docs/review/` | Grader brief and findings |
| `src/` | The app: `client` (pages), `worker` (API and AI), `shared` |
| `tests/` | All tests; `tests/screens/` has screenshots of every screen |

---

# For an AI (or developer) picking up this project

Everything needed to run, edit, test and redeploy. Secret **values** are kept only in the two private files below and are not copied here, because this summary is tracked in git and might get shared. Any AI working in this folder can read those files directly.

## Keys and secrets: where they live

| What | Where | Notes |
|---|---|---|
| Google Gemini API key | `.dev.vars` → `GEMINI_API_KEY` | Powers patients, grading and voice. Free tier from aistudio.google.com/apikey. Regenerate it (it was pasted in chat), then run `npm run launch`. |
| Groq API key (backup AI) | `.dev.vars` → `GROQ_API_KEY` | Optional. console.groq.com/keys. |
| Local educator sign-up key | `.dev.vars` → `EDUCATOR_ACCESS_KEY` | Local dev only. |
| Local admin email | `.dev.vars` → `ADMIN_EMAILS` | Local dev only. |
| **Live** educator sign-up key | `.launch.json` → `educatorKey` | Needed to create educator accounts on the live site. Share only with teachers. |
| Live admin email | `.launch.json` → `adminEmail` | The educator who signs up with it becomes admin. |
| Session signing secret | `.launch.json` → `sessionSecret` | Changing it signs everyone out. |
| Encryption key for stored AI keys | `.launch.json` → `encKey` | Changing it makes saved course and student keys unreadable. Never lose it. |
| Allowed sign-up email domains | `.launch.json` → `allowedEmailDomains` | Empty means anyone can sign up. |
| Optional bot check | `.launch.json` → `turnstileSiteKey` / `turnstileSecret` | Add by hand; see README "Security". |
| Cloudflare login | Wrangler's own login | Run `npx wrangler login` if a deploy says you're not logged in. |
| Local test educator/admin account | `tests/test-admin.mjs` | Local dev database only. `ensureTestAdmin()` creates it when missing. |

Both `.dev.vars` and `.launch.json` are gitignored and readable only by your account. Back them up privately (for example a password manager) together with this folder. `.dev.vars.example` lists the variable names.

## Cloudflare deployment facts

| Item | Value |
|---|---|
| Live URL | https://med-student-practice-ai.medstudentpracticeai.workers.dev |
| Worker name | `med-student-practice-ai` |
| workers.dev subdomain | `medstudentpracticeai` |
| D1 database | `med-student-practice-ai`, id `7bf771c4-3996-43e6-b942-dba6d595d9cd` |
| Production config | `wrangler.jsonc` → `env.production` |

The production config adds the Workers AI binding and a daily 03:00 UTC cron for data retention. The top-level config is local dev and needs no Cloudflare login.

- **Deploy:** `npm run launch`. It builds with `CLOUDFLARE_ENV=production`, uploads the secrets from `.launch.json` and `.dev.vars`, then polls `/api/health`. Never run `wrangler deploy` by hand.
- **Health check:** `GET /api/health` should return `{"ok":true,"ai":{"google":"ok"}}`.

## Run it locally

```bash
npm install
npm run dev
```

The app is then at http://127.0.0.1:5173. It needs Node 20+ (this machine has Node 24); the database tests need Node 22+. The schema creates and migrates itself, and demo content seeds itself (`SEED_VERSION` in `src/worker/seed.ts`; bump it to re-seed system rows).

## Tests

| Command | What it checks |
|---|---|
| `npm run typecheck` | Client and worker types |
| `npx vitest run` | 228 unit tests (`tests/*.test.ts`) |
| `node tests/smoke.mjs` | API walkthrough. Uses the live AI. Don't run it at the same time as e2e: it briefly closes the demo course. |
| `node tests/e2e.mjs [--only=text,voice,emotive,educator,...]` | Real Chrome, with a fake microphone that plays `tests/fixtures/doctor.wav`. Screenshots go to `tests/screens/`. |
| `node tests/voice-check.mjs tests/fixtures/doctor.wav` | Live voice, speech-to-text and voice analysis |
| `node tests/tts-check.mjs` | Natural voice for every demo patient |
| `node tests/grader-check.mjs` | Grading calibration: a strong interviewer vs. a guesser |
| `node tests/fidelity.mjs` | Patient realism eval. Many AI calls. |

## Gotchas learned the hard way

- **Free Gemini quotas are per model per day.** Full Flash allows about 20 requests a day, so grading uses Flash-Lite first. When Google says a model is out for the day, the router skips it. Known bug to fix: it reads only the first 300 characters of Google's error, which can miss the "per day" marker.
- **Cloudflare free plan:** 10 ms CPU per request and 50 subrequests. Long voice clips go through Google's Files API instead of base64. Keep Worker code light.
- **Voice e2e tests need real audio.** Inside a command sandbox, run them with the sandbox disabled. Headless Chrome on a Mac never answers a real microphone request, which is why the tests use a fake mic stream.
- **zsh:** write `${m}:generateContent`, not `$m:generateContent`. zsh treats `:g` as a modifier.
- **Local requests skip per-IP limits.** Without the `CF-Connecting-IP` header they aren't IP-limited, so tests don't lock each other out. Production is always limited.

## Rules the owner set

- Name **Med Student Practice AI**. Keep the credit "Heavily inspired by Dartmouth's AI Patient Actor" and "Independent project, not affiliated with or endorsed by Dartmouth College." Never call this app "AI Patient Actor".
- **Design:** follow `DESIGN.md`:
  - a single forest-green accent on white or black;
  - Newsreader headings with system text;
  - no gradients, beige, purple or emoji icons;
  - no em dashes and sentence case in copy;
  - left-aligned layouts with generous space.
- **Free hosting only.** Ship with `npm run launch`.
- **Done means:** all five graders score 90+ (doctor/teacher, student, head designer, QA tester, AI CEO), none lists a launch blocker, and all tests pass. The grader brief and output format are in `docs/review/REVIEW_BRIEF.md`. Put graders' nice-to-haves in `docs/review/LATER.md`.

## Code map

| Path | What it holds |
|---|---|
| `src/worker/index.ts` | API entry: Hono app, plus the cron cleanup |
| `src/worker/auth.ts`, `limits.ts`, `account.ts` | Sign-in, sessions, throttling, export and delete |
| `src/worker/routes/` | `encounters.ts` (chat, orders, end, grading, voice routes), `courses.ts`, `library.ts`, `me.ts` (admin, capacity) |
| `src/worker/ai/` | `router.ts` (model fallback and cooldowns), `prompts.ts` (patient, grader, assistant), `grade.ts` (feedback building and checks), `audio.ts` (TTS, Live, speech-to-text, voice analysis), `mock.ts` |
| `src/worker/seed.ts` | Demo cases and configurations |
| `src/worker/db.ts` | Schema and migrations |
| `src/client/pages/` | `Public.tsx` (landing, sign-up, sign-in, join), `Student.tsx`, `Encounter.tsx`, `Feedback.tsx`, `Privacy.tsx`, `educator/*` |
| `src/client/ui.tsx`, `components/`, `styles.css` | Shared components and the design system |
| `src/client/voice/` | Microphone, speech, natural voice, Live voice |
| `src/shared/` | Types, defaults, test catalogue, languages |
| `docs/review/` | Grader brief and findings; `HANDOFF.md` is an earlier handoff note |
