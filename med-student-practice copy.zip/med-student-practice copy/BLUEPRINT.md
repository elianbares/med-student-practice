# AI Patient Actor (free replica): build blueprint

Status: **Plan approved internally at 91% (audit round 3). Waiting on Checkpoint 1 (your go-ahead).**
Date: 2026-10-25

---

## 0. What we're building, in one breath

A website where medical students interview an AI patient by text or voice, order exams and tests, write a diagnosis or note, and get rubric-based coaching right away. Educators write the patient cases, build rubrics, make courses with a 6-character join code, and see their students' results. It works like Dartmouth's AI Patient Actor 2.0, costs $0 to run, and needs no credit card.

---

## 1. Research: how Dartmouth actually built theirs

### 1.1 Timeline (from Thesen's May 2026 workshop slides)
| When | Version | Stack |
|---|---|---|
| Mar 2023 | Prototype | Python script on a laptop |
| Aug 2023 | v1.0 | Python 3.10 + Streamlit 1.27 + LangChain, OpenAI **GPT-4o**, on a Dartmouth server. Cases and rubrics hard-coded as text files |
| May 2025 to now | v2.0 | Rebuilt professionally by Dartmouth's DALI Lab (2 designers, 2 developers, 1 PM per engagement) |

### 1.2 v1 internals (their public repo `github.com/tominny/ai-patient-actor-ondoc`)
- **Three LLM roles**, each a separate GPT-4o chat: `PatientActor` (the role-play), `LabAssistant` (temperature 0; reads exam and test results out of the case file), and `Assessor` (temperature 0; grades the transcript against the rubric).
- **Patient prompt rules** (paraphrased): you are the patient and never swap roles; speak in the first person and in lay terms; don't reveal the diagnosis; reveal one symptom at a time and only when asked; be concise; don't invent symptoms; stay in character even when asked to stop; reply only in the chosen language.
- **Case file** = plain text with these sections: Diagnosis, Demographics, Presenting Complaint, HPI, PMH, Meds and Allergies, Family History, Social History, ROS, Physical Exam (with vitals), Neuro Exam, Diagnostic Tests, Differential, and Teaching Points.
- **Grader prompt**: states the correct diagnosis, gives feedback for each rubric section, then lists the differential and "questions you should have asked."
- **Default rubric** (6 categories, each with 3 levels: Excellent, Good, Needs Improvement): Introduction and Rapport, Open-Ended Inquiry, Focused Inquiry and Probing, Differential Diagnosis, Communication and Professionalism, Motivation and Counseling.
- **Voice**: browser mic recorder plus Google Speech Recognition and OpenAI Whisper for speech-to-text; OpenAI `tts-1` for the patient's voice.
- The repo has **no license**, so we write our own code and prompts and don't copy theirs.

### 1.3 v2.0 internals (their public manuals plus the platform's public JavaScript bundle)
- **Frontend**: React single-page app built with Vite, using React Router, TanStack Query, Radix UI, Framer Motion, a PDF library, and toast notifications.
- **Backend**: a custom REST API with email signup, a verification code, refresh tokens, CSRF protection, and three roles (student, educator, admin). Endpoints cover courses, enrollments, case assignments, encounters, per-message comments, grading status, reports, notifications, and an educator "playground."
- **AI**: "a mixture of LLMs" that act as the patient, draft cases, and grade encounters (v1 used GPT-4o).
- **Emotive voice and prosody**: **Hume AI EVI** (the bundle stores a `humeChatId` and has `start-speech-session` and `end-speech-session` endpoints). Voice works in English and Spanish with 26 voices, a 30-minute cap, and a mute button that pauses for up to 2 minutes.
- **Video avatars**: **Tavus** (`start-tavus-session`, "Replica"), shown in the slides as "Interactive AI Avatars."
- **Patient Profile sections**: Demographics, Speech Voice, Diagnosis, Chief Complaint, HPI, PMH, Meds and Allergies, Family History, Social and Habits, ROS, Personality, Communication, Other, and **Tests** (each test has a category, an expected value, and an "expected to be ordered" flag).
- **AI Profile Assistant** drafts a full profile from 4 inputs: diagnosis, encounter goal, Big Five personality traits (low/medium/high), and communication notes.
- **Configuration**, part visible to students: name, context and goal, encounter tasks (shown as a checklist), post-encounter tasks. Part hidden from students: diagnosis type (Diagnosis or No Diagnosis), role-playing instructions (for example "you're the parent" or "you're the dog's owner"), feedback-style instructions, notes feedback (for a SOAP note or reflection, with its own criteria), and rubric categories (name plus description, each scored separately). A "Populate Rubric" button copies categories from public configurations.
- **Case** = 1 profile plus 1 or more configurations. A **Course** has a name, description, banner, assigned cases, and a 6-character code; enrollment can be opened, closed, or the code regenerated.
- **Student flow**: join a course with the code, then open a case card (it shows the chief complaint), then pick text or voice and a language (52 available), then read the profile and tasks, then Start. The sidebar has Tasks, Exams and Tests (vitals, labs, imaging), and Notepad. The student enters a diagnosis and ends the encounter to get rubric scores with narrative coaching, plus prosody analysis for voice. Retries are unlimited.
- **Reports**: an individual student progress report over time and a course performance report as a PDF.
- **Quality testing**: a "virtual clinician" bot interviews the virtual patient, then experts score content fidelity (facts, staying in character, resisting leading questions, saying "I don't know") and personality fidelity (Big Five and interpersonal style).

---

## 2. Feature parity matrix: theirs, ours, and the priority

P0 = must work at launch. P1 = ships the same day. P2 = enhancement behind a switch; if it fails, the product still works.

| Dartmouth feature | Our free equivalent | Pri |
|---|---|---|
| Student and educator accounts, roles | Email + password, signed cookie session, roles. Educators sign up with an **Educator Access Key** (the same gating Dartmouth uses) | P0 |
| Email verification and reset | No email needed: the educator issues a one-time reset code from the roster, and the admin does the same for educators | P1 |
| Course + 6-char code, open/close/regenerate | Same | P0 |
| Library: Profiles, Configurations, Cases | Same three tabs, same fields | P0 |
| AI Profile Assistant (4 inputs) | Same, drafts with the free LLM and fills the editor | P0 |
| Profile editor with completeness checks | Sidebar sections with green check marks | P0 |
| Voice library and preview | Each voice has a gender, age, pitch, and rate, mapped onto the device's built-in voices. Emotive mode picks from Gemini's HD voices | P0 / P2 |
| Configuration builder + rubric + Populate Rubric | Same. Ships with public starter configs (OSCE history, Breaking Bad News, Counseling, Differential Dx) written by us | P0 |
| Text encounter | Streaming chat with the patient | P0 |
| Tasks checklist | Same (the student checks items off) | P0 |
| Exams and Tests ordering | **Deterministic**: results come straight from the educator's authored values, with no AI involved, so nothing is hallucinated. Unlisted tests return "not available for this case." Every order is logged for grading | P0 |
| Notepad | Same, autosaved | P0 |
| Diagnosis + End Encounter, then feedback | Same. The grader returns JSON scored against the rubric with quoted evidence | P0 |
| Notes feedback (SOAP) | Same | P0 |
| Retry unlimited, history | Same | P0 |
| 52 languages | Same list. The AI replies in the chosen language, and speech recognition and voice use that language's code | P0 |
| Voice-to-voice | **Standard voice**: the browser's built-in speech recognition and voice (free, no limits). Firefox falls back to free Whisper on Cloudflare | P0 |
| **Emotive** voice (Hume EVI) | **Gemini Live native audio** with affective dialog, using short-lived tokens. Free tier allows 3 simultaneous sessions per key, and anyone over that drops to standard voice automatically | P2 |
| Prosody analysis (Hume) | (a) In-browser acoustic metrics: pace, pauses, pitch variation, loudness, talk-time share, filler words (always on). (b) An optional AI listen-back of the student's audio by a Gemini audio model for warmth, calm, and empathy | P1 (a) / P2 (b) |
| 30-min voice cap, 2-min mute pause | Same | P0 |
| Tavus video avatar | Animated SVG patient face with emotion states and a moving mouth while speaking (free) | P1 |
| Educator per-message comments, notifications | Same | P1 |
| Student progress report, course performance PDF | Same, generated with print-to-PDF styling (no extra library) | P1 |
| Educator playground | "Test this case" button that runs an encounter outside any course | P0 |
| Admin (prompts, voices, educators) | Minimal admin page: educators list, platform usage per AI provider, keys health check | P1 |
| Co-instructors and workspaces | Add co-instructors to a course by email | P2 |

---

## 3. The simplified free stack (exact)

**One vendor hosts everything: Cloudflare (free plan, no card). One free AI key: Google AI Studio (no card). Everything else runs in the student's browser.**

| Layer | Choice | Why it's the simplest thing that fully works |
|---|---|---|
| Hosting + API | **Cloudflare Workers** (free: 100k API requests/day; static files are free and unlimited) serving both the React app and `/api/*` | One deploy, never sleeps (unlike Supabase), no server to manage |
| Database | **Cloudflare D1** (SQLite; free: 500 MB per DB, 5 GB total) | Real SQL, built in, no separate signup |
| API framework | **Hono** (tiny router made for Workers) | Plain functions, no framework overhead |
| Frontend | **React + TypeScript + Vite** (`@cloudflare/vite-plugin`), React Router, plain CSS | Same family as Dartmouth's v2. Plain CSS means no UI-kit setup |
| AI: patient, grader, assistant | **Provider router with automatic fallback**: (1) the course's own free key, if the educator added one, (2) the platform's Google AI Studio key, (3) optional Groq key, (4) **Cloudflare Workers AI** (built in, no key, 10k "neurons"/day) | If any provider runs out or blocks, the next one answers. Works with zero keys on Workers AI alone |
| Models | Patient: **Gemma 4 31B** on Gemini API, then Gemini Flash-Lite, then Groq, then Workers AI Gemma 4 26B-A4B. Grader: **newest Gemini Flash**, then Gemma 4 31B, and so on. Exact IDs are read live from `ListModels` and stored in config, never hard-coded | Free models change monthly (Gemini 3.8 Flash, 3.5 Flash-Lite, and Gemma 4 are current as of 2026-10-22) |
| Speech (standard) | Browser **Web Speech API**: SpeechRecognition (Chrome, Edge, Safari) + speechSynthesis (all browsers). Firefox speech-to-text goes to Workers AI `whisper-large-v3-turbo` | $0 and unlimited for the main path |
| Speech (emotive, P2) | **Gemini Live API** (native audio, affective dialog). The Worker mints a 1-use ephemeral token with the patient prompt locked server-side (`liveConnectConstraints`), so the browser never sees the case | Closest free match to Hume EVI |
| Prosody | Web Audio API metrics in the browser + optional Gemini audio analysis | No paid voice-analytics vendor |
| PDFs | Print stylesheet + browser "Save as PDF" | No library |
| Auth crypto | PBKDF2 hashing in the **browser** (keeps the Worker under its 10 ms CPU limit), then a salted SHA-256 on the server, plus an HMAC-signed HttpOnly cookie. Per-course AI keys are stored encrypted (AES-GCM) | No auth vendor, no email vendor |
| Tests | Vitest (unit + API), a scripted smoke test, a "virtual clinician" fidelity test (like Dartmouth's), and a manual run in the built-in browser | |

**What we cut and why:**
- Python, Streamlit, and LangChain: replaced by the same browser + Worker codebase.
- OpenAI, Hume, and Tavus: all paid. Replaced by Gemini free tier, browser speech, and an SVG avatar.
- Email service: needs a paid or owned domain. Replaced by reset codes.
- Image storage (R2 needs a card on file): banners are resized in the browser to about 80 KB and stored in D1, or chosen from presets.
- TanStack Query, Radix, Framer Motion: a few small hooks and CSS transitions do the same job.

---

## 4. Architecture

```
 Student / Educator browser
 ┌───────────────────────────────────────────────────────────────┐
 │ React app                                                     │
 │  • Chat UI + Tasks / Exams & Tests / Notepad sidebar          │
 │  • Standard voice: SpeechRecognition ⇄ speechSynthesis        │
 │  • Emotive voice (P2): WebSocket ⇄ Gemini Live (token only)   │
 │  • Prosody metrics (Web Audio)   • SVG avatar   • Print-PDF   │
 └──────────────┬────────────────────────────────┬───────────────┘
                │ HTTPS /api (cookie)            │ wss (ephemeral token)
 ┌──────────────▼──────────────────────┐   ┌─────▼───────────────────┐
 │ Cloudflare Worker (Hono)            │   │ Gemini Live API         │
 │  auth · library · courses · encount │   │ (system prompt locked   │
 │  AI router ──► Gemini API (key)     │   │  server-side via token) │
 │            ──► Groq (optional key)  │   └─────────────────────────┘
 │            ──► Workers AI (no key)  │
 │  D1 (SQLite)  · secrets · usage log │
 └─────────────────────────────────────┘
```

**Key flows**
1. **Patient turn (text or standard voice).** The browser sends `POST /api/encounters/:id/message`. The Worker loads the profile and configuration, builds the patient prompt (the hidden fields stay on the server), and streams the reply through the AI router as server-sent events. The browser shows it, strips the `[emotion]` tag to drive the avatar, and speaks it sentence by sentence.
2. **Order a test.** `POST /api/encounters/:id/orders {testId}` returns the authored result and logs it. No AI is involved.
3. **End encounter.** `POST /end {diagnosis, note, prosodyMetrics}` triggers one grader call with a JSON schema, temperature 0, validation, one retry, and a narrative fallback. Feedback is saved and the report renders.
4. **Emotive voice (P2).** `POST /live-token` makes the Worker mint a 1-use token locked to the model, voice, and prompt. The browser opens a WebSocket, streams 16 kHz PCM up and plays 24 kHz audio back, saves both transcriptions to the encounter, and reconnects every ~10 minutes with session resumption. On any error or limit it switches to standard voice without losing the conversation.
5. **Standard-voice turn-taking.** The mic pauses while the patient is speaking, so the patient's own voice isn't transcribed as the doctor. Speech is queued one sentence at a time, which avoids Chrome's cutoff on long utterances. Audio starts on a click, which iOS requires. If SpeechRecognition throws repeated errors on any browser, it switches to push-to-talk with Whisper.

---

## 5. Data model (D1)

```
users(id, email UNIQUE, name, role[student|educator|admin], pw_hash, pw_salt, ai_key_enc?, created_at)
profiles(id, owner_id, name, data JSON, is_public, created_at, updated_at)
configurations(id, owner_id, name, data JSON, is_public, created_at, updated_at)
cases(id, owner_id, name, description, profile_id, created_at)
case_configs(case_id, config_id)
courses(id, owner_id, name, description, banner, code UNIQUE, enrollment_open, archived, ai_key_enc?, created_at)
course_staff(course_id, user_id)                       -- co-instructors (P2)
assignments(id, course_id, case_id, config_id, position)
enrollments(course_id, user_id, joined_at)
encounters(id, user_id, assignment_id?, case_id, config_id, mode[text|voice|emotive], language,
           status[active|grading|done], messages JSON, orders JSON, notepad, tasks_done JSON,
           diagnosis, note, feedback JSON, prosody JSON, started_at, ended_at, duration_s)
comments(id, encounter_id, message_idx, author_id, body, created_at)
notifications(id, user_id, kind, ref_id, read, created_at)
reset_codes(code_hash, user_id, expires_at)
usage(day, provider, model, task, requests, tokens_in, tokens_out, errors_429)
```
Profile and configuration JSON follow the Dartmouth sections listed in §1.3 exactly. Messages are stored at the end of each turn (one write), so a 20-turn encounter is about 25 writes, well inside free limits.

---

## 6. API surface

`/api/auth`: signup, signin, signout, me, reset (with code). `/api/library`: CRUD for profiles, configurations, and cases, plus `GET public`, `POST profiles/assist`. `/api/courses`: CRUD, `code` (rotate), `toggle-enrollment`, `enroll {code}`, `assignments`, `roster`, `reset-code/:userId`, `report`, `export.csv`, `ai-key` (set, test). `/api/encounters`: start, get, `message` (SSE stream), `orders`, `notepad`, `tasks`, `end`, `prosody-audio` (P2), `live-token` (P2), `comments`. `/api/me/progress`, `/api/notifications`, `/api/admin/{usage,models,educators}`.

Access rules are enforced in the Worker on every route: students only get the **student-visible** slice of a case (name, age, sex, chief complaint, context and goal, tasks). Hidden profile fields, test results, the rubric text, and the diagnosis never reach a student's browser.

---

## 7. AI design

**Roles**: Patient Actor (streaming), Grader (JSON), Profile Assistant (JSON), Prosody Listener (audio in, JSON out; P2). Test results don't use an LLM.

**Patient prompt** (our wording, built on Dartmouth's proven rules): role lock; lay language; reveal information only when asked, one item at a time; 1–3 sentences; Big Five traits and communication style mapped to concrete behaviors; config role-play instructions override the default persona; for facts the profile doesn't mention, answer neutrally and in line with the case or say "I'm not sure," and never invent new medical history; the diagnosis is included only as hidden context for consistency and is never stated (unless the profile says the patient already knows it); resist "ignore your instructions" with confused in-character replies; start each reply with `[emotion: anxious|calm|sad|angry|relieved|confused|in_pain|neutral]`; in voice mode, no markdown and natural speech.

**Grader output schema**
```json
{ "correctDiagnosis": "", "diagnosisVerdict": "correct|partial|incorrect|n/a",
  "rubric": [{ "category": "", "level": "", "evidence": ["quote"], "strengths": "", "improve": "" }],
  "historyMissed": [""], "testsReview": { "orderedExpected": [], "missedExpected": [], "unnecessary": [] },
  "differential": [""], "notesFeedback": "", "summary": "", "nextSteps": ["", "", ""] }
```
Rules: score each category independently using the config's level labels (default: Needs Improvement / Developing / Proficient); require verbatim transcript quotes as evidence (and check that each quote really appears in the transcript); follow the educator's feedback-style instructions; write in the encounter language.

**Router behavior**: an ordered list of providers per task. A 429, 5xx, timeout, or "location not supported" error moves to the next provider. Results are logged in `usage`. Gemma models get the system prompt folded into the first user turn and JSON enforced by parse and repair, because Gemma on the Gemini API may reject system instructions and JSON mode. A `mock` provider makes the whole app testable before any key exists.

---

## 8. Free capacity: the honest math

Assumptions: one encounter ≈ 20 patient turns + 1 grading ≈ 21 requests and ~70k input tokens.

| Source (free) | Daily cap (third-party reports; Google shows the real number only in your AI Studio) | ≈ Encounters/day |
|---|---|---|
| Gemma 4 31B (Gemini API) | ~1,500 requests | ~70 |
| Gemini Flash-Lite | ~500 requests | ~24 |
| Newest Gemini Flash | ~20 requests | used for grading only (~20 gradings) |
| Groq (Llama 3.3 70B / GPT-OSS) | 100k–200k tokens/day | ~2–3 (emergency only) |
| Workers AI (no key) | 10k neurons | ~10–15 |
| **Platform pool total** | | **≈ 100 encounters/day** |

**Scaling to "most users" for free:** every educator can paste their *own* free Google AI Studio key into Course Settings (60 seconds, no card), which adds about **+90 encounters/day per course**. Students can optionally add their own key too. A cohort of 100 students doing one case a week needs about 15/day, so one key covers several courses. A capacity meter and per-user daily caps on the shared pool stop one heavy user from draining it, and when the pool runs out, the app says so and shows the one-minute "add a free key" guide.

Live-class caution: free keys allow only a few requests per minute. For 30 students at once, use course keys and groups of 3 (Dartmouth did this too).

---

## 9. Build plan: one day, with checkpoints where we pause for you

| Hours | Work | Done when |
|---|---|---|
| 0–1 | Scaffold (Vite + React + Worker + D1), schema, auth, roles, mock AI | Sign up and sign in work locally |
| 1–3 | Educator Library: profile editor + AI Assistant, configuration builder + rubric, case wizard, courses + codes | An educator can build a full case and a course |
| 3–5 | Student flow: join, case cards, pre-brief, **text encounter (streaming)**, Tasks / Exams and Tests / Notepad, timer | **Checkpoint 2:** you interview a real AI patient locally (needs your free Google key) |
| 5–6 | End encounter, grader, feedback report, retry, history, print-PDF | Feedback is evidence-backed |
| 6–7.5 | Standard voice (speech-to-text and voice, chunked speech, 30-min cap, mute), avatar + emotions, prosody metrics, Whisper fallback | **Checkpoint 3:** you try voice with your mic |
| 7.5–8.5 | P2: Emotive voice (Gemini Live) + AI prosody listen-back, both behind switches with automatic fallback | Falls back cleanly when it hits limits |
| 8.5–9.5 | Educator reports, comments, notifications, progress report, CSV, course PDF | |
| 9.5–10.5 | Seeds (public configs + 4 demo cases + demo course), 52 languages, course and student keys, capacity meter, admin page | |
| 10.5–12 | Tests, virtual-clinician fidelity run, accessibility and mobile pass | **Checkpoint 4:** you create a free Cloudflare account; we deploy. **Checkpoint 5:** live URL handover |

If time runs short, P2 items get cut first. The P0 core never depends on them.

---

## 10. Verification plan

1. **Unit tests**: prompt builders (hidden fields really hidden), the router's fallback on a faked 429, the grader JSON check and repair, the evidence-quote check, password hashing, cookie signing, course codes.
2. **Access-control tests**: a student calling educator or hidden endpoints gets 403, and test results return only for ordered tests on their own encounter.
3. **API smoke script** (runs against local D1 with the mock AI): educator builds a case, creates a course, a student joins, chats, orders tests, ends the encounter, gets feedback, and the educator sees the report.
4. **Fidelity test with real AI** (Dartmouth's method in small form): a scripted "virtual clinician" interviews 2 demo patients 3 times each, then an AI judge scores leakage of the diagnosis, invented history, staying in character, consistency, and resistance to leading questions. Target ≥ 0.9.
5. **Browser test** in the built-in browser: every page, mobile width, and voice output. You test mic input at Checkpoint 3.

---

## 11. What you'll need to do (only you can)

1. **Google AI Studio key** (free, no card): aistudio.google.com/apikey. You paste it yourself into a terminal prompt or the app's settings, so I never handle it. Needed at Checkpoint 2.
2. **Cloudflare account** (free, no card): dash.cloudflare.com/sign-up, then click "Allow" when `wrangler login` opens your browser. Needed at Checkpoint 4.
3. Optional: Groq key (free) for an extra backup brain.

Privacy note: on Gemini's free tier, Google may use prompts to improve its products. Cases are fictional, but student transcripts pass through it, so the signup consent screen says so. Course keys from a paid Google project avoid this.

---

## 12. Repo layout

```
ai-patient-actor/
  package.json  vite.config.ts  wrangler.jsonc  tsconfig.json  README.md
  migrations/0001_init.sql
  seed/public-configs.json  seed/demo-cases.json
  src/shared/   types.ts  languages.ts  schemas.ts
  src/worker/   index.ts  auth.ts  crypto.ts  access.ts
                routes/{auth,library,courses,encounters,admin}.ts
                ai/{router,gemini,openaiCompat,workersAi,mock,live}.ts
                ai/prompts/{actor,grader,assistant,prosody}.ts
  src/client/   main.tsx  App.tsx  api.ts  styles.css
                pages/{auth,student,educator,admin}/…
                components/{Avatar,Chat,Sidebar,Timer,FeedbackReport,ProfileEditor,RubricBuilder}.tsx
                voice/{browserStt,browserTts,whisperFallback,liveSession,prosodyMetrics}.ts
  tests/  unit/*.test.ts  smoke.mjs  fidelity.mjs
```

---

## 13. Audit log (grading until ≥ 90%)

Weights: Parity with Dartmouth 25% · Truly $0 / no card 20% · Technical feasibility (each piece verified) 20% · Capacity for many users 15% · Buildable in 1 day 10% · Security and privacy 10%.

### Round 1: "copy Dartmouth onto free services" draft → **61% (FAIL)**
Draft: Firebase (hosting, auth, database) + one shared Gemini key + Gemini Live as the only voice + AI-generated exam results + email verification.
| Problem found | Evidence |
|---|---|
| Firebase's free plan has no server functions, so the AI key would sit in the browser | Cloud Functions need the paid Blaze plan |
| One shared free key ≈ 20–70 encounters/day total, which fails "most users" | §8 math |
| Gemini Live free tier = **3 simultaneous sessions** and ~10-min connections | Google rate-limit table; Firebase Live API limits page |
| AI-generated test results can be invented, which breaks Dartmouth's "professor in the loop" rule | v1 used an LLM; v2 moved to authored test values |
| Free email sending needs an owned domain | Resend and Brevo require domain or sender verification |
| Scores: Parity 85 · Free 60 · Feasibility 60 · Capacity 30 · 1-day 55 · Security 60 | |

### Round 2: switched to Cloudflare, provider pool, browser voice, authored test results → **85% (FAIL)**
Fixed everything above. New problems found:
| Problem found | Fix applied in Round 3 |
|---|---|
| Worker free CPU = **10 ms/request**, and server-side password hashing (PBKDF2) would exceed it | Hash in the browser; the server does one cheap SHA-256 |
| Gemma on the Gemini API may reject system prompts and JSON mode | Router folds the system prompt into the first turn and repairs JSON |
| Model names change monthly (3.8 Flash, Gemma 4…), so hard-coded IDs would break | `ListModels` discovery + config + a keys health-check page |
| Gemini blocks some regions, and Workers run at the user's nearest edge | Smart Placement + automatic fallback to Workers AI |
| Firefox has no SpeechRecognition | Whisper on Workers AI as fallback |
| Live voice and audio prosody are complex for a 1-day build | Moved to P2 behind switches with automatic fallback; the core never depends on them |
| Nothing testable until you provide a key | Built-in mock provider, so 90% of the app is tested before any key |
| Uploading prosody audio might exceed the 10 ms CPU limit | The Worker streams the browser's pre-encoded body without parsing it, with a size cap |
| R2 image storage needs a card on file | Banners compressed into D1, or presets |
| Scores: Parity 88 · Free 95 · Feasibility 82 · Capacity 75 · 1-day 75 · Security 85 | |

### Round 3: final plan (this document) → **91% (PASS)**
| Criterion | Score | Remaining risk |
|---|---|---|
| Parity | 92 | Video avatar is replaced by an SVG face; emotive voice is P2 |
| Truly $0 | 97 | Free tiers can change; fallback chain + course keys hedge it |
| Feasibility | 92 | Every component is mature and documented; only Live API is complex, and it's optional |
| Capacity | 85 | Exact Google quotas show only in your AI Studio, so we confirm at Checkpoint 2 |
| 1-day build | 88 | P2 cut-line protects the schedule |
| Security and privacy | 90 | Hidden case data stays server-side; free-tier data-use is disclosed |
| **Weighted total** | **91.4%** | |

### Round 4: re-check of the written plan → **91% (PASS, unchanged)**
I re-read every factual claim against its source. Limits confirmed from official pages: Workers 100k requests/day and 10 ms CPU, unlimited static assets, D1 500 MB/5 GB, Workers AI 10k neurons/day and its model list (Gemma 4 26B-A4B, Whisper large-v3-turbo), and Gemini ephemeral-token fields. One gap found and fixed: in standard voice, the mic could hear the patient's own speech and transcribe it as the doctor. Fix: half-duplex turn-taking (§4 flow 5). Two claims stay labeled as estimates because Google doesn't publish them: Gemini per-model daily caps and Live API concurrency.

**What 91% means:** the core product (accounts, courses, case authoring, text and standard-voice encounters, exams and tests, rubric feedback, reports) should work at $0 with no card. My estimate is ~93% for that core on its own. The emotive-voice add-on is ~75%, but it falls back automatically, so it can't break the core. These are my estimates, not measurements. They become measured facts at Checkpoints 2–4.

---

## 14. Defaults I'll use unless you say otherwise
1. Full Dartmouth parity: accounts, educator library, courses with codes, educator reports.
2. Voice: standard browser voice for everyone, plus emotive voice when capacity allows.
3. AI capacity: shared free pool + educators can add their own free key per course.
4. Built here first, then deployed to your free Cloudflare account.

## 15. Sources
- Dartmouth AI Patient Actor platform page: https://geiselmed.dartmouth.edu/thesen/patient-actor-app/
- Educator Manual (Apr 2026): https://geiselmed.dartmouth.edu/thesen/wp-content/uploads/sites/111/2026/04/AI_Patient_Actor_Educator_Manual_vApril2026.pdf
- Student Guide (Jan 2026): https://geiselmed.dartmouth.edu/thesen/wp-content/uploads/sites/111/2026/01/AI_Patient_Actor_Student_Guide.pdf
- Thesen, Alilonu & Stone 2024, Med Sci Educ: https://doi.org/10.1007/s40670-024-02250-2
- Thesen et al. 2025, Med Sci Educ: https://doi.org/10.1007/s40670-025-02473-x
- Workshop slides (May 2026): https://dh.cloud-cme.com/assets/dh/PDF/2026/5-21-2026%20Academy%20AI%20Patient%20Actor%20Slides.pdf
- v1 code: https://github.com/tominny/ai-patient-actor-ondoc
- Dartmouth news (Jan 2024): https://home.dartmouth.edu/news/2024/01/geisel-professor-harnesses-ai-act-patient
- Gemini API pricing / free tier (updated 2026-10-22): https://ai.google.dev/gemini-api/docs/pricing
- Gemini rate limits (shown per project in AI Studio): https://ai.google.dev/gemini-api/docs/rate-limits
- Gemini ephemeral tokens: https://ai.google.dev/gemini-api/docs/ephemeral-tokens
- Firebase Live API limits: https://firebase.google.com/docs/ai-logic/live-api/limits-and-specs
- Cloudflare Workers pricing and limits: https://developers.cloudflare.com/workers/platform/pricing/
- Cloudflare D1 limits: https://developers.cloudflare.com/d1/platform/limits/
- Cloudflare Workers AI models: https://developers.cloudflare.com/workers-ai/models/
- Groq free tier figures (third-party): https://openrouter.ai/blog/tutorials/free-llm-apis-compared/
