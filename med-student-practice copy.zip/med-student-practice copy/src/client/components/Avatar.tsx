// Illustrated patient faces from DiceBear "Avataaars" (art by Pablo Stanley, free for personal and
// commercial use). The face follows the patient's emotion and the mouth moves while they speak.
import { useEffect, useMemo, useState } from "react";
import { createAvatar } from "@dicebear/core";
import * as avataaars from "@dicebear/avataaars";
import type { PatientLook } from "../../shared/types";

type Face = { eyes: string; eyebrows: string; mouth: string };

const FACES: Record<string, Face> = {
  neutral: { eyes: "default", eyebrows: "defaultNatural", mouth: "default" },
  calm: { eyes: "default", eyebrows: "defaultNatural", mouth: "twinkle" },
  relieved: { eyes: "happy", eyebrows: "raisedExcitedNatural", mouth: "smile" },
  anxious: { eyes: "surprised", eyebrows: "sadConcernedNatural", mouth: "concerned" },
  sad: { eyes: "default", eyebrows: "sadConcerned", mouth: "sad" },
  angry: { eyes: "squint", eyebrows: "angryNatural", mouth: "serious" },
  confused: { eyes: "side", eyebrows: "upDownNatural", mouth: "disbelief" },
  in_pain: { eyes: "squint", eyebrows: "sadConcernedNatural", mouth: "grimace" },
  embarrassed: { eyes: "side", eyebrows: "flatNatural", mouth: "twinkle" },
};

export const EMOTION_LABEL: Record<string, string> = {
  neutral: "Neutral",
  calm: "Calm",
  relieved: "Relieved",
  anxious: "Anxious",
  sad: "Sad",
  angry: "Frustrated",
  confused: "Confused",
  in_pain: "In pain",
  embarrassed: "Embarrassed",
};

const SKINS = ["ffdbb4", "edb98a", "d08b5b", "ae5d29", "614335"];
const HAIRS = ["2c1b18", "4a312c", "724133", "a55728", "b58143", "d6b370"];
const FEMALE_TOPS = ["bob", "bun", "curly", "curvy", "longButNotTooLong", "straight01", "straightAndStrand", "bigHair", "froBand"];
const MALE_TOPS = ["shortFlat", "shortRound", "shortWaved", "shortCurly", "theCaesar", "theCaesarAndSidePart", "frizzle", "dreads01"];
const NEUTRAL_TOPS = ["shaggy", "shortCurly", "bob", "fro"];
const CLOTHES = ["collarAndSweater", "shirtCrewNeck", "shirtScoopNeck", "blazerAndSweater", "shirtVNeck"];
const CLOTHES_COLORS = ["3c4f5c", "5199e4", "25557c", "929598", "a7ffc4", "ffafb9"];

function hash(s: string) {
  let h = 2166136261;
  for (const ch of s) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  return h;
}

/** Fills in anything the educator left on "automatic", deterministically from the patient's name. */
function resolve(look: PatientLook) {
  const h = hash(look.name || "patient");
  const a = look.appearance;
  const { gender, age } = look.voice;
  const older = age === "older";
  const tops = gender === "male" ? MALE_TOPS : gender === "female" ? FEMALE_TOPS : NEUTRAL_TOPS;
  return {
    skin: a.skin || SKINS[h % SKINS.length],
    top: a.top || (gender === "male" && older && h % 3 === 0 ? "sides" : tops[(h >>> 4) % tops.length]),
    hairColor: a.hairColor || (older ? "e8e1e1" : HAIRS[(h >>> 8) % HAIRS.length]),
    facialHair: a.facialHair || (gender === "male" && age !== "child" && h % 4 === 0 ? "beardLight" : "none"),
    accessories: a.accessories || (older && h % 2 === 0 ? "prescription02" : "none"),
    clothing: CLOTHES[(h >>> 12) % CLOTHES.length],
    clothesColor: CLOTHES_COLORS[(h >>> 16) % CLOTHES_COLORS.length],
  };
}

const cache = new Map<string, string>();

export function avatarUri(look: PatientLook, emotion = "neutral", mouth?: string): string {
  const r = resolve(look);
  const face = FACES[emotion] ?? FACES.neutral;
  const key = JSON.stringify([r, face, mouth]);
  const hit = cache.get(key);
  if (hit) return hit;
  const uri = createAvatar(avataaars, {
    seed: look.name || "patient",
    skinColor: [r.skin],
    top: [r.top as never],
    topProbability: 100,
    hairColor: [r.hairColor],
    hatColor: ["25557c"],
    facialHair: r.facialHair === "none" ? undefined : [r.facialHair as never],
    facialHairProbability: r.facialHair === "none" ? 0 : 100,
    facialHairColor: [r.hairColor],
    accessories: r.accessories === "none" ? undefined : [r.accessories as never],
    accessoriesProbability: r.accessories === "none" ? 0 : 100,
    accessoriesColor: ["262e33"],
    clothing: [r.clothing as never],
    clothesColor: [r.clothesColor],
    eyes: [face.eyes as never],
    eyebrows: [face.eyebrows as never],
    mouth: [(mouth ?? face.mouth) as never],
  }).toDataUri();
  if (cache.size > 300) cache.clear();
  cache.set(key, uri);
  return uri;
}

/**
 * The patient's face. `size` is in px; a parent may override it with the CSS variable --avatar-size
 * (the encounter stage uses 40 px on phones).
 */
export function Avatar({
  look,
  emotion = "neutral",
  speaking = false,
  size = 96,
}: {
  look: PatientLook;
  emotion?: string;
  speaking?: boolean;
  size?: number;
  /** @deprecated No longer drawn; kept so existing callers compile. Remove from call sites. */
  showRing?: boolean;
}) {
  const still = useMemo(() => avatarUri(look, emotion), [look, emotion]);
  const talking = useMemo(() => (speaking ? avatarUri(look, emotion, "disbelief") : still), [look, emotion, speaking, still]);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!speaking) {
      setOpen(false);
      return;
    }
    const t = setInterval(() => setOpen((o) => !o), 170);
    return () => clearInterval(t);
  }, [speaking]);
  return (
    <div
      className={`avatar${speaking ? " speaking" : ""}`}
      style={{ width: `var(--avatar-size, ${size}px)`, height: `var(--avatar-size, ${size}px)` }}
      role="img"
      aria-label={`${look.name || "Patient"}${emotion !== "neutral" ? `, looking ${EMOTION_LABEL[emotion]?.toLowerCase() ?? emotion}` : ""}`}
    >
      <img src={speaking && open ? talking : still} alt="" draggable={false} />
    </div>
  );
}
