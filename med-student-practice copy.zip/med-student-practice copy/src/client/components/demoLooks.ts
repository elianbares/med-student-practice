import type { PatientLook } from "../../shared/types";

// Looks of the built-in demo patients, for marketing visuals that render before sign-in.
export const DEMO_LOOKS: Record<string, PatientLook> = {
  marcus: {
    name: "Marcus Bell",
    voice: { gender: "male", age: "adult", pitch: 1, rate: 1 },
    appearance: { skin: "ae5d29", top: "shortRound", hairColor: "2c1b18", facialHair: "beardLight", accessories: "none" },
  },
  priya: {
    name: "Priya Nair",
    voice: { gender: "female", age: "adult", pitch: 1, rate: 1 },
    appearance: { skin: "d08b5b", top: "straight01", hairColor: "2c1b18", facialHair: "none", accessories: "none" },
  },
  elena: {
    name: "Elena Morales",
    voice: { gender: "female", age: "young", pitch: 1, rate: 1 },
    appearance: { skin: "edb98a", top: "curly", hairColor: "4a312c", facialHair: "none", accessories: "none" },
  },
  bob: {
    name: 'Robert "Bob" Kowalski',
    voice: { gender: "male", age: "older", pitch: 1, rate: 1 },
    appearance: { skin: "ffdbb4", top: "sides", hairColor: "e8e1e1", facialHair: "moustacheFancy", accessories: "prescription02" },
  },
};
