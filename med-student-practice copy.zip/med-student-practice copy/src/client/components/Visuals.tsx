import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { APP_NAME, INSPIRED_BY, NOT_AFFILIATED, sentenceCase } from "../../shared/defaults";
import { levelClass, levelIndex } from "../ui";

export function Wordmark() {
  return (
    <span className="wordmark">
      <span className="mark" aria-hidden="true">
        M
      </span>
      <span className="wordmark-text">{APP_NAME}</span>
    </span>
  );
}

/** Rubric level as a segmented bar: one segment per level, filled up to the level reached. */
export function SkillMeter({ level, levels }: { level: string; levels: string[] }) {
  const i = levelIndex(level, levels);
  return (
    <span className={`meter ${levelClass(level, levels)}`} role="img" aria-label={i >= 0 ? `${sentenceCase(level)}, level ${i + 1} of ${levels.length}` : "Not assessed"}>
      {levels.map((l, j) => (
        <span key={l} className={j <= i ? "on" : ""} />
      ))}
    </span>
  );
}

/** Whole percentages that add up to 100 (largest remainder), so captions never read "33% · 33% · 33%". */
function percents(counts: number[]): number[] {
  const total = counts.reduce((a, b) => a + b, 0);
  if (!total) return counts.map(() => 0);
  const raw = counts.map((c) => (c / total) * 100);
  const out = raw.map(Math.floor);
  let left = 100 - out.reduce((a, b) => a + b, 0);
  const order = raw.map((r, i) => [r - Math.floor(r), i] as const).sort((a, b) => b[0] - a[0]);
  for (const [, i] of order) {
    if (left <= 0) break;
    out[i]++;
    left--;
  }
  return out;
}

/**
 * Share of results at each rubric level as one 240 x 8 px stacked bar, lowest level first, with a
 * 13 px caption "50% · 50% · 0%". counts[i] is the number of results at labels[i].
 */
export function LevelBar({ counts, labels }: { counts: number[]; labels: string[] }) {
  const total = counts.reduce((a, b) => a + b, 0);
  const pct = percents(counts);
  const spoken = total ? labels.map((l, i) => `${sentenceCase(l)} ${pct[i] ?? 0}%`).join(", ") : "No results yet";
  return (
    <span className="levelbar-block" role="img" aria-label={spoken} title={spoken}>
      <span className="levelbar" aria-hidden="true">
        {total ? (
          counts.map((c, i) => (c > 0 ? <span key={labels[i] ?? i} className={levelClass(labels[i] ?? "", labels)} style={{ flexGrow: c }} /> : null))
        ) : (
          <span style={{ flexGrow: 1 }} />
        )}
      </span>
      <span className="levelbar-caption" aria-hidden="true">
        {total ? pct.map((p) => `${p}%`).join(" · ") : "No results yet"}
      </span>
    </span>
  );
}

/** A tiny trend line for 0..1 values (oldest first), with a dot on the latest. */
export function Sparkline({ values, label, width = 96, height = 24 }: { values: number[]; label: string; width?: number; height?: number }) {
  const pad = 3;
  const clamp = (v: number) => Math.min(1, Math.max(0, Number.isFinite(v) ? v : 0));
  const pts = values.map((v, i) => [values.length > 1 ? pad + (i * (width - 2 * pad)) / (values.length - 1) : width / 2, pad + (1 - clamp(v)) * (height - 2 * pad)] as const);
  const last = pts[pts.length - 1];
  return (
    <svg className="sparkline" width={width} height={height} viewBox={`0 0 ${width} ${height}`} role="img" aria-label={label}>
      <line x1={pad} x2={width - pad} y1={height - pad} y2={height - pad} stroke="var(--separator)" strokeWidth={1} />
      {pts.length > 1 && <polyline points={pts.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ")} fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinejoin="round" strokeLinecap="round" />}
      {last && <circle cx={last[0]} cy={last[1]} r={2.5} fill="currentColor" />}
    </svg>
  );
}

/** A big number with a short label, for progress summaries. Group several in <div className="stats">. */
export function Stat({ value, label }: { value: ReactNode; label: ReactNode }) {
  return (
    <div className="stat">
      <span className="stat-value">{value}</span>
      <span className="stat-label">{label}</span>
    </div>
  );
}

// Muted solid course colors (DESIGN.md). Keys are kept from earlier versions so saved courses still map.
const COURSE_COLORS: Record<string, { label: string; color: string }> = {
  teal: { label: "Forest", color: "#1d6b46" },
  blue: { label: "Navy", color: "#1f3a5f" },
  slate: { label: "Graphite", color: "#48484a" },
  rose: { label: "Oxblood", color: "#7a2e2e" },
  amber: { label: "Ochre", color: "#8a6d1f" },
};
export const COURSE_COLOR_KEYS = Object.keys(COURSE_COLORS);
export const courseColor = (key: string) => (COURSE_COLORS[key] ?? COURSE_COLORS.teal).color;
export const courseColorLabel = (key: string) => (COURSE_COLORS[key] ?? COURSE_COLORS.teal).label;

export function Footer() {
  return (
    <footer className="footer no-print">
      <div className="footer-inner">
        <strong style={{ color: "var(--label-2)" }}>{APP_NAME}.</strong> {INSPIRED_BY} (Geisel School of Medicine), described by Thesen, Alilonu and Stone in{" "}
        <a href="https://doi.org/10.1007/s40670-024-02250-2" target="_blank" rel="noreferrer">
          Medical Science Educator, 2024
        </a>
        . {NOT_AFFILIATED} Patient illustrations: Avataaars by Pablo Stanley. Practice cases are fictional; never enter real patient information.
        <div style={{ marginTop: 8 }}>
          <Link to="/privacy">Privacy and your data</Link>
        </div>
      </div>
    </footer>
  );
}
