import { ArrowDown, ArrowUp, X } from "lucide-react";
import { invalidProps } from "../ui";

/**
 * Edits an ordered list of short strings (tasks, levels).
 * onChange also gets `from`: for each new position, the item's old position (-1 for an added item),
 * so a caller can keep a parallel list (such as level descriptions) in step.
 */
export function ListEditor({
  items,
  onChange,
  addLabel,
  itemName,
  idBase,
  readOnly,
  invalidAt,
  errorId,
}: {
  items: string[];
  onChange: (v: string[], from: number[]) => void;
  addLabel: string;
  /** "task" or "level": names each input ("Level 2") and its buttons ("Move level 2 up"). */
  itemName: string;
  /** Inputs get the ids `${idBase}-0`, `${idBase}-1`, ... so an error can move focus to one. */
  idBase: string;
  readOnly?: boolean;
  /** The item a server error is about; it is marked invalid and described by `errorId`. */
  invalidAt?: number | null;
  errorId?: string;
}) {
  const name = (i: number) => `${itemName[0].toUpperCase()}${itemName.slice(1)} ${i + 1}`;
  /** Focuses an element after the list re-renders, or `fallback` when it is gone or disabled. */
  const focus = (id: string, fallback: string) =>
    requestAnimationFrame(() => {
      const el = document.getElementById(id) as HTMLButtonElement | null;
      (el && !el.disabled ? el : document.getElementById(fallback))?.focus();
    });
  const positions = items.map((_, i) => i);
  const set = (i: number, v: string) =>
    onChange(
      items.map((x, j) => (j === i ? v : x)),
      positions,
    );
  const move = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= items.length) return;
    const next = [...items];
    const from = [...positions];
    [next[i], next[j]] = [next[j], next[i]];
    [from[i], from[j]] = [from[j], from[i]];
    onChange(next, from);
    // Focus follows the item, so pressing the same button again keeps moving it.
    focus(`${idBase}-${j}-${d < 0 ? "up" : "down"}`, `${idBase}-${j}`);
  };
  const remove = (i: number) =>
    onChange(
      items.filter((_, j) => j !== i),
      positions.filter((j) => j !== i),
    );
  const add = () => {
    onChange([...items, ""], [...positions, -1]);
    focus(`${idBase}-${items.length}`, `${idBase}-${items.length}`);
  };
  return (
    <div className="list-editor">
      {items.map((it, i) => (
        <div key={i} className="item">
          <span className="muted small" style={{ width: 20, flexShrink: 0 }} aria-hidden="true">
            {i + 1}.
          </span>
          <input
            id={`${idBase}-${i}`}
            type="text"
            value={it}
            onChange={(e) => set(i, e.target.value)}
            readOnly={readOnly}
            aria-label={name(i)}
            {...(errorId && invalidAt === i ? invalidProps(errorId, "invalid") : {})}
          />
          {!readOnly && (
            <>
              <button id={`${idBase}-${i}-up`} type="button" className="btn ghost icon small" onClick={() => move(i, -1)} disabled={i === 0} aria-label={`Move ${name(i).toLowerCase()} up`}>
                <ArrowUp size={15} />
              </button>
              <button id={`${idBase}-${i}-down`} type="button" className="btn ghost icon small" onClick={() => move(i, 1)} disabled={i === items.length - 1} aria-label={`Move ${name(i).toLowerCase()} down`}>
                <ArrowDown size={15} />
              </button>
              <button type="button" className="btn ghost icon small" onClick={() => remove(i)} aria-label={`Remove ${name(i).toLowerCase()}`}>
                <X size={15} />
              </button>
            </>
          )}
        </div>
      ))}
      {!readOnly && (
        <button type="button" className="btn small" onClick={add}>
          {addLabel}
        </button>
      )}
    </div>
  );
}
