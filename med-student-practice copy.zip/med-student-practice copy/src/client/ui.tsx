import {
  Fragment,
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type KeyboardEvent as ReactKeyboardEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { Ellipsis, X, type LucideIcon } from "lucide-react";
import type { AiStatus, Role, User } from "../shared/types";
import { sameLevel, sentenceCase } from "../shared/defaults";
import { UNAUTHORIZED_EVENT, api } from "./api";

// ---------- auth ----------

interface AuthState {
  user: User | null;
  ai: AiStatus | null;
  educatorSignup: boolean;
  /** Cloudflare Turnstile site key, only when the server enforces the bot check. */
  turnstileSiteKey: string | null;
  /** Email domains sign-up is limited to; empty means any address. */
  emailDomains: string[];
  loading: boolean;
  /** A short message for the sign-in screen, e.g. after the session ended. Cleared on sign-in. */
  notice: string | null;
  setNotice: (n: string | null) => void;
  refresh: () => Promise<void>;
  setUser: (u: User | null) => void;
}

const AuthCtx = createContext<AuthState | null>(null);

export const SESSION_ENDED = "Your session ended. Sign in again.";

export function AuthProvider({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const [user, setUserState] = useState<User | null>(null);
  const [ai, setAi] = useState<AiStatus | null>(null);
  const [educatorSignup, setEducatorSignup] = useState(false);
  const [turnstileSiteKey, setTurnstileSiteKey] = useState<string | null>(null);
  const [emailDomains, setEmailDomains] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState<string | null>(null);
  const userRef = useRef<User | null>(null);
  const setUser = useCallback((u: User | null) => {
    userRef.current = u;
    setUserState(u);
    if (u) setNotice(null);
  }, []);
  const refresh = useCallback(async () => {
    try {
      const me = await api<{ user: User | null; ai: AiStatus; educatorSignup: boolean; turnstileSiteKey: string | null; emailDomains: string[] }>("/auth/me");
      setUser(me.user);
      setAi(me.ai);
      setEducatorSignup(me.educatorSignup);
      setTurnstileSiteKey(me.turnstileSiteKey ?? null);
      setEmailDomains(me.emailDomains ?? []);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, [setUser]);
  useEffect(() => {
    void refresh();
  }, [refresh]);
  // Any signed-in request that comes back 401 means the session ended: sign out here and come back after signing in.
  useEffect(() => {
    const onUnauthorized = () => {
      if (!userRef.current) return;
      setUser(null);
      setNotice(SESSION_ENDED);
      const { pathname, search } = window.location;
      navigate(signInPath(pathname + search), { replace: true });
    };
    window.addEventListener(UNAUTHORIZED_EVENT, onUnauthorized);
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, onUnauthorized);
  }, [navigate, setUser]);
  return <AuthCtx.Provider value={{ user, ai, educatorSignup, turnstileSiteKey, emailDomains, loading, notice, setNotice, refresh, setUser }}>{children}</AuthCtx.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthCtx);
  if (!ctx) throw new Error("useAuth outside AuthProvider");
  return ctx;
}

export const homeFor = (role: Role | undefined) => (role === "educator" || role === "admin" ? "/educator" : "/home");

/** "/signin?next=/history" so signing in returns to the page the person asked for. */
export const signInPath = (next?: string) => (next && next !== "/" && !next.startsWith("/signin") ? `/signin?next=${encodeURIComponent(next)}` : "/signin");

/** The in-app path in a ?next= query, or null when it is missing or points off-site. */
export function readNext(search: string): string | null {
  const raw = new URLSearchParams(search).get("next");
  if (!raw || !raw.startsWith("/") || raw.startsWith("//") || raw.startsWith("/\\") || raw.startsWith("/signin")) return null;
  return raw;
}

/** Where to go after signing in: the ?next= path when there is a safe one, else the fallback. */
export function useNextPath(fallback: string): string {
  const { search } = useLocation();
  return readNext(search) ?? fallback;
}

export function RequireRole({ roles, children }: { roles?: Role[]; children: ReactNode }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Loading />;
  if (!user) return <Navigate to={signInPath(location.pathname + location.search)} replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to={homeFor(user.role)} replace />;
  return <>{children}</>;
}

// ---------- navigation helpers ----------

/** Back to the previous in-app page, or to `fallback` when this page was opened directly (new tab, bookmark). */
export function useBack(fallback: string) {
  const navigate = useNavigate();
  const { key } = useLocation();
  return useCallback(() => {
    // The router numbers its history entries; a redirect replaces the entry, so after one the key is
    // no longer "default" but there is still nothing in the app to go back to.
    const idx = (window.history.state as { idx?: unknown } | null)?.idx;
    if (typeof idx === "number" ? idx > 0 : key !== "default") navigate(-1);
    else navigate(fallback);
  }, [navigate, key, fallback]);
}

const dirtyForms = new Set<symbol>();

/** Warns before closing or reloading the tab while `dirty`, and lets in-app links ask first (see confirmDiscard). */
export function useUnsavedChanges(dirty: boolean) {
  useEffect(() => {
    if (!dirty) return;
    const token = Symbol("dirty");
    dirtyForms.add(token);
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => {
      dirtyForms.delete(token);
      window.removeEventListener("beforeunload", onBeforeUnload);
    };
  }, [dirty]);
}

export const hasUnsavedChanges = () => dirtyForms.size > 0;

/** True when it's fine to leave: nothing is dirty, or the person agreed to discard. Defaults to any form using useUnsavedChanges. */
export function confirmDiscard(dirty: boolean = hasUnsavedChanges()): boolean {
  return !dirty || window.confirm("Discard unsaved changes?");
}

// ---------- data loading ----------

export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const reload = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await fnRef.current());
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return { data, error, loading, reload, setData };
}

/** Runs an async action with busy and error state for buttons and forms. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const run = useCallback(async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    setBusy(true);
    setError(null);
    try {
      return await fn();
    } catch (e) {
      setError((e as Error).message);
      return undefined;
    } finally {
      setBusy(false);
    }
  }, []);
  return { busy, error, setError, run };
}

/** Grows a textarea with its content up to `max` px. Attach the returned ref; pass the current value. */
export function useAutoGrow(value: string, max = 160) {
  const ref = useRef<HTMLTextAreaElement>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    const border = el.offsetHeight - el.clientHeight;
    el.style.height = `${Math.min(el.scrollHeight + border, max)}px`;
  }, [value, max]);
  return ref;
}

// ---------- small components ----------

/** Skeleton while loading. `inline` drops the page wrapper for use inside a page. */
export function Loading({ label = "Loading", inline }: { label?: string; inline?: boolean }) {
  const bones = (
    <>
      <div className="skeleton" style={{ height: 40, width: 320, maxWidth: "100%", marginBottom: 48 }} />
      <div className="skeleton" style={{ height: 220 }} />
    </>
  );
  return inline ? (
    <div role="status" aria-label={label}>
      {bones}
    </div>
  ) : (
    <div className="page" role="status" aria-label={label}>
      {bones}
    </div>
  );
}

export function ErrorNote({ error, onRetry }: { error: string | null | undefined; onRetry?: () => void }) {
  if (!error) return null;
  return (
    <div className="notice error" role="alert">
      {onRetry ? (
        <div className="row spread">
          <span>{error}</span>
          <button type="button" className="btn small" onClick={onRetry}>
            Try again
          </button>
        </div>
      ) : (
        error
      )}
    </div>
  );
}

/**
 * One place for the loading, error and loaded states of a useLoad() result, so an error never shows
 * next to an empty state. Children run only with data; put the EmptyState inside them.
 */
export function Loaded<T>({ state, children }: { state: { data: T | null; error: string | null; loading: boolean; reload: () => Promise<void> }; children: (data: T) => ReactNode }) {
  if (state.data === null) {
    if (state.error) return <ErrorNote error={state.error} onRetry={() => void state.reload()} />;
    return state.loading ? <Loading inline /> : null;
  }
  return (
    <>
      <ErrorNote error={state.error} onRetry={() => void state.reload()} />
      {children(state.data)}
    </>
  );
}

export function PageHeader({ eyebrow, title, subtitle, actions }: { eyebrow?: string; title: ReactNode; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <header className="page-header">
      <div>
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {actions && <div className="row">{actions}</div>}
    </header>
  );
}

export function EmptyState({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="empty">
      <h3>{title}</h3>
      {children && <p className="muted">{children}</p>}
      {action}
    </div>
  );
}

/** Inline error under a field. Link it with invalidProps(id, error) on the input. */
export function FieldError({ id, children }: { id: string; children?: ReactNode }) {
  return children ? (
    <span id={id} className="field-error">
      {children}
    </span>
  ) : null;
}

/** aria-invalid and aria-describedby for an input whose error is shown by <FieldError id={errorId}>. */
export function invalidProps(errorId: string, error: string | null | undefined): { "aria-invalid"?: true; "aria-describedby"?: string } {
  return error ? { "aria-invalid": true, "aria-describedby": errorId } : {};
}

/** A short confirmation that clears itself: const [flash, showFlash] = useFlash(); showFlash("Saved"); <Flash text={flash} />. */
export function useFlash(ms = 2000): [string, (text: string) => void] {
  const [text, setText] = useState("");
  const timer = useRef<number | undefined>(undefined);
  const show = useCallback(
    (t: string) => {
      window.clearTimeout(timer.current);
      setText(t);
      timer.current = window.setTimeout(() => setText(""), ms);
    },
    [ms],
  );
  useEffect(() => () => window.clearTimeout(timer.current), []);
  return [text, show];
}

/** Always rendered (empty when idle) so screen readers announce each new message. */
export function Flash({ text }: { text: string }) {
  return (
    <span className="flash" role="status" aria-live="polite">
      {text}
    </span>
  );
}

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), summary, [tabindex]:not([tabindex="-1"])';

function focusablesIn(root: HTMLElement): HTMLElement[] {
  return Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE)).filter((el) => el.getClientRects().length > 0);
}

// Open dialogs, oldest first. Only the top one answers Escape.
const modalStack: object[] = [];

/**
 * Dialog sheet. Focus moves into it on open (the first control in the body, else the dialog), Tab and
 * Shift+Tab stay inside, the page behind is inert, Escape and the backdrop close it, and focus returns
 * to the control that opened it. Pass closable={false} while busy: no close button, and Escape and the
 * backdrop do nothing.
 */
export function Modal({ title, onClose, children, wide, closable = true }: { title: ReactNode; onClose: () => void; children: ReactNode; wide?: boolean; closable?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const closableRef = useRef(closable);
  closableRef.current = closable;
  // Read while rendering, before an autoFocus field inside the dialog can take focus.
  const [opener] = useState(() => (document.activeElement instanceof HTMLElement ? document.activeElement : null));

  useEffect(() => {
    const dialog = ref.current;
    if (dialog && !dialog.contains(document.activeElement)) {
      const body = dialog.querySelector<HTMLElement>(".modal-body");
      ((body && focusablesIn(body)[0]) || dialog).focus();
    }
    const token = {};
    modalStack.push(token);
    const root = document.getElementById("root");
    root?.setAttribute("inert", "");
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape" || e.defaultPrevented || e.isComposing || modalStack[modalStack.length - 1] !== token) return;
      e.preventDefault();
      if (closableRef.current) onCloseRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      modalStack.splice(modalStack.indexOf(token), 1);
      if (!modalStack.length) root?.removeAttribute("inert");
      document.body.style.overflow = overflow;
      // Only after a real close: React's development double run keeps the dialog on the page.
      if (!dialog?.isConnected && opener?.isConnected) opener.focus();
    };
  }, [opener]);

  const trapTab = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    if (e.key !== "Tab" || !ref.current) return;
    const items = focusablesIn(ref.current);
    if (!items.length) {
      e.preventDefault();
      return;
    }
    const first = items[0];
    const last = items[items.length - 1];
    const active = document.activeElement;
    if (e.shiftKey && (active === first || active === ref.current || !ref.current.contains(active))) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && (active === last || !ref.current.contains(active))) {
      e.preventDefault();
      first.focus();
    }
  };

  return createPortal(
    <div className="modal-backdrop" onMouseDown={(e) => closable && e.target === e.currentTarget && onClose()}>
      <div ref={ref} className={`modal${wide ? " wide" : ""}`} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1} onKeyDown={trapTab}>
        <div className="modal-head">
          <h2 id={titleId}>{title}</h2>
          {closable && (
            <button type="button" className="btn ghost icon small" onClick={onClose} aria-label="Close">
              <X size={18} />
            </button>
          )}
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </div>,
    document.body,
  );
}

// ---------- tabs and segmented controls ----------

/** Element ids shared by a tab and its panel: tabId("course", "results") pairs with panelId("course", "results"). */
export const tabId = (idBase: string, id: string) => `${idBase}-tab-${id}`;
export const panelId = (idBase: string, id: string) => `${idBase}-panel-${id}`;

/** Arrow keys, Home and End move between enabled options (roving tabindex). */
function rovingTarget<T extends string>(key: string, ids: T[], current: T, disabled: (id: T) => boolean, vertical: boolean): T | null {
  const enabled = ids.filter((id) => !disabled(id));
  if (!enabled.length) return null;
  const i = Math.max(0, enabled.indexOf(current));
  const next = key === "ArrowRight" || (vertical && key === "ArrowDown");
  const prev = key === "ArrowLeft" || (vertical && key === "ArrowUp");
  if (next) return enabled[(i + 1) % enabled.length];
  if (prev) return enabled[(i - 1 + enabled.length) % enabled.length];
  if (key === "Home") return enabled[0];
  if (key === "End") return enabled[enabled.length - 1];
  return null;
}

function focusOption(container: HTMLElement, id: string) {
  container.querySelector<HTMLElement>(`[data-option="${CSS.escape(id)}"]`)?.focus();
}

/**
 * Underlined page tabs. Pass idBase and wrap each panel in <TabPanel idBase={same} id={tab}> to link
 * them for screen readers.
 */
export function Tabs<T extends string>({ tabs, value, onChange, idBase, label }: { tabs: { id: T; label: ReactNode }[]; value: T; onChange: (t: T) => void; idBase?: string; label?: string }) {
  const auto = useId();
  const base = idBase ?? auto;
  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    const next = rovingTarget(
      e.key,
      tabs.map((t) => t.id),
      value,
      () => false,
      false,
    );
    if (next === null) return;
    e.preventDefault();
    onChange(next);
    focusOption(e.currentTarget, next);
  };
  return (
    <div className="tabs" role="tablist" aria-label={label} onKeyDown={onKeyDown}>
      {tabs.map((t) => (
        <button
          key={t.id}
          type="button"
          role="tab"
          id={tabId(base, t.id)}
          data-option={t.id}
          aria-selected={value === t.id}
          aria-controls={idBase ? panelId(idBase, t.id) : undefined}
          tabIndex={value === t.id ? 0 : -1}
          className={`tab ${value === t.id ? "active" : ""}`}
          onClick={() => onChange(t.id)}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

/** The panel for the selected tab of <Tabs idBase> or <Segmented as="tabs" idBase>. */
export function TabPanel({ idBase, id, children, className, style }: { idBase: string; id: string; children: ReactNode; className?: string; style?: CSSProperties }) {
  return (
    <div role="tabpanel" id={panelId(idBase, id)} aria-labelledby={tabId(idBase, id)} tabIndex={0} className={className} style={style}>
      {children}
    </div>
  );
}

/**
 * Apple-style segmented control. A radio group by default (modes); as="tabs" when it switches panels
 * (pair with TabPanel and the same idBase).
 */
export function Segmented<T extends string>({
  options,
  value,
  onChange,
  label,
  as = "radio",
  idBase,
}: {
  options: { id: T; label: ReactNode; icon?: LucideIcon; disabled?: boolean; title?: string }[];
  value: T;
  onChange: (v: T) => void;
  label: string;
  as?: "radio" | "tabs";
  idBase?: string;
}) {
  const auto = useId();
  const base = idBase ?? auto;
  const tabs = as === "tabs";
  const isDisabled = (id: T) => Boolean(options.find((o) => o.id === id)?.disabled);
  const focusable = options.some((o) => o.id === value && !o.disabled) ? value : options.find((o) => !o.disabled)?.id;
  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    const next = rovingTarget(
      e.key,
      options.map((o) => o.id),
      value,
      isDisabled,
      !tabs,
    );
    if (next === null) return;
    e.preventDefault();
    onChange(next);
    focusOption(e.currentTarget, next);
  };
  return (
    <div className="segmented" role={tabs ? "tablist" : "radiogroup"} aria-label={label} onKeyDown={onKeyDown}>
      {options.map((o) => {
        const on = value === o.id;
        return (
          <button
            key={o.id}
            type="button"
            role={tabs ? "tab" : "radio"}
            data-option={o.id}
            id={tabs ? tabId(base, o.id) : undefined}
            aria-checked={tabs ? undefined : on}
            aria-selected={tabs ? on : undefined}
            aria-controls={tabs && idBase ? panelId(idBase, o.id) : undefined}
            tabIndex={o.id === focusable ? 0 : -1}
            className={on ? "on" : ""}
            onClick={() => onChange(o.id)}
            disabled={o.disabled}
            title={o.title}
          >
            {o.icon && <o.icon size={15} />}
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

// ---------- row menu ----------

export interface RowMenuItem {
  label: string;
  onSelect: () => void;
  danger?: boolean;
  disabled?: boolean;
}

/** A compact "More" button that opens a short action menu, for per-row actions in tables and lists. */
export function RowMenu({ label, items }: { label: string; items: RowMenuItem[] }) {
  const [pos, setPos] = useState<{ top?: number; bottom?: number; right: number } | null>(null);
  const btn = useRef<HTMLButtonElement>(null);
  const menu = useRef<HTMLDivElement>(null);
  const menuId = useId();
  const open = pos !== null;
  // Focus goes back to the button after a key or a choice, and is never left on a removed menu item.
  const close = useCallback((refocus: boolean) => {
    const hadFocus = Boolean(menu.current?.contains(document.activeElement));
    setPos(null);
    if (refocus || hadFocus) btn.current?.focus({ preventScroll: !refocus });
  }, []);
  // Below the button, or above it when there is more room there. Null once the button is off screen.
  const place = useCallback(() => {
    if (!btn.current) return null;
    // Measured against the layout viewport (without a scrollbar), which is what position: fixed uses.
    const { clientWidth: vw, clientHeight: vh } = document.documentElement;
    const r = btn.current.getBoundingClientRect();
    if (r.bottom < 0 || r.top > vh) return null;
    const right = Math.max(8, vw - r.right);
    const below = vh - r.bottom;
    return below < 48 * items.length + 16 && r.top > below ? { bottom: vh - r.top + 4, right } : { top: r.bottom + 4, right };
  }, [items.length]);
  const toggle = () => (open ? close(false) : setPos(place()));
  useEffect(() => {
    if (!open) return;
    menu.current?.querySelector<HTMLElement>('[role="menuitem"]:not(:disabled)')?.focus({ preventScroll: true });
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (!menu.current?.contains(t) && !btn.current?.contains(t)) close(false);
    };
    // The menu follows its button while the page scrolls or resizes.
    const onMove = () => {
      const next = place();
      if (next) setPos(next);
      else close(false);
    };
    document.addEventListener("mousedown", onDown);
    window.addEventListener("resize", onMove);
    window.addEventListener("scroll", onMove, true);
    return () => {
      document.removeEventListener("mousedown", onDown);
      window.removeEventListener("resize", onMove);
      window.removeEventListener("scroll", onMove, true);
    };
  }, [open, close, place]);
  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    const els = Array.from(menu.current?.querySelectorAll<HTMLElement>('[role="menuitem"]:not(:disabled)') ?? []);
    const i = els.indexOf(document.activeElement as HTMLElement);
    let to: HTMLElement | undefined;
    if (e.key === "Escape" || e.key === "Tab") {
      e.preventDefault();
      close(true);
      return;
    }
    if (e.key === "ArrowDown") to = els[(i + 1) % els.length];
    else if (e.key === "ArrowUp") to = els[(i - 1 + els.length) % els.length];
    else if (e.key === "Home") to = els[0];
    else if (e.key === "End") to = els[els.length - 1];
    if (to) {
      e.preventDefault();
      to.focus();
    }
  };
  return (
    <span className="row-menu">
      <button
        ref={btn}
        type="button"
        className="btn ghost icon small"
        aria-label={label}
        title={label}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-controls={open ? menuId : undefined}
        onClick={(e) => {
          e.stopPropagation();
          toggle();
        }}
      >
        <Ellipsis size={18} />
      </button>
      {pos &&
        createPortal(
          <div ref={menu} id={menuId} className="row-menu-list" role="menu" aria-label={label} style={pos} onKeyDown={onKeyDown} onClick={(e) => e.stopPropagation()}>
            {items.map((it) => (
              <button
                key={it.label}
                type="button"
                role="menuitem"
                className={it.danger ? "danger" : undefined}
                disabled={it.disabled}
                onClick={() => {
                  close(true);
                  it.onSelect();
                }}
              >
                {it.label}
              </button>
            ))}
          </div>,
          document.body,
        )}
    </span>
  );
}

// ---------- rubric levels ----------

/** Position of a level in the configured scale, ignoring case ("Needs Improvement" matches "Needs improvement"). */
export function levelIndex(level: string, levels: string[]): number {
  return levels.findIndex((l) => sameLevel(l, level));
}

/** Maps a rubric level to low / mid / high by its position in the configured scale. */
export function levelClass(level: string, levels: string[]): "low" | "mid" | "high" | "" {
  const i = levelIndex(level, levels);
  if (i < 0) return "";
  const r = levels.length > 1 ? i / (levels.length - 1) : 1;
  return r < 0.34 ? "low" : r < 0.67 ? "mid" : "high";
}

/** 0..1 score for a level, for meters and trends. */
export function levelValue(level: string, levels: string[]): number {
  const i = levelIndex(level, levels);
  if (i < 0) return 0;
  return levels.length > 1 ? (i + 1) / levels.length : 1;
}

export function LevelPill({ level, levels }: { level: string; levels: string[] }) {
  return <span className={`badge ${levelClass(level, levels)}`}>{sentenceCase(level)}</span>;
}

// ---------- chat text ----------

const DASH = /[\u2012-\u2015]/;

/** Em and en dashes read as commas and number ranges keep a hyphen, as the server does for new replies. */
export function noDashes(text: string): string {
  if (!DASH.test(text)) return text;
  return text
    .replace(/(\d)\s*[\u2012-\u2015]\s*(?=\d)/g, "$1-")
    .replace(/\s*[\u2012-\u2015]+\s*/g, ", ")
    .replace(/,\s*([,.;:!?)])/g, "$1")
    .replace(/^,\s*/, "");
}

/**
 * Chat or transcript text with its nonverbal cues: "*fidgets with bag strap*" renders as
 * <em class="action">. Unpaired asterisks are dropped and dashes read as commas, so raw markdown
 * never shows, even mid-stream.
 */
export function ActionText({ text }: { text: string }) {
  const parts = noDashes(text).split(/\*([^*\n]+)\*/);
  return (
    <>
      {parts.map((p, i) =>
        i % 2 ? (
          <em key={i} className="action">
            {p.trim()}
          </em>
        ) : (
          <Fragment key={i}>{p.replace(/\*/g, "")}</Fragment>
        ),
      )}
    </>
  );
}

// ---------- misc ----------

export function DemoBanner() {
  const { ai, user } = useAuth();
  if (ai?.mode !== "demo") return null;
  return (
    <div className="notice warn">
      Demo mode: patients give simple scripted answers until a free Google AI key is added
      {user?.role === "admin" ? " to the server settings." : " by the site owner, your instructor, or you in Settings."}
    </div>
  );
}

export function Initials({ name }: { name: string }) {
  const parts = name.trim().split(/\s+/);
  const ini = ((parts[0]?.[0] ?? "") + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
  return (
    <span className="initials" aria-hidden="true">
      {ini || "?"}
    </span>
  );
}

/** First name for greetings; keeps a title with the next word ("Dr. Lee"). */
export function shortName(name: string): string {
  const parts = name.trim().split(/\s+/);
  return /^(dr|prof|mr|mrs|ms|mx)\.?$/i.test(parts[0] ?? "") && parts[1] ? `${parts[0]} ${parts[1]}` : parts[0] ?? "";
}

export function greeting(): string {
  const h = new Date().getHours();
  return h < 5 ? "Good evening" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

export function fmtDate(ms: number | null | undefined) {
  if (!ms) return "";
  return new Date(ms).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

export function fmtDuration(ms: number) {
  const s = Math.max(0, Math.round(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

/** Copies text; resolves true when the clipboard accepted it (pair with useFlash for "Copied"). */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
