import type { VoiceSettings } from "../../shared/types";

// ---------- shared audio output ----------

let sharedCtx: AudioContext | null = null;

/** One AudioContext for patient speech. Call from a click so iOS and Safari allow playback. */
export function audioContext(): AudioContext {
  if (!sharedCtx || sharedCtx.state === "closed") sharedCtx = new AudioContext();
  if (sharedCtx.state === "suspended") void sharedCtx.resume().catch(() => undefined);
  return sharedCtx;
}

export function unlockAudio() {
  const ctx = audioContext();
  const b = ctx.createBuffer(1, 1, 22050);
  const s = ctx.createBufferSource();
  s.buffer = b;
  s.connect(ctx.destination);
  s.start();
  try {
    speechSynthesis.speak(new SpeechSynthesisUtterance(" "));
  } catch {
    /* no speech synthesis */
  }
}

/** Plays streamed 16-bit PCM (or WAV) chunks back to back, without gaps. */
class PcmPlayer {
  private nextTime = 0;
  private sources: AudioBufferSourceNode[] = [];
  private carry: number | null = null;

  get playing() {
    const ctx = sharedCtx;
    return Boolean(ctx && this.nextTime > ctx.currentTime + 0.02);
  }

  push(b64: string, mime: string) {
    const ctx = audioContext();
    const bin = atob(b64);
    let bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    let rate = Number(/rate=(\d+)/i.exec(mime)?.[1] ?? 24000);
    if (bytes.length > 44 && bin.startsWith("RIFF")) {
      rate = new DataView(bytes.buffer).getUint32(24, true) || rate;
      const data = bin.indexOf("data", 12);
      bytes = bytes.subarray(data >= 0 ? data + 8 : 44);
    }
    if (this.carry !== null) {
      const merged = new Uint8Array(bytes.length + 1);
      merged[0] = this.carry;
      merged.set(bytes, 1);
      bytes = merged;
      this.carry = null;
    }
    if (bytes.length % 2) {
      this.carry = bytes[bytes.length - 1];
      bytes = bytes.subarray(0, bytes.length - 1);
    }
    const n = bytes.length / 2;
    if (!n) return;
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const buf = ctx.createBuffer(1, n, rate);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) ch[i] = view.getInt16(i * 2, true) / 32768;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.connect(ctx.destination);
    const at = Math.max(ctx.currentTime + 0.05, this.nextTime);
    src.start(at);
    this.nextTime = at + buf.duration;
    this.sources.push(src);
    src.onended = () => (this.sources = this.sources.filter((s) => s !== src));
  }

  stop() {
    for (const s of this.sources) {
      try {
        s.stop();
      } catch {
        /* already stopped */
      }
    }
    this.sources = [];
    this.nextTime = 0;
    this.carry = null;
  }
}

/** Reads Gemini's streamed TTS events and hands each audio chunk to the player. */
async function streamTts(url: string, body: object, player: PcmPlayer, signal: AbortSignal): Promise<void> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json", "x-requested-with": "apa" },
    body: JSON.stringify(body),
    credentials: "same-origin",
    signal,
  });
  if (!res.ok || !res.body) throw new Error(`voice ${res.status}`);
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  let got = 0;
  const handle = (line: string) => {
    const l = line.trim();
    if (!l.startsWith("data:")) return;
    const evt = JSON.parse(l.slice(5)) as { candidates?: { content?: { parts?: { inlineData?: { data: string; mimeType: string } }[] } }[] };
    for (const p of evt.candidates?.[0]?.content?.parts ?? []) {
      if (p.inlineData?.data) {
        got++;
        player.push(p.inlineData.data, p.inlineData.mimeType ?? "");
      }
    }
  };
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let idx: number;
    while ((idx = buf.indexOf("\n")) >= 0) {
      handle(buf.slice(0, idx));
      buf = buf.slice(idx + 1);
    }
  }
  handle(buf);
  if (!got) throw new Error("no audio");
}

// ---------- device voice (fallback) ----------

const FEMALE = /female|woman|samantha|victoria|karen|moira|tessa|fiona|serena|allison|ava|susan|zira|aria|jenny|sonia|libby|natasha|clara|paulina|monica|amelie|anna|alice|ellen|joana|luciana|kyoko|yuna|tingting|meijia|google us english$/i;
const MALE = /\bmale\b|\bman\b|daniel|alex\b|fred|tom\b|aaron|arthur|oliver|gordon|rishi|guy|davis|ryan|thomas|jorge|diego|juan|luca|xander|otoya|google uk english male/i;
const QUALITY = /natural|neural|premium|enhanced|online/i;
let cachedVoices: SpeechSynthesisVoice[] = [];

export function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  if (!("speechSynthesis" in window)) return Promise.resolve([]);
  const now = speechSynthesis.getVoices();
  if (now.length) return Promise.resolve((cachedVoices = now));
  return new Promise((resolve) => {
    const done = () => resolve((cachedVoices = speechSynthesis.getVoices()));
    speechSynthesis.addEventListener("voiceschanged", done, { once: true });
    setTimeout(done, 1500);
  });
}

function pickVoice(lang: string, gender: VoiceSettings["gender"]): SpeechSynthesisVoice | undefined {
  const voices = cachedVoices.length ? cachedVoices : speechSynthesis.getVoices();
  const base = lang.split("-")[0].toLowerCase();
  const exact = voices.filter((v) => v.lang.replace("_", "-").toLowerCase() === lang.toLowerCase());
  const pool = exact.length ? exact : voices.filter((v) => v.lang.toLowerCase().startsWith(base));
  if (!pool.length) return undefined;
  const want = gender === "male" ? MALE : gender === "female" ? FEMALE : null;
  const score = (v: SpeechSynthesisVoice) => (want?.test(v.name) ? 4 : 0) + (QUALITY.test(v.name) ? 2 : 0) + (v.localService ? 0 : 1);
  return [...pool].sort((a, b) => score(b) - score(a))[0];
}

const AGE_PITCH: Record<VoiceSettings["age"], number> = { child: 1.35, young: 1.08, adult: 1, older: 0.9 };

function deviceSpeak(text: string, lang: string, voice: VoiceSettings, onEnd: () => void) {
  const sentences = text
    .replace(/\*[^*]*\*/g, " ")
    .split(/(?<=[.!?…。！？])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (!sentences.length) return onEnd();
  sentences.forEach((s, i) => {
    const u = new SpeechSynthesisUtterance(s);
    u.lang = lang;
    const v = pickVoice(lang, voice.gender);
    if (v) u.voice = v;
    u.rate = voice.rate;
    u.pitch = voice.pitch * AGE_PITCH[voice.age];
    if (i === sentences.length - 1) {
      u.onend = onEnd;
      u.onerror = onEnd;
    }
    speechSynthesis.speak(u);
  });
}

// ---------- patient speaker ----------

/**
 * Speaks patient replies in a natural Google voice (with emotion), and tells the page when speech
 * starts and stops so the microphone can pause meanwhile. Falls back to the device voice if the
 * natural voice is unavailable.
 */
export class Speaker {
  private player = new PcmPlayer();
  private text = "";
  private fetching = false;
  private device = false;
  private failures = 0;
  private abort: AbortController | null = null;
  private tick: ReturnType<typeof setInterval>;
  private wasBusy = false;
  emotion = "neutral";
  onState: (speaking: boolean) => void = () => {};
  onNotice: (message: string) => void = () => {};

  constructor(
    private encounterId: string,
    private lang: string,
    private voice: VoiceSettings,
  ) {
    this.tick = setInterval(() => {
      const busy = this.busy;
      if (busy !== this.wasBusy) {
        this.wasBusy = busy;
        this.onState(busy);
      }
    }, 80);
  }

  get busy() {
    return this.fetching || this.player.playing || this.device;
  }

  feed(chunk: string) {
    this.text += chunk;
  }

  flush() {
    const text = this.text.trim();
    this.text = "";
    if (text) void this.say(text);
  }

  async say(text: string) {
    if (this.failures >= 2) return this.sayDevice(text);
    this.fetching = true;
    this.abort = new AbortController();
    try {
      await streamTts(`/api/encounters/${this.encounterId}/tts`, { text, emotion: this.emotion }, this.player, this.abort.signal);
      this.failures = 0;
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      if (++this.failures === 2) this.onNotice("The natural voice is busy, so the patient is using your device's voice for now.");
      if (!this.player.playing) this.sayDevice(text);
    } finally {
      this.fetching = false;
    }
  }

  private sayDevice(text: string) {
    if (!("speechSynthesis" in window)) return;
    this.device = true;
    deviceSpeak(text, this.lang, this.voice, () => (this.device = false));
  }

  stop() {
    this.abort?.abort();
    this.fetching = false;
    this.text = "";
    this.player.stop();
    if (this.device) speechSynthesis.cancel();
    this.device = false;
  }

  dispose() {
    this.stop();
    clearInterval(this.tick);
  }
}

/** Plays a short sample of a patient's natural voice in the profile editor. */
export async function previewVoice(voice: VoiceSettings, text: string, persona: string): Promise<void> {
  unlockAudio();
  const player = new PcmPlayer();
  try {
    await streamTts("/api/library/voice-preview", { voice: voice.liveVoice, text, persona, emotion: "calm" }, player, new AbortController().signal);
  } catch {
    await loadVoices();
    deviceSpeak(text, "en-US", voice, () => undefined);
  }
}
