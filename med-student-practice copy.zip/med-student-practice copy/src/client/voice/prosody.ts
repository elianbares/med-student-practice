import type { Message, ProsodyMetrics } from "../../shared/types";
import { wavBlob } from "./mic";

const RATE = 16000;
const MAX_RECORD = RATE * 240; // keep up to 4 minutes of the clinician's voice for AI analysis

/**
 * Free, in-browser analysis of how the clinician sounds: pace, response time, pitch and loudness
 * variation, filler words and share of talk time. It also keeps the clinician's audio (only while
 * they are speaking) so an AI can listen back for warmth, calmness and clarity.
 */
export class ProsodyTracker {
  private pitches: number[] = [];
  private loudness: number[] = [];
  private speakingMs = 0;
  private words = 0;
  private latencies: number[] = [];
  private lastPatientEnd = 0;
  private recorded: Int16Array[] = [];
  private recordedSamples = 0;
  active = false; // true while the clinician is mid-utterance

  /** Feed one 100 ms microphone frame. */
  frame(pcm: Int16Array, rms: number, force = false) {
    if ((!this.active && !force) || rms < 0.01) return;
    this.loudness.push(20 * Math.log10(rms));
    const f0 = pitchOf(pcm);
    if (f0) this.pitches.push(f0);
    if (this.recordedSamples < MAX_RECORD) {
      this.recorded.push(pcm);
      this.recordedSamples += pcm.length;
    }
  }

  patientFinished() {
    this.lastPatientEnd = Date.now();
  }

  clinicianTurn(text: string, startedAt: number) {
    const now = Date.now();
    this.speakingMs += Math.max(500, now - startedAt - 1400);
    this.words += text.split(/\s+/).filter(Boolean).length;
    if (this.lastPatientEnd && startedAt > this.lastPatientEnd) this.latencies.push((startedAt - this.lastPatientEnd) / 1000);
  }

  /** A WAV of the clinician's speech, or null if too little was captured. */
  wav(): Blob | null {
    return this.recordedSamples >= RATE * 3 ? wavBlob(this.recorded) : null;
  }

  result(messages: Message[]): ProsodyMetrics {
    const doctorText = messages
      .filter((m) => m.role === "doctor")
      .map((m) => m.text)
      .join(" ");
    const patientWords = messages
      .filter((m) => m.role === "patient")
      .map((m) => m.text)
      .join(" ")
      .split(/\s+/)
      .filter(Boolean).length;
    const doctorWords = doctorText.split(/\s+/).filter(Boolean).length;
    const semis = this.pitches.map((f) => 12 * Math.log2(f / 100));
    // Without per-turn timing (emotive mode), estimate speaking time from recorded speech.
    const speakingMs = this.speakingMs || (this.recordedSamples / RATE) * 1000;
    const words = this.words || doctorWords;
    return {
      speakingSeconds: Math.round(speakingMs / 1000),
      wordsPerMinute: speakingMs > 3000 ? Math.round(words / (speakingMs / 60000)) : 0,
      avgPauseSec: this.latencies.length ? round(this.latencies.reduce((a, b) => a + b, 0) / this.latencies.length) : 0,
      longPauses: this.latencies.filter((l) => l > 6).length,
      pitchVariation: semis.length > 20 ? round(std(semis)) : 0,
      loudnessVariation: this.loudness.length > 20 ? round(std(this.loudness)) : 0,
      talkShare: doctorWords + patientWords ? round(doctorWords / (doctorWords + patientWords)) : 0,
      fillerWords: (doctorText.match(/\b(um+|uh+|erm+|hmm+|you know)\b/gi) ?? []).length,
    };
  }
}

const round = (n: number) => Math.round(n * 100) / 100;

function std(xs: number[]) {
  const m = xs.reduce((a, b) => a + b, 0) / xs.length;
  return Math.sqrt(xs.reduce((a, b) => a + (b - m) ** 2, 0) / xs.length);
}

/** Autocorrelation pitch estimate in the human speech range (70-400 Hz) at 16 kHz. */
function pitchOf(pcm: Int16Array): number | null {
  const minLag = Math.floor(RATE / 400);
  const maxLag = Math.floor(RATE / 70);
  const n = Math.min(pcm.length, 1024);
  let best = 0;
  let bestLag = 0;
  let energy = 0;
  for (let i = 0; i < n; i++) energy += pcm[i] * pcm[i];
  if (!energy) return null;
  for (let lag = minLag; lag <= maxLag; lag++) {
    let c = 0;
    for (let i = 0; i < n - lag; i++) c += pcm[i] * pcm[i + lag];
    if (c > best) {
      best = c;
      bestLag = lag;
    }
  }
  return bestLag && best / energy > 0.3 ? RATE / bestLag : null;
}

/** Plain-language coaching for each metric, shown on the feedback page. */
export function prosodyNotes(p: ProsodyMetrics): { label: string; value: string; note: string; ok: boolean }[] {
  const out: { label: string; value: string; note: string; ok: boolean }[] = [];
  if (p.wordsPerMinute) {
    const ok = p.wordsPerMinute >= 110 && p.wordsPerMinute <= 170;
    out.push({
      label: "Speaking pace",
      value: `${p.wordsPerMinute} words/min`,
      ok,
      note: ok ? "A comfortable pace for patients." : p.wordsPerMinute > 170 ? "Fast. Slow down, especially when explaining or giving news." : "Slow. Fine for difficult news; otherwise keep the conversation moving.",
    });
  }
  if (p.avgPauseSec) {
    const ok = p.avgPauseSec <= 4;
    out.push({
      label: "Response time",
      value: `${p.avgPauseSec}s average${p.longPauses ? `, ${p.longPauses} long pause${p.longPauses > 1 ? "s" : ""}` : ""}`,
      ok,
      note: ok ? "You kept the conversation flowing." : "Long gaps can feel awkward unless they're deliberate silence after emotional moments.",
    });
  }
  if (p.pitchVariation) {
    const ok = p.pitchVariation >= 2;
    out.push({
      label: "Vocal variety",
      value: `${p.pitchVariation} semitones`,
      ok,
      note: ok ? "Your voice had natural, engaged variation." : "Fairly monotone. Varying your tone helps you sound warm and engaged.",
    });
  }
  if (p.talkShare) {
    const ok = p.talkShare <= 0.55;
    out.push({
      label: "Share of talking",
      value: `${Math.round(p.talkShare * 100)}% you`,
      ok,
      note: ok ? "You let the patient do most of the talking." : "You talked more than the patient. Use more open questions and listen.",
    });
  }
  out.push({
    label: "Filler words",
    value: String(p.fillerWords),
    ok: p.fillerWords <= 5,
    note: p.fillerWords <= 5 ? "Few or no fillers recognized." : "Try pausing silently instead of saying “um” or “uh”.",
  });
  return out;
}
