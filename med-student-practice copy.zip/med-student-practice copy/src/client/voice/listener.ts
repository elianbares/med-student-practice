import { recognitionCtor } from "./support";

export interface ListenerHandlers {
  onInterim: (text: string) => void;
  /** A complete clinician turn, sent after a short silence. */
  onFinal: (text: string, startedAt: number) => void;
  onError: (message: string, fatal: boolean) => void;
  onListening: (listening: boolean) => void;
}

const SILENCE_MS = 1400;

/**
 * Wraps the browser SpeechRecognition API: keeps it running across the browser's automatic stops,
 * joins phrases into one turn, and can be paused while the patient is speaking (half-duplex).
 */
export class Listener {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private rec: any;
  private wanted = false;
  private running = false;
  private pending = "";
  private turnStart = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private failures = 0;

  constructor(
    lang: string,
    private h: ListenerHandlers,
  ) {
    const Ctor = recognitionCtor();
    this.rec = new Ctor();
    this.rec.lang = lang;
    this.rec.continuous = true;
    this.rec.interimResults = true;
    this.rec.maxAlternatives = 1;
    this.rec.onstart = () => {
      this.running = true;
      this.h.onListening(true);
    };
    this.rec.onend = () => {
      this.running = false;
      this.h.onListening(false);
      if (this.wanted) setTimeout(() => this.wanted && this.safeStart(), 250);
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    this.rec.onresult = (e: any) => {
      this.failures = 0;
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) this.pending = `${this.pending} ${r[0].transcript}`.trim();
        else interim += r[0].transcript;
      }
      if (!this.turnStart) this.turnStart = Date.now();
      this.h.onInterim(`${this.pending} ${interim}`.trim());
      if (this.timer) clearTimeout(this.timer);
      this.timer = setTimeout(() => this.commit(), interim ? SILENCE_MS + 600 : SILENCE_MS);
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    this.rec.onerror = (e: any) => {
      const err = String(e.error ?? "");
      if (err === "no-speech" || err === "aborted") return;
      if (err === "not-allowed" || err === "service-not-allowed") {
        this.wanted = false;
        this.h.onError("Microphone access was blocked. Allow the microphone in your browser's address bar, or switch to typing below.", true);
        return;
      }
      if (++this.failures >= 4) {
        this.wanted = false;
        this.h.onError("Speech recognition keeps failing (often a network issue). You can keep going by typing below.", true);
        return;
      }
      this.h.onError(`Speech recognition hiccup (${err}). Retrying…`, false);
    };
  }

  private commit() {
    this.timer = null;
    const text = this.pending.trim();
    const started = this.turnStart || Date.now();
    this.pending = "";
    this.turnStart = 0;
    this.h.onInterim("");
    if (text) this.h.onFinal(text, started);
  }

  private safeStart() {
    if (this.running) return;
    try {
      this.rec.start();
    } catch {
      /* already starting */
    }
  }

  start() {
    this.wanted = true;
    this.safeStart();
  }

  /** Stop listening (e.g. while the patient speaks); anything half-heard is discarded. */
  pause() {
    this.wanted = false;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.pending = "";
    this.turnStart = 0;
    this.h.onInterim("");
    try {
      this.rec.abort();
    } catch {
      /* not running */
    }
  }

  stop() {
    this.pause();
    this.rec.onend = null;
  }
}
