// Voice uses the browser's own speech recognition when it has one (Chrome, Edge, Safari). Other
// browsers (e.g. Firefox) detect speech locally and send short clips to the server to transcribe.

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AnyWindow = Window & { SpeechRecognition?: any; webkitSpeechRecognition?: any };

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function recognitionCtor(): any {
  const w = window as AnyWindow;
  return w.SpeechRecognition ?? w.webkitSpeechRecognition;
}

const canCapture = () => typeof AudioWorkletNode !== "undefined" && Boolean(navigator.mediaDevices?.getUserMedia);

export function voiceSupport(): { available: boolean; native: boolean; reason: string } {
  if (typeof window === "undefined") return { available: false, native: false, reason: "" };
  if (!window.isSecureContext) return { available: false, native: false, reason: "Voice needs a secure (https) connection." };
  if (!("speechSynthesis" in window)) return { available: false, native: false, reason: "This browser can't speak replies aloud. Use text mode." };
  if (recognitionCtor()) return { available: true, native: true, reason: "" };
  if (canCapture()) return { available: true, native: false, reason: "" };
  return { available: false, native: false, reason: "This browser can't use the microphone here. Text mode works everywhere." };
}
