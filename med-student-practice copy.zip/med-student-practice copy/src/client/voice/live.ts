// Emotive voice: a direct, low-latency speech-to-speech session with Gemini Live. The Worker mints a
// one-use token with the patient's instructions locked in, so the case never reaches the browser.
import { Mic, pcmToBase64 } from "./mic";

export interface LiveHandlers {
  onState: (state: "connecting" | "live" | "reconnecting" | "closed" | "error", message?: string) => void;
  onSpeaking: (speaking: boolean) => void;
  onDoctorText: (textSoFar: string) => void;
  onPatientText: (textSoFar: string) => void;
  onTurn: (turn: { doctor: string; patient: string }) => void;
  /** Raw clinician audio, for voice analysis. */
  onDoctorAudio?: (pcm: Int16Array, rms: number) => void;
}

const WS_URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained";

export class LiveSession {
  private ws: WebSocket | null = null;
  private out: AudioContext;
  private nextTime = 0;
  private sources: AudioBufferSourceNode[] = [];
  private speaking = false;
  private quietUntil = 0;
  private doctor = "";
  private patient = "";
  private handle = "";
  private closed = false;
  private retries = 0;
  private unsub: (() => void) | null = null;
  private tick: ReturnType<typeof setInterval>;
  muted = false;

  constructor(
    private token: string,
    private model: string,
    private mic: Mic,
    private h: LiveHandlers,
  ) {
    this.out = new AudioContext();
    this.tick = setInterval(() => {
      const playing = this.nextTime > this.out.currentTime + 0.02;
      if (playing !== this.speaking) {
        this.speaking = playing;
        if (!playing) this.quietUntil = performance.now() + 350;
        this.h.onSpeaking(playing);
      }
    }, 80);
  }

  connect() {
    this.h.onState(this.handle ? "reconnecting" : "connecting");
    const ws = new WebSocket(`${WS_URL}?access_token=${encodeURIComponent(this.token)}`);
    this.ws = ws;
    ws.onopen = () => {
      const setup: Record<string, unknown> = { model: `models/${this.model}` };
      if (this.handle) setup.sessionResumption = { handle: this.handle };
      ws.send(JSON.stringify({ setup }));
    };
    ws.onmessage = async (ev) => {
      const text = typeof ev.data === "string" ? ev.data : await (ev.data as Blob).text();
      let m: Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
      try {
        m = JSON.parse(text);
      } catch {
        return;
      }
      if (m.setupComplete) {
        this.retries = 0;
        this.h.onState("live");
        if (!this.unsub) this.unsub = this.mic.on((pcm, rms) => this.onMic(pcm, rms));
      }
      if (m.sessionResumptionUpdate?.newHandle) this.handle = m.sessionResumptionUpdate.newHandle;
      if (m.goAway) this.reconnect();
      const sc = m.serverContent;
      if (!sc) return;
      for (const p of sc.modelTurn?.parts ?? []) if (p.inlineData?.data) this.play(p.inlineData.data);
      if (sc.inputTranscription?.text) {
        this.doctor += sc.inputTranscription.text;
        this.h.onDoctorText(this.doctor.trim());
      }
      if (sc.outputTranscription?.text) {
        this.patient += sc.outputTranscription.text;
        this.h.onPatientText(this.patient.trim());
      }
      if (sc.interrupted) this.stopPlayback();
      if (sc.turnComplete) {
        const turn = { doctor: this.doctor.trim(), patient: this.patient.trim() };
        this.doctor = "";
        this.patient = "";
        if (turn.doctor || turn.patient) this.h.onTurn(turn);
      }
    };
    ws.onclose = (ev) => {
      if (this.closed || ws !== this.ws) return;
      if (this.handle && this.retries < 3) return this.reconnect();
      this.h.onState("error", ev.reason || "The live voice connection closed.");
    };
    ws.onerror = () => undefined;
  }

  private reconnect() {
    if (this.closed) return;
    this.retries++;
    const old = this.ws;
    this.ws = null;
    try {
      old?.close();
    } catch {
      /* already closed */
    }
    setTimeout(() => !this.closed && this.connect(), 300);
  }

  private onMic(pcm: Int16Array, rms: number) {
    // Half-duplex: don't send audio while the patient is talking, so it can't hear (and interrupt) itself.
    if (this.muted || this.speaking || performance.now() < this.quietUntil) return;
    this.h.onDoctorAudio?.(pcm, rms);
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ realtimeInput: { audio: { data: pcmToBase64(pcm), mimeType: "audio/pcm;rate=16000" } } }));
    }
  }

  private play(b64: string) {
    const bin = atob(b64);
    const n = bin.length >> 1;
    const buf = this.out.createBuffer(1, n, 24000);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) {
      const v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8);
      ch[i] = (v >= 0x8000 ? v - 0x10000 : v) / 32768;
    }
    const src = this.out.createBufferSource();
    src.buffer = buf;
    src.connect(this.out.destination);
    const at = Math.max(this.out.currentTime + 0.04, this.nextTime);
    src.start(at);
    this.nextTime = at + buf.duration;
    this.sources.push(src);
    src.onended = () => (this.sources = this.sources.filter((s) => s !== src));
  }

  private stopPlayback() {
    for (const s of this.sources) {
      try {
        s.stop();
      } catch {
        /* already stopped */
      }
    }
    this.sources = [];
    this.nextTime = 0;
  }

  /** Typed input in emotive mode; the patient answers out loud. */
  sendText(text: string) {
    this.doctor = text;
    this.ws?.send(JSON.stringify({ realtimeInput: { text } }));
  }

  /** Tell the patient something happened (e.g. an exam) without asking for a reply. */
  note(text: string) {
    this.ws?.send(JSON.stringify({ clientContent: { turns: [{ role: "user", parts: [{ text }] }], turnComplete: false } }));
  }

  async resumeAudio() {
    if (this.out.state === "suspended") await this.out.resume().catch(() => undefined);
  }

  close() {
    this.closed = true;
    clearInterval(this.tick);
    this.unsub?.();
    this.stopPlayback();
    try {
      this.ws?.close();
    } catch {
      /* already closed */
    }
    void this.out.close().catch(() => undefined);
  }
}

/** A light guess at the patient's feeling from what they said, to drive the avatar's face. */
export function emotionFromText(text: string): string | null {
  const t = text.toLowerCase();
  if (/\b(ow|ouch|hurts?|painful|aching|agony)\b/.test(t)) return "in_pain";
  if (/\b(scared|afraid|worried|nervous|frightened|terrified|anxious)\b/.test(t)) return "anxious";
  if (/\b(sad|cry|crying|upset|depressed|devastat)/.test(t)) return "sad";
  if (/\b(angry|furious|frustrat|ridiculous|why didn't)/.test(t)) return "angry";
  if (/\b(don't understand|what do you mean|confus|not sure what)/.test(t)) return "confused";
  if (/\b(thank|relieved|that helps|good to know|glad)\b/.test(t)) return "relieved";
  return null;
}
