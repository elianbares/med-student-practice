// Microphone capture as 16 kHz 16-bit mono PCM in 100 ms frames, via an AudioWorklet.
// Shared by emotive voice (Gemini Live), the speech-detection fallback, and voice analysis.

const WORKLET = `
class Pcm16Capture extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ratio = sampleRate / 16000;
    this.pos = 0; this.sum = 0; this.count = 0;
    this.buf = new Int16Array(1600); this.n = 0;
  }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch) return true;
    for (let i = 0; i < ch.length; i++) {
      this.sum += ch[i]; this.count++; this.pos += 1;
      if (this.pos >= this.ratio) {
        this.pos -= this.ratio;
        const s = Math.max(-1, Math.min(1, this.sum / this.count));
        this.sum = 0; this.count = 0;
        this.buf[this.n++] = s < 0 ? s * 0x8000 : s * 0x7fff;
        if (this.n === this.buf.length) {
          this.port.postMessage(this.buf.buffer, [this.buf.buffer]);
          this.buf = new Int16Array(1600); this.n = 0;
        }
      }
    }
    return true;
  }
}
registerProcessor("pcm16-capture", Pcm16Capture);
`;

export type FrameListener = (pcm: Int16Array, rms: number) => void;

export class Mic {
  private listeners = new Set<FrameListener>();
  private constructor(
    private ctx: AudioContext,
    private stream: MediaStream,
    private node: AudioWorkletNode,
  ) {
    node.port.onmessage = (e) => {
      const pcm = new Int16Array(e.data as ArrayBuffer);
      let sum = 0;
      for (let i = 0; i < pcm.length; i++) sum += (pcm[i] / 32768) ** 2;
      const rms = Math.sqrt(sum / pcm.length);
      for (const l of this.listeners) l(pcm, rms);
    };
  }

  static supported(): boolean {
    return typeof AudioWorkletNode !== "undefined" && Boolean(navigator.mediaDevices?.getUserMedia);
  }

  static async open(): Promise<Mic> {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } });
    const ctx = new AudioContext();
    const url = URL.createObjectURL(new Blob([WORKLET], { type: "application/javascript" }));
    await ctx.audioWorklet.addModule(url);
    URL.revokeObjectURL(url);
    const node = new AudioWorkletNode(ctx, "pcm16-capture");
    ctx.createMediaStreamSource(stream).connect(node);
    // Keep the graph pulling audio without playing the mic back to the speakers.
    const mute = ctx.createGain();
    mute.gain.value = 0;
    node.connect(mute).connect(ctx.destination);
    if (ctx.state === "suspended") await ctx.resume().catch(() => undefined);
    return new Mic(ctx, stream, node);
  }

  on(fn: FrameListener) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  close() {
    this.listeners.clear();
    this.node.port.onmessage = null;
    this.stream.getTracks().forEach((t) => t.stop());
    void this.ctx.close().catch(() => undefined);
  }
}

export function pcmToBase64(pcm: Int16Array): string {
  const bytes = new Uint8Array(pcm.buffer, pcm.byteOffset, pcm.byteLength);
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

/** Wraps 16 kHz mono PCM chunks in a WAV file. */
export function wavBlob(chunks: Int16Array[], rate = 16000): Blob {
  const samples = chunks.reduce((n, c) => n + c.length, 0);
  const header = new DataView(new ArrayBuffer(44));
  const str = (o: number, s: string) => [...s].forEach((ch, i) => header.setUint8(o + i, ch.charCodeAt(0)));
  str(0, "RIFF");
  header.setUint32(4, 36 + samples * 2, true);
  str(8, "WAVE");
  str(12, "fmt ");
  header.setUint32(16, 16, true);
  header.setUint16(20, 1, true);
  header.setUint16(22, 1, true);
  header.setUint32(24, rate, true);
  header.setUint32(28, rate * 2, true);
  header.setUint16(32, 2, true);
  header.setUint16(34, 16, true);
  str(36, "data");
  header.setUint32(40, samples * 2, true);
  return new Blob([header.buffer, ...chunks.map((c) => c.slice().buffer)], { type: "audio/wav" });
}
