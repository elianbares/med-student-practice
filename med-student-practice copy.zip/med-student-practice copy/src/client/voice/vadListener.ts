// Speech detection for browsers without built-in speech recognition (e.g. Firefox): finds where the
// clinician starts and stops talking, then sends that clip to the server to be transcribed.
import type { ListenerHandlers } from "./listener";
import { Mic, wavBlob } from "./mic";

const START_FRAMES = 2; // 200 ms above threshold
const END_FRAMES = 9; // 900 ms of quiet ends a turn
const PRE_ROLL = 3;
const MAX_FRAMES = 300; // 30 s

export class VadListener {
  private unsub: (() => void) | null = null;
  private noise = 0.01;
  private loud = 0;
  private quiet = 0;
  private speaking = false;
  private clip: Int16Array[] = [];
  private pre: Int16Array[] = [];
  private startedAt = 0;
  private busy = false;

  constructor(
    private mic: Mic,
    private encounterId: string,
    private h: ListenerHandlers,
  ) {}

  start() {
    if (this.unsub) return;
    this.unsub = this.mic.on((pcm, rms) => this.frame(pcm, rms));
    this.h.onListening(true);
  }

  pause() {
    this.unsub?.();
    this.unsub = null;
    this.speaking = false;
    this.clip = [];
    this.h.onInterim("");
    this.h.onListening(false);
  }

  stop() {
    this.pause();
  }

  private frame(pcm: Int16Array, rms: number) {
    if (this.busy) return;
    if (!this.speaking) this.noise = this.noise * 0.95 + Math.min(rms, 0.05) * 0.05;
    const threshold = Math.max(0.012, this.noise * 3);
    if (!this.speaking) {
      this.pre.push(pcm);
      if (this.pre.length > PRE_ROLL) this.pre.shift();
      this.loud = rms > threshold ? this.loud + 1 : 0;
      if (this.loud >= START_FRAMES) {
        this.speaking = true;
        this.startedAt = Date.now() - this.pre.length * 100;
        this.clip = [...this.pre];
        this.quiet = 0;
        this.h.onInterim("Listening…");
      }
      return;
    }
    this.clip.push(pcm);
    this.quiet = rms > threshold ? 0 : this.quiet + 1;
    if (this.quiet >= END_FRAMES || this.clip.length >= MAX_FRAMES) void this.finish();
  }

  private async finish() {
    this.speaking = false;
    const clip = this.clip;
    this.clip = [];
    if (clip.length < START_FRAMES + END_FRAMES + 2) {
      this.h.onInterim("");
      return;
    }
    this.busy = true;
    this.h.onInterim("Transcribing…");
    try {
      const res = await fetch(`/api/encounters/${this.encounterId}/stt`, {
        method: "POST",
        headers: { "content-type": "audio/wav", "x-requested-with": "apa" },
        body: wavBlob(clip),
        credentials: "same-origin",
      });
      const data = (await res.json().catch(() => ({}))) as { text?: string; error?: string };
      this.h.onInterim("");
      if (!res.ok) this.h.onError(data.error ?? "Couldn't transcribe that. Please try again or type.", false);
      else if (data.text?.trim()) this.h.onFinal(data.text.trim(), this.startedAt);
    } catch {
      this.h.onInterim("");
      this.h.onError("Couldn't reach the server to transcribe. Check your connection or type instead.", false);
    } finally {
      this.busy = false;
    }
  }
}
