import type { MouseEvent } from "react";
import { Link, NavLink, Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { LogOut } from "lucide-react";
import { api } from "./api";
import { Initials, RequireRole, confirmDiscard, homeFor, signInPath, useAuth, useLoad } from "./ui";
import { Footer, Wordmark } from "./components/Visuals";
import { JoinPage, Landing, ResetPassword, SignIn, SignUp } from "./pages/Public";
import { PrivacyPage } from "./pages/Privacy";
import { History, Settings, StudentCourse, StudentHome } from "./pages/Student";
import { EncounterPage } from "./pages/Encounter";
import { FeedbackPage } from "./pages/Feedback";
import { EducatorHome } from "./pages/educator/Home";
import { CourseManage } from "./pages/educator/CourseManage";
import { Library } from "./pages/educator/Library";
import { ProfileEditor } from "./pages/educator/ProfileEditor";
import { ConfigEditor } from "./pages/educator/ConfigEditor";
import { CaseEditor } from "./pages/educator/CaseEditor";
import { Admin } from "./pages/educator/Admin";

/**
 * Leaving through the nav asks first while a form on the page has unsaved changes (see useUnsavedChanges).
 * Runs before the link navigates; a click that opens a new tab leaves the page alone.
 */
const guardLeave = (e: MouseEvent) => {
  if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  if ((e.target as Element).closest("a[href]") && !confirmDiscard()) e.preventDefault();
};

/** The first focusable element on every page; moves keyboard focus past the nav. */
function SkipLink() {
  const skip = (e: MouseEvent<HTMLAnchorElement>) => {
    const main = document.getElementById("main");
    if (!main) return;
    e.preventDefault();
    main.focus();
  };
  return (
    <a className="skip-link" href="#main" onClick={skip}>
      Skip to content
    </a>
  );
}

function NavBar() {
  const { user, setUser } = useAuth();
  const navigate = useNavigate();
  const { pathname, search } = useLocation();
  // From a join link (or the sign-up it leads to), signing in should still end in that course.
  const joinCode = pathname.startsWith("/join/") ? pathname.slice(6) : new URLSearchParams(search).get("join");
  const notes = useLoad(() => (user ? api<{ read: number }[]>("/me/notifications") : Promise.resolve([])), [user?.id]);
  const unread = notes.data?.filter((n) => !n.read).length ?? 0;
  const signOut = async () => {
    if (!confirmDiscard()) return;
    await api("/auth/signout", { method: "POST", body: {} }).catch(() => undefined);
    setUser(null);
    navigate("/");
  };
  const educator = user && user.role !== "student";
  return (
    <header className="navbar no-print">
      <div className={`navbar-inner${user ? " has-nav" : ""}`}>
        <Link to={user ? homeFor(user.role) : "/"} className="brandlink" aria-label="Home" onClick={guardLeave}>
          <Wordmark />
        </Link>
        {user && (
          <nav className="nav" aria-label="Main" onClickCapture={guardLeave}>
            {!educator ? (
              <>
                <NavLink to="/home">Home</NavLink>
                <NavLink to="/history">
                  Progress
                  {unread > 0 && <span className="count">{unread} new</span>}
                </NavLink>
                <NavLink to="/settings">Settings</NavLink>
              </>
            ) : (
              <>
                <NavLink to="/educator" end>
                  Courses
                </NavLink>
                <NavLink to="/educator/library">Library</NavLink>
                <NavLink to="/settings">Settings</NavLink>
                {user.role === "admin" && <NavLink to="/admin">Admin</NavLink>}
              </>
            )}
          </nav>
        )}
        <div className="userbox">
          {user ? (
            <>
              <Initials name={user.name} />
              <span className="who small" title={user.name}>
                {user.name}
              </span>
              <button type="button" className="btn ghost icon small" onClick={() => void signOut()} aria-label="Sign out" title="Sign out">
                <LogOut size={17} />
              </button>
            </>
          ) : (
            <>
              <Link className="btn small ghost hide-phone" to={joinCode ? signInPath(`/join/${joinCode}`) : "/signin"}>
                Sign in
              </Link>
              <Link className="btn small primary" to={joinCode ? `/signup?join=${encodeURIComponent(joinCode)}` : "/signup"}>
                Get started
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

export function App() {
  const { user, loading } = useAuth();
  const { pathname } = useLocation();
  const edu = ["educator", "admin"] as const;
  // Public pages render their own footer; the live encounter is full-height and has none.
  const ownFooter = ["/", "/signin", "/signup", "/reset", "/privacy"].includes(pathname) || pathname.startsWith("/join/");
  const showFooter = Boolean(user) && !/^\/encounter\/[^/]+$/.test(pathname) && !ownFooter;
  return (
    <>
      <SkipLink />
      <NavBar />
      {/* Pages render their own <main>; this wrapper is the skip link's target. */}
      <div id="main" tabIndex={-1}>
        <Routes>
          <Route path="/" element={loading ? null : user ? <Navigate to={homeFor(user.role)} replace /> : <Landing />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/reset" element={<ResetPassword />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/join/:code" element={<JoinPage />} />

          <Route path="/home" element={<RequireRole roles={["student"]}><StudentHome /></RequireRole>} />
          <Route path="/courses/:id" element={<RequireRole><StudentCourse /></RequireRole>} />
          <Route path="/history" element={<RequireRole><History /></RequireRole>} />
          <Route path="/settings" element={<RequireRole><Settings /></RequireRole>} />
          <Route path="/encounter/:id" element={<RequireRole><EncounterPage /></RequireRole>} />
          <Route path="/encounter/:id/feedback" element={<RequireRole><FeedbackPage /></RequireRole>} />

          <Route path="/educator" element={<RequireRole roles={[...edu]}><EducatorHome /></RequireRole>} />
          <Route path="/educator/courses/:id" element={<RequireRole roles={[...edu]}><CourseManage /></RequireRole>} />
          <Route path="/educator/library" element={<RequireRole roles={[...edu]}><Library /></RequireRole>} />
          <Route path="/educator/profiles/:id" element={<RequireRole roles={[...edu]}><ProfileEditor /></RequireRole>} />
          <Route path="/educator/configs/:id" element={<RequireRole roles={[...edu]}><ConfigEditor /></RequireRole>} />
          <Route path="/educator/cases/:id" element={<RequireRole roles={[...edu]}><CaseEditor /></RequireRole>} />
          <Route path="/admin" element={<RequireRole roles={["admin"]}><Admin /></RequireRole>} />

          <Route
            path="*"
            element={
              <main className="page narrow">
                <h1>Page not found</h1>
                <p className="muted">The link may be old, or the page was moved.</p>
                <Link to="/">Go home</Link>
              </main>
            }
          />
        </Routes>
      </div>
      {showFooter && <Footer />}
    </>
  );
}
