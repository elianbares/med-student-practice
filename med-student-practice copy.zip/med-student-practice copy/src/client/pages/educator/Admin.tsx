import type { AiStatus, CapacityInfo } from "../../../shared/types";
import { sentenceCase } from "../../../shared/defaults";
import { api } from "../../api";
import { ErrorNote, Flash, Loaded, Loading, PageHeader, useAction, useFlash, useLoad } from "../../ui";
import { Stat } from "../../components/Visuals";

interface Status {
  ai: AiStatus;
  configured: { gemini: boolean; groq: boolean; workersAi: boolean; educatorKey: boolean; actorModels?: string; graderModels?: string };
  geminiModels: string[] | string;
  usage: { day: string; provider: string; model: string; task: string; requests: number; errors: number }[];
  counts: { users: number; educators: number; encounters: number; courses: number };
}

/** Plain names for the AI jobs the server counts. */
const JOBS: Record<string, string> = {
  actor: "Patient replies",
  grader: "Feedback reports",
  assistant: "Profile drafts",
  judge: "Key tests",
  tts: "Natural voice clips",
  stt: "Transcriptions",
  live: "Emotive voice sessions",
  prosody: "Voice analyses",
};
const jobLabel = (task: string) => JOBS[task] ?? sentenceCase(task);

const PROVIDERS: Record<string, string> = { gemini: "Google", groq: "Groq", "workers-ai": "Cloudflare Workers AI", demo: "Demo AI" };
const providerLabel = (p: string) => PROVIDERS[p] ?? p;

const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? "" : "s"}`;

/** What the free AI can take on, from GET /api/admin/capacity. On the Admin page and in each course's settings. */
export function CapacityPanel({ cap }: { cap: CapacityInfo }) {
  const { platform, courses, students } = cap.keys;
  const keys = (platform ? 1 : 0) + courses + students;
  const requests = cap.today.reduce((n, t) => n + t.requests, 0);
  const failed = cap.today.reduce((n, t) => n + t.errors, 0);
  // The table already lists today's numbers, so the guidance line that repeats them is left out.
  const guidance = cap.today.length ? cap.guidance.filter((g) => !g.startsWith("So far today")) : cap.guidance;
  return (
    <div className="stack">
      <div className="stats">
        <Stat value={keys} label={`Google key${keys === 1 ? "" : "s"} in use`} />
        <Stat value={requests} label="AI requests today (UTC)" />
        <Stat value={failed} label="Failed today" />
      </div>
      <div className="kv" style={{ marginTop: 32 }}>
        <span className="caption">Site key</span>
        <span>{platform ? "Set" : "Not set"}</span>
        <span className="caption">Course keys</span>
        <span>{courses}</span>
        <span className="caption">Student keys</span>
        <span>{students}</span>
        <span className="caption">Backup AI</span>
        <span>{cap.overflow.length ? cap.overflow.map(providerLabel).join(", then ") : "None. Google models only."}</span>
      </div>
      {cap.today.length > 0 && (
        <div className="list" style={{ marginTop: 32 }}>
          <table className="table">
            <caption className="sr-only">AI requests today by job</caption>
            <thead>
              <tr>
                <th>Job today</th>
                <th className="end">Requests</th>
                <th className="end">Failed</th>
              </tr>
            </thead>
            <tbody>
              {cap.today.map((t) => (
                <tr key={t.task}>
                  <td>{jobLabel(t.task)}</td>
                  <td className="end" data-label="Requests">
                    {t.requests}
                  </td>
                  <td className="end" data-label="Failed">
                    {t.errors}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <h3 style={{ marginTop: 32 }}>What this setup can handle</h3>
      <ul className="stack secondary" style={{ margin: 0, paddingLeft: 20, maxWidth: 712 }}>
        {guidance.map((g) => (
          <li key={g}>{g}</li>
        ))}
      </ul>
    </div>
  );
}

/** Admin switch for the public demo course (code MEDSIM). */
function DemoCourseSwitch({ open, onChange }: { open: boolean; onChange: (open: boolean) => void }) {
  const act = useAction();
  const [flash, showFlash] = useFlash();
  const toggle = (next: boolean) =>
    void act.run(async () => {
      const r = await api<{ demoCourseOpen: boolean }>("/admin/settings", { method: "PUT", body: { demoCourseOpen: next } });
      onChange(r.demoCourseOpen);
      showFlash("Saved");
    });
  return (
    <>
      <ErrorNote error={act.error} />
      <div className="row" style={{ alignItems: "flex-start", flexWrap: "nowrap" }}>
        <label className="check" style={{ marginBottom: 0 }}>
          <input type="checkbox" role="switch" checked={open} disabled={act.busy} onChange={(e) => toggle(e.target.checked)} aria-describedby="demo-course-hint" />
          <span>Demo course open to anyone with code MEDSIM</span>
        </label>
        <Flash text={flash} />
      </div>
      <p id="demo-course-hint" className="small muted" style={{ marginTop: 8, marginLeft: 30 }}>
        While it's closed, no one can join the demo course and its students can't start new encounters, so the shared AI allowance goes to your own courses.
      </p>
    </>
  );
}

export function Admin() {
  const s = useLoad(() => api<Status>("/admin/status"), []);
  const cap = useLoad(() => api<CapacityInfo>("/admin/capacity"), []);
  if (s.loading && !s.data) return <Loading />;
  if (!s.data)
    return (
      <main className="page form">
        <ErrorNote error={s.error} onRetry={() => void s.reload()} />
      </main>
    );
  const d = s.data;
  const wanted = [...(d.configured.actorModels ?? "").split(","), ...(d.configured.graderModels ?? "").split(",")].map((x) => x.trim()).filter((x, i, a) => x && a.indexOf(x) === i);
  const setting = (on: boolean, yes = "Set", no = "Not set") => <span className={`badge ${on ? "" : "mid"}`}>{on ? yes : no}</span>;
  return (
    <main className="page form">
      <PageHeader eyebrow="Admin" title="Platform status" subtitle="AI setup, capacity, model availability and usage." />
      <div className="stats">
        <Stat value={d.counts.users} label={`Users, ${plural(d.counts.educators, "educator")}`} />
        <Stat value={d.counts.courses} label="Courses" />
        <Stat value={d.counts.encounters} label="Encounters" />
      </div>

      <section className="section">
        <h2>Capacity</h2>
        <p className="muted" style={{ marginBottom: 32 }}>
          How many students the current AI setup can serve. All numbers are estimates, because Google sets the free limits.
        </p>
        <Loaded state={cap}>{(c) => <CapacityPanel cap={c} />}</Loaded>
      </section>

      <section className="section">
        <h2>Demo course</h2>
        <Loaded state={cap}>{(c) => <DemoCourseSwitch open={c.demoCourseOpen} onChange={(demoCourseOpen) => cap.setData({ ...c, demoCourseOpen })} />}</Loaded>
      </section>

      <section className="section">
        <h2>Configuration</h2>
        <div className="kv">
          <span className="caption">AI mode</span>
          <span>
            <span className={`badge ${d.ai.mode === "real" ? "" : "mid"}`}>{d.ai.mode === "real" ? "Real AI" : "Demo AI"}</span>{" "}
            <span className="muted small">{d.ai.providers.map(providerLabel).join(", then ")}</span>
          </span>
          <span className="caption">Google key</span>
          <span>{setting(d.configured.gemini)}</span>
          <span className="caption">Groq key</span>
          <span>{setting(d.configured.groq, "Set", "Not set")}</span>
          <span className="caption">Workers AI</span>
          <span>{setting(d.configured.workersAi, "On", "Off")}</span>
          <span className="caption">Educator key</span>
          <span>{setting(d.configured.educatorKey)}</span>
        </div>
      </section>

      <section className="section">
        <h2>Gemini models</h2>
        {typeof d.geminiModels === "string" ? (
          <p className="muted">{d.geminiModels}</p>
        ) : (
          <>
            <p className="muted">The models this site is set to use, and whether the site key can use them.</p>
            <div className="list">
              {wanted.map((m) => (
                <div key={m} className="list-row">
                  <span className="grow truncate" style={{ maxWidth: "none" }}>
                    {m}
                  </span>
                  {(d.geminiModels as string[]).includes(m) ? <span className="badge">Available</span> : <span className="badge low">Not available</span>}
                </div>
              ))}
            </div>
            <details style={{ marginTop: 16 }}>
              <summary className="small">All {d.geminiModels.length} models this key can use</summary>
              <p className="small muted" style={{ marginTop: 8 }}>
                {d.geminiModels.join(", ")}
              </p>
            </details>
          </>
        )}
      </section>

      <section className="section">
        <h2>AI requests, last 7 days</h2>
        {d.usage.length ? (
          <div className="list scroll-x">
            <table className="table">
              <thead>
                <tr>
                  <th>Day</th>
                  <th>Job</th>
                  <th>Model</th>
                  <th className="end">Requests</th>
                  <th className="end">Failed</th>
                </tr>
              </thead>
              <tbody>
                {d.usage.map((u, i) => (
                  <tr key={i}>
                    <td className="nowrap">{u.day}</td>
                    <td>{jobLabel(u.task)}</td>
                    <td>
                      <span className="truncate" title={`${providerLabel(u.provider)}: ${u.model}`}>
                        {u.model}
                      </span>
                    </td>
                    <td className="end" data-label="Requests">
                      {u.requests}
                    </td>
                    <td className="end" data-label="Failed">
                      {u.errors}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="muted">No AI requests yet. The demo AI isn't counted.</p>
        )}
      </section>
    </main>
  );
}
