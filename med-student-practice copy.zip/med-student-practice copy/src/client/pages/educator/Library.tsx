import { useState, type ReactNode } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import type { CaseItem, ConfigData, LibraryItem, ProfileData } from "../../../shared/types";
import { lookOf, patientLabel } from "../../../shared/defaults";
import { api } from "../../api";
import { ErrorNote, Loaded, Modal, PageHeader, TabPanel, Tabs, useAction, useLoad } from "../../ui";
import { Avatar } from "../../components/Avatar";

import { LANGUAGES } from "../../../shared/languages";

type Tab = "cases" | "profiles" | "configs";

const TABS: { id: Tab; label: string }[] = [
  { id: "cases", label: "Cases" },
  { id: "profiles", label: "Patient profiles" },
  { id: "configs", label: "Configurations" },
];

export function Library() {
  const [params, setParams] = useSearchParams();
  const tab = TABS.find((t) => t.id === params.get("tab"))?.id ?? "cases";
  return (
    <main className="page">
      <PageHeader
        eyebrow="Library"
        title="Cases, patients and rubrics"
        subtitle="A case pairs a patient profile (who the patient is) with one or more configurations (tasks, rubric and role-play rules). Public items are shared templates you can copy."
      />
      <Tabs<Tab> idBase="library" label="Library sections" value={tab} onChange={(t) => setParams({ tab: t }, { replace: true })} tabs={TABS} />
      <TabPanel idBase="library" id={tab}>
        {tab === "cases" && <CasesTab />}
        {tab === "profiles" && <ItemsTab kind="profiles" />}
        {tab === "configs" && <ItemsTab kind="configs" />}
      </TabPanel>
    </main>
  );
}

/** A titled group of cards; groups sit 48 px apart inside .stack.loose. */
function Group({ title, empty, children }: { title: string; empty: string; children: ReactNode[] }) {
  return (
    <section>
      <h2>{title}</h2>
      {children.length ? <div className="grid">{children}</div> : <p className="muted">{empty}</p>}
    </section>
  );
}

function CasesTab() {
  const navigate = useNavigate();
  const list = useLoad(() => api<CaseItem[]>("/library/cases"), []);
  const [testing, setTesting] = useState<CaseItem | null>(null);
  const act = useAction();
  const remove = (c: CaseItem) =>
    confirm(`Delete the case "${c.name}"? This can't be undone.`) && void act.run(async () => (await api(`/library/cases/${c.id}`, { method: "DELETE" }), list.reload()));
  const card = (c: CaseItem) => (
    <div key={c.id} className="card case-card">
      <div className="who">
        {c.look && <Avatar look={c.look} size={56} />}
        <div style={{ minWidth: 0 }}>
          <h3 style={{ margin: 0 }}>{c.name}</h3>
          <div className="small muted">{c.profileName}</div>
        </div>
      </div>
      {c.description && (
        <p className="small muted" style={{ margin: 0 }}>
          {c.description}
        </p>
      )}
      <div className="row tight">
        {c.configNames?.map((n) => (
          <span key={n} className="badge">
            {n}
          </span>
        ))}
      </div>
      <div className="row foot" style={{ justifyContent: "flex-start" }}>
        <button className="btn small" onClick={() => setTesting(c)}>
          Try it
        </button>
        {c.mine && (
          <Link className="btn small" to={`/educator/cases/${c.id}`}>
            Edit
          </Link>
        )}
        {c.mine && (
          <button className="btn small danger" disabled={act.busy} onClick={() => remove(c)}>
            Delete
          </button>
        )}
      </div>
    </div>
  );
  return (
    <div className="stack loose">
      <div className="stack">
        <ErrorNote error={act.error} />
        <div className="row">
          <button className="btn primary" onClick={() => navigate("/educator/cases/new")}>
            New case
          </button>
        </div>
      </div>
      <Loaded state={list}>
        {(cases) => (
          <div className="stack loose">
            <Group title="My cases" empty="No cases yet. A case pairs a patient profile with one or more configurations.">
              {cases.filter((c) => c.mine).map(card)}
            </Group>
            <Group title="Public cases" empty="No public cases yet.">
              {cases.filter((c) => !c.mine).map(card)}
            </Group>
          </div>
        )}
      </Loaded>
      {testing && <PlaygroundModal kase={testing} onClose={() => setTesting(null)} />}
    </div>
  );
}

function PlaygroundModal({ kase, onClose }: { kase: CaseItem; onClose: () => void }) {
  const navigate = useNavigate();
  const [configId, setConfigId] = useState(kase.configIds[0] ?? "");
  const [mode, setMode] = useState("text");
  const [language, setLanguage] = useState("en-US");
  const { busy, error, run } = useAction();
  return (
    <Modal title={`Try “${kase.name}”`} onClose={onClose} closable={!busy}>
      <p className="muted small">Run the case yourself, exactly as a student would. Test runs aren't part of any course.</p>
      <ErrorNote error={error} />
      <label className="field">
        Configuration
        <select value={configId} onChange={(e) => setConfigId(e.target.value)}>
          {kase.configIds.map((id, i) => (
            <option key={id} value={id}>
              {kase.configNames?.[i] ?? id}
            </option>
          ))}
        </select>
      </label>
      <div className="grid-2">
        <label className="field">
          Mode
          <select value={mode} onChange={(e) => setMode(e.target.value)}>
            <option value="text">Text</option>
            <option value="voice">Voice</option>
            <option value="emotive">Emotive voice</option>
          </select>
        </label>
        <label className="field">
          Language
          <select value={language} onChange={(e) => setLanguage(e.target.value)}>
            {LANGUAGES.map((l) => (
              <option key={l.code} value={l.code}>
                {l.name}
              </option>
            ))}
          </select>
        </label>
      </div>
      <button
        className="btn primary block"
        disabled={busy}
        onClick={() => void run(async () => navigate(`/encounter/${(await api<{ id: string }>(`/library/cases/${kase.id}/playground`, { body: { configId, mode, language } })).id}`))}
      >
        {busy ? "Starting" : "Start test encounter"}
      </button>
    </Modal>
  );
}

function ItemsTab({ kind }: { kind: "profiles" | "configs" }) {
  const navigate = useNavigate();
  const path = kind === "profiles" ? "/library/profiles" : "/library/configurations";
  const list = useLoad(() => api<LibraryItem<ProfileData | ConfigData>[]>(path), [path]);
  const act = useAction();
  const editPath = (id: string) => `/educator/${kind}/${id}`;
  const what = kind === "profiles" ? "patient profile" : "configuration";
  const copy = (id: string) => void act.run(async () => navigate(editPath((await api<LibraryItem<unknown>>(`${path}/${id}/copy`, { body: {} })).id)));
  const remove = (it: LibraryItem<unknown>) =>
    confirm(`Delete the ${what} "${it.name}"? This can't be undone.`) && void act.run(async () => (await api(`${path}/${it.id}`, { method: "DELETE" }), list.reload()));
  const describe = (it: LibraryItem<ProfileData | ConfigData>) => {
    if (kind === "profiles") {
      const p = it.data as ProfileData;
      return (
        <>
          <div className="row" style={{ flexWrap: "nowrap", margin: "8px 0" }}>
            <Avatar look={lookOf(p)} size={48} />
            <span className="small">{patientLabel(p)}</span>
          </div>
          {p.chiefComplaint && <p className="small muted">“{p.chiefComplaint}”</p>}
          {p.diagnosis && (
            <p className="small">
              <strong>Diagnosis:</strong> {p.diagnosis}
            </p>
          )}
        </>
      );
    }
    const c = it.data as ConfigData;
    const categories = c.rubric.length;
    const tasks = c.encounterTasks.length;
    return (
      <>
        {c.contextGoal && (
          <p className="small muted">
            {c.contextGoal.slice(0, 140)}
            {c.contextGoal.length > 140 ? "…" : ""}
          </p>
        )}
        <p className="small">
          {[
            `${categories} rubric ${categories === 1 ? "category" : "categories"}`,
            `${tasks} task${tasks === 1 ? "" : "s"}`,
            c.diagnosisType === "diagnosis" ? "diagnosis required" : "no diagnosis",
            c.notesFeedback.enabled ? "notes feedback" : "",
            c.testOrdering === "menu" ? "tests as a menu" : "",
          ]
            .filter(Boolean)
            .join(" · ")}
        </p>
      </>
    );
  };
  const card = (it: LibraryItem<ProfileData | ConfigData>) => (
    <div key={it.id} className="card">
      <div className="row spread" style={{ flexWrap: "nowrap", alignItems: "flex-start" }}>
        <h3 style={{ margin: 0, minWidth: 0 }}>{it.name}</h3>
        {it.isPublic && <span className="badge">Public</span>}
      </div>
      {describe(it)}
      <div className="row">
        {it.mine ? (
          <>
            <Link className="btn small" to={editPath(it.id)}>
              Edit
            </Link>
            <button className="btn small danger" disabled={act.busy} onClick={() => remove(it)}>
              Delete
            </button>
          </>
        ) : (
          <>
            <Link className="btn small" to={editPath(it.id)}>
              View
            </Link>
            <button className="btn small" disabled={act.busy} onClick={() => copy(it.id)}>
              Copy to my library
            </button>
          </>
        )}
      </div>
    </div>
  );
  return (
    <div className="stack loose">
      <div className="stack">
        <ErrorNote error={act.error} />
        <div className="row">
          <button className="btn primary" onClick={() => navigate(editPath("new"))}>
            New {what}
          </button>
        </div>
      </div>
      <Loaded state={list}>
        {(items) => (
          <div className="stack loose">
            <Group title={kind === "profiles" ? "My patient profiles" : "My configurations"} empty={`No ${what}s yet.`}>
              {items.filter((x) => x.mine).map(card)}
            </Group>
            <Group title="Public templates" empty="No public templates yet.">
              {items.filter((x) => !x.mine).map(card)}
            </Group>
          </div>
        )}
      </Loaded>
    </div>
  );
}
