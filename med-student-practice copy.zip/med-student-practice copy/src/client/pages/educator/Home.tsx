import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Check, ChevronRight } from "lucide-react";
import type { CaseItem, ConfigData, Course, LibraryItem, ProfileData } from "../../../shared/types";
import { ApiError, api } from "../../api";
import { DemoBanner, EmptyState, ErrorNote, FieldError, Loading, Modal, PageHeader, greeting, invalidProps, shortName, useAction, useAuth, useLoad } from "../../ui";
import { COURSE_COLOR_KEYS, courseColor, courseColorLabel } from "../../components/Visuals";

export function EducatorHome() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  // A message from the page that sent us here (such as "Deleted the course ..."), kept until the next visit.
  const [notice, setNotice] = useState(() => (location.state as { notice?: string } | null)?.notice ?? "");
  useEffect(() => {
    if (location.state) navigate(location.pathname, { replace: true, state: null });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const courses = useLoad(() => api<Course[]>("/courses"), []);
  const lib = useLoad(
    async () => ({
      profiles: await api<LibraryItem<ProfileData>[]>("/library/profiles"),
      configs: await api<LibraryItem<ConfigData>[]>("/library/configurations"),
      cases: await api<CaseItem[]>("/library/cases"),
    }),
    [],
  );
  const [creating, setCreating] = useState(false);
  if (courses.loading) return <Loading />;
  const live = (courses.data ?? []).filter((c) => !c.archived);
  const students = live.reduce((n, c) => n + (c.studentCount ?? 0), 0);
  const steps = [
    { done: Boolean(lib.data?.profiles.some((p) => p.mine)), label: "Create a patient profile", hint: "The assistant can draft one from a diagnosis.", to: "/educator/profiles/new" },
    { done: Boolean(lib.data?.configs.some((c) => c.mine)), label: "Create a configuration", hint: "Tasks and rubric. You can copy a public template.", to: "/educator/configs/new" },
    { done: Boolean(lib.data?.cases.some((c) => c.mine)), label: "Pair them into a case", hint: "One patient with one or more configurations.", to: "/educator/cases/new" },
    { done: live.some((c) => (c.caseCount ?? 0) > 0), label: "Add the case to a course", hint: "Then share the six-character code with students.", to: "" },
  ];
  const allDone = steps.every((s) => s.done);
  return (
    <main className="page">
      <PageHeader
        eyebrow="Educator"
        title={`${greeting()}, ${shortName(user?.name ?? "")}`}
        subtitle={`${live.length} active course${live.length === 1 ? "" : "s"}, ${students} student${students === 1 ? "" : "s"} enrolled.`}
        actions={
          <>
            <Link className="btn" to="/educator/library">
              Library
            </Link>
            <button className="btn primary" onClick={() => setCreating(true)}>
              New course
            </button>
          </>
        }
      />
      <DemoBanner />
      {notice && (
        <div className="notice ok row spread" role="status" style={{ marginBottom: 24 }}>
          <span>{notice}</span>
          <button className="btn ghost small" onClick={() => setNotice("")}>
            Dismiss
          </button>
        </div>
      )}
      <ErrorNote error={courses.error} />

      <h2>Courses</h2>
      {courses.data?.length ? (
        <div className="list" style={{ marginTop: 16 }}>
          {courses.data.map((c) => (
            <Link key={c.id} className="list-row" to={`/educator/courses/${c.id}`}>
              <span className="color-bar" style={{ background: courseColor(c.banner) }} />
              <div className="grow">
                <div className="headline" style={{ margin: 0 }}>
                  {c.name} {c.archived && <span className="badge">Archived</span>}
                </div>
                <div className="muted tiny">
                  {c.studentCount} student{c.studentCount === 1 ? "" : "s"}, {c.caseCount} case{c.caseCount === 1 ? "" : "s"}
                </div>
              </div>
              <span className="code muted tiny">{c.code}</span>
              <ChevronRight size={18} className="chev" />
            </Link>
          ))}
        </div>
      ) : (
        <EmptyState title="No courses yet" action={<button className="btn primary" onClick={() => setCreating(true)}>Create your first course</button>}>
          A course groups cases for a cohort and gives students a six-character code to join.
        </EmptyState>
      )}

      {!allDone && (
        <section className="section split">
          <div>
            <h2>Getting started</h2>
            <p className="muted small">Tip: make a separate student account and join your own course to see exactly what students see.</p>
          </div>
          <div className="list">
            {steps.map((s, i) =>
              s.to && !s.done ? (
                <Link key={s.label} className="list-row" to={s.to}>
                  <span className="muted" style={{ width: 20, fontFamily: "var(--font-display)", fontSize: 18 }}>
                    {i + 1}
                  </span>
                  <div className="grow">
                    <div>{s.label}</div>
                    <div className="muted tiny">{s.hint}</div>
                  </div>
                  <ChevronRight size={18} className="chev" />
                </Link>
              ) : (
                <div key={s.label} className="list-row">
                  <span style={{ width: 20 }}>{s.done ? <Check size={18} color="var(--good)" /> : <span className="muted" style={{ fontFamily: "var(--font-display)", fontSize: 18 }}>{i + 1}</span>}</span>
                  <div className="grow">
                    <div className={s.done ? "muted" : ""}>{s.label}</div>
                    <div className="muted tiny">{s.hint}</div>
                  </div>
                </div>
              ),
            )}
          </div>
        </section>
      )}
      {creating && <CreateCourse onClose={() => setCreating(false)} onCreated={(id) => navigate(`/educator/courses/${id}`)} />}
    </main>
  );
}

export function BannerPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="swatches" role="radiogroup" aria-label="Course color">
      {COURSE_COLOR_KEYS.map((k) => (
        <button
          key={k}
          type="button"
          role="radio"
          aria-checked={value === k}
          aria-label={courseColorLabel(k)}
          title={courseColorLabel(k)}
          className={`swatch-btn ${value === k ? "on" : ""}`}
          style={{ background: courseColor(k) }}
          onClick={() => onChange(k)}
        />
      ))}
    </div>
  );
}

function CreateCourse({ onClose, onCreated }: { onClose: () => void; onCreated: (id: string) => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [banner, setBanner] = useState("teal");
  const [errors, setErrors] = useState<{ name?: string; description?: string }>({});
  const { busy, error, run } = useAction();
  const create = () =>
    void run(async () => {
      setErrors({});
      try {
        onCreated((await api<Course>("/courses", { body: { name, description, banner } })).id);
      } catch (e) {
        // Name and description problems show under the field, with what was typed left in place.
        if (!(e instanceof ApiError && e.status === 400 && /name|description/i.test(e.message))) throw e;
        const field = /description/i.test(e.message) ? "description" : "name";
        setErrors({ [field]: e.message });
        requestAnimationFrame(() => document.getElementById(`new-course-${field}`)?.focus());
      }
    });
  return (
    <Modal title="New course" onClose={onClose} closable={!busy}>
      <ErrorNote error={error} />
      <label className="field">
        Name
        <input
          id="new-course-name"
          type="text"
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            setErrors((x) => ({ ...x, name: undefined }));
          }}
          autoFocus
          placeholder="For example, Clinical skills 1"
          {...invalidProps("new-course-name-error", errors.name)}
        />
        <FieldError id="new-course-name-error">{errors.name}</FieldError>
      </label>
      <label className="field">
        Description
        <span className="hint">Students see this on the course page.</span>
        <textarea
          id="new-course-description"
          value={description}
          onChange={(e) => {
            setDescription(e.target.value);
            setErrors((x) => ({ ...x, description: undefined }));
          }}
          {...invalidProps("new-course-description-error", errors.description)}
        />
        <FieldError id="new-course-description-error">{errors.description}</FieldError>
      </label>
      <div className="field">
        Color
        <BannerPicker value={banner} onChange={setBanner} />
      </div>
      <button className="btn primary lg block" disabled={busy || !name.trim()} onClick={create}>
        {busy ? "Creating" : "Create course"}
      </button>
    </Modal>
  );
}
