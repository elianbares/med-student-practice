import { useEffect, useRef, useState, type ReactNode, type TextareaHTMLAttributes } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Copy, Trash2, Volume2, X } from "lucide-react";
import type { Appearance, Level3, LibraryItem, ProfileData, TestItem } from "../../../shared/types";
import { EMOTIONS, LIVE_VOICES, LOOK_OPTIONS, TEST_CATEGORIES, canonicalCategory, emptyProfile, lookOf } from "../../../shared/defaults";
import { ApiError, api } from "../../api";
import { Avatar, EMOTION_LABEL } from "../../components/Avatar";
import { ErrorNote, FieldError, Flash, Loading, confirmDiscard, invalidProps, useAction, useAutoGrow, useFlash, useUnsavedChanges } from "../../ui";
import { previewVoice } from "../../voice/speaker";

type Section = { id: string; label: string; done: (p: ProfileData) => boolean };

const SECTIONS: Section[] = [
  { id: "demographics", label: "Patient demographics", done: (p) => Boolean(p.demographics.name && p.demographics.age && p.demographics.sex) },
  { id: "start", label: "Start of the visit", done: (p) => Boolean(p.chiefComplaint) },
  { id: "voice", label: "Appearance and voice", done: () => true },
  { id: "diagnosis", label: "Diagnosis", done: (p) => Boolean(p.diagnosis) },
  { id: "hpi", label: "History of present illness", done: (p) => Boolean(p.hpi) },
  { id: "pmh", label: "Past medical history", done: (p) => Boolean(p.pmh) },
  { id: "meds", label: "Medications and allergies", done: (p) => Boolean(p.medsAllergies) },
  { id: "fh", label: "Family history", done: (p) => Boolean(p.familyHistory) },
  { id: "sh", label: "Social history and habits", done: (p) => Boolean(p.socialHistory) },
  { id: "ros", label: "Review of systems", done: (p) => Boolean(p.ros) },
  { id: "personality", label: "Personality", done: () => true },
  { id: "communication", label: "How the patient communicates", done: (p) => Boolean(p.communication) },
  { id: "other", label: "Other information", done: () => true },
  { id: "tests", label: "Exams and tests", done: (p) => p.tests.length > 0 },
];
const sectionLabel = (id: string) => SECTIONS.find((s) => s.id === id)?.label ?? "";

const BIG5: (keyof Omit<ProfileData["personality"], "notes">)[] = ["openness", "conscientiousness", "extraversion", "agreeableness", "neuroticism"];

type Draft = { name: string; isPublic: boolean; data: ProfileData; mine: boolean };
const toDraft = (it: LibraryItem<ProfileData>): Draft => ({ name: it.name, isPublic: it.isPublic, data: it.data, mine: Boolean(it.mine) });
/** What the editor compares to decide whether there are unsaved changes. */
const snapshot = (d: Draft) => JSON.stringify([d.name.trim(), d.isPublic, d.data]);
/** Moves focus to a field after the error under it has rendered. */
const focusField = (id: string) => requestAnimationFrame(() => document.getElementById(id)?.focus());
const LIBRARY = "/educator/library?tab=profiles";

export function ProfileEditor() {
  const { id } = useParams();
  const isNew = id === "new";
  const navigate = useNavigate();
  const [item, setItem] = useState<Draft | null>(null);
  // The last loaded or saved version; "" for an AI draft, which is unsaved from the start.
  const [baseline, setBaseline] = useState("");
  const [stage, setStage] = useState<"assist" | "edit">(isNew ? "assist" : "edit");
  const [nameError, setNameError] = useState<string | null>(null);
  const [testErrors, setTestErrors] = useState<Record<string, string>>({});
  const load = useAction();
  const save = useAction();
  const copy = useAction();
  const [flash, showFlash] = useFlash(3000);
  // Set when this page itself moves to a new id (after the first save or a copy), so it doesn't reload.
  const landed = useRef<string | null>(null);
  const dirty = Boolean(item?.mine) && snapshot(item!) !== baseline;
  useUnsavedChanges(dirty);

  useEffect(() => {
    if (isNew || landed.current === id) return;
    void load.run(async () => {
      const next = toDraft(await api<LibraryItem<ProfileData>>(`/library/profiles/${id}`));
      setItem(next);
      setBaseline(snapshot(next));
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (stage === "assist") {
    return (
      <Assistant
        onDraft={(name, data) => {
          setItem({ name, isPublic: false, data, mine: true });
          setBaseline("");
          setStage("edit");
        }}
        onSkip={() => {
          const blank = { name: "New patient", isPublic: false, data: emptyProfile(), mine: true };
          setItem(blank);
          setBaseline(snapshot(blank));
          setStage("edit");
        }}
      />
    );
  }
  if (load.busy || !item)
    return load.error ? (
      <main className="page narrow">
        <ErrorNote error={load.error} />
      </main>
    ) : (
      <Loading />
    );

  const p = item.data;
  const readOnly = !item.mine;
  const set = (patch: Partial<ProfileData>) => setItem({ ...item, data: { ...p, ...patch } });
  const setLook = (patch: Partial<Appearance>) => set({ appearance: { ...p.appearance, ...patch } });
  const leave = () => confirmDiscard(dirty) && navigate(LIBRARY);
  const land = (r: LibraryItem<ProfileData>, replace: boolean) => {
    const next = toDraft(r);
    setItem(next);
    setBaseline(snapshot(next));
    if (r.id !== id) {
      landed.current = r.id;
      navigate(`/educator/profiles/${r.id}`, { replace });
    }
  };
  const doSave = () => {
    setNameError(null);
    // A result without a test name would be dropped by the server, so ask for the name instead.
    const unnamed = p.tests.filter((t) => !t.name.trim() && t.result.trim());
    setTestErrors(Object.fromEntries(unnamed.map((t) => [t.id, "Name this test or remove it."])));
    if (unnamed.length) return focusField(`test-${unnamed[0].id}-name`);
    const data = { ...p, tests: p.tests.filter((t) => t.name.trim() || t.result.trim()) };
    void save.run(async () => {
      const body = { name: item.name, isPublic: item.isPublic, data };
      try {
        const r = isNew ? await api<LibraryItem<ProfileData>>("/library/profiles", { body }) : await api<LibraryItem<ProfileData>>(`/library/profiles/${id}`, { method: "PUT", body });
        land(r, true);
        showFlash("Saved");
      } catch (e) {
        // Name problems show under the name, with what was typed left in place.
        if (!(e instanceof ApiError && e.status === 400 && /name/i.test(e.message))) throw e;
        setNameError(e.message);
        focusField("profile-name");
      }
    });
  };
  const copyToEdit = () =>
    void copy.run(async () => {
      land(await api<LibraryItem<ProfileData>>(`/library/profiles/${id}/copy`, { body: {} }), false);
      showFlash("Copied to your library. You can edit it now.");
    });

  /** A section whose heading labels its one text box. */
  const textSection = (s: string, key: keyof ProfileData, hint?: string, rows = 4, extra?: ReactNode) => (
    <section id={s} className="editor-section">
      <h2 id={`${s}-title`}>{sectionLabel(s)}</h2>
      {hint && (
        <p id={`${s}-hint`} className="small muted" style={{ marginTop: -16 }}>
          {hint}
        </p>
      )}
      <GrowText
        rows={rows}
        value={p[key] as string}
        readOnly={readOnly}
        onChange={(e) => set({ [key]: e.target.value } as Partial<ProfileData>)}
        aria-labelledby={`${s}-title`}
        aria-describedby={hint ? `${s}-hint` : undefined}
      />
      {extra}
    </section>
  );
  const sec = (s: string, children: ReactNode) => (
    <section id={s} className="editor-section">
      <h2>{sectionLabel(s)}</h2>
      {children}
    </section>
  );
  const voiceSelect = <K extends "gender" | "age">(k: K, label: string, options: [ProfileData["voice"][K], string][]) => (
    <label className="field">
      {label}
      <select disabled={readOnly} value={p.voice[k]} onChange={(e) => set({ voice: { ...p.voice, [k]: e.target.value } })}>
        {options.map(([v, l]) => (
          <option key={v} value={v}>
            {l}
          </option>
        ))}
      </select>
    </label>
  );
  const lookSelect = (k: "top" | "facialHair" | "accessories", label: string) => (
    <label className="field">
      {label}
      <select disabled={readOnly} value={p.appearance[k]} onChange={(e) => setLook({ [k]: e.target.value })}>
        <option value="">Auto</option>
        {LOOK_OPTIONS[k].map(([v, l]) => (
          <option key={v} value={v}>
            {l}
          </option>
        ))}
      </select>
    </label>
  );

  return (
    <main className="page">
      <div className="sticky-actions row spread" style={{ alignItems: "flex-start" }}>
        <div style={{ flex: 1, minWidth: 220 }}>
          <input
            id="profile-name"
            type="text"
            value={item.name}
            readOnly={readOnly}
            onChange={(e) => {
              setItem({ ...item, name: e.target.value });
              setNameError(null);
            }}
            aria-label="Profile name"
            style={{ fontWeight: 700, fontSize: 17 }}
            {...invalidProps("profile-name-error", nameError)}
          />
          <FieldError id="profile-name-error">{nameError}</FieldError>
        </div>
        <div className="row tight">
          <Flash text={flash} />
          {readOnly ? (
            <>
              <span className="muted small hide-phone">Public template, read only</span>
              <button className="btn primary" onClick={copyToEdit} disabled={copy.busy}>
                <Copy size={16} /> {copy.busy ? "Copying" : "Copy to edit"}
              </button>
            </>
          ) : (
            <>
              <label className="check" style={{ margin: 0 }}>
                <input type="checkbox" checked={item.isPublic} onChange={(e) => setItem({ ...item, isPublic: e.target.checked })} />
                <span className="small">Share as public template</span>
              </label>
              <button className="btn primary" onClick={doSave} disabled={save.busy || !(dirty || isNew)}>
                {save.busy ? "Saving" : "Save"}
              </button>
            </>
          )}
          <button className="btn ghost" onClick={leave} aria-label="Close">
            <X size={18} />
            <span className="hide-phone">Close</span>
          </button>
        </div>
      </div>
      <ErrorNote error={save.error ?? copy.error} />
      {readOnly && (
        <div className="notice info" style={{ marginBottom: 32 }}>
          This is a public template, so it's read only here. Choose Copy to edit to put your own copy in your library and change it there.
        </div>
      )}
      <div className="editor">
        <nav className="section-nav" aria-label="Sections">
          {SECTIONS.map((s) => (
            <a key={s.id} href={`#${s.id}`}>
              {s.label} {s.done(p) ? <span className="done">Done</span> : <span className="todo">To do</span>}
            </a>
          ))}
        </nav>
        <div style={{ minWidth: 0 }}>
          {sec(
            "demographics",
            <>
              <div className="grid-2">
                {(
                  [
                    ["name", "Name", "For example, Maria Lopez"],
                    ["age", "Age", "For example, 58"],
                    ["sex", "Sex", "For example, Female"],
                    ["occupation", "Occupation", "For example, School bus driver"],
                  ] as const
                ).map(([k, label, example]) => (
                  <label key={k} className="field">
                    {label}
                    <input
                      type="text"
                      readOnly={readOnly}
                      value={p.demographics[k]}
                      placeholder={readOnly ? undefined : example}
                      onChange={(e) => set({ demographics: { ...p.demographics, [k]: e.target.value } })}
                    />
                  </label>
                ))}
              </div>
              <label className="field">
                Other details (optional)
                <input
                  type="text"
                  readOnly={readOnly}
                  value={p.demographics.other}
                  onChange={(e) => set({ demographics: { ...p.demographics, other: e.target.value } })}
                  placeholder={readOnly ? undefined : "For example, pronouns, language background, who came with them"}
                />
              </label>
            </>,
          )}
          {sec(
            "start",
            <>
              <label className="field">
                Chief complaint, in the patient's own words
                <span className="hint">Shown to students on the case card.</span>
                <input type="text" readOnly={readOnly} value={p.chiefComplaint} onChange={(e) => set({ chiefComplaint: e.target.value })} placeholder={readOnly ? undefined : "For example, I've had this cough for a week and now I can't catch my breath"} />
              </label>
              <label className="field">
                Door note (optional)
                <span className="hint">Shown on the student's brief before the visit, like the note on an exam room door: the setting and the vital signs.</span>
                <GrowText
                  rows={2}
                  max={240}
                  readOnly={readOnly}
                  value={p.doorNote}
                  onChange={(e) => set({ doorNote: e.target.value })}
                  placeholder={readOnly ? undefined : "For example: Urgent care clinic. BP 126/78, HR 108, T 38.7 °C, RR 24, SpO2 92% on room air."}
                />
              </label>
              <div className="grid-2">
                <label className="field">
                  Starting emotion
                  <span className="hint">How the patient feels as the visit starts. Their face and replies change with the conversation from here.</span>
                  <select disabled={readOnly} value={p.initialEmotion === "neutral" ? "" : p.initialEmotion} onChange={(e) => set({ initialEmotion: e.target.value })}>
                    {EMOTIONS.map((e) => (
                      <option key={e} value={e === "neutral" ? "" : e}>
                        {EMOTION_LABEL[e] ?? e}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="field" aria-hidden="true" style={{ alignSelf: "end" }}>
                  <Avatar look={lookOf(p)} emotion={p.initialEmotion || "neutral"} size={64} />
                </div>
              </div>
            </>,
          )}
          {sec(
            "voice",
            <>
              <div className="row" style={{ alignItems: "flex-start", gap: 24, flexWrap: "wrap" }}>
                <Avatar look={lookOf(p)} emotion="calm" size={120} />
                <div style={{ flex: 1, minWidth: 240 }}>
                  <Swatches label="Skin tone" value={p.appearance.skin} options={LOOK_OPTIONS.skin} disabled={readOnly} onChange={(skin) => setLook({ skin })} />
                  <Swatches label="Hair color" value={p.appearance.hairColor} options={LOOK_OPTIONS.hairColor} disabled={readOnly} onChange={(hairColor) => setLook({ hairColor })} />
                  <div className="grid-2">
                    {lookSelect("top", "Hair style")}
                    {lookSelect("facialHair", "Facial hair")}
                    {lookSelect("accessories", "Glasses")}
                  </div>
                </div>
              </div>
              <span className="eyebrow">Expressions students will see</span>
              <div className="expr-strip" style={{ margin: "8px 0 32px" }}>
                {Object.keys(EMOTION_LABEL).map((e) => (
                  <figure key={e}>
                    <Avatar look={lookOf(p)} emotion={e} size={56} />
                    <figcaption>{EMOTION_LABEL[e]}</figcaption>
                  </figure>
                ))}
              </div>
              <div className="grid-2">
                {voiceSelect("gender", "Voice", [
                  ["female", "Female"],
                  ["male", "Male"],
                  ["neutral", "Neutral"],
                ])}
                {voiceSelect("age", "Age of voice", [
                  ["child", "Child"],
                  ["young", "Young adult"],
                  ["adult", "Adult"],
                  ["older", "Older adult"],
                ])}
                <label className="field">
                  Pitch ({p.voice.pitch.toFixed(2)})
                  <input type="range" min={0.5} max={1.5} step={0.05} disabled={readOnly} value={p.voice.pitch} onChange={(e) => set({ voice: { ...p.voice, pitch: Number(e.target.value) } })} />
                </label>
                <label className="field">
                  Speed ({p.voice.rate.toFixed(2)})
                  <input type="range" min={0.7} max={1.3} step={0.05} disabled={readOnly} value={p.voice.rate} onChange={(e) => set({ voice: { ...p.voice, rate: Number(e.target.value) } })} />
                </label>
                <label className="field">
                  Emotive HD voice
                  <span className="hint">Used in emotive voice mode.</span>
                  <select disabled={readOnly} value={p.voice.liveVoice} onChange={(e) => set({ voice: { ...p.voice, liveVoice: e.target.value } })}>
                    {LIVE_VOICES.map((v) => (
                      <option key={v}>{v}</option>
                    ))}
                  </select>
                </label>
              </div>
              <button
                type="button"
                className="btn small"
                onClick={() =>
                  void previewVoice(
                    p.voice,
                    `Hi doctor, I'm ${p.demographics.name.split(" ")[0] || "here"}. ${p.chiefComplaint}.`,
                    `a ${p.demographics.age || "middle-aged"}-year-old ${/^f/i.test(p.demographics.sex) ? "woman" : /^m/i.test(p.demographics.sex) ? "man" : "person"} patient`,
                  )
                }
              >
                <Volume2 size={15} /> Preview standard voice
              </button>
              <p className="small muted" style={{ marginTop: 8 }}>
                Standard voice uses each student's device voices, so it sounds slightly different on different computers. Emotive voice uses the selected HD voice.
              </p>
            </>,
          )}
          {textSection(
            "diagnosis",
            "diagnosis",
            "Hidden from students. Include relevant comorbidities.",
            2,
            <label className="check" style={{ marginTop: 16 }}>
              <input type="checkbox" disabled={readOnly} checked={p.patientKnowsDiagnosis} onChange={(e) => set({ patientKnowsDiagnosis: e.target.checked })} />
              <span>The patient already knows this diagnosis (for example, a follow-up visit)</span>
            </label>,
          )}
          {textSection("hpi", "hpi", "Onset, timing, character, severity, triggers, associated symptoms and pertinent negatives.", 7)}
          {textSection("pmh", "pmh")}
          {textSection("meds", "medsAllergies")}
          {textSection("fh", "familyHistory")}
          {textSection("sh", "socialHistory", "Tobacco, alcohol, drugs, work, home, relationships, diet and exercise.")}
          {textSection("ros", "ros", "Other symptoms the patient has or denies when asked.")}
          {sec(
            "personality",
            <>
              <div className="grid-2">
                {BIG5.map((k) => (
                  <label key={k} className="field">
                    {k[0].toUpperCase() + k.slice(1)}
                    <select disabled={readOnly} value={p.personality[k]} onChange={(e) => set({ personality: { ...p.personality, [k]: e.target.value as Level3 } })}>
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                    </select>
                  </label>
                ))}
              </div>
              <label className="field">
                Personality notes
                <GrowText rows={3} readOnly={readOnly} value={p.personality.notes} onChange={(e) => set({ personality: { ...p.personality, notes: e.target.value } })} />
              </label>
            </>,
          )}
          {textSection("communication", "communication", "Tone, what they volunteer or hide, questions they ask, and how they react to empathy or jargon.")}
          {textSection("other", "other", "Anything else the patient knows or would say.")}
          {sec(
            "tests",
            <TestsEditor
              tests={p.tests}
              readOnly={readOnly}
              errors={testErrors}
              onChange={(tests) => {
                set({ tests });
                setTestErrors({});
              }}
            />,
          )}
          {!readOnly && (
            <div className="row" style={{ marginTop: 48 }}>
              <button className="btn primary" onClick={doSave} disabled={save.busy || !(dirty || isNew)}>
                {save.busy ? "Saving" : "Save patient profile"}
              </button>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}

/** A textarea that grows with its text up to `max` px, then scrolls. Also used by the configuration editor. */
export function GrowText({ value, max = 480, ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement> & { value: string; max?: number }) {
  const ref = useAutoGrow(value, max);
  return <textarea ref={ref} value={value} {...rest} />;
}

/** Color choices as swatches, with "Auto" (picked from the patient's details) as a text chip. */
function Swatches({ label, value, options, disabled, onChange }: { label: string; value: string; options: readonly (readonly [string, string])[]; disabled: boolean; onChange: (v: string) => void }) {
  return (
    <div className="field">
      {label}
      <div className="swatches" role="radiogroup" aria-label={label}>
        <button type="button" role="radio" aria-checked={!value} className={`swatch-btn auto ${value ? "" : "on"}`} title="Picked automatically for this patient" disabled={disabled} onClick={() => onChange("")}>
          Auto
        </button>
        {options.map(([k, name]) => (
          <button
            key={k}
            type="button"
            role="radio"
            aria-checked={value === k}
            aria-label={name}
            title={name}
            className={`swatch-btn ${value === k ? "on" : ""}`}
            disabled={disabled}
            onClick={() => onChange(k)}
            style={{ background: `#${k}` }}
          />
        ))}
      </div>
    </div>
  );
}

function TestsEditor({ tests, onChange, readOnly, errors }: { tests: TestItem[]; onChange: (t: TestItem[]) => void; readOnly: boolean; errors: Record<string, string> }) {
  const set = (i: number, patch: Partial<TestItem>) => onChange(tests.map((t, j) => (j === i ? { ...t, ...patch } : t)));
  const add = () => {
    const max = tests.reduce((m, t) => Math.max(m, Number(t.id.replace(/\D/g, "")) || 0), 0);
    const id = `t${max + 1}`;
    onChange([...tests, { id, category: "Laboratory", name: "", result: "", expected: true }]);
    focusField(`test-${id}-name`);
  };
  return (
    <div>
      <p className="small muted" style={{ marginTop: -16, marginBottom: 24 }}>
        Students order these during the encounter and see exactly the result you write here. The AI never invents results. Tick Expected for the tests a student
        should order, and add a few unnecessary ones with normal results to test judgment.
      </p>
      {tests.length === 0 && <p className="muted">No exams or tests yet.</p>}
      {tests.map((t, i) => (
        <TestRow key={t.id} t={t} n={i + 1} readOnly={readOnly} error={errors[t.id]} onChange={(patch) => set(i, patch)} onRemove={() => onChange(tests.filter((_, j) => j !== i))} />
      ))}
      {!readOnly && (
        <button type="button" className="btn small" onClick={add}>
          Add exam or test
        </button>
      )}
    </div>
  );
}

function TestRow({ t, n, readOnly, error, onChange, onRemove }: { t: TestItem; n: number; readOnly: boolean; error?: string; onChange: (patch: Partial<TestItem>) => void; onRemove: () => void }) {
  const result = useAutoGrow(t.result, 240);
  const category = canonicalCategory(t.category);
  const name = t.name.trim() || `test ${n}`;
  const errorId = `test-${t.id}-error`;
  return (
    <div className="test-editor-row">
      <select disabled={readOnly} value={category} onChange={(e) => onChange({ category: e.target.value })} aria-label={`Category of ${name}`}>
        {[...TEST_CATEGORIES, ...(TEST_CATEGORIES.includes(category) ? [] : [category])].map((c) => (
          <option key={c}>{c}</option>
        ))}
      </select>
      <input
        id={`test-${t.id}-name`}
        type="text"
        readOnly={readOnly}
        value={t.name}
        onChange={(e) => onChange({ name: e.target.value })}
        placeholder="Exam or test name"
        aria-label={`Name of test ${n}`}
        {...invalidProps(errorId, error)}
      />
      <textarea ref={result} readOnly={readOnly} rows={1} value={t.result} onChange={(e) => onChange({ result: e.target.value })} placeholder="Result shown to the student" aria-label={`Result of ${name}`} />
      <label className="check small">
        <input type="checkbox" disabled={readOnly} checked={t.expected} onChange={(e) => onChange({ expected: e.target.checked })} />
        Expected
      </label>
      {!readOnly && (
        <button type="button" className="btn ghost icon small" onClick={onRemove} aria-label={`Remove ${name}`}>
          <Trash2 size={15} />
        </button>
      )}
      {error && (
        <div style={{ gridColumn: "1 / -1" }}>
          <FieldError id={errorId}>{error}</FieldError>
        </div>
      )}
    </div>
  );
}

function Assistant({ onDraft, onSkip }: { onDraft: (name: string, data: ProfileData) => void; onSkip: () => void }) {
  const navigate = useNavigate();
  const [diagnosis, setDiagnosis] = useState("");
  const [goal, setGoal] = useState("First clinic visit");
  const [big5, setBig5] = useState("medium openness, medium conscientiousness, medium extraversion, high agreeableness, medium neuroticism");
  const [communication, setCommunication] = useState("");
  const { busy, error, run } = useAction();
  const dirty = Boolean(diagnosis.trim() || communication.trim());
  useUnsavedChanges(dirty);
  return (
    <main className="page narrow">
      <button className="btn ghost small" onClick={() => confirmDiscard(dirty) && navigate(LIBRARY)} style={{ marginBottom: 16, marginLeft: -12 }}>
        <ArrowLeft size={16} /> Library
      </button>
      <div>
        <span className="eyebrow">New patient profile</span>
        <h1>Draft a patient profile</h1>
        <p className="muted">
          Describe the patient in a few words and the assistant drafts a complete profile for you to review and edit. You can also skip this and start from a blank
          profile.
        </p>
        <ErrorNote error={error} />
        <label className="field">
          Patient diagnosis
          <span className="hint">Include comorbidities, for example “Decompensated heart failure (HFrEF), poorly controlled hypertension, 30 pack-year smoker”.</span>
          <textarea value={diagnosis} onChange={(e) => setDiagnosis(e.target.value)} rows={2} autoFocus />
        </label>
        <label className="field">
          Goal of the encounter
          <span className="hint">For example “First clinic visit”, “Delivering a diagnosis” or “Follow-up to review test results”.</span>
          <input type="text" value={goal} onChange={(e) => setGoal(e.target.value)} />
        </label>
        <label className="field">
          Personality (Big Five)
          <span className="hint">Low, medium or high for openness, conscientiousness, extraversion, agreeableness and neuroticism.</span>
          <input type="text" value={big5} onChange={(e) => setBig5(e.target.value)} />
        </label>
        <label className="field">
          Other personality and communication
          <span className="hint">For example “Calm and soft-spoken. Tends to understate symptoms. Worried about burdening his family.”</span>
          <textarea value={communication} onChange={(e) => setCommunication(e.target.value)} rows={2} />
        </label>
        <div className="row">
          <button
            className="btn primary"
            disabled={busy || !diagnosis.trim()}
            onClick={() =>
              void run(async () => {
                const r = await api<{ name: string; data: ProfileData }>("/library/profiles/assist", { body: { diagnosis, goal, big5, communication } });
                onDraft(r.name, r.data);
              })
            }
          >
            {busy ? "Drafting the profile, up to a minute" : "Draft the profile"}
          </button>
          <button className="btn ghost" onClick={onSkip} disabled={busy}>
            Start from a blank profile
          </button>
        </div>
      </div>
    </main>
  );
}
