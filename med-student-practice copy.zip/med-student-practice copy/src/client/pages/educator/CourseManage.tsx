import { useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { ArrowLeft, Download, Printer } from "lucide-react";
import type { Assignment, CapacityInfo, CaseItem, Course, EncounterSummary } from "../../../shared/types";
import { sentenceCase } from "../../../shared/defaults";
import { ApiError, api } from "../../api";
import {
  EmptyState,
  ErrorNote,
  FieldError,
  Flash,
  Loaded,
  Loading,
  Modal,
  RowMenu,
  TabPanel,
  Tabs,
  confirmDiscard,
  copyText,
  fmtDate,
  invalidProps,
  levelClass,
  levelIndex,
  useAction,
  useFlash,
  useLoad,
  useUnsavedChanges,
} from "../../ui";
import { Avatar } from "../../components/Avatar";
import { LevelBar, Stat, courseColor } from "../../components/Visuals";
import { BannerPicker } from "./Home";
import { CapacityPanel } from "./Admin";

type Tab = "cases" | "students" | "results" | "settings";

const TABS: { id: Tab; label: string }[] = [
  { id: "cases", label: "Cases" },
  { id: "students", label: "Students" },
  { id: "results", label: "Results" },
  { id: "settings", label: "Settings" },
];

interface RosterRow {
  id: string;
  name: string;
  email: string;
  joinedAt: number;
  encounters: number;
  lastActive: number | null;
}

/** A course results row. */
type ResultRow = EncounterSummary;

const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? "" : "s"}`;
const joinLink = (code: string) => `${window.location.origin}/join/${code}`;
const copyMessage = (ok: boolean) => (ok ? "Copied" : "Couldn't copy. Select the text and copy it.");
/** Moves focus to a field after the error under it has rendered. */
const focusField = (id: string) => requestAnimationFrame(() => document.getElementById(id)?.focus());

export function CourseManage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const d = useLoad(() => api<{ course: Course; assignments: Assignment[] }>(`/courses/${id}`), [id]);
  const act = useAction();
  const [flash, showFlash] = useFlash();
  // The tab lives in the URL, so Back from a student's feedback returns to Results.
  const tab = TABS.find((t) => t.id === params.get("tab"))?.id ?? "cases";
  if (!d.data) {
    if (d.loading) return <Loading />;
    return (
      <main className="page">
        <ErrorNote error={d.error} onRetry={() => void d.reload()} />
      </main>
    );
  }
  const { course, assignments } = d.data;
  const update = (patch: Partial<Course>) => d.setData({ ...d.data!, course: { ...course, ...patch } });
  const selectTab = (t: Tab) => {
    if (t !== tab && confirmDiscard()) setParams(t === "cases" ? {} : { tab: t }, { replace: true });
  };
  const copy = async (text: string) => showFlash(copyMessage(await copyText(text)));
  const link = joinLink(course.code);

  return (
    <main className="page">
      <button className="btn ghost small no-print" onClick={() => confirmDiscard() && navigate("/educator")} style={{ marginBottom: 24, marginLeft: -12 }}>
        <ArrowLeft size={16} /> All courses
      </button>
      <div className="row spread" style={{ alignItems: "flex-start", marginBottom: 32 }}>
        <div style={{ borderLeft: `4px solid ${courseColor(course.banner)}`, paddingLeft: 24, minWidth: 0 }}>
          <span className="eyebrow">Course</span>
          <h1 style={{ margin: 0 }}>{course.name}</h1>
          <p className="muted" style={{ margin: "8px 0 0" }}>
            {[plural(course.studentCount ?? 0, "student"), plural(course.caseCount ?? 0, "case"), course.enrollmentOpen ? "Enrollment open" : "Enrollment closed"].join(" · ")}
            {course.archived && (
              <>
                {" "}
                <span className="badge">Archived</span>
              </>
            )}
          </p>
        </div>
        <div className="card compact">
          <span className="caption">Course code</span>
          <span className="code" style={{ fontSize: 24 }}>
            {course.code}
          </span>
          <span className="muted tiny truncate" title={link} style={{ marginTop: 4 }}>
            {link.replace(/^https?:\/\//, "")}
          </span>
          <div className="row tight no-print" style={{ marginTop: 12 }}>
            <button className="btn small" onClick={() => void copy(course.code)}>
              Copy code
            </button>
            <button className="btn small" onClick={() => void copy(link)}>
              Copy join link
            </button>
            <Flash text={flash} />
          </div>
        </div>
      </div>
      <div className="row no-print" style={{ marginBottom: 32 }}>
        <button className="btn small" disabled={act.busy} onClick={() => void act.run(async () => update(await api<{ enrollmentOpen: boolean }>(`/courses/${course.id}/toggle-enrollment`, { body: {} })))}>
          {course.enrollmentOpen ? "Close enrollment" : "Open enrollment"}
        </button>
        <button
          className="btn small"
          disabled={act.busy}
          onClick={() => confirm("Make a new code? The old code and join link will stop working.") && void act.run(async () => update(await api<{ code: string }>(`/courses/${course.id}/code`, { body: {} })))}
        >
          New code
        </button>
        <button className="btn small" onClick={() => confirmDiscard() && navigate(`/courses/${course.id}`)}>
          Student view
        </button>
      </div>
      <ErrorNote error={act.error} />

      <Tabs<Tab> idBase="course" label="Course sections" value={tab} onChange={selectTab} tabs={TABS} />
      <TabPanel idBase="course" id={tab}>
        {tab === "cases" && <CasesTab course={course} assignments={assignments} onChange={(a) => d.setData({ ...d.data!, assignments: a, course: { ...course, caseCount: a.length } })} />}
        {tab === "students" && <StudentsTab course={course} />}
        {tab === "results" && <ResultsTab course={course} />}
        {tab === "settings" && <SettingsTab course={course} onChange={update} />}
      </TabPanel>
    </main>
  );
}

// ---------- cases ----------

function CasesTab({ course, assignments, onChange }: { course: Course; assignments: Assignment[]; onChange: (a: Assignment[]) => void }) {
  const [adding, setAdding] = useState(false);
  const act = useAction();
  const remove = (a: Assignment) =>
    confirm(`Remove "${a.caseName}" (${a.configName}) from this course? Past encounters are kept.`) &&
    void act.run(async () => onChange(await api<Assignment[]>(`/courses/${course.id}/assignments/${a.id}`, { method: "DELETE" })));
  return (
    <div className="stack">
      <ErrorNote error={act.error} />
      <div className="row">
        <button className="btn primary" onClick={() => setAdding(true)}>
          Add case
        </button>
      </div>
      {assignments.length ? (
        <div className="grid">
          {assignments.map((a) => (
            <div key={a.id} className="card case-card">
              <div className="who">
                <Avatar look={a.look} size={56} />
                <div style={{ minWidth: 0 }}>
                  <h3 style={{ margin: 0 }}>{a.caseName}</h3>
                  <div className="small muted">{a.patientLabel}</div>
                </div>
              </div>
              <p className="quote">“{a.chiefComplaint}”</p>
              <div className="row tight">
                <span className="badge">{a.configName}</span>
              </div>
              <div className="foot">
                <span className="muted tiny">{a.diagnosisType === "diagnosis" ? "Ends with a diagnosis" : "No diagnosis"}</span>
                <button className="btn small danger" disabled={act.busy} onClick={() => remove(a)}>
                  Remove from course
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState title="No cases yet">Add a case from your library. Students see every case you add here.</EmptyState>
      )}
      {adding && <AddCase course={course} assignments={assignments} onClose={() => setAdding(false)} onAdded={(a) => (onChange(a), setAdding(false))} />}
    </div>
  );
}

function AddCase({ course, assignments, onClose, onAdded }: { course: Course; assignments: Assignment[]; onClose: () => void; onAdded: (a: Assignment[]) => void }) {
  const cases = useLoad(() => api<CaseItem[]>("/library/cases"), []);
  const [caseId, setCaseId] = useState("");
  const [configId, setConfigId] = useState("");
  const [taken, setTaken] = useState<string | null>(null);
  const { busy, error, run } = useAction();
  const kase = cases.data?.find((c) => c.id === caseId);
  const inCourse = (cid: string, kid = caseId) => assignments.some((a) => a.caseId === kid && a.configId === cid);
  const chooseCase = (kid: string) => {
    setCaseId(kid);
    setTaken(null);
    const ids = cases.data?.find((c) => c.id === kid)?.configIds ?? [];
    setConfigId(ids.find((cid) => !inCourse(cid, kid)) ?? ids[0] ?? "");
  };
  const add = () =>
    void run(async () => {
      setTaken(null);
      try {
        onAdded(await api<Assignment[]>(`/courses/${course.id}/assignments`, { body: { caseId, configId } }));
      } catch (e) {
        // The same case and configuration twice: say so under the configuration.
        if (!(e instanceof ApiError && e.status === 409)) throw e;
        setTaken(e.message);
        focusField("add-case-config");
      }
    });
  return (
    <Modal title="Add a case to this course" onClose={onClose}>
      <ErrorNote error={error ?? cases.error} />
      {cases.loading ? (
        <span className="spinner" role="status" aria-label="Loading cases" />
      ) : (
        <>
          <label className="field">
            Case
            <select value={caseId} onChange={(e) => chooseCase(e.target.value)}>
              <option value="">Choose a case</option>
              {cases.data?.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                  {c.mine ? "" : " (public)"}
                </option>
              ))}
            </select>
          </label>
          {kase && (
            <label className="field">
              Configuration
              <select
                id="add-case-config"
                value={configId}
                onChange={(e) => {
                  setConfigId(e.target.value);
                  setTaken(null);
                }}
                {...invalidProps("add-case-config-error", taken)}
              >
                {kase.configIds.map((cid, i) => (
                  <option key={cid} value={cid}>
                    {kase.configNames?.[i] ?? cid}
                    {inCourse(cid) ? " (already in this course)" : ""}
                  </option>
                ))}
              </select>
              <FieldError id="add-case-config-error">{taken}</FieldError>
            </label>
          )}
          <button className="btn primary block" disabled={busy || !caseId || !configId} onClick={add}>
            {busy ? "Adding" : "Add to course"}
          </button>
        </>
      )}
    </Modal>
  );
}

// ---------- students ----------

function StudentsTab({ course }: { course: Course }) {
  const roster = useLoad(() => api<RosterRow[]>(`/courses/${course.id}/roster`), [course.id]);
  const act = useAction();
  const [reset, setReset] = useState<{ name: string; code: string } | null>(null);
  const [flash, showFlash] = useFlash();
  const makeCode = (s: RosterRow) =>
    void act.run(async () => {
      const r = await api<{ code: string }>(`/courses/${course.id}/roster/${s.id}/reset-code`, { body: {} });
      setReset({ name: s.name, code: r.code });
    });
  const remove = (s: RosterRow) =>
    confirm(`Remove ${s.name} from this course? Their past encounters stay in the results.`) &&
    void act.run(async () => {
      await api(`/courses/${course.id}/roster/${s.id}`, { method: "DELETE" });
      await roster.reload();
    });
  return (
    <div className="stack">
      <ErrorNote error={act.error} />
      <p className="muted small" style={{ maxWidth: 712 }}>
        Students join with the code <strong className="code">{course.code}</strong> or the join link. If a student forgets their password, choose Make reset code in
        the menu at the end of their row. They enter the code at “Use a reset code” on the sign-in page within 24 hours.
      </p>
      <Loaded state={roster}>
        {(rows) =>
          rows.length ? (
            <div className="list scroll-x">
              <table className="table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Joined</th>
                    <th className="end">Encounters</th>
                    <th>Last active</th>
                    <th>
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((s) => (
                    <tr key={s.id}>
                      <td>
                        <span className="truncate" title={s.name}>
                          {s.name}
                        </span>
                      </td>
                      <td>
                        <span className="truncate" title={s.email}>
                          {s.email}
                        </span>
                      </td>
                      <td className="nowrap" data-label="Joined">
                        {fmtDate(s.joinedAt)}
                      </td>
                      <td className="end" data-label="Encounters">
                        {s.encounters}
                      </td>
                      <td className="nowrap" data-label="Last active">
                        {s.lastActive ? fmtDate(s.lastActive) : "Not yet"}
                      </td>
                      <td className="end">
                        <RowMenu
                          label={`More actions for ${s.name}`}
                          items={[
                            { label: "Make reset code", onSelect: () => makeCode(s), disabled: act.busy },
                            { label: "Remove from course", onSelect: () => remove(s), danger: true, disabled: act.busy },
                          ]}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState title="No students yet">Share the join link or the course code {course.code} with your students.</EmptyState>
          )
        }
      </Loaded>
      {reset && (
        <Modal title={`Reset code for ${reset.name}`} onClose={() => setReset(null)}>
          <p>Give this one-time code to the student. It works once, within 24 hours, at “Use a reset code” on the sign-in page.</p>
          <p className="code" style={{ fontSize: 34, lineHeight: 1.15, margin: "24px 0" }}>
            {reset.code}
          </p>
          <div className="row">
            <button className="btn primary" onClick={() => void copyText(reset.code).then((ok) => showFlash(copyMessage(ok)))}>
              Copy code
            </button>
            <Flash text={flash} />
          </div>
        </Modal>
      )}
    </div>
  );
}

// ---------- results ----------

const MODE: Record<string, string> = { text: "Text", voice: "Voice", emotive: "Emotive voice" };
const VERDICT: Record<string, { label: string; cls: string }> = {
  correct: { label: "Correct", cls: "high" },
  partial: { label: "Partly correct", cls: "mid" },
  incorrect: { label: "Not correct", cls: "low" },
};
const SUPPORT: Record<string, string> = { supported: "Supported", partly: "Partly supported", unsupported: "Not supported" };

/** Finished means graded after a real conversation. In-progress, grading and silent attempts are unfinished. */
const isFinished = (r: ResultRow) => r.status === "done" && (r.doctorTurns ?? 1) > 0;
const statusLabel = (r: ResultRow) => (isFinished(r) ? "Finished" : r.status === "active" ? "In progress" : r.status === "grading" ? "Grading" : "Ended without talking");
const minutes = (ms: number) => (ms < 60_000 ? "Under 1 min" : `${Math.round(ms / 60_000)} min`);

/** "2 Developing, 4 Needs improvement": how many skills reached each level, highest level first. */
function levelCounts(r: ResultRow): string {
  const parts: string[] = [];
  for (let i = r.levels.length - 1; i >= 0; i--) {
    const n = r.scores.filter((s) => levelIndex(s.level, r.levels) === i).length;
    if (n) parts.push(`${n} ${sentenceCase(r.levels[i])}`);
  }
  const other = r.scores.filter((s) => levelIndex(s.level, r.levels) < 0).length;
  if (other) parts.push(`${other} Not assessed`);
  return parts.join(", ");
}

/** "gemini/gemini-flash-lite-latest" reads "gemini-flash-lite-latest"; other providers keep their name. */
function graderName(provider: string): string {
  if (provider === "demo") return "the demo AI";
  const [source, ...rest] = provider.split("/");
  const model = rest.join("/").replace(/^@cf\/[^/]+\//, "");
  if (!model) return provider;
  return source === "gemini" ? model : `${model} (${source === "workers-ai" ? "Workers AI" : source === "groq" ? "Groq" : source})`;
}

interface SkillGroup {
  key: string;
  name: string;
  levels: string[];
  n: number;
  skills: Map<string, { counts: number[]; other: number }>;
}

/** Level counts per rubric skill, one group per configuration, so skills from different rubrics never mix. */
function byConfiguration(rows: ResultRow[]): SkillGroup[] {
  const groups = new Map<string, SkillGroup>();
  for (const r of rows) {
    if (!r.scores.length) continue;
    const key = `${r.configId || r.configName}\u0000${r.levels.join("\u0000")}`;
    let g = groups.get(key);
    if (!g) groups.set(key, (g = { key, name: r.configName || "Configuration", levels: r.levels, n: 0, skills: new Map() }));
    g.n++;
    for (const s of r.scores) {
      const skill = g.skills.get(s.category) ?? { counts: g.levels.map(() => 0), other: 0 };
      const i = levelIndex(s.level, g.levels);
      if (i >= 0) skill.counts[i]++;
      else skill.other++;
      g.skills.set(s.category, skill);
    }
  }
  return [...groups.values()];
}

/** One CSV cell. A value starting with = + - @, a tab or a return gets a leading ' so a spreadsheet never runs it as a formula. */
function csvCell(v: unknown): string {
  let s = v === null || v === undefined ? "" : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return `"${s.replace(/"/g, '""')}"`;
}

function exportCsv(course: Course, rows: ResultRow[]) {
  const header = ["Student", "Email", "Case", "Configuration", "Mode", "Status", "Started", "Duration (min)", "Doctor turns", "Diagnosis verdict", "Diagnosis support", "Graded by", "Scores"];
  const lines = [header, ...rows.map((r) => [
    r.studentName,
    r.studentEmail,
    r.caseName,
    r.configName,
    MODE[r.mode] ?? r.mode,
    statusLabel(r),
    new Date(r.startedAt).toISOString(),
    r.endedAt ? Math.round((r.endedAt - r.startedAt) / 6_000) / 10 : "",
    r.doctorTurns ?? "",
    r.diagnosisVerdict ? (VERDICT[r.diagnosisVerdict]?.label ?? (r.diagnosisVerdict === "n/a" ? "No diagnosis" : r.diagnosisVerdict)) : "",
    r.diagnosisSupport ? (SUPPORT[r.diagnosisSupport] ?? "") : "",
    r.gradedBy ?? "",
    r.scores.map((s) => `${s.category}: ${sentenceCase(s.level)}`).join("; "),
  ])].map((cells) => cells.map(csvCell).join(","));
  // The byte order mark lets Excel read names with accents correctly.
  const url = URL.createObjectURL(new Blob([`﻿${lines.join("\r\n")}\r\n`], { type: "text/csv;charset=utf-8" }));
  const a = Object.assign(document.createElement("a"), { href: url, download: `${course.name.replace(/[^\w]+/g, "-").replace(/^-+|-+$/g, "") || "course"}-results.csv` });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function ResultsTab({ course }: { course: Course }) {
  const rows = useLoad(() => api<ResultRow[]>(`/courses/${course.id}/encounters`), [course.id]);
  const [caseFilter, setCaseFilter] = useState("");
  const [student, setStudent] = useState("");
  const [showUnfinished, setShowUnfinished] = useState(false);
  return (
    <Loaded state={rows}>
      {(all) => {
        if (!all.length) return <EmptyState title="No encounters yet">Results appear here once students finish an encounter in this course.</EmptyState>;
        const caseKey = (r: ResultRow) => `${r.caseName} · ${r.configName}`;
        const caseNames = [...new Set(all.map(caseKey))].sort();
        const q = student.trim().toLowerCase();
        const matching = all.filter((r) => (!caseFilter || caseKey(r) === caseFilter) && (!q || `${r.studentName ?? ""} ${r.studentEmail ?? ""}`.toLowerCase().includes(q)));
        const finished = matching.filter(isFinished);
        const unfinished = matching.length - finished.length;
        const shown = showUnfinished ? matching : finished;
        const groups = byConfiguration(finished);
        const withDiagnosis = finished.filter((r) => r.diagnosisVerdict && VERDICT[r.diagnosisVerdict]);
        const correct = withDiagnosis.filter((r) => r.diagnosisVerdict === "correct").length;
        const students = new Set(finished.map((r) => r.studentEmail ?? r.studentName)).size;
        return (
          <div className="stack loose">
            <div className="toolbar labeled no-print">
              <div className="toolbar-field">
                <label htmlFor="results-case">Case</label>
                <select id="results-case" value={caseFilter} onChange={(e) => setCaseFilter(e.target.value)} style={{ maxWidth: 260 }}>
                  <option value="">All cases</option>
                  {caseNames.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div className="toolbar-field">
                <label htmlFor="results-student">Student</label>
                <input id="results-student" type="search" placeholder="Name or email" value={student} onChange={(e) => setStudent(e.target.value)} style={{ maxWidth: 200 }} />
              </div>
              <label className="check" style={{ margin: 0 }}>
                <input type="checkbox" checked={showUnfinished} onChange={(e) => setShowUnfinished(e.target.checked)} style={{ width: 18, height: 18, minHeight: 0 }} />
                Show unfinished attempts{unfinished ? ` (${unfinished})` : ""}
              </label>
              <button className="btn" onClick={() => exportCsv(course, shown)} disabled={!shown.length}>
                <Download size={16} /> Export CSV
              </button>
              <button className="btn" onClick={() => window.print()}>
                <Printer size={16} /> Print report
              </button>
            </div>

            <div className="stats">
              <Stat value={finished.length} label="Finished encounters" />
              <Stat value={students} label={`Student${students === 1 ? "" : "s"} with a finished encounter`} />
              {withDiagnosis.length > 0 && <Stat value={`${Math.round((correct / withDiagnosis.length) * 100)}%`} label={`Correct diagnoses, ${correct} of ${withDiagnosis.length}`} />}
            </div>

            {groups.length > 0 && (
              <section>
                <h2>Skill levels</h2>
                <p className="muted" style={{ maxWidth: 712 }}>
                  Each bar shows the share of finished encounters at each level, lowest level first, for one configuration's rubric.
                </p>
                <div className="stack loose" style={{ maxWidth: 712 }}>
                  {groups.map((g) => (
                    <div key={g.key}>
                      <h3 style={{ margin: 0 }}>{g.name}</h3>
                      <div className="row tight" style={{ margin: "8px 0 16px" }}>
                        <span className="muted small">{plural(g.n, "graded encounter")} · Levels, lowest first:</span>
                        {g.levels.map((l) => (
                          <span key={l} className={`badge ${levelClass(l, g.levels)}`}>
                            {sentenceCase(l)}
                          </span>
                        ))}
                      </div>
                      <div className="list">
                        {[...g.skills].map(([name, s]) => (
                          <div key={name} className="list-row row spread">
                            <div style={{ minWidth: 0 }}>
                              <div>{name}</div>
                              {s.other > 0 && <div className="muted tiny">{s.other} not assessed</div>}
                            </div>
                            <LevelBar counts={s.counts} labels={g.levels} />
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            <section>
              <h2>Encounters</h2>
              {shown.length ? (
                <div className="list scroll-x" style={{ marginTop: 16 }}>
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Student</th>
                        <th>Case</th>
                        <th>Date</th>
                        <th>Duration</th>
                        <th>Skills</th>
                        <th className="end">Diagnosis</th>
                      </tr>
                    </thead>
                    <tbody>
                      {shown.map((r) => (
                        <ResultLine key={r.id} r={r} />
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="muted">
                  {matching.length ? `No finished encounters match. ${plural(unfinished, "unfinished attempt")} hidden.` : "No encounters match these filters."}
                </p>
              )}
            </section>
          </div>
        );
      }}
    </Loaded>
  );
}

function ResultLine({ r }: { r: ResultRow }) {
  const done = isFinished(r);
  const verdict = done && r.diagnosisVerdict ? VERDICT[r.diagnosisVerdict] : undefined;
  const support = done && r.diagnosisSupport ? SUPPORT[r.diagnosisSupport] : undefined;
  return (
    <tr>
      <td>
        {done ? (
          <Link className="row-link" to={`/encounter/${r.id}/feedback`} aria-label={`Feedback for ${r.studentName}, ${r.caseName}, ${fmtDate(r.startedAt)}`}>
            {r.studentName}
          </Link>
        ) : (
          r.studentName
        )}
        <span className="muted tiny truncate" title={r.studentEmail}>
          {r.studentEmail}
        </span>
      </td>
      <td className="case-cell">
        {r.caseName}
        <div className="muted tiny">{[r.configName, MODE[r.mode] ?? r.mode].filter(Boolean).join(" · ")}</div>
      </td>
      <td className="nowrap">{fmtDate(r.startedAt)}</td>
      <td className="nowrap" data-label="Duration">
        {r.endedAt ? minutes(r.endedAt - r.startedAt) : ""}
      </td>
      <td className="wide">
        {!done ? (
          <span className="badge">{statusLabel(r)}</span>
        ) : r.scores.length ? (
          <>
            {levelCounts(r)}
            {r.gradedBy && <div className="muted tiny nowrap">Graded by {graderName(r.gradedBy)}</div>}
          </>
        ) : (
          <span className="muted">Not graded</span>
        )}
      </td>
      <td className="end">
        {verdict && <span className={`badge ${verdict.cls}`}>{verdict.label}</span>}
        {support && <div className="muted tiny">{support}</div>}
      </td>
    </tr>
  );
}

// ---------- settings ----------

type DetailsField = "name" | "description" | "retention";

/** Which field a 400 from PUT /courses/:id is about. */
const detailsField = (message: string): DetailsField | null =>
  /course name|give the course a name/i.test(message) ? "name" : /description/i.test(message) ? "description" : /keep encounters|days/i.test(message) ? "retention" : null;

function SettingsTab({ course, onChange }: { course: Course; onChange: (c: Partial<Course>) => void }) {
  const cap = useLoad(() => api<CapacityInfo>("/admin/capacity"), []);
  return (
    <div>
      <section className="editor-section split">
        <div>
          <h3>Course details</h3>
          <p className="muted small">Students see the name, description and color on their course page.</p>
        </div>
        <CourseDetails course={course} onChange={onChange} />
      </section>
      <section className="editor-section split">
        <div>
          <h3>Course AI key</h3>
          <p className="muted small">Recommended. Your own key gives this course its own free allowance.</p>
        </div>
        <CourseKey course={course} onChange={onChange} />
      </section>
      <section className="editor-section split">
        <div>
          <h3>Capacity</h3>
          <p className="muted small">For the whole site, not only this course. All numbers are estimates.</p>
        </div>
        <div>
          <Loaded state={cap}>{(c) => <CapacityPanel cap={c} />}</Loaded>
        </div>
      </section>
      <section className="editor-section split">
        <div>
          <h3>Archive or delete</h3>
          <p className="muted small">Archive a course when the term ends. Only an archived course can be deleted.</p>
        </div>
        <ArchiveCourse course={course} onChange={onChange} />
      </section>
    </div>
  );
}

function CourseDetails({ course, onChange }: { course: Course; onChange: (c: Partial<Course>) => void }) {
  const [name, setName] = useState(course.name);
  const [description, setDescription] = useState(course.description);
  const [banner, setBanner] = useState(course.banner);
  const [retention, setRetention] = useState(String(course.retentionDays ?? 0));
  const [errors, setErrors] = useState<Partial<Record<DetailsField, string>>>({});
  const act = useAction();
  const [flash, showFlash] = useFlash();
  const dirty = name !== course.name || description !== course.description || banner !== course.banner || retention !== String(course.retentionDays ?? 0);
  useUnsavedChanges(dirty);
  const clear = (f: DetailsField) => setErrors((e) => ({ ...e, [f]: undefined }));
  const save = () =>
    void act.run(async () => {
      setErrors({});
      try {
        const c = await api<Course>(`/courses/${course.id}`, {
          method: "PUT",
          body: { name, description, banner, retentionDays: retention.trim() === "" ? null : Number(retention) },
        });
        onChange(c);
        setName(c.name);
        setDescription(c.description);
        setBanner(c.banner);
        setRetention(String(c.retentionDays ?? 0));
        showFlash("Saved");
      } catch (e) {
        // Field problems show under the field, with what was typed left in place.
        const field = e instanceof ApiError && e.status === 400 ? detailsField(e.message) : null;
        if (!field) throw e;
        setErrors({ [field]: (e as Error).message });
        focusField(`course-${field}`);
      }
    });
  return (
    <div>
      <ErrorNote error={act.error} />
      <label className="field">
        Name
        <input
          id="course-name"
          type="text"
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            clear("name");
          }}
          {...invalidProps("course-name-error", errors.name)}
        />
        <FieldError id="course-name-error">{errors.name}</FieldError>
      </label>
      <label className="field">
        Description
        <textarea
          id="course-description"
          value={description}
          onChange={(e) => {
            setDescription(e.target.value);
            clear("description");
          }}
          {...invalidProps("course-description-error", errors.description)}
        />
        <FieldError id="course-description-error">{errors.description}</FieldError>
      </label>
      <div className="field">
        Color
        <BannerPicker value={banner} onChange={setBanner} />
      </div>
      <label className="field">
        Keep encounters for (days)
        <span className="hint">Each day, encounters older than this are deleted with their comments. 0 keeps them forever.</span>
        <input
          id="course-retention"
          type="number"
          inputMode="numeric"
          min={0}
          max={3650}
          step={1}
          value={retention}
          onChange={(e) => {
            setRetention(e.target.value);
            clear("retention");
          }}
          style={{ maxWidth: 160 }}
          {...invalidProps("course-retention-error", errors.retention)}
        />
        <FieldError id="course-retention-error">{errors.retention}</FieldError>
      </label>
      <div className="row">
        <button className="btn primary" disabled={act.busy || !dirty} onClick={save}>
          {act.busy ? "Saving" : "Save details"}
        </button>
        <Flash text={flash} />
      </div>
    </div>
  );
}

function CourseKey({ course, onChange }: { course: Course; onChange: (c: Partial<Course>) => void }) {
  const [provider, setProvider] = useState<"gemini" | "groq">("gemini");
  const [key, setKey] = useState("");
  const [keyError, setKeyError] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const act = useAction();
  const test = async () => {
    const r = await api<{ ok: boolean; message: string }>(`/courses/${course.id}/ai-key/test`, { body: {} });
    setMsg({ ok: r.ok, text: r.message });
  };
  const save = () =>
    void act.run(async () => {
      setKeyError(null);
      setMsg(null);
      try {
        await api(`/courses/${course.id}/ai-key`, { method: "PUT", body: { provider, key } });
      } catch (e) {
        if (!(e instanceof ApiError && e.status === 400)) throw e;
        setKeyError(e.message);
        focusField("course-key");
        return;
      }
      setKey("");
      onChange({ hasKey: true });
      await test();
    });
  return (
    <div>
      <p className="secondary">
        Add a free Google AI Studio key so your students use your allowance (roughly 90 practice encounters a day) instead of the shared one. Get one in a minute at{" "}
        <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">
          aistudio.google.com/apikey
        </a>
        , no credit card needed. The key is stored encrypted and never shown to students.
      </p>
      <p>
        Status: {course.hasKey ? <span className="badge">Course key active</span> : <span className="badge">Using the shared allowance</span>}
      </p>
      <ErrorNote error={act.error} />
      {msg && (
        <div className={`notice ${msg.ok ? "ok" : "error"}`} role="status">
          {msg.text}
        </div>
      )}
      <div className="grid-2">
        <label className="field">
          Provider
          <select value={provider} onChange={(e) => setProvider(e.target.value as "gemini" | "groq")}>
            <option value="gemini">Google AI Studio</option>
            <option value="groq">Groq</option>
          </select>
        </label>
        <label className="field">
          API key
          <input
            id="course-key"
            type="password"
            autoComplete="off"
            value={key}
            onChange={(e) => {
              setKey(e.target.value);
              setKeyError(null);
            }}
            placeholder="Paste the key"
            {...invalidProps("course-key-error", keyError)}
          />
          <FieldError id="course-key-error">{keyError}</FieldError>
        </label>
      </div>
      <div className="row">
        <button className="btn primary" disabled={act.busy || !key.trim()} onClick={save}>
          Save and test key
        </button>
        {course.hasKey && (
          <>
            <button className="btn" disabled={act.busy} onClick={() => void act.run(test)}>
              Test key
            </button>
            <button
              className="btn danger"
              disabled={act.busy}
              onClick={() =>
                confirm("Remove the course key? Students go back to the shared allowance.") &&
                void act.run(async () => {
                  await api(`/courses/${course.id}/ai-key`, { method: "DELETE" });
                  onChange({ hasKey: false });
                  setMsg(null);
                })
              }
            >
              Remove key
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function ArchiveCourse({ course, onChange }: { course: Course; onChange: (c: Partial<Course>) => void }) {
  const navigate = useNavigate();
  const act = useAction();
  const toggle = () =>
    (course.archived || confirm("Archive this course? Students keep their results but can't start new encounters. You can unarchive it later.")) &&
    void act.run(async () => onChange(await api<{ archived: boolean }>(`/courses/${course.id}/archive`, { body: {} })));
  const remove = () =>
    confirm(`Delete "${course.name}"? The course, its case list and its roster are removed for good. Students keep their encounters in their own history.`) &&
    void act.run(async () => {
      await api(`/courses/${course.id}`, { method: "DELETE" });
      navigate("/educator", { replace: true, state: { notice: `Deleted the course ${course.name}.` } });
    });
  return (
    <div>
      <ErrorNote error={act.error} />
      <p className="secondary">
        {course.archived
          ? "This course is archived. Students can still open their results, but they can't start new encounters."
          : "Archived courses keep all results, but students can't start new encounters."}
      </p>
      <div className="row">
        <button className="btn" disabled={act.busy} onClick={toggle}>
          {course.archived ? "Unarchive course" : "Archive course"}
        </button>
        {course.archived && (
          <button className="btn danger" disabled={act.busy} onClick={remove}>
            Delete course
          </button>
        )}
      </div>
    </div>
  );
}
