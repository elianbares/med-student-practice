import { useEffect, useRef, useState } from "react";
import { Copy, X } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import type { ConfigData, LibraryItem, RubricCategory } from "../../../shared/types";
import { emptyConfig, sentenceCase } from "../../../shared/defaults";
import { ApiError, api } from "../../api";
import { ListEditor } from "../../components/ListEditor";
import { GrowText } from "./ProfileEditor";
import { ErrorNote, FieldError, Flash, Loading, confirmDiscard, invalidProps, useAction, useFlash, useLoad, useUnsavedChanges } from "../../ui";

type Draft = { name: string; isPublic: boolean; data: ConfigData; mine: boolean };
type Field = "name" | "levels" | "rubric" | "time";
type Errors = Partial<Record<Field, string>> & { levelAt?: number; rubricAt?: number };

const toDraft = (it: LibraryItem<ConfigData>): Draft => ({ name: it.name, isPublic: it.isPublic, data: it.data, mine: Boolean(it.mine) });
/** What the editor compares to decide whether there are unsaved changes. */
const snapshot = (d: Draft, time: string) => JSON.stringify([d.name.trim(), d.isPublic, d.data, time.trim()]);
/** Moves focus to a field after the error under it has rendered. */
const focusField = (id: string) => requestAnimationFrame(() => document.getElementById(id)?.focus());
const LIBRARY = "/educator/library?tab=configs";

/** Which field a 400 from saving is about, and which level or category ("Score level 3 is empty"). */
function errorFor(message: string, rubric: RubricCategory[]): Errors | null {
  const nth = (re: RegExp) => {
    const m = re.exec(message);
    return m ? Number(m[1]) - 1 : undefined;
  };
  if (/score level/i.test(message)) return { levels: message, levelAt: nth(/score level (\d+)/i) };
  if (/rubric category names/i.test(message)) return { rubric: message, rubricAt: rubric.findIndex((r) => r.name.trim().length > 120) };
  if (/rubric/i.test(message)) return { rubric: message, rubricAt: nth(/rubric category (\d+)/i) };
  if (/time limit/i.test(message)) return { time: message };
  if (/name/i.test(message)) return { name: message };
  return null;
}

export function ConfigEditor() {
  const { id } = useParams();
  const isNew = id === "new";
  const navigate = useNavigate();
  const fresh = (): Draft => ({ name: "New configuration", isPublic: false, data: emptyConfig(), mine: true });
  const [item, setItem] = useState<Draft | null>(isNew ? fresh : null);
  // The time limit as typed, so the box can be cleared and a bad value reaches the server's check.
  const [time, setTime] = useState(isNew ? "0" : "");
  const [baseline, setBaseline] = useState(() => (isNew ? snapshot(fresh(), "0") : ""));
  const [errors, setErrors] = useState<Errors>({});
  const load = useAction();
  const save = useAction();
  const copy = useAction();
  const [flash, showFlash] = useFlash(3000);
  const all = useLoad(() => api<LibraryItem<ConfigData>[]>("/library/configurations"), []);
  // Set when this page itself moves to a new id (after the first save or a copy), so it doesn't reload.
  const landed = useRef<string | null>(null);
  const dirty = Boolean(item?.mine) && snapshot(item!, time) !== baseline;
  useUnsavedChanges(dirty);

  const land = (r: LibraryItem<ConfigData>, replace: boolean) => {
    const next = toDraft(r);
    const t = String(r.data.timeLimitMin);
    setItem(next);
    setTime(t);
    setBaseline(snapshot(next, t));
    if (r.id !== id) {
      landed.current = r.id;
      navigate(`/educator/configs/${r.id}`, { replace });
    }
  };

  useEffect(() => {
    if (isNew || landed.current === id) return;
    void load.run(async () => land(await api<LibraryItem<ConfigData>>(`/library/configurations/${id}`), true));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!item)
    return load.error ? (
      <main className="page form">
        <ErrorNote error={load.error} />
      </main>
    ) : (
      <Loading />
    );
  const c = item.data;
  const readOnly = !item.mine;
  const set = (patch: Partial<ConfigData>) => setItem({ ...item, data: { ...c, ...patch } });
  const clear = (f: Field) => errors[f] && setErrors((e) => ({ ...e, [f]: undefined }));
  const setCategory = (i: number, patch: Partial<RubricCategory>) => {
    set({ rubric: c.rubric.map((x, j) => (j === i ? { ...x, ...patch } : x)) });
    clear("rubric");
  };
  const leave = () => confirmDiscard(dirty) && navigate(LIBRARY);

  const doSave = () =>
    void save.run(async () => {
      setErrors({});
      // Level descriptions follow the levels list and are kept only when at least one is written.
      const rubric = c.rubric.map(({ levelDescriptors, ...r }) => {
        const d = c.levels.map((_, j) => levelDescriptors?.[j]?.trim() ?? "");
        return d.some(Boolean) ? { ...r, levelDescriptors: d } : r;
      });
      const t = time.trim();
      const body = { name: item.name, isPublic: item.isPublic, data: { ...c, rubric, timeLimitMin: t === "" ? 0 : Number(t) } };
      try {
        land(isNew ? await api<LibraryItem<ConfigData>>("/library/configurations", { body }) : await api<LibraryItem<ConfigData>>(`/library/configurations/${id}`, { method: "PUT", body }), true);
        showFlash("Saved");
      } catch (e) {
        // Problems with a field show under it, with what was typed left in place.
        const found = e instanceof ApiError && e.status === 400 ? errorFor(e.message, c.rubric) : null;
        if (!found) throw e;
        setErrors(found);
        if (found.name) focusField("config-name");
        else if (found.time) focusField("config-time");
        else if (found.levels) focusField(`config-levels-${found.levelAt ?? 0}`);
        else if (found.rubricAt !== undefined && found.rubricAt >= 0) focusField(`rubric-${found.rubricAt}-name`);
      }
    });
  const copyToEdit = () =>
    void copy.run(async () => {
      land(await api<LibraryItem<ConfigData>>(`/library/configurations/${id}/copy`, { body: {} }), false);
      showFlash("Copied to your library. You can edit it now.");
    });
  const sources = (all.data ?? []).filter((x) => x.id !== id && x.data.rubric.length);
  const copyRubric = (sourceId: string) => {
    const src = sources.find((s) => s.id === sourceId);
    if (!src) return;
    if (c.rubric.length && !confirm(`Replace this rubric and its score levels with the ones from "${src.name}"?`)) return;
    set({ rubric: src.data.rubric.map((r) => ({ ...r, levelDescriptors: r.levelDescriptors && [...r.levelDescriptors] })), levels: [...src.data.levels] });
    setErrors({});
  };

  return (
    <main className="page form">
      <div className="sticky-actions row spread" style={{ alignItems: "flex-start" }}>
        <div style={{ flex: 1, minWidth: 220 }}>
          <input
            id="config-name"
            type="text"
            value={item.name}
            readOnly={readOnly}
            onChange={(e) => {
              setItem({ ...item, name: e.target.value });
              clear("name");
            }}
            aria-label="Configuration name"
            style={{ fontWeight: 700, fontSize: 17 }}
            {...invalidProps("config-name-error", errors.name)}
          />
          <FieldError id="config-name-error">{errors.name}</FieldError>
        </div>
        <div className="row tight">
          <Flash text={flash} />
          {readOnly ? (
            <>
              <span className="muted small hide-phone">Public template, read only</span>
              <button className="btn primary" onClick={copyToEdit} disabled={copy.busy}>
                <Copy size={16} /> {copy.busy ? "Copying" : "Copy to edit"}
              </button>
            </>
          ) : (
            <>
              <label className="check" style={{ margin: 0 }}>
                <input type="checkbox" checked={item.isPublic} onChange={(e) => setItem({ ...item, isPublic: e.target.checked })} />
                <span className="small">Share as public template</span>
              </label>
              <button className="btn primary" onClick={doSave} disabled={save.busy || !(dirty || isNew)}>
                {save.busy ? "Saving" : isNew ? "Create" : "Save"}
              </button>
            </>
          )}
          <button className="btn ghost" onClick={leave} aria-label="Close">
            <X size={18} />
            <span className="hide-phone">Close</span>
          </button>
        </div>
      </div>
      <ErrorNote error={save.error ?? copy.error} />
      {readOnly && (
        <div className="notice info" style={{ marginBottom: 32 }}>
          This is a public template, so it's read only here. Choose Copy to edit to put your own copy in your library and change it there.
        </div>
      )}

      <section className="editor-section" style={{ paddingTop: 16 }}>
        <h2>Guiding details</h2>
        <p className="small muted" style={{ marginTop: -16 }}>
          Students see these before and during the encounter.
        </p>
        <label className="field">
          Context and goal
          <span className="hint">A few sentences on the clinical situation and what the student should achieve.</span>
          <GrowText readOnly={readOnly} value={c.contextGoal} onChange={(e) => set({ contextGoal: e.target.value })} rows={3} />
        </label>
        <div className="field">
          Encounter tasks
          <span className="hint">Shown as a checklist beside the conversation. They can match your rubric categories.</span>
          <ListEditor items={c.encounterTasks} onChange={(encounterTasks) => set({ encounterTasks })} addLabel="Add task" itemName="task" idBase="config-tasks" readOnly={readOnly} />
        </div>
        <div className="field">
          Post-encounter tasks (optional)
          <ListEditor items={c.postEncounterTasks} onChange={(postEncounterTasks) => set({ postEncounterTasks })} addLabel="Add post-encounter task" itemName="post-encounter task" idBase="config-post-tasks" readOnly={readOnly} />
        </div>
      </section>

      <section className="editor-section">
        <h2>Encounter setup</h2>
        <p className="small muted" style={{ marginTop: -16 }}>
          Hidden from students. This shapes how the AI patient behaves and how the encounter is graded.
        </p>
        <div className="field" role="radiogroup" aria-labelledby="diagnosis-type-label">
          <span id="diagnosis-type-label">Diagnosis type</span>
          <label className="check" style={{ marginTop: 8 }}>
            <input type="radio" name="diagnosis-type" disabled={readOnly} checked={c.diagnosisType === "diagnosis"} onChange={() => set({ diagnosisType: "diagnosis" })} />
            <span>Diagnosis: students give their most likely diagnosis at the end</span>
          </label>
          <label className="check" style={{ marginBottom: 0 }}>
            <input type="radio" name="diagnosis-type" disabled={readOnly} checked={c.diagnosisType === "none"} onChange={() => set({ diagnosisType: "none" })} />
            <span>No diagnosis</span>
          </label>
        </div>
        <label className="field">
          Role-playing instructions (optional)
          <span className="hint">For scenarios that differ from a standard visit, for example “You are the patient's mother in a pediatric emergency unit”.</span>
          <GrowText readOnly={readOnly} value={c.roleplayInstructions} onChange={(e) => set({ roleplayInstructions: e.target.value })} rows={3} />
        </label>
        <label className="field">
          Encounter feedback instructions (optional)
          <span className="hint">Tone, level of detail, and the balance of strengths and improvements. This doesn't change the rubric.</span>
          <GrowText readOnly={readOnly} value={c.feedbackInstructions} onChange={(e) => set({ feedbackInstructions: e.target.value })} rows={2} />
        </label>
        <label className="check">
          <input type="checkbox" disabled={readOnly} checked={c.notesFeedback.enabled} onChange={(e) => set({ notesFeedback: { ...c.notesFeedback, enabled: e.target.checked } })} />
          <span>
            <strong>Notes feedback:</strong> students write a note (for example a SOAP note or a reflection) and get feedback on it
          </span>
        </label>
        {c.notesFeedback.enabled && (
          <label className="field">
            How should the note be evaluated?
            <GrowText readOnly={readOnly} value={c.notesFeedback.criteria} onChange={(e) => set({ notesFeedback: { ...c.notesFeedback, criteria: e.target.value } })} rows={3} />
          </label>
        )}
        <label className="field" style={{ marginTop: 24 }}>
          Time limit (minutes)
          <span className="hint" id="config-time-hint">
            0 means no limit. At most 120.
          </span>
          <input
            id="config-time"
            type="number"
            inputMode="numeric"
            min={0}
            max={120}
            step={1}
            readOnly={readOnly}
            value={time}
            onChange={(e) => {
              setTime(e.target.value);
              clear("time");
            }}
            style={{ maxWidth: 160 }}
            {...(errors.time ? invalidProps("config-time-error", errors.time) : { "aria-describedby": "config-time-hint" })}
          />
          <FieldError id="config-time-error">{errors.time}</FieldError>
        </label>
      </section>

      <section className="editor-section">
        <h2>Exams and tests</h2>
        <p className="small muted" style={{ marginTop: -16 }}>
          The tests and their results come from the case's patient profile.
        </p>
        <div className="field" role="radiogroup" aria-labelledby="test-ordering-label">
          <span id="test-ordering-label">Test ordering</span>
          <label className="check" style={{ marginTop: 8 }}>
            <input type="radio" name="test-ordering" disabled={readOnly} checked={c.testOrdering !== "menu"} onChange={() => set({ testOrdering: "search" })} />
            <span>
              Students type the tests they want (recommended)
              <span className="hint">Gives nothing away: students decide what to order, as in a real visit.</span>
            </span>
          </label>
          <label className="check" style={{ marginBottom: 0 }}>
            <input type="radio" name="test-ordering" disabled={readOnly} checked={c.testOrdering === "menu"} onChange={() => set({ testOrdering: "menu" })} />
            <span>
              Show the case's tests as a menu
              <span className="hint">Easier for early learners, but the list hints at what matters.</span>
            </span>
          </label>
        </div>
        <div className="field" style={{ marginBottom: 0 }}>
          <label className="check" style={{ marginBottom: 0 }}>
            <input type="checkbox" role="switch" disabled={readOnly} checked={c.showResultsInBrief} onChange={(e) => set({ showResultsInBrief: e.target.checked })} aria-describedby="results-brief-hint" />
            <span>
              Show test results on the brief
              <span id="results-brief-hint" className="hint">
                For visits about results or bad news: students read the case's test results before they start.
              </span>
            </span>
          </label>
        </div>
      </section>

      <section className="editor-section">
        <div className="row spread" style={{ marginBottom: 24 }}>
          <h2 style={{ margin: 0 }}>Rubric</h2>
          {!readOnly && sources.length > 0 && (
            <select aria-label="Copy a rubric from another configuration" value="" onChange={(e) => copyRubric(e.target.value)} style={{ maxWidth: 320 }}>
              <option value="">Copy a rubric from</option>
              {sources.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          )}
        </div>
        <p className="small muted" style={{ marginTop: 0 }}>
          Each category is scored on its own and shown to the student as a separate item in their feedback.
        </p>
        <div className="field">
          Score levels, lowest to highest
          <ListEditor
            items={c.levels}
            onChange={(levels, from) => {
              // Each category's level descriptions move with their level.
              set({ levels, rubric: c.rubric.map((r) => (r.levelDescriptors ? { ...r, levelDescriptors: from.map((j) => (j >= 0 ? (r.levelDescriptors?.[j] ?? "") : "")) } : r)) });
              clear("levels");
            }}
            addLabel="Add level"
            itemName="level"
            idBase="config-levels"
            readOnly={readOnly}
            invalidAt={errors.levelAt}
            errorId="config-levels-error"
          />
          <FieldError id="config-levels-error">{errors.levels}</FieldError>
        </div>
        {c.rubric.map((r, i) => (
          <RubricItem
            key={i}
            r={r}
            i={i}
            levels={c.levels}
            readOnly={readOnly}
            error={errors.rubricAt === i ? errors.rubric : undefined}
            onChange={(patch) => setCategory(i, patch)}
            onRemove={() => {
              set({ rubric: c.rubric.filter((_, j) => j !== i) });
              setErrors({});
            }}
          />
        ))}
        {errors.rubric && (errors.rubricAt === undefined || errors.rubricAt < 0) && <FieldError id="config-rubric-error">{errors.rubric}</FieldError>}
        {c.rubric.length === 0 && <p className="muted">No rubric categories yet.</p>}
        {!readOnly && (
          <button
            className="btn small"
            style={{ marginTop: 16 }}
            onClick={() => {
              set({ rubric: [...c.rubric, { name: "", description: "" }] });
              focusField(`rubric-${c.rubric.length}-name`);
            }}
          >
            Add rubric category
          </button>
        )}
      </section>
    </main>
  );
}

function RubricItem({
  r,
  i,
  levels,
  readOnly,
  error,
  onChange,
  onRemove,
}: {
  r: RubricCategory;
  i: number;
  levels: string[];
  readOnly: boolean;
  error?: string;
  onChange: (patch: Partial<RubricCategory>) => void;
  onRemove: () => void;
}) {
  const label = r.name.trim() || `category ${i + 1}`;
  const descriptors = levels.map((_, j) => r.levelDescriptors?.[j] ?? "");
  const written = descriptors.some((d) => d.trim());
  // Open from the start when something is written; after that the person decides.
  const [open, setOpen] = useState(written);
  const errorId = `rubric-${i}-error`;
  if (readOnly && !written && !r.name && !r.description) return null;
  return (
    <div style={{ borderTop: "1px solid var(--separator)", paddingTop: 24, marginTop: 8 }}>
      <div className="row" style={{ alignItems: "flex-start", flexWrap: "nowrap" }}>
        <label className="field" style={{ flex: 1, minWidth: 0 }}>
          Category {i + 1}
          <input
            id={`rubric-${i}-name`}
            type="text"
            readOnly={readOnly}
            value={r.name}
            placeholder={readOnly ? undefined : "For example, History taking"}
            onChange={(e) => onChange({ name: e.target.value })}
            {...invalidProps(errorId, error)}
          />
          <FieldError id={errorId}>{error}</FieldError>
        </label>
        {!readOnly && (
          <button className="btn ghost icon small" onClick={onRemove} aria-label={`Remove ${label}`} style={{ marginTop: 34 }}>
            <X size={15} />
          </button>
        )}
      </div>
      <label className="field">
        Description
        <span className="hint">What is assessed, and what excellent looks like.</span>
        <GrowText readOnly={readOnly} value={r.description} onChange={(e) => onChange({ description: e.target.value })} rows={2} aria-label={`Description of ${label}`} />
      </label>
      {(!readOnly || written) && (
        <details open={open} onToggle={(e) => setOpen(e.currentTarget.open)} style={{ marginBottom: 24 }}>
          <summary className="small">What each level looks like (optional)</summary>
          <p className="small muted" style={{ margin: "8px 0 16px" }}>
            One line per level helps the AI grade consistently and shows students what the next level means.
          </p>
          {levels.map((l, j) => (
            <label key={j} className="field" style={{ fontWeight: 400 }}>
              {sentenceCase(l) || `Level ${j + 1}`}
              <GrowText
                rows={1}
                max={200}
                readOnly={readOnly}
                value={descriptors[j]}
                onChange={(e) => onChange({ levelDescriptors: descriptors.map((d, k) => (k === j ? e.target.value : d)) })}
                aria-label={`${sentenceCase(l) || `Level ${j + 1}`} for ${label}`}
                style={{ minHeight: 0 }}
              />
            </label>
          ))}
        </details>
      )}
    </div>
  );
}
