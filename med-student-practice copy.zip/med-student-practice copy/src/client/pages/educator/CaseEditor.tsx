import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import type { CaseItem, ConfigData, LibraryItem, ProfileData } from "../../../shared/types";
import { lookOf, patientLabel } from "../../../shared/defaults";
import { Avatar } from "../../components/Avatar";
import { ApiError, api } from "../../api";
import { ErrorNote, FieldError, Loading, confirmDiscard, invalidProps, useAction, useLoad, useUnsavedChanges } from "../../ui";

type Field = "name" | "profile" | "configs";
const LIBRARY = "/educator/library?tab=cases";
/** Moves focus to a field after the error under it has rendered. */
const focusField = (id: string) => requestAnimationFrame(() => document.getElementById(id)?.focus());
/** Which field a 400 from saving is about. */
const fieldOf = (message: string): Field | null => (/configuration/i.test(message) ? "configs" : /patient profile/i.test(message) ? "profile" : /name/i.test(message) ? "name" : null);
const FOCUS: Record<Field, string> = { name: "case-name", profile: "case-profile-change", configs: "case-configs" };

export function CaseEditor() {
  const { id } = useParams();
  const isNew = id === "new";
  const navigate = useNavigate();
  const profiles = useLoad(() => api<LibraryItem<ProfileData>[]>("/library/profiles"), []);
  const configs = useLoad(() => api<LibraryItem<ConfigData>[]>("/library/configurations"), []);
  const [step, setStep] = useState(isNew ? 1 : 2);
  const [profileId, setProfileId] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [configIds, setConfigIds] = useState<string[]>([]);
  const [isPublic, setIsPublic] = useState(false);
  const [filter, setFilter] = useState("");
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({});
  const [baseline, setBaseline] = useState(JSON.stringify(["", "", "", [], false]));
  const load = useAction();
  const save = useAction();
  const current = JSON.stringify([profileId, name.trim(), description.trim(), [...configIds].sort(), isPublic]);
  const dirty = current !== baseline;
  useUnsavedChanges(dirty);

  useEffect(() => {
    if (isNew) return;
    void load.run(async () => {
      const c = await api<CaseItem>(`/library/cases/${id}`);
      setProfileId(c.profileId);
      setName(c.name);
      setDescription(c.description);
      setConfigIds(c.configIds);
      setIsPublic(c.isPublic);
      setBaseline(JSON.stringify([c.profileId, c.name.trim(), c.description.trim(), [...c.configIds].sort(), c.isPublic]));
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (profiles.loading || configs.loading || load.busy) return <Loading />;
  const q = filter.trim().toLowerCase();
  const plist = (profiles.data ?? []).filter((p) => !q || `${p.name} ${p.data.diagnosis} ${p.data.chiefComplaint}`.toLowerCase().includes(q));
  const profile = profiles.data?.find((p) => p.id === profileId);
  const leave = () => confirmDiscard(dirty) && navigate(LIBRARY);
  const clear = (f: Field) => errors[f] && setErrors((e) => ({ ...e, [f]: undefined }));
  const submit = () => {
    // The same checks the server makes, so the answer shows next to the field straight away.
    const found: Partial<Record<Field, string>> = {};
    if (!name.trim()) found.name = "Give the case a name.";
    if (!configIds.length) found.configs = "Choose at least one configuration.";
    setErrors(found);
    const first = (["name", "configs"] as const).find((f) => found[f]);
    if (first) return focusField(FOCUS[first]);
    void save.run(async () => {
      const body = { name, description, profileId, configIds, isPublic };
      try {
        if (isNew) await api("/library/cases", { body });
        else await api(`/library/cases/${id}`, { method: "PUT", body });
      } catch (e) {
        const f = e instanceof ApiError && e.status === 400 ? fieldOf(e.message) : null;
        if (!f) throw e;
        setErrors({ [f]: (e as ApiError).message });
        return focusField(FOCUS[f]);
      }
      setBaseline(current);
      navigate(LIBRARY);
    });
  };

  return (
    <main className="page form">
      <button className="btn ghost small" onClick={leave} style={{ marginBottom: 16, marginLeft: -12 }}>
        <ArrowLeft size={16} /> Library
      </button>
      <span className="eyebrow">Library</span>
      <h1>{isNew ? "Create a case" : "Edit case"}</h1>
      <ErrorNote error={profiles.error ?? configs.error ?? load.error ?? save.error} />
      {step === 1 && (
        <section className="editor-section" aria-labelledby="case-step-1">
          <h2 id="case-step-1">Step 1: Choose a patient profile</h2>
          <input
            type="search"
            placeholder="Search by name, diagnosis or complaint"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            aria-label="Search patient profiles"
            style={{ maxWidth: 400, marginBottom: 24 }}
          />
          {plist.length ? (
            <div className="grid" role="radiogroup" aria-label="Patient profile">
              {plist.map((p) => (
                <label key={p.id} className={`card clickable ${profileId === p.id ? "selected" : ""}`} style={{ borderColor: profileId === p.id ? "var(--accent)" : undefined }}>
                  <div className="row" style={{ flexWrap: "nowrap", alignItems: "flex-start" }}>
                    <input type="radio" name="profile" checked={profileId === p.id} onChange={() => setProfileId(p.id)} style={{ marginTop: 14 }} />
                    <span style={{ flexShrink: 0, display: "inline-flex" }}>
                      <Avatar look={lookOf(p.data)} size={44} />
                    </span>
                    <div style={{ minWidth: 0 }}>
                      <strong>{p.name}</strong>
                      <div className="small muted">{patientLabel(p.data)}</div>
                      {!p.mine && (
                        <span className="badge" style={{ marginTop: 8 }}>
                          Public
                        </span>
                      )}
                    </div>
                  </div>
                  {p.data.chiefComplaint && <div className="small">“{p.data.chiefComplaint}”</div>}
                </label>
              ))}
            </div>
          ) : (
            <p className="muted">{q ? "No patient profiles match." : "No patient profiles yet."}</p>
          )}
          <div className="row" style={{ marginTop: 24 }}>
            <button className="btn primary" disabled={!profileId} onClick={() => setStep(2)}>
              Next
            </button>
            <button className="btn ghost" onClick={() => confirmDiscard(dirty) && navigate("/educator/profiles/new")}>
              Or create a new profile
            </button>
          </div>
        </section>
      )}
      {step === 2 && (
        <section className="editor-section" aria-labelledby="case-step-2">
          <h2 id="case-step-2">{isNew ? "Step 2: Name it and pick configurations" : "Case details"}</h2>
          <div className="field">
            Patient profile
            <div className="row" style={{ marginTop: 8, flexWrap: "nowrap" }}>
              {profile && <Avatar look={lookOf(profile.data)} size={40} />}
              <span style={{ fontWeight: 400, minWidth: 0 }}>
                {profile ? (
                  <>
                    {profile.name}
                    <span className="small muted"> · {patientLabel(profile.data)}</span>
                  </>
                ) : (
                  <span className="muted">Not available. Choose another profile.</span>
                )}
              </span>
              <button id="case-profile-change" className="btn small" onClick={() => setStep(1)} aria-describedby={errors.profile ? "case-profile-error" : undefined}>
                Change
              </button>
            </div>
            <FieldError id="case-profile-error">{errors.profile}</FieldError>
          </div>
          <label className="field">
            Case name
            <span className="hint">Visible to students. Avoid giving away the diagnosis.</span>
            <input
              id="case-name"
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                clear("name");
              }}
              {...invalidProps("case-name-error", errors.name)}
            />
            <FieldError id="case-name-error">{errors.name}</FieldError>
          </label>
          <label className="field">
            Short description
            <span className="hint">Visible to students.</span>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
          </label>
          <fieldset id="case-configs" className="field" tabIndex={-1} style={{ border: 0, padding: 0, margin: "0 0 24px", minWidth: 0 }} aria-describedby={errors.configs ? "case-configs-error" : undefined}>
            <legend style={{ padding: 0 }}>Configurations</legend>
            <span className="hint" style={{ marginBottom: 8 }}>
              Choose one or more. Each one becomes a separate activity you can add to a course.
            </span>
            {(configs.data ?? []).map((c) => (
              <label key={c.id} className="check">
                <input
                  type="checkbox"
                  checked={configIds.includes(c.id)}
                  onChange={(e) => {
                    setConfigIds(e.target.checked ? [...configIds, c.id] : configIds.filter((x) => x !== c.id));
                    clear("configs");
                  }}
                />
                <span>
                  {c.name} {!c.mine && <span className="badge">Public</span>}
                  <span className="small muted">
                    {" "}
                    · {c.data.rubric.length} rubric {c.data.rubric.length === 1 ? "category" : "categories"}
                  </span>
                </span>
              </label>
            ))}
            <FieldError id="case-configs-error">{errors.configs}</FieldError>
          </fieldset>
          <label className="check">
            <input type="checkbox" checked={isPublic} onChange={(e) => setIsPublic(e.target.checked)} />
            <span className="small">Share this case as a public template</span>
          </label>
          <div className="row" style={{ marginTop: 24 }}>
            <button className="btn primary" disabled={save.busy || !profileId} onClick={submit}>
              {save.busy ? "Saving" : isNew ? "Create case" : "Save case"}
            </button>
            <button className="btn ghost" onClick={leave}>
              Cancel
            </button>
          </div>
        </section>
      )}
    </main>
  );
}
