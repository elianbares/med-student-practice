import { useMemo, useState, type FormEvent, type ReactNode } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, AudioLines, ChevronRight, Download, Keyboard, Mic } from "lucide-react";
import type { Assignment, Course, EncounterSummary } from "../../shared/types";
import { sameLevel, sentenceCase } from "../../shared/defaults";
import { LANGUAGES } from "../../shared/languages";
import { ApiError, api, passwordHash } from "../api";
import {
  DemoBanner,
  EmptyState,
  ErrorNote,
  FieldError,
  Flash,
  LevelPill,
  Loaded,
  Modal,
  PageHeader,
  Segmented,
  fmtDate,
  greeting,
  invalidProps,
  levelIndex,
  levelValue,
  shortName,
  useAction,
  useAuth,
  useBack,
  useFlash,
  useLoad,
} from "../ui";
import { voiceSupport } from "../voice/support";
import { Avatar } from "../components/Avatar";
import { Sparkline, Stat, courseColor } from "../components/Visuals";

const DAY = 86_400_000;
const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? "" : "s"}`;

/** Focuses a field once the error under it has rendered, so screen readers read the message with it. */
const focusSoon = (id: string) => window.requestAnimationFrame(() => document.getElementById(id)?.focus());

// ---------- progress helpers ----------

/** The student said something; 0 turns means the attempt was abandoned before the conversation began. */
const talked = (r: EncounterSummary) => r.doctorTurns !== 0;

/** Finished, with a conversation, and at least one skill actually scored (not all "Not assessed"). */
export function isScored(r: EncounterSummary): boolean {
  return r.status === "done" && talked(r) && r.scores.some((s) => levelIndex(s.level, r.levels) >= 0);
}

export interface SkillPoint {
  level: string;
  levels: string[];
  value: number;
  id: string;
  caseName: string;
  configName: string;
  at: number;
}

export interface SkillTrend {
  label: string;
  latest: string;
  levels: string[];
  /** Every scored level, oldest first. */
  history: SkillPoint[];
  /** history as 0..1 values, oldest first, for a Sparkline. */
  values: number[];
  latestValue: number;
  /** Mean of the last five scores. */
  average: number;
  /** Configuration of the latest score; each configuration has its own rubric. */
  configName: string;
}

/**
 * Per rubric skill: the latest level and every scored level, oldest first. Abandoned attempts and skills
 * marked "Not assessed" are left out, so they never count as the lowest level.
 */
export function skillSummary(rows: EncounterSummary[]): SkillTrend[] {
  const scored = rows.filter(isScored).sort((a, b) => a.startedAt - b.startedAt);
  const by = new Map<string, { label: string; history: SkillPoint[] }>();
  for (const r of scored)
    for (const s of r.scores) {
      if (levelIndex(s.level, r.levels) < 0) continue;
      const key = s.category.trim().toLowerCase();
      const e = by.get(key) ?? { label: sentenceCase(s.category), history: [] };
      e.history.push({ level: s.level, levels: r.levels, value: levelValue(s.level, r.levels), id: r.id, caseName: r.caseName, configName: r.configName, at: r.startedAt });
      by.set(key, e);
    }
  return [...by.values()].map(({ label, history }) => {
    const last = history[history.length - 1];
    const recent = history.slice(-5);
    return {
      label,
      history,
      latest: last.level,
      levels: last.levels,
      values: history.map((h) => h.value),
      latestValue: last.value,
      average: recent.reduce((a, h) => a + h.value, 0) / recent.length,
      configName: last.configName,
    };
  });
}

/** "2 Developing, 4 Needs improvement": how many skills landed on each level, best level first. */
export function levelCounts(r: EncounterSummary): string {
  const parts: string[] = [];
  for (const level of [...r.levels].reverse()) {
    const n = r.scores.filter((s) => sameLevel(s.level, level)).length;
    if (n) parts.push(`${n} ${sentenceCase(level)}`);
  }
  const unscored = r.scores.filter((s) => levelIndex(s.level, r.levels) < 0).length;
  if (unscored) parts.push(`${unscored} not assessed`);
  return parts.join(", ");
}

/** A short tag for a configuration name: "OSCE: History and diagnosis" is "OSCE", "Breaking bad news (SPIKES)" is "Bad news". */
export function configTag(name: string): string {
  const known: [RegExp, string][] = [
    [/\bosce\b/i, "OSCE"],
    [/bad news|\bspikes\b/i, "Bad news"],
    [/counsel|motivational/i, "Counseling"],
    [/clerkship/i, "Clerkship"],
    [/follow.?up/i, "Follow-up"],
    [/telehealth|video visit/i, "Telehealth"],
  ];
  for (const [re, tag] of known) if (re.test(name)) return tag;
  const head = name.split(/[:(]|\s-\s/)[0].trim();
  const words = head.split(/\s+/);
  return (words.length > 3 ? words.slice(0, 3).join(" ") : head) || "Practice";
}

const dayKey = (ms: number) => new Date(ms).toDateString();

/** Days in a row with practice, counting back from today, or from yesterday when today has none yet. */
function practiceStreak(days: Set<string>): number {
  const d = new Date();
  if (!days.has(dayKey(d.getTime()))) d.setDate(d.getDate() - 1);
  let n = 0;
  while (days.has(dayKey(d.getTime()))) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
}

const modeIcon = (m: string) => (m === "text" ? <Keyboard size={14} /> : m === "emotive" ? <AudioLines size={14} /> : <Mic size={14} />);
const modeLabel = (m: string) => (m === "text" ? "Text" : m === "emotive" ? "Emotive voice" : "Voice");

// ---------- components ----------

export function JoinCourse({ onJoined }: { onJoined: (id: string) => void }) {
  const [code, setCode] = useState("");
  const { busy, error, setError, run } = useAction();
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (code.length < 6) return setError(code ? "Course codes have six characters." : "Enter the course code from your instructor.");
    void run(async () => onJoined((await api<{ id: string }>("/courses/enroll", { body: { code } })).id));
  };
  return (
    <form onSubmit={submit} noValidate style={{ maxWidth: 420 }}>
      <h4>Have a course code?</h4>
      <div className="row" style={{ flexWrap: "nowrap" }}>
        <input
          type="text"
          className="code"
          maxLength={12}
          autoComplete="off"
          value={code}
          onChange={(e) => (setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "")), setError(null))}
          placeholder="ABC123"
          aria-label="Course code"
          style={{ marginTop: 0 }}
          {...invalidProps("join-code-error", error)}
        />
        <button type="submit" className="btn" disabled={busy}>
          {busy ? "Joining" : "Join"}
        </button>
      </div>
      <FieldError id="join-code-error">{error}</FieldError>
    </form>
  );
}

/** Where a row goes: your unfinished encounter continues; anything else opens its feedback. */
const encounterHref = (r: EncounterSummary) => (r.status === "active" ? `/encounter/${r.id}` : `/encounter/${r.id}/feedback`);

function ResultCell({ r }: { r: EncounterSummary }) {
  if (r.status === "active") return <span className="badge">In progress</span>;
  if (!talked(r)) return <span className="muted">Ended before the conversation</span>;
  return <span className="muted">{levelCounts(r) || "Graded"}</span>;
}

/** Your encounters, newest first. Each row is a real link (the case name), so it works with a keyboard and stacks on phones. */
export function EncounterTable({ rows }: { rows: EncounterSummary[] }) {
  return (
    <div className="list">
      <table className="table">
        <thead>
          <tr>
            <th>Case</th>
            <th>Date</th>
            <th>Mode</th>
            <th className="end">Result</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>
                <Link className="row-link" to={encounterHref(r)}>
                  {r.caseName}
                  <span className="sr-only">{r.status === "active" ? ", continue" : ", open feedback"}</span>
                </Link>
                <div className="muted tiny">{r.configName}</div>
              </td>
              <td className="nowrap muted">{fmtDate(r.startedAt)}</td>
              <td className="nowrap">
                <span className="row tight muted" style={{ flexWrap: "nowrap" }}>
                  {modeIcon(r.mode)} {modeLabel(r.mode)}
                </span>
              </td>
              <td className="end">
                <ResultCell r={r} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function CaseCard({ a, onOpen, disabled }: { a: Assignment; onOpen: () => void; disabled?: boolean }) {
  return (
    <div className="card case-card">
      <div className="who">
        <Avatar look={a.look} size={64} />
        <div style={{ minWidth: 0 }}>
          <span className="badge" title={a.configName}>
            {configTag(a.configName)}
          </span>
          <h3 style={{ margin: "6px 0 0" }}>{a.caseName}</h3>
          <div className="muted small">{a.patientLabel}</div>
        </div>
      </div>
      <div>
        <span className="caption" style={{ marginBottom: 4 }}>
          Chief complaint
        </span>
        <p className="quote">“{a.chiefComplaint}”</p>
      </div>
      <div className="muted tiny">
        {a.configName}
        {a.diagnosisType === "diagnosis" ? ". Ends with your diagnosis." : "."}
      </div>
      <div className="foot">
        <span className="muted tiny">{a.attempts ? `Practiced ${a.attempts === 1 ? "once" : `${a.attempts} times`}` : "Not practiced yet"}</span>
        <button type="button" className="btn primary small" onClick={onOpen} disabled={disabled} aria-label={`Start ${a.caseName}`}>
          Start
        </button>
      </div>
    </div>
  );
}

export function StartEncounterModal({ assignment, onClose }: { assignment: Assignment; onClose: () => void }) {
  const navigate = useNavigate();
  const { ai } = useAuth();
  const { busy, error, run } = useAction();
  const support = voiceSupport();
  const liveOk = Boolean(ai?.live) && typeof AudioWorkletNode !== "undefined";
  const [mode, setMode] = useState<"text" | "voice" | "emotive">("text");
  const [language, setLanguage] = useState(() => {
    try {
      return localStorage.getItem("apa-lang") || "en-US";
    } catch {
      return "en-US";
    }
  });
  const start = () =>
    run(async () => {
      try {
        localStorage.setItem("apa-lang", language);
      } catch {
        /* private browsing */
      }
      const r = await api<{ id: string }>("/encounters", { body: { assignmentId: assignment.id, mode, language } });
      navigate(`/encounter/${r.id}`);
    });
  return (
    <Modal title={assignment.caseName} onClose={onClose} closable={!busy}>
      <div className="row" style={{ flexWrap: "nowrap", marginBottom: 20 }}>
        <Avatar look={assignment.look} size={64} />
        <div>
          <div className="headline">{assignment.patientLabel}</div>
          <div className="muted small">{assignment.configName}</div>
        </div>
      </div>
      {assignment.caseDescription && <p className="secondary">{assignment.caseDescription}</p>}
      <p className="quote" style={{ marginBottom: 24 }}>
        “{assignment.chiefComplaint}”
      </p>
      <div className="field">
        How do you want to talk?
        <div style={{ marginTop: 8 }}>
          <Segmented<"text" | "voice" | "emotive">
            label="Interaction mode"
            value={mode}
            onChange={setMode}
            options={[
              { id: "text", label: "Text", icon: Keyboard },
              { id: "voice", label: "Voice", icon: Mic, disabled: !support.available, title: support.reason },
              { id: "emotive", label: "Emotive voice", icon: AudioLines, disabled: !liveOk, title: liveOk ? "" : "Not available right now" },
            ]}
          />
        </div>
        <span className="hint" style={{ marginTop: 8 }}>
          {mode === "text" && "Type your questions. Works in any browser."}
          {mode === "voice" && "Speak, then pause, and the patient answers in a natural voice. Up to 30 minutes."}
          {mode === "emotive" && "A real-time spoken conversation with an expressive voice. Best with headphones. Up to 30 minutes."}
        </span>
        {!support.available && <span className="hint">{support.reason}</span>}
      </div>
      <label className="field">
        Language
        <select value={language} onChange={(e) => setLanguage(e.target.value)}>
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>
              {l.name}
            </option>
          ))}
        </select>
      </label>
      <ErrorNote error={error} />
      <button type="button" className="btn primary lg block" onClick={() => void start()} disabled={busy}>
        {busy ? "Preparing the patient" : "Start encounter"}
      </button>
    </Modal>
  );
}

// ---------- pages ----------

export function StudentHome() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const courses = useLoad(() => api<Course[]>("/courses"), []);
  const encounters = useLoad(() => api<EncounterSummary[]>("/encounters"), []);
  const demo = useAction();
  const rows = useMemo(() => [...(encounters.data ?? [])].sort((a, b) => b.startedAt - a.startedAt), [encounters.data]);
  const weekCount = rows.filter((r) => talked(r) && Date.now() - r.startedAt < 7 * DAY).length;
  const active = rows.find((r) => r.status === "active");
  // Attempts left before the conversation began are noise here; Progress lists everything.
  const recent = rows.filter((r) => r.status === "active" || talked(r)).slice(0, 5);
  const openDemo = () => void demo.run(async () => navigate(`/courses/${(await api<{ id: string }>("/courses/enroll", { body: { code: "MEDSIM" } })).id}`));
  return (
    <main className="page">
      <PageHeader
        eyebrow={new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
        title={`${greeting()}, ${shortName(user?.name ?? "")}`}
        subtitle={weekCount ? `You've practiced ${weekCount} time${weekCount === 1 ? "" : "s"} this week.` : "Pick a patient when you're ready."}
      />
      <DemoBanner />

      {active && (
        <div className="list" style={{ marginBottom: 48 }}>
          <Link className="list-row" to={`/encounter/${active.id}`}>
            <div className="grow">
              <span className="caption" style={{ color: "var(--accent)", marginBottom: 2 }}>
                Continue where you left off
              </span>
              <div className="headline" style={{ margin: 0 }}>
                {active.caseName}
              </div>
              <div className="muted tiny">
                {active.configName}. Started {fmtDate(active.startedAt)}.
              </div>
            </div>
            <ChevronRight size={18} className="chev" />
          </Link>
        </div>
      )}

      <div className="section-title" style={{ marginTop: 0 }}>
        <h2>Courses</h2>
      </div>
      <Loaded state={courses}>
        {(list) =>
          list.length ? (
            <div className="list">
              {list.map((c) => (
                <Link key={c.id} className="list-row" to={`/courses/${c.id}`}>
                  <span className="color-bar" style={{ background: courseColor(c.banner) }} />
                  <div className="grow" style={{ minWidth: 0 }}>
                    <div className="headline" style={{ margin: 0 }}>
                      {c.name}
                    </div>
                    <div className="muted tiny">{c.archived ? "Archived. You can review your past encounters." : c.description}</div>
                  </div>
                  <span className="muted tiny nowrap">{plural(c.caseCount ?? 0, "case")}</span>
                  <ChevronRight size={18} className="chev" />
                </Link>
              ))}
            </div>
          ) : (
            <EmptyState
              title="No courses yet"
              action={
                <>
                  <button type="button" className="btn primary" disabled={demo.busy} onClick={openDemo} {...invalidProps("demo-error", demo.error)}>
                    {demo.busy ? "Opening" : "Open the demo course"}
                  </button>
                  <FieldError id="demo-error">{demo.error}</FieldError>
                </>
              }
            >
              Your instructor will give you a course code or a join link. To try the app now, open the demo course.
            </EmptyState>
          )
        }
      </Loaded>
      <div style={{ marginTop: 24 }}>
        <JoinCourse onJoined={(id) => navigate(`/courses/${id}`)} />
      </div>

      <div className="section-title">
        <h2>Recent encounters</h2>
        {recent.length > 0 && <Link to="/history">See all</Link>}
      </div>
      <Loaded state={encounters}>
        {() =>
          recent.length ? (
            <EncounterTable rows={recent} />
          ) : (
            <EmptyState title="No encounters yet">Open a course and start a case. Your results will show up here.</EmptyState>
          )
        }
      </Loaded>
    </main>
  );
}

export function StudentCourse() {
  const { id } = useParams();
  const { user } = useAuth();
  const back = useBack(user?.role === "student" ? "/home" : "/educator");
  const d = useLoad(() => api<{ course: Course; role: string; assignments: Assignment[] }>(`/courses/${id}`), [id]);
  const [open, setOpen] = useState<Assignment | null>(null);
  return (
    <main className="page">
      <button type="button" className="btn ghost small" onClick={back} style={{ marginBottom: 24, marginLeft: -12 }}>
        <ArrowLeft size={16} /> Back
      </button>
      <Loaded state={d}>
        {({ course, role, assignments }) => {
          const done = assignments.filter((a) => a.attempts).length;
          const patients = new Set(assignments.map((a) => a.patientLabel || a.caseId)).size;
          return (
            <>
              <div style={{ borderLeft: `4px solid ${courseColor(course.banner)}`, paddingLeft: 20, marginBottom: 48 }}>
                <span className="eyebrow">Course</span>
                <h1>{course.name}</h1>
                {course.description && (
                  <p className="secondary" style={{ maxWidth: 640, fontSize: 17 }}>
                    {course.description}
                  </p>
                )}
                <p className="muted small" style={{ margin: "0 0 12px" }}>
                  {plural(patients, "patient")}, {plural(assignments.length, "case")}
                </p>
                {assignments.length > 0 && (
                  <div className="row" style={{ maxWidth: 360 }}>
                    <span className="muted tiny nowrap">
                      {done} of {assignments.length} practiced
                    </span>
                    <div className="progress" style={{ flex: 1 }} aria-hidden="true">
                      <span style={{ width: `${(done / assignments.length) * 100}%` }} />
                    </div>
                  </div>
                )}
                {role === "staff" && user?.role !== "student" && (
                  <Link className="btn small" to={`/educator/courses/${course.id}`} style={{ marginTop: 16 }}>
                    Manage course
                  </Link>
                )}
              </div>
              <DemoBanner />
              {course.archived && <div className="notice warn">This course is archived. You can review past encounters but not start new ones.</div>}
              {assignments.length ? (
                <div className="grid">
                  {assignments.map((a) => (
                    <CaseCard key={a.id} a={a} onOpen={() => setOpen(a)} disabled={course.archived} />
                  ))}
                </div>
              ) : (
                <EmptyState title="No cases yet">Your instructor hasn't added any cases to this course.</EmptyState>
              )}
            </>
          );
        }}
      </Loaded>
      {open && <StartEncounterModal assignment={open} onClose={() => setOpen(null)} />}
    </main>
  );
}

// ---------- progress ----------

interface PracticeCase {
  course: Course;
  assignment: Assignment;
}

/** Every case in your open courses, with how often you've practiced each. */
async function loadPracticeCases(): Promise<PracticeCase[]> {
  const courses = (await api<Course[]>("/courses")).filter((c) => !c.archived);
  const details = await Promise.all(courses.map((c) => api<{ course: Course; assignments: Assignment[] }>(`/courses/${c.id}`).catch(() => null)));
  return details.flatMap((d) => (d ? d.assignments.map((assignment) => ({ course: d.course, assignment })) : []));
}

/** Lowest latest level, then lowest recent average. */
const weakestSkill = (skills: SkillTrend[]) => [...skills].sort((a, b) => a.latestValue - b.latestValue || a.average - b.average)[0] ?? null;

/** The case you've practiced least; among equals, one whose rubric scores `skill`. */
function suggestCase(cases: PracticeCase[], skill: SkillTrend | null, rows: EncounterSummary[]): { pick: PracticeCase; trains: boolean } | null {
  const key = skill?.label.toLowerCase();
  const trains = new Set(key ? rows.filter((r) => r.scores.some((s) => s.category.trim().toLowerCase() === key)).map((r) => r.configName) : []);
  const scoresSkill = (c: PracticeCase) => (trains.has(c.assignment.configName) ? 1 : 0);
  const pick = [...cases].sort((a, b) => (a.assignment.attempts ?? 0) - (b.assignment.attempts ?? 0) || scoresSkill(b) - scoresSkill(a))[0];
  return pick ? { pick, trains: Boolean(scoresSkill(pick)) } : null;
}

function NextUp({ skills, rows, cases }: { skills: SkillTrend[]; rows: EncounterSummary[]; cases: ReturnType<typeof useLoad<PracticeCase[]>> }) {
  const [open, setOpen] = useState<Assignment | null>(null);
  const weakest = weakestSkill(skills);
  return (
    <section className="card" aria-labelledby="next-up-title" style={{ marginBottom: 48 }}>
      <h2 id="next-up-title" className="eyebrow" style={{ fontFamily: "var(--font-text)" }}>
        Next up
      </h2>
      {weakest ? (
        <>
          <div className="row" style={{ marginBottom: 4 }}>
            <h3 style={{ margin: 0 }}>Work on {weakest.label.charAt(0).toLowerCase() + weakest.label.slice(1)}</h3>
            <LevelPill level={weakest.latest} levels={weakest.levels} />
          </div>
          <p className="muted small" style={{ margin: "0 0 20px" }}>
            It's your lowest skill in your latest feedback.
          </p>
        </>
      ) : (
        <>
          <h3 style={{ margin: "0 0 4px" }}>Start your first case</h3>
          <p className="muted small" style={{ margin: "0 0 20px" }}>
            Your feedback will show which skill to work on next.
          </p>
        </>
      )}
      <Loaded state={cases}>
        {(list) => {
          const s = suggestCase(list, weakest, rows);
          if (!s)
            return (
              <p className="secondary" style={{ margin: 0 }}>
                Join a course to get a suggested case. <Link to="/home">Go to your courses</Link>
              </p>
            );
          const a = s.pick.assignment;
          const why = a.attempts
            ? `You've practiced it ${a.attempts === 1 ? "once" : `${a.attempts} times`}, less than your other cases`
            : "You haven't practiced it yet";
          return (
            <div className="row" style={{ flexWrap: "nowrap", alignItems: "flex-start", borderTop: "1px solid var(--separator)", paddingTop: 20 }}>
              <Avatar look={a.look} size={48} />
              <div className="grow" style={{ minWidth: 0, flex: 1 }}>
                <div className="row tight">
                  <span className="headline" style={{ margin: 0 }}>
                    {a.caseName}
                  </span>
                  <span className="badge" title={a.configName}>
                    {configTag(a.configName)}
                  </span>
                </div>
                <div className="muted small">
                  {a.patientLabel}. {s.pick.course.name}.
                </div>
                <p className="secondary small" style={{ margin: "8px 0 0" }}>
                  {why}
                  {weakest && s.trains ? `, and it's scored on ${weakest.label.charAt(0).toLowerCase() + weakest.label.slice(1)}.` : "."}
                </p>
              </div>
              <button type="button" className="btn primary" onClick={() => setOpen(a)} aria-label={`Start ${a.caseName}`}>
                Start
              </button>
            </div>
          );
        }}
      </Loaded>
      {open && <StartEncounterModal assignment={open} onClose={() => setOpen(null)} />}
    </section>
  );
}

/** "3 scored encounters. Up from Needs improvement." */
function trendNote(s: SkillTrend): string {
  const count = plural(s.history.length, "scored encounter");
  if (s.history.length < 2) return `${count} so far.`;
  const first = s.history[0];
  if (s.latestValue > first.value) return `${count}. Up from ${sentenceCase(first.level)}.`;
  if (s.latestValue < first.value) return `${count}. Down from ${sentenceCase(first.level)}.`;
  return `${count}. Holding steady.`;
}

function ProgressStats({ rows }: { rows: EncounterSummary[] }) {
  const practiced = rows.filter(talked);
  const completed = new Set(practiced.filter((r) => r.status === "done").map((r) => `${r.caseName}\n${r.configName}`)).size;
  const thisWeek = practiced.filter((r) => Date.now() - r.startedAt < 7 * DAY).length;
  const days = new Set(practiced.map((r) => dayKey(r.startedAt)));
  const streak = practiceStreak(days);
  // Three zeros say nothing to someone who hasn't started; Next up covers that case.
  if (!practiced.length) return null;
  return (
    <section aria-label="Your practice" style={{ marginBottom: 16 }}>
      <div className="stats">
        <Stat value={completed} label={completed === 1 ? "Case completed" : "Cases completed"} />
        <Stat value={thisWeek} label={thisWeek === 1 ? "Encounter this week" : "Encounters this week"} />
        {streak >= 2 ? <Stat value={streak} label="Days in a row" /> : <Stat value={days.size} label={days.size === 1 ? "Day practiced" : "Days practiced"} />}
      </div>
    </section>
  );
}

/** Skills grouped by the kind of encounter that scores them (each has its own rubric), most recently practiced first. */
function SkillTrends({ skills }: { skills: SkillTrend[] }) {
  const groups = new Map<string, SkillTrend[]>();
  for (const s of skills) {
    const tag = configTag(s.configName);
    groups.set(tag, [...(groups.get(tag) ?? []), s]);
  }
  const lastAt = (list: SkillTrend[]) => Math.max(...list.map((s) => s.history[s.history.length - 1].at));
  const ordered = [...groups.entries()].sort(([, a], [, b]) => lastAt(b) - lastAt(a));
  return (
    <>
      <div className="section-title">
        <h2>Skills over time</h2>
      </div>
      <div className="stack">
        {ordered.map(([tag, list], i) => (
          <div key={tag}>
            <h3 id={`skills-${i}`} className="caption" style={{ fontFamily: "var(--font-text)", margin: "0 0 8px" }}>
              {tag}
            </h3>
            <div className="list">
              <table className="table" aria-labelledby={`skills-${i}`}>
                {/* Same column widths in every group so the trends line up (phones stack the rows instead). */}
                <colgroup>
                  <col style={{ width: "55%" }} />
                  <col style={{ width: "20%" }} />
                  <col />
                </colgroup>
                {/* One visible header row is enough; later tables keep theirs for screen readers. */}
                <thead className={i ? "sr-only" : undefined}>
                  <tr>
                    <th>Skill</th>
                    <th>Trend</th>
                    <th className="end">Latest</th>
                  </tr>
                </thead>
                <tbody>
                  {list.map((s) => {
                    const shown = s.history.slice(-10);
                    return (
                      <tr key={s.label}>
                        <td>
                          {s.label}
                          <div className="muted tiny">{trendNote(s)}</div>
                        </td>
                        <td>
                          <Sparkline values={shown.map((h) => h.value)} label={`${s.label}, oldest first: ${shown.map((h) => sentenceCase(h.level)).join(", ")}`} />
                        </td>
                        <td className="end">
                          <LevelPill level={s.latest} levels={s.levels} />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

export function History() {
  const encounters = useLoad(() => api<EncounterSummary[]>("/encounters"), []);
  const cases = useLoad(loadPracticeCases, []);
  const notes = useLoad(() => api<{ id: string; body: string; refId: string; read: number; createdAt: number }[]>("/me/notifications"), []);
  const rows = useMemo(() => [...(encounters.data ?? [])].sort((a, b) => b.startedAt - a.startedAt), [encounters.data]);
  const skills = useMemo(() => skillSummary(rows), [rows]);
  const unread = notes.data?.filter((n) => !n.read) ?? [];
  return (
    <main className="page">
      <PageHeader eyebrow="Progress" title="How you're doing" subtitle="What to practice next, how each skill is changing, and every encounter you've had." />
      {!!unread.length && (
        <div className="card grouped" style={{ marginBottom: 48 }}>
          <div className="row spread">
            <h4 style={{ margin: 0 }}>New comments from your instructors</h4>
            <button type="button" className="btn small" onClick={() => void api("/me/notifications/read", { body: {} }).then(() => notes.reload())}>
              Mark as read
            </button>
          </div>
          <ul style={{ margin: "12px 0 0", paddingLeft: 18 }}>
            {unread.map((n) => (
              <li key={n.id}>
                <Link to={`/encounter/${n.refId}/feedback`}>{n.body}</Link> <span className="muted tiny">{fmtDate(n.createdAt)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      <Loaded state={encounters}>
        {() => (
          <>
            <NextUp skills={skills} rows={rows} cases={cases} />
            <ProgressStats rows={rows} />
            {skills.length > 0 && <SkillTrends skills={skills} />}
            <div className="section-title">
              <h2>All encounters</h2>
            </div>
            {rows.length ? <EncounterTable rows={rows} /> : <EmptyState title="No encounters yet">Open a case from one of your courses to begin.</EmptyState>}
          </>
        )}
      </Loaded>
    </main>
  );
}

// ---------- settings ----------

function SettingsSection({ title, aside, children, first }: { title: string; aside?: ReactNode; children: ReactNode; first?: boolean }) {
  return (
    <section className={first ? "split" : "split section"} aria-label={title}>
      <div>
        <h3>{title}</h3>
        {aside && <p className="muted small">{aside}</p>}
      </div>
      <div>{children}</div>
    </section>
  );
}

type PasswordField = "current" | "next" | "confirm" | "form";

function ChangePassword({ email }: { email: string }) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<Partial<Record<PasswordField, string>>>({});
  const [busy, setBusy] = useState(false);
  const [flash, showFlash] = useFlash(3000);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const errs: Partial<Record<PasswordField, string>> = {};
    if (!current) errs.current = "Enter your current password.";
    if (!next) errs.next = "Enter a new password.";
    else if (next.length < 8) errs.next = "Use at least 8 characters.";
    else if (!next.trim()) errs.next = "A password can't be only spaces.";
    if (!errs.next && confirm !== next) errs.confirm = confirm ? "The passwords don't match." : "Enter the new password again.";
    setErrors(errs);
    const first = (["current", "next", "confirm"] as const).find((f) => errs[f]);
    if (first) return focusSoon(`password-${first}`);
    setBusy(true);
    try {
      await api("/auth/password", { body: { currentHash: await passwordHash(email, current), newHash: await passwordHash(email, next) } });
      setCurrent("");
      setNext("");
      setConfirm("");
      showFlash("Password changed");
    } catch (err) {
      const wrong = err instanceof ApiError && err.status === 403;
      setErrors(wrong ? { current: (err as Error).message } : { form: (err as Error).message });
      if (wrong) focusSoon("password-current");
    } finally {
      setBusy(false);
    }
  };
  return (
    <form onSubmit={(e) => void submit(e)} noValidate style={{ maxWidth: 440 }}>
      {/* Lets password managers file the new password under the right account. */}
      <input type="email" name="username" autoComplete="username" value={email} readOnly tabIndex={-1} hidden />
      <label className="field">
        Current password
        <input
          id="password-current"
          type="password"
          autoComplete="current-password"
          value={current}
          onChange={(e) => (setCurrent(e.target.value), setErrors({ ...errors, current: undefined }))}
          {...invalidProps("password-current-error", errors.current)}
        />
        <FieldError id="password-current-error">{errors.current}</FieldError>
      </label>
      <label className="field">
        New password
        <span className="hint" id="password-next-hint">
          At least 8 characters.
        </span>
        <input
          id="password-next"
          type="password"
          autoComplete="new-password"
          value={next}
          onChange={(e) => (setNext(e.target.value), setErrors({ ...errors, next: undefined }))}
          {...invalidProps("password-next-error", errors.next)}
          aria-describedby={errors.next ? "password-next-error" : "password-next-hint"}
        />
        <FieldError id="password-next-error">{errors.next}</FieldError>
      </label>
      <label className="field">
        Confirm new password
        <input
          id="password-confirm"
          type="password"
          autoComplete="new-password"
          value={confirm}
          onChange={(e) => (setConfirm(e.target.value), setErrors({ ...errors, confirm: undefined }))}
          {...invalidProps("password-confirm-error", errors.confirm)}
        />
        <FieldError id="password-confirm-error">{errors.confirm}</FieldError>
      </label>
      {errors.form && (
        <p className="field-error" role="alert" style={{ marginBottom: 16 }}>
          {errors.form}
        </p>
      )}
      <div className="row">
        <button type="submit" className="btn primary" disabled={busy}>
          {busy ? "Changing password" : "Change password"}
        </button>
        <Flash text={flash} />
      </div>
    </form>
  );
}

function DeleteAccount({ email, educator }: { email: string; educator: boolean }) {
  const { setUser, setNotice } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ password?: string; form?: string }>({});
  const [busy, setBusy] = useState(false);
  const close = () => {
    setOpen(false);
    setPassword("");
    setErrors({});
  };
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    if (!password) {
      setErrors({ password: "Enter your password to confirm." });
      return focusSoon("delete-password");
    }
    setBusy(true);
    setErrors({});
    try {
      await api("/me", { method: "DELETE", body: { passwordHash: await passwordHash(email, password) } });
      setNotice("Your account and data were deleted.");
      setUser(null);
      navigate("/", { replace: true });
    } catch (err) {
      const wrong = err instanceof ApiError && err.status === 403;
      setErrors(wrong ? { password: (err as Error).message } : { form: (err as Error).message });
      if (wrong) focusSoon("delete-password");
      setBusy(false);
    }
  };
  return (
    <>
      <button type="button" className="btn danger" onClick={() => setOpen(true)}>
        Delete my account and data
      </button>
      {open && (
        <Modal title="Delete your account?" onClose={close} closable={!busy}>
          <form onSubmit={(e) => void submit(e)} noValidate>
            <p className="secondary">
              This deletes your account, your encounters with their transcripts, scores and feedback, your instructors' comments on them, your course
              memberships and your notifications. It can't be undone. If you want a copy, download your data first.
            </p>
            {educator && (
              <p className="secondary">
                Courses that still have students must be archived or handed over first. Cases and configurations that are shared or used in a course stay on
                the site.
              </p>
            )}
            <input type="email" name="username" autoComplete="username" value={email} readOnly tabIndex={-1} hidden />
            <label className="field">
              Your password
              <input
                id="delete-password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => (setPassword(e.target.value), setErrors({}))}
                {...invalidProps("delete-password-error", errors.password)}
              />
              <FieldError id="delete-password-error">{errors.password}</FieldError>
            </label>
            {errors.form && (
              <p className="field-error" role="alert" style={{ marginBottom: 16 }}>
                {errors.form}
              </p>
            )}
            <div className="row">
              <button type="submit" className="btn danger" disabled={busy}>
                {busy ? "Deleting" : "Delete my account"}
              </button>
              <button type="button" className="btn ghost" onClick={close} disabled={busy}>
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}

function AiKey() {
  const { user, refresh } = useAuth();
  const [provider, setProvider] = useState<"gemini" | "groq">("gemini");
  const [key, setKey] = useState("");
  const [saved, setSaved] = useState<string | null>(null);
  const { busy, error, run } = useAction();
  const save = () =>
    run(async () => {
      await api("/me/ai-key", { method: "PUT", body: { provider, key } });
      setKey("");
      setSaved("Saved. Your practice now uses your own free allowance first.");
      await refresh();
    });
  const remove = () =>
    run(async () => {
      await api("/me/ai-key", { method: "DELETE" });
      setSaved("Your key was removed.");
      await refresh();
    });
  return (
    <>
      <p className="secondary">
        Everyone shares a free daily AI allowance. Adding your own free Google key gives you more practice and leaves the shared allowance for others. It takes
        about a minute and needs no credit card.
      </p>
      <ol className="secondary small" style={{ paddingLeft: 18 }}>
        <li>
          Open{" "}
          <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">
            aistudio.google.com/apikey
          </a>{" "}
          and sign in with a Google account.
        </li>
        <li>Choose Create API key and copy it.</li>
        <li>Paste it below and save.</li>
      </ol>
      {saved && <div className="notice ok">{saved}</div>}
      <div className="two-col">
        <label className="field">
          Provider
          <select value={provider} onChange={(e) => setProvider(e.target.value as "gemini" | "groq")}>
            <option value="gemini">Google AI Studio</option>
            <option value="groq">Groq</option>
          </select>
        </label>
        <label className="field">
          API key
          <input type="password" autoComplete="off" value={key} onChange={(e) => setKey(e.target.value)} {...invalidProps("ai-key-error", error)} />
          <FieldError id="ai-key-error">{error}</FieldError>
        </label>
      </div>
      <div className="row">
        <button type="button" className="btn primary" onClick={() => void save()} disabled={busy || !key}>
          Save key
        </button>
        {user?.hasOwnKey && (
          <button type="button" className="btn danger" onClick={() => void remove()} disabled={busy}>
            Remove my key
          </button>
        )}
      </div>
    </>
  );
}

export function Settings() {
  const { user } = useAuth();
  if (!user) return null;
  const educator = user.role !== "student";
  return (
    <main className="page">
      <PageHeader eyebrow="Settings" title="Account" />
      <SettingsSection title="Profile" first>
        <div className="list">
          <div className="list-row">
            <span className="muted" style={{ width: 80 }}>
              Name
            </span>
            <span className="grow">{user.name}</span>
          </div>
          <div className="list-row">
            <span className="muted" style={{ width: 80 }}>
              Email
            </span>
            <span className="grow truncate">{user.email}</span>
          </div>
          <div className="list-row">
            <span className="muted" style={{ width: 80 }}>
              Role
            </span>
            <span className="grow">{sentenceCase(user.role)}</span>
          </div>
        </div>
      </SettingsSection>

      <SettingsSection title="Password" aside="Changing it signs you out on your other devices.">
        <ChangePassword email={user.email} />
      </SettingsSection>

      <SettingsSection title="Your own AI key" aside={`Optional. ${user.hasOwnKey ? "Your key is active." : "You're using the shared allowance."}`}>
        <AiKey />
      </SettingsSection>

      <SettingsSection
        title="Your data"
        aside={
          <>
            Read <Link to="/privacy">how your data is used</Link>.
          </>
        }
      >
        <h4 style={{ marginTop: 0 }}>Download my data</h4>
        <p className="secondary">A file with your account, courses, encounters, transcripts, feedback and comments, in JSON format.</p>
        <a className="btn" href="/api/me/export" download>
          <Download size={16} /> Download my data
        </a>
        <h4 style={{ marginTop: 32 }}>Delete my account and data</h4>
        <p className="secondary">
          Deletes your account and everything stored about your practice: encounters, transcripts, scores, feedback, comments and notifications. You'll be
          asked for your password. This can't be undone.
        </p>
        <DeleteAccount email={user.email} educator={educator} />
      </SettingsSection>
    </main>
  );
}
