import { useEffect, useRef, useState, type FormEvent, type InputHTMLAttributes, type ReactNode } from "react";
import { Link, Navigate, useLocation, useNavigate, useParams } from "react-router-dom";
import { Briefcase, GraduationCap, KeyRound, Lock, Mail, User as UserIcon } from "lucide-react";
import type { User } from "../../shared/types";
import { APP_NAME, INSPIRED_BY, NOT_AFFILIATED } from "../../shared/defaults";
import { ApiError, api, passwordHash } from "../api";
import { FieldError, Loading, Segmented, homeFor, invalidProps, readNext, signInPath, useAuth } from "../ui";
import { Avatar } from "../components/Avatar";
import { Footer } from "../components/Visuals";
import { DEMO_LOOKS } from "../components/demoLooks";

function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <main className="auth">
        <div className="auth-form">{children}</div>
      </main>
      <Footer />
    </>
  );
}

function IconInput({ icon: Icon, ...props }: { icon: typeof Mail } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="input-icon">
      <Icon size={18} />
      <input {...props} />
    </div>
  );
}

// ---------- landing ----------

export function Landing() {
  const notice = useNotice();
  return (
    <>
      <main className="page">
        {notice && (
          <div className="notice ok" role="status" style={{ marginBottom: 32 }}>
            {notice}
          </div>
        )}
        <section className="hero">
          <div>
            <span className="eyebrow">{INSPIRED_BY}</span>
            <h1>Rehearse the patient interview before it counts.</h1>
            <p className="lede">
              Talk with simulated patients by text or voice. Take the history, order exams and tests, commit to a diagnosis, and get feedback scored against
              your course rubric as soon as you finish.
            </p>
            <div className="row">
              <Link className="btn primary lg" to="/signup">
                Create a free account
              </Link>
              <Link className="btn plain lg" to="/signin">
                Sign in
              </Link>
            </div>
            <p className="muted tiny" style={{ marginTop: 16 }}>
              To try it now, create a student account and join the demo course with code <span className="code">MEDSIM</span>.
            </p>
          </div>
          <Preview />
        </section>

        <section className="section split">
          <div>
            <h2>How a session works</h2>
            <p className="muted">About fifteen minutes, start to finish.</p>
          </div>
          <ol className="steps">
            <li>
              <div>
                <h4>Read the brief</h4>
                <p className="muted" style={{ margin: 0 }}>
                  You see who the patient is, why they came in, and what your instructor wants you to practice.
                </p>
              </div>
            </li>
            <li>
              <div>
                <h4>Interview the patient</h4>
                <p className="muted" style={{ margin: 0 }}>
                  Type or speak. The patient answers in character and only shares what you ask about. Their face and voice react to how the visit is going.
                </p>
              </div>
            </li>
            <li>
              <div>
                <h4>Examine and test</h4>
                <p className="muted" style={{ margin: 0 }}>
                  Order vitals, exam findings, labs and imaging. Results come straight from the case your instructor wrote.
                </p>
              </div>
            </li>
            <li>
              <div>
                <h4>Get feedback and try again</h4>
                <p className="muted" style={{ margin: 0 }}>
                  Each rubric skill is scored with quotes from your own words, plus the questions and tests you missed. Retry any case as often as you like.
                </p>
              </div>
            </li>
          </ol>
        </section>

        <section className="section split">
          <div>
            <h2>For educators</h2>
          </div>
          <div>
            <p className="secondary" style={{ fontSize: 17 }}>
              You write the medicine. The AI only plays the patient. Build a patient profile (or have the assistant draft one), set the tasks and rubric, and
              share a six-character course code. Every transcript, score and missed question is in one place, and you can comment on any line.
            </p>
            <div className="list" style={{ marginTop: 24 }}>
              <div className="list-row">
                <span className="grow">Patient profiles with history, personality, voice and appearance</span>
              </div>
              <div className="list-row">
                <span className="grow">Rubrics, encounter tasks, role-play instructions and SOAP-note feedback</span>
              </div>
              <div className="list-row">
                <span className="grow">Course codes, rosters, results, CSV export and a course report</span>
              </div>
            </div>
          </div>
        </section>

        <section className="section split">
          <div>
            <h2>Where the idea comes from</h2>
          </div>
          <div>
            <p className="secondary" style={{ fontSize: 17 }}>
              {APP_NAME} is heavily inspired by the AI Patient Actor built by Dr. Thomas Thesen and colleagues at Dartmouth's Geisel School of Medicine. Their
              published work showed that expert-written cases, with the AI limited to playing the patient, give students realistic practice with reliable
              medical content. This is an independent, free implementation of that approach.
            </p>
            <p className="muted tiny">{NOT_AFFILIATED}</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

/** A flat, static preview of a real encounter screen. */
function Preview() {
  return (
    <div className="preview" aria-hidden="true">
      <div className="preview-head">
        <Avatar look={DEMO_LOOKS.priya} emotion="in_pain" size={44} />
        <div style={{ flex: 1 }}>
          <div className="headline" style={{ fontSize: 15, margin: 0 }}>
            Priya Nair, 39
          </div>
          <div className="muted tiny">Sudden headache. Urgent care.</div>
        </div>
        <span className="status live">Listening</span>
      </div>
      <div className="preview-body">
        <div className="msg doctor" style={{ fontSize: 15 }}>
          Hi Ms. Nair, I'm Sam, a medical student. What brings you in today?
        </div>
        <div className="msg patient" style={{ fontSize: 15 }}>
          The worst headache of my life. It came on all at once at the gym.
        </div>
        <div className="record" style={{ margin: "4px 0", fontSize: 14 }}>
          <span className="caption">Neck exam</span>
          Marked neck stiffness; positive Kernig sign
        </div>
      </div>
      <div className="preview-foot row spread">
        <span>Rapport and introduction</span>
        <span className="badge high">Proficient</span>
      </div>
    </div>
  );
}

// ---------- shared auth helpers ----------

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const EMAIL_TAKEN = "An account with this email already exists. Sign in instead.";
const JOIN_PATH = /^\/join\/([A-Za-z0-9]{1,12})\/?$/;

/** Course codes are letters and digits; links and typing may add spaces or lower case. */
const cleanCode = (raw: string) => raw.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12);

/** The course code a visitor is joining with: ?join=CODE, or ?next=/join/CODE left by the join page. */
function joinCodeFrom(search: string): string {
  const raw = new URLSearchParams(search).get("join") ?? readNext(search)?.match(JOIN_PATH)?.[1] ?? "";
  return cleanCode(raw);
}

/** Sign-up and sign-in link to each other without losing where the visitor was going. */
function signUpHref(joinCode: string, next: string | null): string {
  if (joinCode) return `/signup?join=${joinCode}`;
  return next ? `/signup?next=${encodeURIComponent(next)}` : "/signup";
}
function signInHref(joinCode: string, next: string | null): string {
  return signInPath(joinCode ? `/join/${joinCode}` : (next ?? undefined));
}

/** Focuses a field once the error under it has rendered, so screen readers read the message with it. */
const focusSoon = (id: string) => window.requestAnimationFrame(() => document.getElementById(id)?.focus());

/**
 * The one-time message for this screen, such as "Your session ended. Sign in again." It is taken out of
 * the auth state when the page opens, so it shows here once and not on the next visit.
 */
function useNotice(): string | null {
  const { notice, setNotice } = useAuth();
  const [message, setMessage] = useState(notice);
  useEffect(() => {
    if (!notice) return;
    setMessage(notice);
    setNotice(null);
  }, [notice, setNotice]);
  return message;
}

// ---------- sign in ----------

type SignInField = "email" | "password" | "form";

export function SignIn() {
  const { user, loading, setUser, refresh } = useAuth();
  const navigate = useNavigate();
  const { search } = useLocation();
  const notice = useNotice();
  const next = readNext(search);
  const joinCode = joinCodeFrom(search);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Partial<Record<SignInField, string>>>({});
  const [busy, setBusy] = useState(false);
  // Already signed in (another tab, or the back button): go where sign-in would have gone.
  if (!loading && user && !busy) return <Navigate to={next ?? homeFor(user.role)} replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const errs: Partial<Record<SignInField, string>> = {};
    const address = email.trim();
    if (!address) errs.email = "Enter your email address.";
    else if (!EMAIL_RE.test(address)) errs.email = "Enter a valid email address.";
    if (!password) errs.password = "Enter your password.";
    setErrors(errs);
    if (errs.email || errs.password) return focusSoon(errs.email ? "signin-email" : "signin-password");
    setBusy(true);
    try {
      const r = await api<{ user: User }>("/auth/signin", { body: { email: address, clientHash: await passwordHash(address, password) } });
      setUser(r.user);
      await refresh();
      navigate(next ?? homeFor(r.user.role), { replace: true });
    } catch (err) {
      // 401 is the wrong email or password; anything else (too many tries, offline) belongs to the form.
      const wrong = err instanceof ApiError && err.status === 401;
      setErrors(wrong ? { password: (err as Error).message } : { form: (err as Error).message });
      if (wrong) focusSoon("signin-password");
      setBusy(false);
    }
  };

  return (
    <AuthLayout>
      <form onSubmit={(e) => void submit(e)} noValidate>
        {notice && (
          <div className="notice info" role="status" style={{ marginBottom: 24 }}>
            {notice}
          </div>
        )}
        <span className="eyebrow">{joinCode ? `Joining course ${joinCode}` : "Welcome back"}</span>
        <h1>{joinCode ? "Sign in to join" : "Sign in to continue"}</h1>
        <label className="field">
          Email
          <IconInput
            id="signin-email"
            icon={Mail}
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => (setEmail(e.target.value), errors.email && setErrors({ ...errors, email: undefined }))}
            {...invalidProps("signin-email-error", errors.email)}
          />
          <FieldError id="signin-email-error">{errors.email}</FieldError>
        </label>
        <label className="field">
          Password
          <IconInput
            id="signin-password"
            icon={Lock}
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => (setPassword(e.target.value), errors.password && setErrors({ ...errors, password: undefined }))}
            {...invalidProps("signin-password-error", errors.password)}
          />
          <FieldError id="signin-password-error">{errors.password}</FieldError>
        </label>
        {errors.form && (
          <p className="field-error" role="alert" style={{ marginBottom: 16 }}>
            {errors.form}
          </p>
        )}
        <button type="submit" className="btn primary lg block" disabled={busy}>
          {busy ? "Signing in" : "Sign in"}
        </button>
        <p className="muted small" style={{ marginTop: 24 }}>
          New here? <Link to={signUpHref(joinCode, next)}>Create an account</Link>
          <br />
          Forgot your password? <Link to="/reset">Use a reset code</Link>
        </p>
      </form>
    </AuthLayout>
  );
}

// ---------- sign up ----------

type SignUpField = "name" | "email" | "password" | "confirm" | "accessKey" | "consent" | "turnstile" | "form";
type SignUpErrors = Partial<Record<SignUpField, string>>;
type CheckResult = { emailAvailable: boolean; emailAllowed: boolean; accessKeyValid: boolean | null };

/** "uni.edu", "uni.edu or college.edu", "a.edu, b.edu or c.edu", as the server words it. */
const domainList = (domains: string[]) => (domains.length > 1 ? `${domains.slice(0, -1).join(", ")} or ${domains[domains.length - 1]}` : (domains[0] ?? ""));

/** Which field a sign-up error from the server belongs to, so it shows next to that field. */
function signUpErrorField(err: unknown): SignUpField {
  if (!(err instanceof ApiError) || err.status === 429 || err.status === 0) return "form";
  const msg = err.message;
  if (err.status === 409 || /email/i.test(msg)) return "email";
  if (/access key|educator sign-up/i.test(msg)) return "accessKey";
  if (/security check/i.test(msg)) return "turnstile";
  if (/terms/i.test(msg)) return "consent";
  if (/your name/i.test(msg)) return "name";
  if (/password/i.test(msg)) return "password";
  return "form";
}

const SIGNUP_ORDER: SignUpField[] = ["name", "email", "password", "confirm", "accessKey", "consent", "turnstile", "form"];
const SIGNUP_IDS: Record<SignUpField, string> = {
  name: "signup-name",
  email: "signup-email",
  password: "signup-password",
  confirm: "signup-confirm",
  accessKey: "signup-key",
  consent: "signup-consent",
  turnstile: "signup-check",
  form: "signup-submit",
};

export function SignUp() {
  const { setUser, refresh, educatorSignup, turnstileSiteKey: siteKey, emailDomains: domains } = useAuth();
  const navigate = useNavigate();
  const { search } = useLocation();
  const next = readNext(search);
  const joinCode = joinCodeFrom(search);
  const [role, setRole] = useState<"student" | "educator">("student");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [accessKey, setAccessKey] = useState("");
  const [consent, setConsent] = useState(false);
  const [token, setToken] = useState("");
  const [resetCheck, setResetCheck] = useState(0);
  const [errors, setErrors] = useState<SignUpErrors>({});
  const [busy, setBusy] = useState(false);
  const latestEmail = useRef("");
  const educator = !joinCode && role === "educator";

  const setError = (field: SignUpField, message: string | null) => setErrors((prev) => ({ ...prev, [field]: message ?? undefined }));
  const showErrors = (errs: SignUpErrors) => {
    setErrors(errs);
    const first = SIGNUP_ORDER.find((f) => errs[f]);
    if (first && first !== "form") focusSoon(SIGNUP_IDS[first]);
  };
  const domainMessage = () => (domains.length ? `Sign-ups here are limited to ${domainList(domains)} email addresses.` : "Enter a valid email address.");
  const emailFormat = (v: string) => (!v ? "Enter your email address." : EMAIL_RE.test(v) ? null : "Enter a valid email address.");
  const emailProblem = (r: CheckResult) => (!r.emailAllowed ? domainMessage() : !r.emailAvailable ? EMAIL_TAKEN : null);

  /** The server's early check. Null when it can't answer (too many checks, offline): sign-up checks again anyway. */
  const check = async (withKey: boolean): Promise<CheckResult | null> => {
    try {
      return await api<CheckResult>("/auth/check", { body: { email: email.trim(), role: educator ? "educator" : "student", ...(withKey && educator ? { accessKey } : {}) } });
    } catch {
      return null;
    }
  };

  const onEmailBlur = async () => {
    const v = email.trim();
    if (!v) return; // tabbing past an empty field is not an error yet
    const format = emailFormat(v);
    if (format) return setError("email", format);
    const r = await check(false);
    if (r && latestEmail.current.trim() === v) setError("email", emailProblem(r));
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const errs: SignUpErrors = {};
    if (name.trim().length < 2) errs.name = "Enter your full name.";
    const format = emailFormat(email.trim());
    if (format) errs.email = format;
    if (!password) errs.password = "Create a password.";
    else if (password.length < 8) errs.password = "Use at least 8 characters.";
    else if (!password.trim()) errs.password = "A password can't be only spaces.";
    if (!errs.password && confirm !== password) errs.confirm = confirm ? "The passwords don't match." : "Enter the password again.";
    if (educator && !educatorSignup) errs.accessKey = "Educator sign-up isn't turned on for this site yet.";
    else if (educator && !accessKey.trim()) errs.accessKey = "Enter the educator access key.";
    if (!consent) errs.consent = "Check the box to agree before you continue.";
    if (siteKey && !token) errs.turnstile = "Wait for the security check to finish, then try again.";
    if (Object.keys(errs).length) return showErrors(errs);
    setBusy(true);
    try {
      const r = await check(true);
      if (r) {
        const problem = emailProblem(r);
        if (problem) errs.email = problem;
        if (educator && r.accessKeyValid === false) errs.accessKey = "That educator access key is not correct.";
        if (Object.keys(errs).length) {
          setBusy(false);
          return showErrors(errs);
        }
      }
      const res = await api<{ user: User; enrolledCourseId: string | null }>("/auth/signup", {
        body: {
          role: educator ? "educator" : "student",
          name: name.trim(),
          email: email.trim(),
          clientHash: await passwordHash(email.trim(), password),
          consent,
          ...(educator ? { accessKey: accessKey.trim() } : {}),
          ...(joinCode ? { joinCode } : {}),
          ...(siteKey ? { turnstileToken: token } : {}),
        },
      });
      setUser(res.user);
      await refresh();
      // A join code goes through the join page, which confirms the course or says why the code didn't work.
      const student = res.user.role === "student";
      const dest = student && joinCode ? `/join/${joinCode}` : (next ?? (res.enrolledCourseId ? `/courses/${res.enrolledCourseId}` : homeFor(res.user.role)));
      navigate(dest, { replace: true });
    } catch (err) {
      // Without a widget on the page (the site settings didn't load) there is no field to put a bot-check error under.
      const f = signUpErrorField(err);
      showErrors({ [f === "turnstile" && !siteKey ? "form" : f]: (err as Error).message });
      // A security check token works once; get a fresh one for the next try.
      setToken("");
      setResetCheck((n) => n + 1);
      setBusy(false);
    }
  };

  const field = (f: SignUpField) => ({ id: SIGNUP_IDS[f], ...invalidProps(`${SIGNUP_IDS[f]}-error`, errors[f]) });
  const clear = (f: SignUpField) => errors[f] && setError(f, null);
  const signInLink = signInHref(joinCode, next);

  return (
    <AuthLayout>
      <form onSubmit={(e) => void submit(e)} noValidate>
        <span className="eyebrow">{joinCode ? `Joining course ${joinCode}` : "Free for students and educators"}</span>
        <h1>{joinCode ? "Create an account to join" : "Create your account"}</h1>
        {joinCode ? (
          <div className="notice info" style={{ marginBottom: 24 }}>
            Joining course <span className="code">{joinCode}</span>. You'll be added to it as a student as soon as your account is ready.
          </div>
        ) : (
          <div className="field">
            <span id="signup-role-label">Role</span>
            <div style={{ marginTop: 8 }}>
              <Segmented<"student" | "educator">
                label="Role"
                value={role}
                onChange={(v) => (setRole(v), setError("accessKey", null))}
                options={[
                  { id: "student", label: "Student", icon: GraduationCap },
                  { id: "educator", label: "Educator", icon: Briefcase },
                ]}
              />
            </div>
            <span className="hint">
              {educator
                ? educatorSignup
                  ? "Write cases, build courses and review your students' encounters. You need an access key from your site administrator."
                  : "Educator sign-up isn't turned on for this site yet. Ask your site administrator."
                : "Practice interviews with simulated patients and get feedback on each one."}
            </span>
          </div>
        )}

        <label className="field">
          Full name
          <IconInput {...field("name")} icon={UserIcon} type="text" autoComplete="name" value={name} onChange={(e) => (setName(e.target.value), clear("name"))} />
          <FieldError id="signup-name-error">{errors.name}</FieldError>
        </label>

        <label className="field">
          Email
          <span className="hint" id="signup-email-hint">
            {domains.length ? `Use your ${domainList(domains)} email address.` : "Use your school email so your instructor recognizes you."}
          </span>
          <IconInput
            {...field("email")}
            aria-describedby={errors.email ? "signup-email-error" : "signup-email-hint"}
            icon={Mail}
            type="email"
            autoComplete="email"
            placeholder="you@school.edu"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              latestEmail.current = e.target.value;
              clear("email");
            }}
            onBlur={() => void onEmailBlur()}
          />
          <FieldError id="signup-email-error">
            {errors.email === EMAIL_TAKEN ? (
              <>
                An account with this email already exists. <Link to={signInLink}>Sign in instead</Link>.
              </>
            ) : (
              errors.email
            )}
          </FieldError>
        </label>

        <label className="field">
          Password
          <span className="hint" id="signup-password-hint">
            At least 8 characters.
          </span>
          <IconInput
            {...field("password")}
            aria-describedby={errors.password ? "signup-password-error" : "signup-password-hint"}
            icon={Lock}
            type="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => (setPassword(e.target.value), clear("password"))}
          />
          <FieldError id="signup-password-error">{errors.password}</FieldError>
        </label>

        <label className="field">
          Confirm password
          <IconInput {...field("confirm")} icon={Lock} type="password" autoComplete="new-password" value={confirm} onChange={(e) => (setConfirm(e.target.value), clear("confirm"))} />
          <FieldError id="signup-confirm-error">{errors.confirm}</FieldError>
        </label>

        {educator && (
          <label className="field">
            Educator access key
            <span className="hint" id="signup-key-hint">
              Your site administrator can give you this key.
            </span>
            <IconInput
              {...field("accessKey")}
              aria-describedby={errors.accessKey ? "signup-key-error" : "signup-key-hint"}
              icon={KeyRound}
              type="password"
              autoComplete="off"
              value={accessKey}
              onChange={(e) => (setAccessKey(e.target.value), clear("accessKey"))}
            />
            <FieldError id="signup-key-error">{errors.accessKey}</FieldError>
          </label>
        )}

        <div className="field">
          <label className="check" style={{ marginBottom: 0 }}>
            <input {...field("consent")} type="checkbox" checked={consent} onChange={(e) => (setConsent(e.target.checked), clear("consent"))} />
            <span>
              I understand that my conversations, and my voice in voice modes, are processed by Google's Gemini AI, which may use them to improve its products.
              Cases are fictional, so I won't enter real patient information, and this is practice, not medical advice.{" "}
              <Link to="/privacy" target="_blank" rel="noreferrer">
                How your data is used<span className="sr-only"> (opens in a new tab)</span>
              </Link>
            </span>
          </label>
          <FieldError id="signup-consent-error">{errors.consent}</FieldError>
        </div>

        {siteKey && (
          <div className="field">
            <SecurityCheck siteKey={siteKey} onToken={setToken} reset={resetCheck} />
            <FieldError id="signup-check-error">{errors.turnstile}</FieldError>
          </div>
        )}

        {errors.form && (
          <p className="field-error" role="alert" id="signup-submit-error" style={{ marginBottom: 16 }}>
            {errors.form}
          </p>
        )}
        <button type="submit" id="signup-submit" className="btn primary lg block" disabled={busy}>
          {busy ? "Creating account" : "Create account"}
        </button>
        <p className="muted small" style={{ marginTop: 24 }}>
          Already have an account? <Link to={signInLink}>Sign in</Link>
          {joinCode && (
            <>
              <br />
              Signing up as an educator? <Link to="/signup">Use the full sign-up</Link>
            </>
          )}
        </p>
      </form>
    </AuthLayout>
  );
}

// ---------- security check (Cloudflare Turnstile, only when the site turns it on) ----------

interface TurnstileApi {
  render(
    el: HTMLElement,
    opts: { sitekey: string; theme?: "auto" | "light" | "dark"; callback: (token: string) => void; "expired-callback"?: () => void; "error-callback"?: () => void },
  ): string;
  reset(widgetId?: string): void;
  remove(widgetId: string): void;
}

declare global {
  interface Window {
    turnstile?: TurnstileApi;
  }
}

const TURNSTILE_SRC = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";

function loadTurnstile(): Promise<TurnstileApi> {
  if (window.turnstile) return Promise.resolve(window.turnstile);
  return new Promise((resolve, reject) => {
    let script = document.querySelector<HTMLScriptElement>(`script[src="${TURNSTILE_SRC}"]`);
    if (!script) {
      script = document.createElement("script");
      script.src = TURNSTILE_SRC;
      script.async = true;
      document.head.appendChild(script);
    }
    const failed = () => {
      script?.remove(); // so the next visit to the page tries again
      reject(new Error("The security check couldn't load. Check your connection and reload the page."));
    };
    script.addEventListener("load", () => (window.turnstile ? resolve(window.turnstile) : failed()), { once: true });
    script.addEventListener("error", failed, { once: true });
  });
}

/** Renders the Turnstile widget and reports its token; a change in `reset` asks for a fresh token. */
function SecurityCheck({ siteKey, onToken, reset }: { siteKey: string; onToken: (token: string) => void; reset: number }) {
  const box = useRef<HTMLDivElement>(null);
  const widget = useRef<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    loadTurnstile()
      .then((t) => {
        if (cancelled || !box.current) return;
        widget.current = t.render(box.current, {
          sitekey: siteKey,
          theme: "auto",
          callback: onToken,
          "expired-callback": () => onToken(""),
          "error-callback": () => onToken(""),
        });
      })
      .catch((e: Error) => !cancelled && setError(e.message));
    return () => {
      cancelled = true;
      if (widget.current) window.turnstile?.remove(widget.current);
      widget.current = null;
    };
  }, [siteKey, onToken]);
  useEffect(() => {
    if (reset && widget.current) window.turnstile?.reset(widget.current);
  }, [reset]);
  return (
    <>
      <span className="sr-only">Security check</span>
      <div ref={box} id="signup-check" tabIndex={-1} style={{ minHeight: 65 }} />
      {error && <span className="field-error">{error}</span>}
    </>
  );
}

// ---------- join link ----------

/** /join/:code. Signed-out visitors choose sign up or sign in; signed-in students are enrolled and sent to the course. */
export function JoinPage() {
  const { code: raw = "" } = useParams();
  const code = cleanCode(raw);
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const started = useRef("");
  const student = user?.role === "student";
  useEffect(() => {
    if (!student || !code || started.current === code) return;
    started.current = code;
    setError(null);
    api<{ id: string }>("/courses/enroll", { body: { code } })
      .then((r) => navigate(`/courses/${r.id}`, { replace: true }))
      .catch((e: Error) => setError(e.message));
  }, [student, code, navigate]);

  if (loading) return <Loading />;
  if (!code)
    return (
      <AuthLayout>
        <span className="eyebrow">Course invitation</span>
        <h1>This link is missing its course code</h1>
        <p className="secondary">Ask your instructor for the six-character course code, then enter it on your home page.</p>
        <Link className="btn primary lg" to={user ? homeFor(user.role) : "/signup"}>
          {user ? "Go to your home page" : "Create an account"}
        </Link>
      </AuthLayout>
    );
  if (!user)
    return (
      <AuthLayout>
        <span className="eyebrow">Course invitation</span>
        <h1>Join course {code}</h1>
        <p className="secondary" style={{ fontSize: 17, marginBottom: 32 }}>
          You've been invited to a course. Create an account or sign in to join.
        </p>
        <div className="row">
          <Link className="btn primary lg" to={signUpHref(code, null)}>
            Sign up
          </Link>
          <Link className="btn lg" to={signInHref(code, null)}>
            Sign in
          </Link>
        </div>
      </AuthLayout>
    );
  if (!student)
    return (
      <AuthLayout>
        <span className="eyebrow">Course invitation</span>
        <h1>Join links are for students</h1>
        <p className="secondary" style={{ fontSize: 17, marginBottom: 32 }}>
          You're signed in as an educator. Students use this link to join course <span className="code">{code}</span>. Your own courses are on your courses
          page.
        </p>
        <Link className="btn primary lg" to={homeFor(user.role)}>
          Go to your courses
        </Link>
      </AuthLayout>
    );
  if (error)
    return (
      <AuthLayout>
        <span className="eyebrow">Course invitation</span>
        <h1>Couldn't join course {code}</h1>
        <p className="notice error" role="alert" style={{ marginBottom: 32 }}>
          {error}
        </p>
        <Link className="btn primary lg" to="/home">
          Go to your home page
        </Link>
      </AuthLayout>
    );
  return <Loading label="Joining the course" />;
}

// ---------- reset password ----------

type ResetField = "email" | "code" | "password" | "form";

export function ResetPassword() {
  const navigate = useNavigate();
  const { refresh } = useAuth();
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Partial<Record<ResetField, string>>>({});
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const errs: Partial<Record<ResetField, string>> = {};
    if (!EMAIL_RE.test(email.trim())) errs.email = email.trim() ? "Enter a valid email address." : "Enter your email address.";
    if (!code.trim()) errs.code = "Enter the reset code from your instructor.";
    if (password.length < 8) errs.password = "Use at least 8 characters.";
    else if (!password.trim()) errs.password = "A password can't be only spaces.";
    setErrors(errs);
    const first = (["email", "code", "password"] as const).find((f) => errs[f]);
    if (first) return focusSoon(`reset-${first}`);
    setBusy(true);
    try {
      await api("/auth/reset", { body: { email: email.trim(), code: code.trim(), clientHash: await passwordHash(email.trim(), password) } });
      await refresh();
      navigate("/", { replace: true });
    } catch (err) {
      const msg = (err as Error).message;
      const f: ResetField = err instanceof ApiError && err.status === 400 && /code/i.test(msg) ? "code" : "form";
      setErrors({ [f]: msg });
      if (f === "code") focusSoon("reset-code");
      setBusy(false);
    }
  };
  return (
    <AuthLayout>
      <form onSubmit={(e) => void submit(e)} noValidate>
        <span className="eyebrow">Account recovery</span>
        <h1>Reset your password</h1>
        <p className="muted" style={{ marginTop: -16, marginBottom: 24 }}>
          Ask your instructor for a reset code from the course roster. A code works once and expires after 24 hours.
        </p>
        <label className="field">
          Email
          <IconInput
            id="reset-email"
            icon={Mail}
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            {...invalidProps("reset-email-error", errors.email)}
          />
          <FieldError id="reset-email-error">{errors.email}</FieldError>
        </label>
        <label className="field">
          Reset code
          <IconInput
            id="reset-code"
            icon={KeyRound}
            type="text"
            autoComplete="one-time-code"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            {...invalidProps("reset-code-error", errors.code)}
          />
          <FieldError id="reset-code-error">{errors.code}</FieldError>
        </label>
        <label className="field">
          New password
          <IconInput
            id="reset-password"
            icon={Lock}
            type="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            {...invalidProps("reset-password-error", errors.password)}
          />
          <FieldError id="reset-password-error">{errors.password}</FieldError>
        </label>
        {errors.form && (
          <p className="field-error" role="alert" style={{ marginBottom: 16 }}>
            {errors.form}
          </p>
        )}
        <button type="submit" className="btn primary lg block" disabled={busy}>
          {busy ? "Saving" : "Set new password"}
        </button>
        <p className="muted small" style={{ marginTop: 24 }}>
          Remembered it? <Link to="/signin">Sign in</Link>
        </p>
      </form>
    </AuthLayout>
  );
}
