import { useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowUp, AudioLines, Keyboard, Mic, MicOff } from "lucide-react";
import type { Encounter, Message, Order } from "../../shared/types";
import { EMOTIONS, TEST_CATEGORIES, canonicalCategory, lookOf } from "../../shared/defaults";
import { TEST_CATALOG } from "../../shared/testCatalog";
import { languageName } from "../../shared/languages";
import { ApiError, api, streamReply } from "../api";
import { Avatar, EMOTION_LABEL } from "../components/Avatar";
import {
  ActionText,
  DemoBanner,
  ErrorNote,
  Flash,
  FieldError,
  Loading,
  Modal,
  Segmented,
  TabPanel,
  fmtDuration,
  invalidProps,
  noDashes,
  useAuth,
  useAutoGrow,
  useFlash,
  useLoad,
} from "../ui";
import { Listener } from "../voice/listener";
import { VadListener } from "../voice/vadListener";
import { Speaker, loadVoices, unlockAudio } from "../voice/speaker";
import { ProsodyTracker } from "../voice/prosody";
import { Mic as MicCapture } from "../voice/mic";
import { LiveSession, emotionFromText } from "../voice/live";
import { voiceSupport } from "../voice/support";

const MUTE_MS = 2 * 60_000;
const VOICE_LIMIT_MIN = 30;
/** The countdown turns red and is announced this long before the end. */
const WARN_MS = 2 * 60_000;
const TOOLS = "enc-tools";
type Mode = Encounter["mode"];
type Tool = "tasks" | "tests" | "notes";
interface OrderOutcome {
  order: Order;
  repeated: boolean;
}

const modeLabel = (m: Mode) => (m === "text" ? "Text" : m === "emotive" ? "Emotive voice" : "Voice");
/** A case test's name without its bracketed synonyms: "Complete blood count (CBC, ...)" reads "Complete blood count". */
const testLabel = (name: string) => name.split(" (")[0];
/** Message text as a screen reader should hear it: no asterisks around actions, no dashes. */
const spoken = (text: string) => noDashes(text).replace(/\*/g, "");
const EMOTION_SET = new Set<string>(EMOTIONS);
/** A leading "[in_pain]" tag the AI sometimes leaves in a saved reply: taken out of the text and read as the emotion. */
function withoutTag(m: Message): Message {
  const tag = m.role === "patient" ? m.text.match(/^\s*\[\s*(?:emotion\s*:\s*)?([a-z_ -]+?)\s*\]\s*/i) : null;
  const emotion = tag?.[1].toLowerCase().replace(/[\s-]+/g, "_");
  return tag && emotion && EMOTION_SET.has(emotion) ? { ...m, text: m.text.slice(tag[0].length), emotion } : m;
}

export function EncounterPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: enc, error, loading } = useLoad(() => api<Encounter>(`/encounters/${id}`), [id]);
  const { user } = useAuth();
  useEffect(() => {
    if (enc && (enc.status !== "active" || enc.userId !== user?.id)) navigate(`/encounter/${enc.id}/feedback`, { replace: true });
  }, [enc, user, navigate]);
  if (loading) return <Loading label="Opening encounter…" />;
  if (error || !enc) return <main className="page"><ErrorNote error={error ?? "Encounter not found."} /></main>;
  if (enc.status !== "active") return <Loading />;
  return <LiveEncounter enc={enc} />;
}

function LiveEncounter({ enc }: { enc: Encounter }) {
  const navigate = useNavigate();
  const b = enc.brief;
  const look = useMemo(() => lookOf({ demographics: { ...b.patient, other: "" }, voice: b.voice, appearance: b.appearance }), [b]);
  const support = useMemo(() => voiceSupport(), []);
  const [mode, setMode] = useState<Mode>(enc.mode === "voice" && !support.available ? "text" : enc.mode);
  const [messages, setMessages] = useState<Message[]>(() => enc.messages.map(withoutTag));
  const [orders, setOrders] = useState<Order[]>(enc.orders);
  const [tasksDone, setTasksDone] = useState<number[]>(enc.tasksDone);
  const [notepad, setNotepad] = useState(enc.notepad);
  const [begun, setBegun] = useState(enc.messages.length > 0);
  const [startedAt, setStartedAt] = useState(enc.startedAt);
  const [now, setNow] = useState(Date.now());
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [retrying, setRetrying] = useState(false);
  const [emotion, setEmotion] = useState(() => enc.messages.map(withoutTag).filter((m) => m.role === "patient").pop()?.emotion ?? (b.initialEmotion || "neutral"));
  const [err, setErr] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [demo, setDemo] = useState(false);
  const [tab, setTab] = useState<Tool>("tasks");
  const [showEnd, setShowEnd] = useState(false);
  const [timeUp, setTimeUp] = useState(false);
  const [warned, setWarned] = useState(false);
  // Screen readers hear finished patient replies, exam results and timer warnings, never streamed chunks.
  const [announce, setAnnounce] = useState("");
  const [timeNote, setTimeNote] = useState("");

  // voice state
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [interim, setInterim] = useState("");
  const [voiceErr, setVoiceErr] = useState<string | null>(null);
  const [mutedUntil, setMutedUntil] = useState(0);
  const [liveState, setLiveState] = useState<string>("");
  const [micWaiting, setMicWaiting] = useState(false);
  const listener = useRef<Listener | VadListener | null>(null);
  const speaker = useRef<Speaker | null>(null);
  const prosody = useRef<ProsodyTracker | null>(null);
  const mic = useRef<MicCapture | null>(null);
  const live = useRef<LiveSession | null>(null);
  const chatRef = useRef<HTMLDivElement>(null);
  const composer = useAutoGrow(input);
  const sendRef = useRef<(text: string) => Promise<void>>(async () => {});
  const stateRef = useRef({ sending, mutedUntil, timeUp, emotion, ending: showEnd, interim });
  stateRef.current = { sending, mutedUntil, timeUp, emotion, ending: showEnd, interim };

  const voiceMode = mode !== "text";
  const limitMin = [b.timeLimitMin, voiceMode ? VOICE_LIMIT_MIN : 0].filter((m) => m > 0).reduce((a, m) => (a ? Math.min(a, m) : m), 0);
  const limitMs = limitMin * 60_000;
  const elapsed = begun ? now - startedAt : 0;
  const left = limitMs - elapsed;
  const muted = mutedUntil > now;
  const first = b.patient.name.split(" ")[0] || "Patient";
  const talked = messages.some((m) => m.role === "doctor");

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (begun) window.scrollTo(0, 0);
  }, [begun]);

  // Keep the newest line in view by scrolling the conversation itself, never the page: on phones the page
  // scrolls too, and scrolling it would push the composer out of view.
  useEffect(() => {
    const el = chatRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages, streaming, interim, begun]);

  // Countdown: a polite warning two minutes before the end; at zero the End dialog opens. A sentence in
  // progress still finishes, and the server allows a short grace period for it.
  useEffect(() => {
    if (!limitMs || !begun) return;
    if (!warned && left > 0 && left <= WARN_MS) {
      setWarned(true);
      setTimeNote(left > WARN_MS - 5000 ? "Two minutes left." : "Less than two minutes left.");
    }
    if (!timeUp && left <= 0) {
      setTimeUp(true);
      stateRef.current.timeUp = true;
      setTimeNote("Time is up. Finish your sentence, then end the encounter.");
      setShowEnd(true);
    }
  }, [left, limitMs, begun, warned, timeUp]);

  // Autosave the notepad shortly after typing stops.
  useEffect(() => {
    if (notepad === enc.notepad) return;
    const t = setTimeout(() => void api(`/encounters/${enc.id}`, { method: "PATCH", body: { notepad } }).catch(() => undefined), 800);
    return () => clearTimeout(t);
  }, [notepad, enc.id, enc.notepad]);

  const resumeListening = useCallback(() => {
    const s = stateRef.current;
    if (mode !== "voice" || s.sending || s.mutedUntil > Date.now() || s.ending || speaker.current?.busy) return;
    prosody.current?.patientFinished();
    listener.current?.start();
  }, [mode]);

  // After time is up, each finished turn brings the End dialog back.
  const reopenIfTimeUp = () => {
    if (!stateRef.current.timeUp) return;
    stateRef.current.ending = true;
    setShowEnd(true);
  };

  // ----- text and standard-voice turns -----
  const send = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text || stateRef.current.sending) return;
      if (live.current) {
        live.current.sendText(text);
        setInput("");
        setInterim(text);
        return;
      }
      setSending(true);
      stateRef.current.sending = true;
      setErr(null);
      setInput("");
      listener.current?.pause();
      const before = messages.length;
      setMessages((m) => [...m, { role: "doctor", text, t: Date.now() - startedAt }]);
      setStreaming("");
      try {
        const r = await streamReply(
          enc.id,
          text,
          (chunk) => {
            setRetrying(false);
            setStreaming((s) => (s ?? "") + chunk);
            speaker.current?.feed(chunk);
          },
          (emo) => {
            setEmotion(emo);
            if (speaker.current) speaker.current.emotion = emo;
          },
          { onRetry: () => setRetrying(true) },
        );
        const reply = withoutTag(r.message);
        setMessages((m) => [...m, reply]);
        if (reply.emotion) setEmotion(reply.emotion);
        if (mode === "text") setAnnounce(`${first}: ${spoken(reply.text)}`);
        setDemo(r.demo);
        speaker.current?.flush();
      } catch (e) {
        setErr((e as Error).message);
        speaker.current?.stop();
        const fresh = await api<Encounter>(`/encounters/${enc.id}`).catch(() => null);
        if (fresh) setMessages(fresh.messages.map(withoutTag));
        if (!fresh || fresh.messages.length === before) setInput(text);
        // The server refuses new messages once the grace period after the time limit is over.
        if (e instanceof ApiError && e.status === 409) setShowEnd(true);
      } finally {
        setStreaming(null);
        setRetrying(false);
        setSending(false);
        stateRef.current.sending = false;
        reopenIfTimeUp();
        if (!speaker.current?.busy) resumeListening();
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [enc.id, startedAt, resumeListening, messages.length, mode, first],
  );
  sendRef.current = send;

  // ----- voice setup (standard or emotive) -----
  useEffect(() => {
    if (!voiceMode || !begun) return;
    let cancelled = false;
    const cleanups: (() => void)[] = [];
    const tracker = new ProsodyTracker();
    prosody.current = tracker;

    const fallBack = (why?: string) => {
      if (cancelled) return;
      setNotice(`${why ? `${why} ` : ""}Switched to standard voice.`);
      setMode(support.available ? "voice" : "text");
    };

    void (async () => {
      let m: MicCapture | null = null;
      if (MicCapture.supported()) {
        setMicWaiting(true);
        try {
          m = await MicCapture.open();
        } catch {
          if (mode === "emotive" || !support.native) setVoiceErr("Microphone access was blocked. Allow the microphone in your browser's address bar, or type below.");
        } finally {
          if (!cancelled) setMicWaiting(false);
        }
      }
      if (cancelled) return m?.close();
      mic.current = m;

      if (mode === "emotive") {
        if (!m) return fallBack();
        try {
          const t = await api<{ token: string; model: string }>(`/encounters/${enc.id}/live-token`, { body: {} });
          if (cancelled) return;
          const session = new LiveSession(t.token, t.model, m, {
            onState: (s, msg) => {
              setLiveState(s);
              if (s === "error") {
                live.current?.close();
                live.current = null;
                fallBack(msg ? "The emotive voice connection ended." : undefined);
              }
            },
            onSpeaking: (sp) => {
              setSpeaking(sp);
              if (!sp) tracker.patientFinished();
            },
            onDoctorText: (txt) => setInterim(txt),
            onPatientText: (txt) => {
              setStreaming(txt);
              const emo = emotionFromText(txt);
              if (emo) setEmotion(emo);
            },
            onTurn: ({ doctor, patient }) => {
              const emo = emotionFromText(patient) ?? stateRef.current.emotion;
              const t0 = Date.now() - startedAt;
              setMessages((ms) => [
                ...ms,
                ...(doctor ? [{ role: "doctor" as const, text: doctor, t: Math.max(0, t0 - 1500) }] : []),
                ...(patient ? [{ role: "patient" as const, text: patient, t: t0, emotion: emo }] : []),
              ]);
              setInterim("");
              setStreaming(null);
              void api(`/encounters/${enc.id}/transcript`, { body: { doctor, patient, emotion: emo } }).catch(() => undefined);
              if (stateRef.current.timeUp && live.current) {
                live.current.muted = true;
                reopenIfTimeUp();
              }
            },
            onDoctorAudio: (pcm, rms) => tracker.frame(pcm, rms, true),
          });
          live.current = session;
          session.connect();
          await session.resumeAudio();
        } catch (e) {
          fallBack((e as Error).message);
        }
        return;
      }

      const sp = new Speaker(enc.id, enc.language, b.voice);
      sp.onState = (s) => {
        setSpeaking(s);
        if (!s) resumeListening();
      };
      sp.onNotice = setNotice;
      speaker.current = sp;
      if (m) cleanups.push(m.on((pcm, rms) => tracker.frame(pcm, rms)));
      const handlers = {
        onInterim: (t: string) => {
          setInterim(t);
          tracker.active = Boolean(t);
        },
        onFinal: (t: string, started: number) => {
          tracker.active = false;
          tracker.clinicianTurn(t, started);
          void sendRef.current(t);
        },
        onError: (msg: string) => setVoiceErr(msg),
        onListening: setListening,
      };
      listener.current = support.native ? new Listener(enc.language, handlers) : m ? new VadListener(m, enc.id, handlers) : null;
      if (!listener.current) setVoiceErr("Couldn't use the microphone. You can type instead.");
      await loadVoices();
      if (!cancelled) resumeListening();
    })();

    return () => {
      cancelled = true;
      cleanups.forEach((f) => f());
      listener.current?.stop();
      speaker.current?.dispose();
      live.current?.close();
      mic.current?.close();
      listener.current = null;
      speaker.current = null;
      live.current = null;
      mic.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [voiceMode, mode, begun]);

  // While the End dialog is open the microphone rests, unless the student is mid-sentence (time ran out
  // as they spoke): that sentence still goes through.
  useEffect(() => {
    if (!begun || !voiceMode) return;
    if (showEnd) {
      if (stateRef.current.interim) return;
      listener.current?.pause();
      if (live.current) live.current.muted = true;
    } else {
      if (live.current && !(stateRef.current.mutedUntil > Date.now())) live.current.muted = false;
      resumeListening();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showEnd]);

  // The mute button pauses the session for up to two minutes.
  useEffect(() => {
    if (!mutedUntil) return;
    const left = mutedUntil - Date.now();
    const t = setTimeout(() => unmute(), Math.max(0, left));
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mutedUntil]);

  const unmute = () => {
    setMutedUntil(0);
    stateRef.current.mutedUntil = 0;
    if (live.current && !stateRef.current.ending) live.current.muted = false;
    resumeListening();
  };
  const toggleMute = () => {
    if (muted) return unmute();
    const until = Date.now() + MUTE_MS;
    setMutedUntil(until);
    stateRef.current.mutedUntil = until;
    listener.current?.pause();
    speaker.current?.stop();
    if (live.current) live.current.muted = true;
  };

  const begin = async () => {
    if (voiceMode) unlockAudio(); // a click unlocks audio playback on iOS and Safari
    await api(`/encounters/${enc.id}/begin`, { body: {} }).catch(() => undefined);
    setStartedAt(Date.now());
    setBegun(true);
  };

  const order = async (testId?: string, query?: string): Promise<OrderOutcome> => {
    const r = await api<{ order: Order; message?: Message; repeated?: boolean }>(`/encounters/${enc.id}/orders`, { body: { testId, query } });
    if (!r.repeated) {
      setOrders((o) => [...o, r.order]);
      if (r.message) setMessages((m) => [...m, r.message!]);
      live.current?.note(`(The clinician performs or orders: ${r.order.name}.)`);
      setAnnounce(`${testLabel(r.order.name)}: ${spoken(r.order.result)}`);
    }
    return { order: r.order, repeated: Boolean(r.repeated) };
  };

  const toggleTask = (i: number) => {
    const next = tasksDone.includes(i) ? tasksDone.filter((x) => x !== i) : [...tasksDone, i];
    setTasksDone(next);
    void api(`/encounters/${enc.id}`, { method: "PATCH", body: { tasksDone: next } }).catch(() => undefined);
  };

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void send(input);
    }
  };

  const stopVoice = () => {
    listener.current?.stop();
    speaker.current?.dispose();
    live.current?.close();
    live.current = null;
    mic.current?.close();
    mic.current = null;
  };

  const finish = async (diagnosis: string, note: string) => {
    const tracker = prosody.current;
    const metrics = voiceMode && tracker ? tracker.result(messages) : undefined;
    const wav = voiceMode ? tracker?.wav() : null;
    listener.current?.pause();
    if (wav) {
      // Voice analysis runs alongside grading; the feedback page picks it up when ready. The pace measured
      // here goes with it so both pages agree.
      const wpm = metrics?.wordsPerMinute ? `?wpm=${Math.round(metrics.wordsPerMinute)}` : "";
      void fetch(`/api/encounters/${enc.id}/prosody-audio${wpm}`, { method: "POST", headers: { "content-type": "audio/wav", "x-requested-with": "apa" }, body: wav, credentials: "same-origin" }).catch(() => undefined);
    }
    try {
      await api(`/encounters/${enc.id}/end`, { body: { diagnosis, note, prosody: metrics } });
    } catch (e) {
      // 409: already being graded (another tab, or a retry after a dropped connection). The feedback page shows it.
      if (!(e instanceof ApiError && e.status === 409)) throw e;
    }
    stopVoice();
    // Without a recording the feedback page has no tone listen-back to wait for.
    navigate(`/encounter/${enc.id}/feedback`, { replace: true, state: { voiceUpload: Boolean(wav) } });
  };

  if (!begun) return <PreBrief enc={enc} look={look} mode={mode} limitMin={limitMin} onBegin={() => void begin()} />;

  const status = retrying
    ? { live: false, text: "The AI is busy. Trying again." }
    : !voiceMode
      ? null
      : micWaiting
        ? { live: false, text: "Allow microphone access to start (see your browser's prompt)" }
        : muted
          ? { live: false, text: `Paused · resumes in ${fmtDuration(mutedUntil - now)}` }
          : mode === "emotive" && liveState !== "live"
            ? { live: false, text: liveState === "reconnecting" ? "Reconnecting…" : "Connecting emotive voice…" }
            : speaking
              ? { live: false, text: `${first} is speaking…` }
              : sending
                ? { live: false, text: `${first} is thinking…` }
                : showEnd && !interim
                  ? { live: false, text: "Microphone paused" }
                  : mode === "emotive" || listening
                    ? { live: true, text: "Listening, go ahead and speak" }
                    : { live: false, text: "Microphone starting…" };
  const demographics = [b.patient.age && `${b.patient.age} y`, b.patient.sex, b.patient.occupation].filter(Boolean).join(" · ");
  const warn = limitMs > 0 && left <= WARN_MS;

  return (
    <div className="encounter">
      <aside className="enc-side">
        <div className="card enc-brief">
          <p className="quote" style={{ fontSize: 16 }}>
            “{b.patient.chiefComplaint}”
          </p>
          {b.doorNote && (
            <details className="small" style={{ marginTop: 12 }} open>
              <summary>Door note</summary>
              <p className="secondary" style={{ margin: "8px 0 0" }}>
                {b.doorNote}
              </p>
            </details>
          )}
          {b.contextGoal && (
            <details className="small" style={{ marginTop: 12 }}>
              <summary>Your goal</summary>
              <p className="secondary" style={{ margin: "8px 0 0" }}>
                {b.contextGoal}
              </p>
            </details>
          )}
        </div>
        <div className="card" style={{ flex: 1 }}>
          <div style={{ marginBottom: 16 }}>
            <Segmented<Tool>
              label="Encounter tools"
              as="tabs"
              idBase={TOOLS}
              value={tab}
              onChange={setTab}
              options={[
                { id: "tasks", label: b.encounterTasks.length ? `Checklist ${tasksDone.length}/${b.encounterTasks.length}` : "Checklist" },
                { id: "tests", label: `Exams${orders.length ? ` (${orders.length})` : ""}` },
                { id: "notes", label: "Notes" },
              ]}
            />
          </div>
          {tab === "tasks" && (
            <TabPanel idBase={TOOLS} id="tasks">
              <h3 style={{ margin: 0, fontSize: 15 }}>Your checklist</h3>
              <p className="muted tiny" style={{ margin: "4px 0 16px" }}>
                For your own tracking. Feedback comes from the conversation, not from these ticks.
              </p>
              {b.encounterTasks.map((t, i) => (
                <label key={i} className="check">
                  <input type="checkbox" checked={tasksDone.includes(i)} onChange={() => toggleTask(i)} />
                  <span style={{ textDecoration: tasksDone.includes(i) ? "line-through" : undefined, color: tasksDone.includes(i) ? "var(--label-3)" : undefined }}>{t}</span>
                </label>
              ))}
              {!b.encounterTasks.length && <p className="muted small">No checklist for this case.</p>}
              {!!b.postEncounterTasks.length && (
                <>
                  <span className="caption" style={{ marginTop: 16 }}>
                    After the encounter
                  </span>
                  <ul className="small" style={{ margin: 0, paddingLeft: 18 }}>
                    {b.postEncounterTasks.map((t, i) => (
                      <li key={i}>{t}</li>
                    ))}
                  </ul>
                </>
              )}
            </TabPanel>
          )}
          {tab === "tests" && (
            <TabPanel idBase={TOOLS} id="tests">
              <TestsPanel brief={b} orders={orders} onOrder={order} />
            </TabPanel>
          )}
          {tab === "notes" && (
            <TabPanel idBase={TOOLS} id="notes">
              <textarea
                aria-label="Notepad"
                value={notepad}
                onChange={(e) => setNotepad(e.target.value)}
                placeholder="Private notes, saved automatically. You can copy them into your note at the end."
                style={{ minHeight: 280, marginTop: 0 }}
              />
            </TabPanel>
          )}
        </div>
      </aside>

      <section className="enc-main" aria-label="Conversation">
        <div className="enc-head">
          <div className="title">
            <strong>{b.caseName}</strong> <span className="muted small">· {b.configName}</span>
          </div>
          <span className="timer enc-mode">
            {mode === "text" ? <Keyboard size={15} /> : mode === "emotive" ? <AudioLines size={15} /> : <Mic size={15} />}
            {modeLabel(mode)}
          </span>
          <span className={`timer ${warn ? "warn" : ""}`} role="timer">
            {limitMs ? (
              timeUp ? (
                "Time is up"
              ) : (
                `${fmtDuration(left)} left`
              )
            ) : (
              <>
                <span className="sr-only">Time so far </span>
                {fmtDuration(elapsed)}
              </>
            )}
          </span>
          <button className="btn primary small" onClick={() => setShowEnd(true)} disabled={sending}>
            End encounter
          </button>
        </div>
        <div className="stage">
          <Avatar look={look} emotion={emotion} speaking={speaking || (!voiceMode && streaming !== null && streaming.length > 0)} size={88} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <h3 style={{ margin: 0 }}>{b.patient.name}</h3>
            <div className="muted small">
              {demographics && <span className="hide-phone">{demographics} · </span>}
              Appears {(EMOTION_LABEL[emotion] ?? emotion).toLowerCase()}
            </div>
            {status && (
              <span className={`status ${status.live ? "live" : ""}`} aria-live="polite" style={{ marginTop: 4 }}>
                {status.text}
              </span>
            )}
          </div>
          {voiceMode && (
            <button className="btn" onClick={toggleMute} aria-pressed={muted}>
              {muted ? <Mic size={16} /> : <MicOff size={16} />} {muted ? "Resume" : "Pause"}
            </button>
          )}
        </div>
        <div className="chat" ref={chatRef}>
          <DemoBanner />
          {demo && <span className="sr-only">Demo AI reply</span>}
          {notice && <div className="notice info small">{notice}</div>}
          {messages.map((m, i) => (
            <Bubble key={i} m={m} patientName={first} />
          ))}
          {streaming !== null && (
            <div className="msg patient streaming" aria-busy="true">
              <span className="who">{first}</span>
              {streaming ? (
                <ActionText text={streaming} />
              ) : (
                <span className="typing-dots" aria-label={`${first} is typing`}>
                  <span />
                  <span />
                  <span />
                </span>
              )}
            </div>
          )}
          {!messages.length && streaming === null && !interim && (
            <p className="muted" style={{ margin: "auto 0", textAlign: "center" }}>
              {voiceMode ? `Say hello and introduce yourself to ${first}.` : `Introduce yourself to ${first} to begin.`}
            </p>
          )}
        </div>
        <div className="sr-only" aria-live="polite" aria-atomic="true">
          {announce}
        </div>
        <div className="sr-only" aria-live="polite" aria-atomic="true">
          {timeNote}
        </div>
        <div style={{ padding: "0 16px" }}>
          <ErrorNote error={err} />
          {voiceErr && <div className="notice warn small">{voiceErr}</div>}
        </div>
        {interim && <div className="interim">{interim}</div>}
        <div className="composer">
          <textarea
            ref={composer}
            aria-label="Your message to the patient"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKey}
            placeholder={timeUp ? "Finish your last sentence…" : voiceMode ? "Speak, or type here…" : `Message ${first}…`}
            rows={1}
          />
          <button className="btn primary send" onClick={() => void send(input)} disabled={sending || !input.trim()} aria-label="Send">
            <ArrowUp size={20} />
          </button>
        </div>
      </section>
      {showEnd && (
        <EndModal
          enc={enc}
          notepad={notepad}
          timeUp={timeUp}
          waiting={sending}
          talked={talked}
          patientName={first}
          onCancel={() => setShowEnd(false)}
          onFinish={finish}
        />
      )}
    </div>
  );
}

function PreBrief({ enc, look, mode, limitMin, onBegin }: { enc: Encounter; look: ReturnType<typeof lookOf>; mode: Mode; limitMin: number; onBegin: () => void }) {
  const b = enc.brief;
  const voiceMode = mode !== "text";
  const results = b.briefResults ?? [];
  return (
    <main className="page form prebrief">
      <DemoBanner />
      <span className="eyebrow">{b.configName}</span>
      <h1>{b.caseName}</h1>
      {b.caseDescription && (
        <p className="secondary" style={{ fontSize: 17, maxWidth: 640 }}>
          {b.caseDescription}
        </p>
      )}
      <div className="row" style={{ alignItems: "center", flexWrap: "nowrap", margin: "32px 0", gap: 24 }}>
        <Avatar look={look} emotion={b.initialEmotion || "neutral"} size={96} />
        <div style={{ minWidth: 0 }}>
          <div className="headline">{b.patient.name}</div>
          <div className="muted small">{[b.patient.age && `${b.patient.age} years old`, b.patient.sex, b.patient.occupation].filter(Boolean).join(", ")}</div>
          <p className="quote" style={{ marginTop: 8 }}>
            “{b.patient.chiefComplaint}”
          </p>
        </div>
      </div>

      {b.doorNote && (
        <section className="card" aria-labelledby="door-note" style={{ borderColor: "var(--separator-strong)", marginBottom: 32 }}>
          <h2 id="door-note" className="caption">
            Door note
          </h2>
          <p className="pre" style={{ margin: 0, fontSize: 17, lineHeight: 1.6 }}>
            {b.doorNote}
          </p>
        </section>
      )}

      <div className="kv" style={{ marginBottom: 40 }}>
        <span className="caption">Time limit</span>
        <span>{limitMin > 0 ? `${limitMin} minutes` : "None"}</span>
        <span className="caption">Mode</span>
        <span>
          {modeLabel(mode)} in {languageName(enc.language)}
        </span>
        <span className="caption">Tests</span>
        <span>{b.testOrdering === "menu" ? `Choose from ${b.tests.length} in the Exams tab` : "Order any exam or test by name in the Exams tab"}</span>
      </div>

      <div className="split" style={{ gap: 32 }}>
        <div>
          <h3>Your goal</h3>
        </div>
        <p className="secondary" style={{ margin: 0 }}>
          {b.contextGoal || "Interview the patient as you would in clinic."}
        </p>
      </div>
      {!!b.encounterTasks.length && (
        <div className="split" style={{ gap: 32, marginTop: 32 }}>
          <div>
            <h3>Your tasks</h3>
          </div>
          <div>
            {b.encounterTasks.map((t, i) => (
              <div key={i} className="task-row">
                <span className="n">{i + 1}</span>
                <span>{t}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      {!!b.postEncounterTasks.length && (
        <div className="split" style={{ gap: 32, marginTop: 32 }}>
          <div>
            <h3>After the encounter</h3>
          </div>
          <ul className="secondary" style={{ margin: 0, paddingLeft: 18 }}>
            {b.postEncounterTasks.map((t, i) => (
              <li key={i}>{t}</li>
            ))}
          </ul>
        </div>
      )}
      {!!results.length && (
        <div className="split" style={{ gap: 32, marginTop: 32 }}>
          <div>
            <h3>Results to review</h3>
            <p className="muted small">Already in the chart before you go in.</p>
          </div>
          <div className="list">
            <table className="table no-stack">
              <thead>
                <tr>
                  <th style={{ width: "36%" }}>Test</th>
                  <th>Result</th>
                </tr>
              </thead>
              <tbody>
                {results.map((r, i) => (
                  <tr key={i}>
                    <td style={{ verticalAlign: "top" }}>
                      <strong>{testLabel(r.name)}</strong>
                      <div className="muted tiny">{canonicalCategory(r.category)}</div>
                    </td>
                    <td style={{ verticalAlign: "top" }}>
                      <ActionText text={r.result} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <hr className="divider" style={{ margin: "40px 0 24px" }} />
      {voiceMode && <p className="muted small">Find a quiet place. Headphones help. Your browser will ask to use the microphone, and you can also type at any time.</p>}
      <button className="btn primary lg" onClick={onBegin}>
        Start conversation
      </button>
    </main>
  );
}

function Bubble({ m, patientName }: { m: Message; patientName: string }) {
  if (m.role === "exam") {
    const name = m.test || m.text.split(": ")[0];
    return (
      <div className="record">
        <span className="caption">{testLabel(name)}</span>
        <ActionText text={m.text.startsWith(`${name}: `) ? m.text.slice(name.length + 2) : m.text} />
      </div>
    );
  }
  if (m.role === "system") {
    return (
      <p className="muted small" style={{ textAlign: "center", margin: "4px 0" }}>
        <ActionText text={m.text} />
      </p>
    );
  }
  return (
    <div className={`msg ${m.role}`}>
      <span className="who">{m.role === "doctor" ? "You" : patientName}</span>
      <ActionText text={m.text} />
    </div>
  );
}

function TestsPanel({ brief, orders, onOrder }: { brief: Encounter["brief"]; orders: Order[]; onOrder: (testId?: string, query?: string) => Promise<OrderOutcome> }) {
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [flash, showFlash] = useFlash(4000);
  const menu = brief.testOrdering === "menu";
  const groups = useMemo(() => {
    const items = brief.tests.map((t) => ({ ...t, category: canonicalCategory(t.category) }));
    const cats = [...TEST_CATEGORIES, ...items.map((t) => t.category)];
    return cats
      .filter((c, i) => cats.indexOf(c) === i)
      .map((c) => ({ c, items: items.filter((t) => t.category === c) }))
      .filter((g) => g.items.length);
  }, [brief.tests]);

  const run = async (testId?: string, q?: string) => {
    setBusy(testId ?? "query");
    setError(null);
    try {
      const r = await onOrder(testId, q);
      if (q) setQuery("");
      if (r.repeated) showFlash(`Already ordered: ${testLabel(r.order.name)}`);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(null);
    }
  };

  // Newest first; in menu mode the case's tests show their result under their own row instead.
  const results = [...orders].reverse().filter((o) => !menu || !o.testId);

  return (
    <div>
      {menu ? (
        <>
          {groups.map((g) => (
            <div key={g.c} className="test-cat">
              <span className="caption">{g.c}</span>
              {g.items.map((t) => {
                const done = orders.find((o) => o.testId === t.id);
                return (
                  <div key={t.id}>
                    <button type="button" className="test-row" onClick={() => void run(t.id)} disabled={Boolean(done) || busy !== null}>
                      <span>{testLabel(t.name)}</span>
                      <span className={`trail ${done ? "done" : ""}`}>{busy === t.id ? "Ordering" : done ? "Done" : "Order"}</span>
                    </button>
                    {done && (
                      <div className="test-result">
                        <ActionText text={done.result} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
          {!groups.length && <p className="muted small">This case lists no exams or tests.</p>}
          <ErrorNote error={error} />
        </>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (query.trim() && busy === null) void run(undefined, query.trim());
          }}
        >
          <label htmlFor="order-query" className="field" style={{ marginBottom: 0 }}>
            Order an exam or test
          </label>
          <div className="toolbar" style={{ flexWrap: "nowrap", gap: 8, margin: "8px 0 0" }}>
            <input
              id="order-query"
              type="text"
              list="order-catalog"
              autoComplete="off"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setError(null);
              }}
              placeholder="For example, CBC"
              style={{ flex: 1 }}
              {...invalidProps("order-query-error", error)}
            />
            <button type="submit" className="btn" disabled={!query.trim() || busy !== null}>
              {busy ? "Ordering" : "Order"}
            </button>
          </div>
          <FieldError id="order-query-error">{error}</FieldError>
          <datalist id="order-catalog">
            {TEST_CATALOG.map((t) => (
              <option key={t.name} value={t.name} />
            ))}
          </datalist>
          <p className="muted tiny" style={{ margin: "8px 0 0" }}>
            Suggestions are common exams and tests, not a list for this case.
          </p>
        </form>
      )}
      <div style={{ minHeight: 20, marginTop: 8 }}>
        <Flash text={flash} />
      </div>
      {!!results.length && (
        <div style={{ marginTop: 8 }}>
          <span className="caption">{menu ? "Other requests" : "Results"}</span>
          {results.map((o) => (
            <div key={`${o.t}-${o.name}`} className="test-result">
              <strong>{testLabel(o.name)}</strong>
              <div>
                <ActionText text={o.result} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function EndModal({
  enc,
  notepad,
  timeUp,
  waiting,
  talked,
  patientName,
  onCancel,
  onFinish,
}: {
  enc: Encounter;
  notepad: string;
  timeUp: boolean;
  /** A patient reply is still on its way. */
  waiting: boolean;
  /** The student said anything at all. */
  talked: boolean;
  patientName: string;
  onCancel: () => void;
  onFinish: (dx: string, note: string) => Promise<void>;
}) {
  const b = enc.brief;
  const [dx, setDx] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<"silent" | "no-dx" | null>(null);
  const dxRef = useRef<HTMLInputElement>(null);
  const needsDx = b.diagnosisType === "diagnosis";

  const submit = async (sure = false) => {
    if (!sure && !talked) return setConfirm("silent");
    if (!sure && needsDx && !dx.trim()) return setConfirm("no-dx");
    setConfirm(null);
    setBusy(true);
    setErr(null);
    try {
      await onFinish(dx.trim(), note);
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
    }
  };

  return (
    <Modal title={timeUp ? "Time is up" : "End encounter"} onClose={onCancel} closable={!busy}>
      {busy ? (
        <div style={{ padding: "16px 0" }} role="status">
          <span className="spinner" style={{ width: 28, height: 28 }} />
          <h3 style={{ marginTop: 16 }}>Reviewing your encounter</h3>
          <p className="muted small">Scoring each skill against the rubric and finding quotes from your conversation. This can take up to a minute.</p>
        </div>
      ) : (
        <>
          {timeUp && <p className="secondary">If you were in the middle of a sentence, you can finish it first. Then end the encounter to get your feedback.</p>}
          <ErrorNote error={err} />
          {!!b.postEncounterTasks.length && (
            <>
              <span className="caption">After the encounter</span>
              <ul className="small" style={{ margin: "0 0 24px", paddingLeft: 18 }}>
                {b.postEncounterTasks.map((t, i) => (
                  <li key={i}>{t}</li>
                ))}
              </ul>
            </>
          )}
          {needsDx && (
            <label className="field">
              Your most likely diagnosis
              <input
                ref={dxRef}
                type="text"
                value={dx}
                onChange={(e) => {
                  setDx(e.target.value);
                  if (confirm === "no-dx") setConfirm(null);
                }}
                placeholder="Your leading diagnosis"
                autoFocus
              />
            </label>
          )}
          {b.notesEnabled && (
            <label className="field">
              Your note
              <span className="hint">
                For example a SOAP note or a reflection.{" "}
                {notepad && (
                  <button type="button" className="btn small ghost" onClick={() => setNote((n) => (n ? `${n}\n${notepad}` : notepad))}>
                    Copy in my notepad
                  </button>
                )}
              </span>
              <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={8} placeholder={"S:\nO:\nA:\nP:"} />
            </label>
          )}
          {!needsDx && !b.notesEnabled && <p className="muted">You'll get rubric feedback on this conversation right away.</p>}
          {waiting && (
            <p className="muted small" role="status">
              Waiting for {patientName} to finish answering.
            </p>
          )}
          {confirm === "silent" ? (
            <div className="notice warn" role="alert">
              <p style={{ margin: "0 0 12px" }}>
                <strong>End without talking?</strong> This attempt won't count toward your progress.
              </p>
              <div className="row" style={{ justifyContent: "flex-end" }}>
                <button className="btn" onClick={onCancel} autoFocus>
                  Keep talking
                </button>
                <button className="btn primary" onClick={() => void submit(true)}>
                  End anyway
                </button>
              </div>
            </div>
          ) : confirm === "no-dx" ? (
            <div className="notice warn" role="alert">
              <p style={{ margin: "0 0 12px" }}>
                <strong>End without a diagnosis?</strong> Your feedback will show the diagnosis as missing.
              </p>
              <div className="row" style={{ justifyContent: "flex-end" }}>
                <button
                  className="btn"
                  onClick={() => {
                    setConfirm(null);
                    dxRef.current?.focus();
                  }}
                  autoFocus
                >
                  Add a diagnosis
                </button>
                <button className="btn primary" onClick={() => void submit(true)} disabled={waiting}>
                  End without a diagnosis
                </button>
              </div>
            </div>
          ) : (
            <div className="row" style={{ justifyContent: "flex-end" }}>
              <button className="btn" onClick={onCancel}>
                {timeUp ? "Finish my sentence" : "Keep talking"}
              </button>
              <button className="btn primary" onClick={() => void submit()} disabled={waiting}>
                End and get feedback
              </button>
            </div>
          )}
        </>
      )}
    </Modal>
  );
}
