import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Printer, RotateCcw } from "lucide-react";
import type { Comment, Encounter, Feedback } from "../../shared/types";
import { EMOTIONS } from "../../shared/defaults";
import { languageName } from "../../shared/languages";
import { api } from "../api";
import { ActionText, ErrorNote, LevelPill, Loading, fmtDate, fmtDuration, levelClass, useAction, useAuth, useBack, useLoad } from "../ui";
import { prosodyNotes } from "../voice/prosody";
import { SkillMeter } from "../components/Visuals";

const VERDICT: Record<string, { label: string; cls: string }> = {
  correct: { label: "Correct", cls: "high" },
  partial: { label: "Partly correct", cls: "mid" },
  incorrect: { label: "Not correct", cls: "low" },
};
const SUPPORT: Record<string, { label: string; cls: string }> = {
  supported: { label: "Supported by what you gathered", cls: "high" },
  partly: { label: "Partly supported", cls: "mid" },
  unsupported: { label: "Not supported by what you gathered", cls: "low" },
};
const TOO_LITTLE_SPEECH = "Not enough of your speech was recorded to rate your tone fairly. Speak for at least 30 seconds in a voice encounter to get tone ratings.";
/** How long after an encounter ends the page keeps checking for grading and the voice listen-back. */
const WAIT_MS = 3 * 60_000;

/** True when a strength or comment says something (older feedback may leave it out). */
const said = (s: string | undefined) => Boolean(s && s.trim());
const firstSentence = (s: string) => (s.match(/^.*?[.!?](\s|$)/)?.[0] ?? s).trim();
const modeLabel = (m: string) => (m === "text" ? "Text" : m === "emotive" ? "Emotive voice" : "Voice");
const skillId = (category: string) => `skill-${category.replace(/\W+/g, "-")}`;
const testLabel = (name: string) => name.split(" (")[0];
/** Drops a leading "[in_pain]" emotion tag the AI sometimes leaves in a saved patient reply. */
const untagged = (text: string) =>
  text.replace(/^\s*\[\s*(?:emotion\s*:\s*)?([a-z_ -]+?)\s*\]\s*/i, (tag, e: string) => ((EMOTIONS as readonly string[]).includes(e.toLowerCase().replace(/[\s-]+/g, "_")) ? "" : tag));
const durationLabel = (ms: number) => (ms < 60_000 ? `${Math.max(1, Math.round(ms / 1000))} sec` : `${Math.round(ms / 60_000)} min`);
/** "gemini/gemini-2.5-flash-lite" reads "gemini-2.5-flash-lite". */
const modelName = (provider: string) => provider.split("/").pop() ?? provider;

export function FeedbackPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const back = useBack(user?.role === "student" ? "/history" : "/educator");
  const d = useLoad(() => api<Encounter>(`/encounters/${id}`), [id]);
  const retry = useAction();
  const practice = useAction();
  const recent = Boolean(d.data?.endedAt && Date.now() - d.data.endedAt < WAIT_MS);
  // The encounter screen says when it sent no recording, so there's nothing to wait for.
  const noUpload = (location.state as { voiceUpload?: boolean } | null)?.voiceUpload === false;
  const waitingVoice = Boolean(d.data && d.data.mode !== "text" && d.data.prosody && !d.data.prosody.ai && recent && !noUpload);
  const gradingNow = Boolean(d.data?.status === "grading" && recent);

  // Voice analysis finishes a little after grading; pick it up when it lands.
  useEffect(() => {
    if (!waitingVoice || !d.data) return;
    let n = 0;
    const encId = d.data.id;
    const t = setInterval(async () => {
      const fresh = await api<Encounter>(`/encounters/${encId}`).catch(() => null);
      if (fresh?.prosody?.ai || ++n > 15) {
        clearInterval(t);
        if (fresh) d.setData(fresh);
      }
    }, 4000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [waitingVoice, d.data?.id]);

  // Grading still running (another tab, or the End dialog was closed early): show it when it's done.
  useEffect(() => {
    if (!gradingNow || !d.data) return;
    let n = 0;
    const encId = d.data.id;
    const t = setInterval(async () => {
      const fresh = await api<Encounter>(`/encounters/${encId}`).catch(() => null);
      if ((fresh && fresh.status !== "grading") || ++n > 45) {
        clearInterval(t);
        if (fresh) d.setData(fresh);
      }
    }, 4000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gradingNow, d.data?.id]);

  if (d.loading) return <Loading label="Loading feedback" />;
  if (d.error || !d.data) return <main className="page"><ErrorNote error={d.error} /></main>;
  const enc = d.data;
  const fb = enc.feedback;
  const owner = enc.userId === user?.id;
  const levels = enc.levels ?? [];
  const staff = !owner && user?.role !== "student";
  const educator = user?.role === "educator" || user?.role === "admin";
  // Nothing was said: the summary says so, and skill ratings, the diagnosis and missed tests would only be
  // noise (or give the case away before a real attempt).
  const silent = !enc.messages.some((m) => m.role === "doctor");

  if (enc.status === "active") {
    return (
      <main className="page narrow">
        <p className="secondary">This encounter is still in progress.</p>
        {owner && (
          <Link className="btn primary" to={`/encounter/${enc.id}`}>
            Continue encounter
          </Link>
        )}
      </main>
    );
  }

  const regrade = () => retry.run(async () => d.setData(await api<Encounter>(`/encounters/${enc.id}/grade`, { body: {} })));
  // Only skills with a real strength from the transcript; never invented praise.
  const strengths = (fb?.rubric ?? [])
    .filter((r) => said(r.strengths) && levelClass(r.level, levels) !== "low")
    .slice(0, 3)
    .map((r) => ({ cat: r.category, text: firstSentence(r.strengths) }));
  const meta = [
    staff && enc.studentName,
    fmtDate(enc.startedAt),
    enc.endedAt ? durationLabel(enc.endedAt - enc.startedAt) : "",
    modeLabel(enc.mode),
    languageName(enc.language),
    fb?.provider === "demo" ? "Demo feedback" : "",
  ].filter(Boolean);
  const tryAgain = (
    <button className="btn small" onClick={() => void regrade()} disabled={retry.busy}>
      {retry.busy ? "Grading" : "Try again"}
    </button>
  );

  return (
    <main className="page">
      <div className="row spread no-print" style={{ marginBottom: 32 }}>
        <button className="btn ghost small" onClick={back} style={{ marginLeft: -12 }}>
          <ArrowLeft size={16} /> Back
        </button>
        <div className="row">
          <button className="btn small" onClick={() => window.print()}>
            <Printer size={16} /> Print or save PDF
          </button>
          {owner && enc.assignmentId && (
            <button
              className="btn small primary"
              onClick={() =>
                void practice.run(async () => {
                  const r = await api<{ id: string }>("/encounters", { body: { assignmentId: enc.assignmentId, mode: enc.mode, language: enc.language } });
                  navigate(`/encounter/${r.id}`);
                })
              }
              disabled={practice.busy}
            >
              <RotateCcw size={16} /> Practice again
            </button>
          )}
        </div>
      </div>

      <span className="eyebrow">{enc.brief.configName}</span>
      <h1>{enc.brief.caseName}</h1>
      <p className="muted small" style={{ margin: 0 }}>
        {meta.join(" · ")}
      </p>
      {educator && fb?.provider && fb.provider !== "demo" && (
        <p className="muted tiny" style={{ margin: "4px 0 0" }}>
          Graded by {modelName(fb.provider)}
        </p>
      )}
      {fb?.summary && (
        <p className="secondary" style={{ fontSize: 19, lineHeight: 1.5, maxWidth: 760, margin: "24px 0 40px" }}>
          {fb.summary}
        </p>
      )}

      <ErrorNote error={retry.error ?? practice.error} />
      {enc.status === "grading" &&
        (gradingNow ? (
          <div className="notice info" role="status">
            <span className="spinner" style={{ width: 14, height: 14, marginRight: 8 }} />
            Your feedback is being prepared. This page updates when it's ready.
          </div>
        ) : (
          <div className="notice warn">
            Grading was interrupted before your feedback was ready. {owner && tryAgain}
          </div>
        ))}
      {fb?.error && (
        <div className="notice warn">
          {fb.error} {owner && tryAgain}
        </div>
      )}

      {!!fb?.rubric.length && !silent && (
        <div className="list" style={{ marginTop: fb.summary ? 0 : 32 }}>
          <table className="table">
            <thead>
              <tr>
                <th>Skill</th>
                <th className="end">Level</th>
              </tr>
            </thead>
            <tbody>
              {fb.rubric.map((r) => (
                <tr key={r.category}>
                  <td>
                    <a href={`#${skillId(r.category)}`} style={{ color: "inherit" }}>
                      {r.category}
                    </a>
                  </td>
                  <td className="end">
                    <span className="level-cell">
                      <span className="hide-phone">
                        <SkillMeter level={r.level} levels={levels} />
                      </span>
                      <LevelPill level={r.level} levels={levels} />
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {fb && !fb.error && !silent && (
        <>
          <section className="section split">
            <div>
              <h2>What went well</h2>
            </div>
            {strengths.length ? (
              <ul className="secondary" style={{ paddingLeft: 18, margin: 0 }}>
                {strengths.map((s) => (
                  <li key={s.cat} style={{ marginBottom: 8 }}>
                    <strong style={{ color: "var(--label)" }}>{s.cat}.</strong> {s.text}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="muted" style={{ margin: 0 }}>
                Nothing to highlight yet.{fb.nextSteps.length ? " The focus points below show where to start." : ""}
              </p>
            )}
          </section>
          {!!fb.nextSteps.length && (
            <section className="section split">
              <div>
                <h2>Focus next time</h2>
              </div>
              <ol className="secondary" style={{ paddingLeft: 18, margin: 0 }}>
                {fb.nextSteps.map((x, i) => (
                  <li key={i} style={{ marginBottom: 8 }}>
                    {x}
                  </li>
                ))}
              </ol>
            </section>
          )}
        </>
      )}

      {fb && !silent ? <FeedbackBody enc={enc} fb={fb} levels={levels} waitingVoice={waitingVoice} /> : enc.mode !== "text" && <VoiceSection enc={enc} waitingVoice={waitingVoice} />}

      <Transcript enc={enc} canComment={staff} onComment={(c) => d.setData({ ...enc, comments: [...(enc.comments ?? []), c] })} />
    </main>
  );
}

function FeedbackBody({ enc, fb, levels, waitingVoice }: { enc: Encounter; fb: Feedback; levels: string[]; waitingVoice: boolean }) {
  const v = VERDICT[fb.diagnosisVerdict];
  const s = fb.diagnosisSupport ? SUPPORT[fb.diagnosisSupport] : undefined;
  const tr = fb.testsReview;
  return (
    <>
      {enc.brief.diagnosisType === "diagnosis" && (
        <section className="section split">
          <div>
            <h2>Diagnosis</h2>
          </div>
          <div>
            <div className="kv">
              <span className="caption">You said</span>
              <div>
                {enc.diagnosis ? <span>{enc.diagnosis}</span> : <span className="muted">No diagnosis entered</span>}
                {(v || s) && (
                  <div className="row tight" style={{ marginTop: 8 }}>
                    {v && <span className={`badge ${v.cls}`}>{v.label}</span>}
                    {s && <span className={`badge ${s.cls}`}>{s.label}</span>}
                  </div>
                )}
              </div>
              <span className="caption">Case</span>
              <span>{fb.correctDiagnosis}</span>
            </div>
            {fb.diagnosisComment && (
              <p className="secondary" style={{ marginTop: 16 }}>
                {fb.diagnosisComment}
              </p>
            )}
            {!!fb.differential.length && (
              <>
                <h4 style={{ marginTop: 24 }}>Differential to consider</h4>
                <ol className="secondary" style={{ paddingLeft: 18, margin: 0 }}>
                  {fb.differential.map((x, i) => (
                    <li key={i}>{x}</li>
                  ))}
                </ol>
              </>
            )}
          </div>
        </section>
      )}

      {!!fb.rubric.length && (
        <section className="section split">
          <div>
            <h2>Skill by skill</h2>
            <p className="muted small">Quotes are your own words from the transcript. Paraphrases are marked.</p>
          </div>
          <div>
            {fb.rubric.map((r) => (
              <div key={r.category} className="skill-detail" id={skillId(r.category)}>
                <div className="row spread" style={{ marginBottom: 12 }}>
                  <h3 style={{ margin: 0 }}>{r.category}</h3>
                  <LevelPill level={r.level} levels={levels} />
                </div>
                <div className="kv">
                  {said(r.strengths) ? (
                    <>
                      <span className="caption">Went well</span>
                      <span className="secondary">{r.strengths}</span>
                    </>
                  ) : (
                    r.improve && (
                      <>
                        <span className="caption">Went well</span>
                        <span className="muted">Nothing to highlight yet for this skill.</span>
                      </>
                    )
                  )}
                  {r.improve && (
                    <>
                      <span className="caption">Next time</span>
                      <span className="secondary">{r.improve}</span>
                    </>
                  )}
                </div>
                {r.evidence.map((e, j) => (
                  <blockquote key={j} title={e.verified ? "Found in your transcript" : "Paraphrased; not found word for word in your transcript"} style={{ marginTop: 12 }}>
                    {e.kind && (
                      <span className={`badge ${e.kind === "praise" ? "high" : "mid"}`} style={{ marginRight: 8 }}>
                        {e.kind === "praise" ? "Well done" : "Try differently"}
                      </span>
                    )}
                    “<ActionText text={e.quote} />”{!e.verified && <span className="muted tiny"> (paraphrased)</span>}
                  </blockquote>
                ))}
              </div>
            ))}
          </div>
        </section>
      )}

      {(tr.orderedExpected.length + tr.missedExpected.length + tr.unnecessary.length > 0 || fb.historyMissed.length > 0) && (
        <section className="section split">
          <div>
            <h2>What you missed</h2>
          </div>
          <div>
            {tr.orderedExpected.length + tr.missedExpected.length + tr.unnecessary.length > 0 && (
              <div className="kv" style={{ marginBottom: 24 }}>
                {!!tr.orderedExpected.length && (
                  <>
                    <span className="caption">Ordered</span>
                    <span>{tr.orderedExpected.map(testLabel).join(", ")}</span>
                  </>
                )}
                {!!tr.missedExpected.length && (
                  <>
                    <span className="caption" style={{ color: "var(--low)" }}>
                      Not ordered
                    </span>
                    <span>{tr.missedExpected.map(testLabel).join(", ")}</span>
                  </>
                )}
                {!!tr.unnecessary.length && (
                  <>
                    <span className="caption">Not needed</span>
                    <span>{tr.unnecessary.map(testLabel).join(", ")}</span>
                  </>
                )}
              </div>
            )}
            {tr.comment && <p className="secondary">{tr.comment}</p>}
            {!!fb.historyMissed.length && (
              <>
                <h4 style={{ marginTop: 24 }}>Questions you could have asked</h4>
                <ul className="secondary" style={{ paddingLeft: 18, margin: 0 }}>
                  {fb.historyMissed.map((x, i) => (
                    <li key={i}>{x}</li>
                  ))}
                </ul>
              </>
            )}
          </div>
        </section>
      )}

      {enc.mode !== "text" && <VoiceSection enc={enc} waitingVoice={waitingVoice} />}

      {fb.notesFeedback && (
        <section className="section split">
          <div>
            <h2>Your note</h2>
          </div>
          <div>
            <p className="secondary pre">{fb.notesFeedback}</p>
            <details>
              <summary className="small">Show what you wrote</summary>
              <p className="pre small secondary" style={{ marginTop: 8 }}>
                {enc.note || "Empty"}
              </p>
            </details>
          </div>
        </section>
      )}
    </>
  );
}

/** "How you sounded": the tone listen-back and the measures from the microphone, or why there are none. */
function VoiceSection({ enc, waitingVoice }: { enc: Encounter; waitingVoice: boolean }) {
  const p = enc.prosody;
  const ai = p?.ai;
  const rated = Boolean(ai && !ai.insufficient && ai.dimensions.length);
  // Plenty of speech was measured, but the listen-back didn't run (no key, or the AI was busy).
  const unrated = !waitingVoice && !ai && Boolean(p && p.speakingSeconds >= 30);
  const tooLittle = !waitingVoice && !rated && !unrated;
  const notes = p && !tooLittle ? prosodyNotes(p) : [];
  return (
    <section className="section split">
      <div>
        <h2>How you sounded</h2>
        <p className="muted small">Measured from your microphone, plus an AI listening to your tone.</p>
      </div>
      <div>
        {waitingVoice && (
          <p className="muted small" role="status">
            <span className="spinner" style={{ width: 14, height: 14, marginRight: 8 }} />
            Listening back to your recording for warmth, calm and clarity.
          </p>
        )}
        {tooLittle && <p className="notice info">{TOO_LITTLE_SPEECH}</p>}
        {unrated && <p className="notice info">Tone ratings aren't available for this encounter. The measures below come from your microphone.</p>}
        {rated && ai && (
          <>
            <p className="secondary">{ai.summary}</p>
            <div className="list" style={{ marginBottom: 16 }}>
              <table className="table">
                <tbody>
                  {ai.dimensions.map((dim) => (
                    <tr key={dim.name}>
                      <td style={{ width: "24%" }}>{dim.name}</td>
                      <td className="small secondary wide">{dim.comment}</td>
                      <td className="end nowrap">
                        <span className={`meter ${dim.score >= 4 ? "high" : dim.score >= 3 ? "mid" : "low"}`} role="img" aria-label={`${dim.score} of 5`}>
                          {[1, 2, 3, 4, 5].map((n) => (
                            <span key={n} className={n <= dim.score ? "on" : ""} style={{ width: 14 }} />
                          ))}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {!!ai.tips.length && (
              <ul className="secondary small" style={{ paddingLeft: 18 }}>
                {ai.tips.map((t, i) => (
                  <li key={i}>{t}</li>
                ))}
              </ul>
            )}
          </>
        )}
        {!!notes.length && (
          <div className="list">
            <table className="table">
              <tbody>
                {notes.map((n) => (
                  <tr key={n.label}>
                    <td style={{ width: "24%" }}>{n.label}</td>
                    <td className="small secondary wide">{n.note}</td>
                    <td className="end nowrap">
                      <span className={`badge ${n.ok ? "high" : "mid"}`}>{n.value}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}

function Transcript({ enc, canComment, onComment }: { enc: Encounter; canComment: boolean; onComment: (c: Comment) => void }) {
  const [open, setOpen] = useState<number | null>(null);
  const [text, setText] = useState("");
  const { busy, error, run } = useAction();
  const first = enc.brief.patient.name.split(" ")[0] || "Patient";
  const comments = enc.comments ?? [];
  const save = (idx: number) =>
    run(async () => {
      onComment(await api<Comment>(`/encounters/${enc.id}/comments`, { body: { messageIdx: idx, body: text } }));
      setText("");
      setOpen(null);
    });
  return (
    <section className="section split">
      <div>
        <h2>Transcript</h2>
        {canComment && <p className="muted small no-print">Comment on any line to leave feedback for the student.</p>}
      </div>
      <div>
        <ErrorNote error={error} />
        <div className="list">
          {enc.messages.map((m, i) => {
            const body = m.role === "exam" && m.test && m.text.startsWith(`${m.test}: `) ? m.text.slice(m.test.length + 2) : m.role === "patient" ? untagged(m.text) : m.text;
            return (
              <div key={i} className="list-row" style={{ alignItems: "flex-start", display: "block" }}>
                <div className="row" style={{ alignItems: "baseline", flexWrap: "nowrap" }}>
                  <span className="muted tiny nowrap" style={{ width: 40, fontVariantNumeric: "tabular-nums" }}>
                    {fmtDuration(m.t)}
                  </span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <span className="tiny" style={{ fontWeight: 600, color: m.role === "doctor" ? "var(--accent)" : m.role === "exam" ? "var(--info)" : "var(--label)" }}>
                      {m.role === "doctor" ? (canComment && enc.studentName) || "You" : m.role === "patient" ? first : m.test ? testLabel(m.test) : "Exam"}
                    </span>
                    <div className="pre" style={{ fontSize: 15 }}>
                      <ActionText text={body} />
                    </div>
                  </div>
                  {canComment && (
                    <button
                      className="btn plain small no-print"
                      onClick={() => setOpen(open === i ? null : i)}
                      aria-expanded={open === i}
                      aria-label={`Add a comment on message ${i + 1}`}
                    >
                      Comment
                    </button>
                  )}
                </div>
                {comments
                  .filter((c) => c.messageIdx === i)
                  .map((c) => (
                    <div key={c.id} className="notice info small" style={{ marginLeft: 52, marginTop: 8, marginBottom: 0 }}>
                      <strong>{c.authorName}:</strong> {c.body}
                    </div>
                  ))}
                {open === i && (
                  <div style={{ marginLeft: 52, marginTop: 8 }} className="no-print">
                    <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Comment for the student" aria-label={`Comment on message ${i + 1}`} autoFocus />
                    <button className="btn small primary" style={{ marginTop: 8 }} onClick={() => void save(i)} disabled={busy || !text.trim()}>
                      Save comment
                    </button>
                  </div>
                )}
              </div>
            );
          })}
          {!enc.messages.length && <div className="list-row muted">No conversation recorded.</div>}
        </div>
      </div>
    </section>
  );
}
