import { Link } from "react-router-dom";
import { PageHeader } from "../ui";
import { Footer } from "../components/Visuals";

/**
 * /privacy: what the app keeps, what goes to Google's AI, and how to download or delete it, in plain words.
 * Keep it true to the code: README "Privacy", src/worker/account.ts (export and delete), the retention
 * cleanup in src/worker/index.ts and the first-name rule in src/worker/ai/prompts.ts.
 */
export function PrivacyPage() {
  return (
    <>
      <main className="page narrow">
        <PageHeader
          eyebrow="Privacy"
          title="How your data is used"
          subtitle="What this app keeps, what it sends to Google's AI, who can see your work, and how to download or delete it."
        />
        <div className="stack loose">
          <section aria-labelledby="privacy-short">
            <h2 id="privacy-short">The short version</h2>
            <ul className="secondary">
              <li>This is a practice tool for education, not medical advice. Every case is fictional, so never enter real patient information.</li>
              <li>
                Your conversations are sent to Google's Gemini AI so the patient can answer you and your encounter can be graded. On Google's free tier, Google
                may use them to improve its products.
              </li>
              <li>The AI sees only your first name. Your email address and password are never sent to it.</li>
              <li>
                You can download everything stored about you, or delete it, in <Link to="/settings">Settings</Link>.
              </li>
            </ul>
          </section>

          <section aria-labelledby="privacy-stored">
            <h2 id="privacy-stored">What the app stores</h2>
            <ul className="secondary">
              <li>
                Your account: your name, email address and role. Your browser turns your password into a one-way code before sending it, so the app never sees
                or stores the password itself.
              </li>
              <li>The courses you have joined.</li>
              <li>
                Each encounter: the conversation, the exams and tests you ordered, your notes, your diagnosis and written note, and your feedback and scores.
              </li>
              <li>
                In voice modes, measurements of how you spoke, such as your pace, pauses and filler words, and the AI's comments on your tone. The app does not
                store recordings of your voice.
              </li>
              <li>Comments your instructors write on your encounters, and notifications about them.</li>
              <li>Your own AI key, if you add one in Settings. It is stored encrypted.</li>
            </ul>
            <p className="secondary">
              Everything is kept in the database of the site you are using. The app uses one cookie to keep you signed in and remembers your encounter language
              in your browser. There are no ads and no tracking. Headings use a font from Google Fonts, and some sites add Cloudflare's bot check to the sign-up
              page.
            </p>
          </section>

          <section aria-labelledby="privacy-google">
            <h2 id="privacy-google">What is sent to Google's AI</h2>
            <p className="secondary">The app uses Google's Gemini AI to play the patient, to grade your encounter and, in voice modes, to handle speech. It sends:</p>
            <ul className="secondary">
              <li>The case your instructor wrote, so the AI can play the patient.</li>
              <li>What you type or say in the conversation, the tests you order, and your diagnosis and note for grading.</li>
              <li>
                In voice modes, recordings of what you say, for speech recognition, the emotive voice and feedback on your tone. The patient's lines go to
                Google's text-to-speech. In Chrome and Safari, the browser's own speech recognition turns your speech into text, which uses Google's or Apple's
                servers.
              </li>
            </ul>
            <p className="secondary">
              Unless your course uses a paid key, this goes through Google's free tier. On the free tier, Google may use what is sent to improve its products,
              and people at Google may read it. Google does not use prompts sent with a paid key this way.
            </p>
          </section>

          <section aria-labelledby="privacy-never">
            <h2 id="privacy-never">What is never sent to the AI</h2>
            <p className="secondary">
              Your email address, your password and your full name. The AI sees only your first name, and if you type your full name in a conversation, it is
              cut to your first name before it is sent.
            </p>
          </section>

          <section aria-labelledby="privacy-who">
            <h2 id="privacy-who">Who can see your work</h2>
            <p className="secondary">
              You, the instructors of the course an encounter belongs to, and the people who run this site. Instructors can read your transcripts, scores and
              feedback, and comment on them. Other students can't see your work.
            </p>
          </section>

          <section aria-labelledby="privacy-kept">
            <h2 id="privacy-kept">How long it is kept</h2>
            <p className="secondary">
              Your account and encounters are kept until you delete them. Instructors can also set a course to delete encounters automatically after a number
              of days. A daily cleanup then removes older encounters along with their comments and notifications.
            </p>
          </section>

          <section aria-labelledby="privacy-yours">
            <h2 id="privacy-yours">Download or delete your data</h2>
            <p className="secondary">
              In <Link to="/settings">Settings</Link>, Download my data gives you a file with your account, courses, encounters, feedback and comments. Delete
              my account and data removes your account, your encounters with their comments, and your notifications. Deleting can't be undone. Educators first
              archive or hand over courses that still have students.
            </p>
          </section>

          <section aria-labelledby="privacy-questions">
            <h2 id="privacy-questions">Questions</h2>
            <p className="secondary">Ask your instructor, or contact the person who runs this site.</p>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
