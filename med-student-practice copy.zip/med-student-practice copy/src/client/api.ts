import type { Message } from "../shared/types";

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    /** Milliseconds from the Retry-After header, when the server sent one. */
    public retryAfterMs?: number,
  ) {
    super(message);
  }
}

/** Fired on window when a signed-in request gets 401; AuthProvider signs the user out and asks them to sign in again. */
export const UNAUTHORIZED_EVENT = "apa:unauthorized";

export interface ApiOptions {
  method?: string;
  body?: unknown;
  /**
   * Retry when the AI is busy: a 503 or 429 that has a Retry-After header or says "busy". Up to 3 more tries,
   * after 1 s, 2 s and 4 s, or after Retry-After when that is longer, never more than 8 s apart. A Retry-After
   * over a minute (a daily allowance, a sign-in limit) is not retried. GET requests retry unless this is false;
   * other methods retry only when it is true, so pass it only for requests that are safe to repeat.
   */
  retry?: boolean;
  /** Called before each retry, for a "Busy, trying again" hint. */
  onRetry?: (attempt: number, waitMs: number) => void;
}

const HEADERS = { "content-type": "application/json", "x-requested-with": "apa" };
const BACKOFF_MS = [1000, 2000, 4000];
const MAX_WAIT_MS = 8000;
const NO_RETRY_AFTER_MS = 60_000;
// A 401 from these means "not signed in" or "wrong password", not "your session ended".
const NO_SESSION_PATHS = ["/auth/me", "/auth/signin"];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function retryAfterMs(res: Response): number | undefined {
  const h = res.headers.get("retry-after");
  if (!h) return undefined;
  const s = Number(h);
  if (Number.isFinite(s)) return Math.max(0, s * 1000);
  const at = Date.parse(h);
  return Number.isNaN(at) ? undefined : Math.max(0, at - Date.now());
}

/**
 * How long to wait before retrying this failed response, or null when it should not be retried. The server
 * asks for 20 s when the AI is busy; a busy model often frees up sooner, so waits are capped at 8 s.
 */
function retryWait(res: Response, message: string, attempt: number): number | null {
  if (attempt >= BACKOFF_MS.length || (res.status !== 503 && res.status !== 429)) return null;
  const after = retryAfterMs(res);
  if (after === undefined ? !/busy/i.test(message) : after > NO_RETRY_AFTER_MS) return null;
  return Math.min(MAX_WAIT_MS, Math.max(BACKOFF_MS[attempt], after ?? 0));
}

function noteUnauthorized(path: string, status: number) {
  if (status === 401 && !NO_SESSION_PATHS.some((p) => path === p || path.startsWith(`${p}?`))) {
    window.dispatchEvent(new CustomEvent(UNAUTHORIZED_EVENT, { detail: { path } }));
  }
}

export async function api<T = unknown>(path: string, opts: ApiOptions = {}): Promise<T> {
  const method = opts.method ?? (opts.body === undefined ? "GET" : "POST");
  const mayRetry = opts.retry ?? method === "GET";
  for (let attempt = 0; ; attempt++) {
    let res: Response;
    try {
      res = await fetch(`/api${path}`, {
        method,
        headers: HEADERS,
        body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
        credentials: "same-origin",
      });
    } catch {
      throw new ApiError(0, "Can't reach the server. Check your internet connection and try again.");
    }
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    if (res.ok) return data as T;
    const message = data.error ?? `Request failed (${res.status}).`;
    const wait = mayRetry ? retryWait(res, message, attempt) : null;
    if (wait === null) {
      noteUnauthorized(path, res.status);
      throw new ApiError(res.status, message, retryAfterMs(res));
    }
    opts.onRetry?.(attempt + 1, wait);
    await sleep(wait);
  }
}

/**
 * Sends the clinician's line and streams the patient's reply. A busy AI is retried like `api` with
 * `retry: true`: the server saves the clinician's line only once the reply stream opens, so a retry
 * never doubles it.
 */
export async function streamReply(
  encounterId: string,
  text: string,
  onText: (chunk: string) => void,
  onEmotion?: (emotion: string) => void,
  opts: { onRetry?: (attempt: number, waitMs: number) => void } = {},
): Promise<{ message: Message; demo: boolean }> {
  const path = `/encounters/${encounterId}/message`;
  let body: Response["body"] = null;
  for (let attempt = 0; !body; attempt++) {
    let res: Response;
    try {
      res = await fetch(`/api${path}`, { method: "POST", headers: HEADERS, body: JSON.stringify({ text }), credentials: "same-origin" });
    } catch {
      throw new ApiError(0, "Can't reach the server. Check your internet connection and try again.");
    }
    if (res.ok && res.body) {
      body = res.body;
      continue;
    }
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    const message = data.error ?? "The patient couldn't answer. Please try again.";
    const wait = retryWait(res, message, attempt);
    if (wait === null) {
      noteUnauthorized(path, res.status);
      throw new ApiError(res.status, message, retryAfterMs(res));
    }
    opts.onRetry?.(attempt + 1, wait);
    await sleep(wait);
  }
  const reader = body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let idx: number;
    while ((idx = buf.indexOf("\n\n")) >= 0) {
      const block = buf.slice(0, idx).trim();
      buf = buf.slice(idx + 2);
      if (!block.startsWith("data:")) continue;
      const evt = JSON.parse(block.slice(5)) as { t?: string; emotion?: string; done?: boolean; message?: Message; demo?: boolean };
      if (evt.emotion) onEmotion?.(evt.emotion);
      if (evt.t) onText(evt.t);
      if (evt.done && evt.message) return { message: evt.message, demo: Boolean(evt.demo) };
    }
  }
  throw new ApiError(0, "The connection was interrupted. Your conversation is saved; reload the page to continue.");
}

/** PBKDF2 in the browser so the server never sees the password and stays within its CPU budget. */
export async function passwordHash(email: string, password: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: enc.encode(`ai-patient-actor:${email.trim().toLowerCase()}`), iterations: 210000 },
    key,
    256,
  );
  return Array.from(new Uint8Array(bits), (b) => b.toString(16).padStart(2, "0")).join("");
}
