import { Hono } from "hono";
import type { AppEnv, DbUser, Env } from "../env";
import type { CaseItem, LibraryItem } from "../../shared/types";
import { lookOf, normalizeConfig, normalizeProfile } from "../../shared/defaults";
import { requireEducator, requireUser } from "../auth";
import { canEdit, canSee, keysFor } from "../access";
import { newId } from "../crypto";
import { body, fail, parseJson, str } from "../util";
import { AiUnavailableError, complete, targetsFor } from "../ai/router";
import { ASSISTANT_SYSTEM, assistantPrompt } from "../ai/prompts";
import { noDashes, parseLooseJson } from "../ai/grade";
import { mockProfile } from "../ai/mock";
import { deliveryPrompt, geminiKeys, ttsStream } from "../ai/audio";
import { LIVE_VOICES } from "../../shared/defaults";
import { createEncounter } from "./encounters";

interface ItemRow {
  id: string;
  owner_id: string;
  name: string;
  data: string;
  is_public: number;
  updated_at: number;
}

const toItem = <T>(r: ItemRow, user: DbUser, normalize: (x: unknown) => T): LibraryItem<T> => ({
  id: r.id,
  ownerId: r.owner_id,
  name: r.name,
  isPublic: r.is_public === 1,
  data: normalize(parseJson(r.data, {})),
  updatedAt: r.updated_at,
  mine: r.owner_id === user.id,
});

const NAME_MAX = 120;

/** Names are required and at most 120 characters. Bad input gets a clear 400, never a silent fix. */
function checkName(v: unknown, what: string): string {
  const name = typeof v === "string" ? v.trim() : "";
  if (!name) fail(400, `Give the ${what} a name.`);
  if (name.length > NAME_MAX) fail(400, `${what[0].toUpperCase()}${what.slice(1)} names can be at most ${NAME_MAX} characters (this one has ${name.length}).`);
  return name;
}

/** Rejects configuration input that normalizeConfig would otherwise quietly replace or drop. */
function checkConfigData(raw: unknown) {
  if (!raw || typeof raw !== "object") return;
  const c = raw as Record<string, unknown>;
  if (c.levels !== undefined) {
    const levels = Array.isArray(c.levels) ? c.levels.map((l) => String(l ?? "").trim()) : [];
    const blank = levels.findIndex((l) => !l);
    if (blank >= 0) fail(400, `Score level ${blank + 1} is empty. Name it or remove it.`);
    if (levels.length < 2) fail(400, "Add at least 2 score levels, lowest to highest.");
    if (new Set(levels.map((l) => l.toLowerCase())).size < levels.length) fail(400, "Each score level needs a different name.");
  }
  if (c.rubric !== undefined) {
    if (!Array.isArray(c.rubric)) fail(400, "The rubric must be a list of categories.");
    c.rubric.forEach((r: unknown, i) => {
      const name = String((r as { name?: unknown } | null)?.name ?? "").trim();
      if (!name) fail(400, `Rubric category ${i + 1} needs a name. Name it or remove it.`);
      if (name.length > NAME_MAX) fail(400, `Rubric category names can be at most ${NAME_MAX} characters.`);
    });
  }
  if (c.timeLimitMin !== undefined && c.timeLimitMin !== null && c.timeLimitMin !== "") {
    const n = Number(c.timeLimitMin);
    if (!Number.isFinite(n) || n < 0) fail(400, "Set the time limit in minutes, or 0 for no limit.");
    if (n > 120) fail(400, "The time limit can be at most 120 minutes.");
  }
}

/** CRUD for profiles and configurations, which share the same table shape. */
function itemRoutes<T>(table: "profiles" | "configurations", normalize: (x: unknown) => T) {
  const what = table === "profiles" ? "patient profile" : "configuration";
  const check = (data: unknown) => table === "configurations" && checkConfigData(data);
  const usedBy = table === "profiles" ? `SELECT 1 FROM cases WHERE profile_id = ? LIMIT 1` : `SELECT 1 FROM case_configs WHERE config_id = ? LIMIT 1`;
  const load = async (env: Env, id: string) =>
    env.DB.prepare(`SELECT id, owner_id, name, data, is_public, updated_at FROM ${table} WHERE id = ?`).bind(id).first<ItemRow>();

  return new Hono<AppEnv>()
    .get("/", async (c) => {
      const u = c.get("user");
      const rows = await c.env.DB.prepare(
        `SELECT id, owner_id, name, data, is_public, updated_at FROM ${table} WHERE owner_id = ? OR is_public = 1 ORDER BY owner_id = ? DESC, updated_at DESC`,
      )
        .bind(u.id, u.id)
        .all<ItemRow>();
      return c.json(rows.results.map((r) => toItem(r, u, normalize)));
    })
    .get("/:id", async (c) => {
      const u = c.get("user");
      const row = await load(c.env, c.req.param("id"));
      if (!row || !canSee(u, row)) fail(404, "Not found.");
      return c.json(toItem(row, u, normalize));
    })
    .post("/", async (c) => {
      const u = c.get("user");
      const b = await body(c.req);
      const name = checkName(b.name, what);
      check(b.data);
      const id = newId();
      const now = Date.now();
      await c.env.DB.prepare(`INSERT INTO ${table} (id, owner_id, name, data, is_public, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)`)
        .bind(id, u.id, name, JSON.stringify(normalize(b.data)), b.isPublic ? 1 : 0, now, now)
        .run();
      return c.json(toItem((await load(c.env, id))!, u, normalize));
    })
    .put("/:id", async (c) => {
      const u = c.get("user");
      const row = await load(c.env, c.req.param("id"));
      if (!row || !canEdit(u, row)) fail(404, "Not found.");
      const b = await body(c.req);
      const name = b.name === undefined ? row.name : checkName(b.name, what);
      if (b.data !== undefined) check(b.data);
      await c.env.DB.prepare(`UPDATE ${table} SET name = ?, data = ?, is_public = ?, updated_at = ? WHERE id = ?`)
        .bind(name, JSON.stringify(normalize(b.data ?? parseJson(row.data, {}))), b.isPublic === undefined ? row.is_public : b.isPublic ? 1 : 0, Date.now(), row.id)
        .run();
      return c.json(toItem((await load(c.env, row.id))!, u, normalize));
    })
    .post("/:id/copy", async (c) => {
      const u = c.get("user");
      const row = await load(c.env, c.req.param("id"));
      if (!row || !canSee(u, row)) fail(404, "Not found.");
      const id = newId();
      const now = Date.now();
      await c.env.DB.prepare(`INSERT INTO ${table} (id, owner_id, name, data, is_public, created_at, updated_at) VALUES (?, ?, ?, ?, 0, ?, ?)`)
        .bind(id, u.id, `${row.name} (copy)`.slice(0, 120), row.data, now, now)
        .run();
      return c.json(toItem((await load(c.env, id))!, u, normalize));
    })
    .delete("/:id", async (c) => {
      const u = c.get("user");
      const row = await load(c.env, c.req.param("id"));
      if (!row || !canEdit(u, row)) fail(404, "Not found.");
      if (await c.env.DB.prepare(usedBy).bind(row.id).first()) fail(409, "This item is used by a case. Remove it from the case first.");
      await c.env.DB.prepare(`DELETE FROM ${table} WHERE id = ?`).bind(row.id).run();
      return c.json({ ok: true });
    });
}

interface CaseRow {
  id: string;
  owner_id: string;
  name: string;
  description: string;
  profile_id: string;
  is_public: number;
  profile_name: string | null;
  profile_data: string | null;
  config_ids: string | null;
  config_names: string | null;
}

const CASE_SELECT = `SELECT c.id, c.owner_id, c.name, c.description, c.profile_id, c.is_public,
  p.name AS profile_name, p.data AS profile_data,
  (SELECT json_group_array(cc.config_id) FROM case_configs cc WHERE cc.case_id = c.id) AS config_ids,
  (SELECT json_group_array(cf.name) FROM case_configs cc JOIN configurations cf ON cf.id = cc.config_id WHERE cc.case_id = c.id) AS config_names
  FROM cases c LEFT JOIN profiles p ON p.id = c.profile_id`;

function toCase(r: CaseRow, user: DbUser): CaseItem {
  const profile = normalizeProfile(parseJson(r.profile_data, {}));
  return {
    id: r.id,
    ownerId: r.owner_id,
    name: r.name,
    description: r.description,
    profileId: r.profile_id,
    profileName: r.profile_name ?? "(missing profile)",
    chiefComplaint: profile.chiefComplaint,
    look: lookOf(profile),
    configIds: parseJson<string[]>(r.config_ids, []),
    configNames: parseJson<string[]>(r.config_names, []),
    isPublic: r.is_public === 1,
    mine: r.owner_id === user.id,
  };
}

async function loadCase(env: Env, id: string) {
  return env.DB.prepare(`${CASE_SELECT} WHERE c.id = ?`).bind(id).first<CaseRow>();
}

async function checkParts(env: Env, user: DbUser, profileId: string, configIds: string[]) {
  const p = await env.DB.prepare(`SELECT owner_id, is_public FROM profiles WHERE id = ?`).bind(profileId).first<{ owner_id: string; is_public: number }>();
  if (!p || !canSee(user, p)) fail(400, "Choose a patient profile.");
  if (!configIds.length) fail(400, "Choose at least one configuration.");
  for (const id of configIds) {
    const cfg = await env.DB.prepare(`SELECT owner_id, is_public FROM configurations WHERE id = ?`).bind(id).first<{ owner_id: string; is_public: number }>();
    if (!cfg || !canSee(user, cfg)) fail(400, "One of the configurations is not available.");
  }
}

const caseRoutes = new Hono<AppEnv>()
  .get("/", async (c) => {
    const u = c.get("user");
    const rows = await c.env.DB.prepare(`${CASE_SELECT} WHERE c.owner_id = ? OR c.is_public = 1 ORDER BY c.owner_id = ? DESC, c.updated_at DESC`)
      .bind(u.id, u.id)
      .all<CaseRow>();
    return c.json(rows.results.map((r) => toCase(r, u)));
  })
  .get("/:id", async (c) => {
    const u = c.get("user");
    const row = await loadCase(c.env, c.req.param("id"));
    if (!row || !canSee(u, row)) fail(404, "Not found.");
    return c.json(toCase(row, u));
  })
  .post("/", async (c) => {
    const u = c.get("user");
    const b = await body(c.req);
    const profileId = str(b.profileId, 40);
    const configIds = Array.isArray(b.configIds) ? b.configIds.map((x) => str(x, 40)).filter(Boolean).slice(0, 10) : [];
    const name = checkName(b.name, "case");
    await checkParts(c.env, u, profileId, configIds);
    const id = newId();
    const now = Date.now();
    await c.env.DB.batch([
      c.env.DB.prepare(`INSERT INTO cases (id, owner_id, name, description, profile_id, is_public, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).bind(
        id,
        u.id,
        name,
        str(b.description, 1000),
        profileId,
        b.isPublic ? 1 : 0,
        now,
        now,
      ),
      ...configIds.map((cfg) => c.env.DB.prepare(`INSERT OR IGNORE INTO case_configs (case_id, config_id) VALUES (?, ?)`).bind(id, cfg)),
    ]);
    return c.json(toCase((await loadCase(c.env, id))!, u));
  })
  .put("/:id", async (c) => {
    const u = c.get("user");
    const row = await loadCase(c.env, c.req.param("id"));
    if (!row || !canEdit(u, row)) fail(404, "Not found.");
    const b = await body(c.req);
    const profileId = str(b.profileId, 40) || row.profile_id;
    const configIds = Array.isArray(b.configIds) ? b.configIds.map((x) => str(x, 40)).filter(Boolean).slice(0, 10) : parseJson<string[]>(row.config_ids, []);
    const name = b.name === undefined ? row.name : checkName(b.name, "case");
    await checkParts(c.env, u, profileId, configIds);
    await c.env.DB.batch([
      c.env.DB.prepare(`UPDATE cases SET name = ?, description = ?, profile_id = ?, is_public = ?, updated_at = ? WHERE id = ?`).bind(
        name,
        typeof b.description === "string" ? str(b.description, 1000) : row.description,
        profileId,
        b.isPublic === undefined ? row.is_public : b.isPublic ? 1 : 0,
        Date.now(),
        row.id,
      ),
      c.env.DB.prepare(`DELETE FROM case_configs WHERE case_id = ?`).bind(row.id),
      ...configIds.map((cfg) => c.env.DB.prepare(`INSERT OR IGNORE INTO case_configs (case_id, config_id) VALUES (?, ?)`).bind(row.id, cfg)),
    ]);
    return c.json(toCase((await loadCase(c.env, row.id))!, u));
  })
  .delete("/:id", async (c) => {
    const u = c.get("user");
    const row = await loadCase(c.env, c.req.param("id"));
    if (!row || !canEdit(u, row)) fail(404, "Not found.");
    if (await c.env.DB.prepare(`SELECT 1 FROM assignments WHERE case_id = ? LIMIT 1`).bind(row.id).first()) {
      fail(409, "This case is assigned to a course. Remove it from the course first.");
    }
    await c.env.DB.batch([
      c.env.DB.prepare(`DELETE FROM case_configs WHERE case_id = ?`).bind(row.id),
      c.env.DB.prepare(`DELETE FROM cases WHERE id = ?`).bind(row.id),
    ]);
    return c.json({ ok: true });
  })
  .post("/:id/playground", async (c) => {
    const u = c.get("user");
    const row = await loadCase(c.env, c.req.param("id"));
    if (!row || !canSee(u, row)) fail(404, "Not found.");
    const b = await body(c.req);
    const configId = str(b.configId, 40) || parseJson<string[]>(row.config_ids, [])[0];
    if (!parseJson<string[]>(row.config_ids, []).includes(configId)) fail(400, "Choose one of this case's configurations.");
    const id = await createEncounter(c.env, u, { caseId: row.id, configId, assignmentId: null, courseId: null, mode: b.mode, language: b.language });
    return c.json({ id });
  });

/** Every string in an AI draft without em or en dashes, the same as patient replies and feedback. */
function withoutDashes(v: unknown): unknown {
  if (typeof v === "string") return noDashes(v);
  if (Array.isArray(v)) return v.map(withoutDashes);
  if (v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, withoutDashes(x)]));
  return v;
}

export const libraryRoutes = new Hono<AppEnv>()
  .use("*", requireUser, requireEducator)
  .post("/profiles/assist", async (c) => {
    const u = c.get("user");
    const b = await body(c.req);
    const input = {
      diagnosis: str(b.diagnosis, 600),
      goal: str(b.goal, 300),
      big5: str(b.big5, 300),
      communication: str(b.communication, 1000),
    };
    const targets = targetsFor(c.env, "assistant", await keysFor(c.env, u, null));
    try {
      const { text, target } = await complete(
        c.env,
        targets,
        { task: "assistant", system: ASSISTANT_SYSTEM, messages: [{ role: "user", content: assistantPrompt(input) }], json: true, temperature: 0.8, maxTokens: 8192, mock: () => mockProfile(input) },
        { waitUntil: (p) => c.executionCtx.waitUntil(p) },
      );
      const raw = parseLooseJson(text) as { name?: string; profile?: unknown } | null;
      if (!raw?.profile) fail(502, "The AI draft could not be read. Please try again.");
      // Names follow the library's "Cough and fever, 46M" style, so a spaced hyphen used as a dash becomes a comma.
      const name = str(withoutDashes(raw.name), 120).replace(/\s+-\s+/g, ", ");
      return c.json({ name: name || "New patient", data: normalizeProfile(withoutDashes(raw.profile)), provider: target.provider });
    } catch (err) {
      if (err instanceof AiUnavailableError) fail(503, "The free AI is busy or out of daily capacity. Try again in a minute, or add a free key in Settings.");
      throw err;
    }
  })
  .post("/voice-preview", async (c) => {
    const b = await body(c.req);
    const voice = LIVE_VOICES.includes(str(b.voice, 40)) ? str(b.voice, 40) : "Sulafat";
    const keys = geminiKeys(c.env, await keysFor(c.env, c.get("user"), null));
    if (!keys.length) fail(503, "Natural voice needs a Google AI key.");
    try {
      const upstream = await ttsStream(c.env, keys, deliveryPrompt(str(b.text, 400) || "Hi doctor, thanks for seeing me today.", str(b.emotion, 30) || "neutral", str(b.persona, 80) || "a patient"), voice, (x) => c.executionCtx.waitUntil(x));
      return new Response(upstream.body, { headers: { "content-type": "text/event-stream", "cache-control": "no-cache" } });
    } catch {
      fail(503, "Natural voice is busy right now.");
    }
  })
  .route("/profiles", itemRoutes("profiles", normalizeProfile))
  .route("/configurations", itemRoutes("configurations", normalizeConfig))
  .route("/cases", caseRoutes);
