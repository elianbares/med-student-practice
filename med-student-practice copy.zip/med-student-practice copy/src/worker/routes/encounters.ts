import { Hono } from "hono";
import { HTTPException } from "hono/http-exception";
import type { AppEnv, DbUser, Env } from "../env";
import type {
  Comment,
  ConfigData,
  Encounter,
  EncounterSummary,
  Feedback,
  Message,
  Order,
  ProfileData,
  ProsodyAi,
  ProsodyMetrics,
  StudentBrief,
  TestItem,
} from "../../shared/types";
import { DEFAULT_RUBRIC, EMOTIONS, normalizeConfig, normalizeProfile } from "../../shared/defaults";
import { LANGUAGES, languageName } from "../../shared/languages";
import { TEST_CATALOG } from "../../shared/testCatalog";
import { requireUser } from "../auth";
import { courseRole, keysFor } from "../access";
import { getSetting } from "../db";
import { clearLimit, rateLimit } from "../limits";
import { DEMO_COURSE_CODE } from "../seed";
import { newId } from "../crypto";
import { body, fail, parseJson, str, today } from "../util";
import { AiUnavailableError, complete, stream, targetsFor } from "../ai/router";
import { GRADER_SYSTEM, actorMessages, actorSystemPrompt, firstName, firstNameOnly, graderPrompt, pseudonymize } from "../ai/prompts";
import { type FeedbackContext, buildFeedback, noDashes, normText, oneAction, parseLooseJson, spoke, withoutAnswerKey } from "../ai/grade";
import { mockFeedback, mockPatient } from "../ai/mock";
import { MIN_SPEECH_SEC, TOO_LITTLE_SPEECH, analyzeVoice, deliveryPrompt, geminiKeys, liveToken, transcribe, ttsStream, wavSeconds } from "../ai/audio";

/** Daily encounters per student on the shared free pool (unlimited with a course or personal key). */
export const DAILY_POOL_LIMIT = 15;
const VOICE_LIMIT_MIN = 30;
/**
 * A D1 row holds at most 2 MB, and the transcript is one column. Past this many characters (up to 1.5 MB even
 * in scripts that take 3 bytes a character, and hundreds of turns in any real visit) nothing more is added.
 */
const MAX_TRANSCRIPT_CHARS = 500_000;
const TRANSCRIPT_FULL = "This conversation has reached its length limit. End the encounter to get your feedback.";

interface Snapshot {
  caseName: string;
  caseDescription: string;
  configName: string;
  profile: ProfileData;
  config: ConfigData;
}

interface EncounterRow {
  id: string;
  user_id: string;
  assignment_id: string | null;
  course_id: string | null;
  case_id: string;
  config_id: string;
  mode: Encounter["mode"];
  language: string;
  status: Encounter["status"];
  messages: string;
  orders: string;
  notepad: string;
  tasks_done: string;
  diagnosis: string;
  note: string;
  feedback: string | null;
  prosody: string | null;
  prosody_ai?: string | null;
  snapshot: string;
  started_at: number;
  ended_at: number | null;
}

export function briefFrom(s: Snapshot): StudentBrief {
  const p = s.profile;
  return {
    caseName: s.caseName,
    caseDescription: s.caseDescription,
    configName: s.configName,
    patient: { ...p.demographics, chiefComplaint: p.chiefComplaint },
    contextGoal: s.config.contextGoal,
    encounterTasks: s.config.encounterTasks,
    postEncounterTasks: s.config.postEncounterTasks,
    diagnosisType: s.config.diagnosisType,
    notesEnabled: s.config.notesFeedback.enabled,
    timeLimitMin: s.config.timeLimitMin,
    voice: p.voice,
    appearance: p.appearance,
    // In search mode the case's tests stay hidden so the list can't hint at the diagnosis.
    tests: s.config.testOrdering === "menu" ? p.tests.map((t) => ({ id: t.id, category: t.category, name: t.name })) : [],
    testOrdering: s.config.testOrdering,
    doorNote: p.doorNote,
    initialEmotion: p.initialEmotion,
    ...(s.config.showResultsInBrief ? { briefResults: p.tests.map((t) => ({ category: t.category, name: t.name, result: t.result })) } : {}),
  };
}

const snapshotOf = (r: EncounterRow): Snapshot => {
  const s = parseJson<Snapshot>(r.snapshot, {} as Snapshot);
  return { ...s, profile: normalizeProfile(s.profile), config: normalizeConfig(s.config) };
};

export async function createEncounter(
  env: Env,
  user: DbUser,
  o: { caseId: string; configId: string; assignmentId: string | null; courseId: string | null; mode: unknown; language: unknown },
): Promise<string> {
  const row = await env.DB.prepare(
    `SELECT c.name AS case_name, c.description, p.data AS profile, cf.name AS config_name, cf.data AS config
     FROM cases c JOIN profiles p ON p.id = c.profile_id JOIN configurations cf ON cf.id = ? WHERE c.id = ?`,
  )
    .bind(o.configId, o.caseId)
    .first<{ case_name: string; description: string; profile: string; config_name: string; config: string }>();
  if (!row) fail(404, "This case is no longer available.");

  const keys = await keysFor(env, user, o.courseId);
  if (!keys.length && user.role === "student") {
    const count = await env.DB.prepare(`SELECT COUNT(*) AS n FROM encounters WHERE user_id = ? AND started_at > ?`)
      .bind(user.id, Date.parse(today()))
      .first<{ n: number }>();
    if ((count?.n ?? 0) >= DAILY_POOL_LIMIT) {
      // The allowance resets at midnight UTC; Retry-After (set by the error handler from `cause`) says when.
      const retryAfter = Math.max(60, Math.ceil((Date.parse(today()) + 86400_000 - Date.now()) / 1000));
      const hours = Math.ceil(retryAfter / 3600);
      throw new HTTPException(429, {
        message: `You've used today's ${DAILY_POOL_LIMIT} free practice encounters on the shared AI. More open up in about ${hours} ${hours === 1 ? "hour" : "hours"}. For unlimited practice, add your own free AI key in Settings.`,
        cause: { retryAfter },
      });
    }
  }

  const mode = o.mode === "voice" || o.mode === "emotive" ? o.mode : "text";
  const language = LANGUAGES.some((l) => l.code === o.language) ? (o.language as string) : "en-US";
  const snapshot: Snapshot = {
    caseName: row.case_name,
    caseDescription: row.description,
    configName: row.config_name,
    profile: normalizeProfile(parseJson(row.profile, {})),
    config: normalizeConfig(parseJson(row.config, {})),
  };
  const id = newId();
  await env.DB.prepare(
    `INSERT INTO encounters (id, user_id, assignment_id, course_id, case_id, config_id, mode, language, status, snapshot, started_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)`,
  )
    .bind(id, user.id, o.assignmentId, o.courseId, o.caseId, o.configId, mode, language, JSON.stringify(snapshot), Date.now())
    .run();
  return id;
}

async function loadEncounter(env: Env, id: string) {
  return env.DB.prepare(`SELECT * FROM encounters WHERE id = ?`).bind(id).first<EncounterRow>();
}

/** Owner can read and write; course staff (and admins) can read and comment. */
async function access(env: Env, user: DbUser, id: string) {
  const row = await loadEncounter(env, id);
  if (!row) fail(404, "Encounter not found.");
  if (row.user_id === user.id) return { row, owner: true };
  if (user.role === "admin") return { row, owner: false };
  if (row.course_id && (await courseRole(env, user, row.course_id)) === "staff") return { row, owner: false };
  fail(404, "Encounter not found.");
}

async function owned(env: Env, user: DbUser, id: string) {
  const a = await access(env, user, id);
  if (!a.owner) fail(403, "Only the student who ran this encounter can change it.");
  return a.row;
}

export function toEncounter(r: EncounterRow, comments: Comment[] = [], studentName?: string): Encounter {
  const snap = snapshotOf(r);
  const messages = parseJson<Message[]>(r.messages, []);
  const feedback = parseJson<Feedback | null>(r.feedback, null);
  return {
    id: r.id,
    userId: r.user_id,
    assignmentId: r.assignment_id,
    caseId: r.case_id,
    configId: r.config_id,
    mode: r.mode,
    language: r.language,
    status: r.status,
    messages,
    orders: parseJson<Order[]>(r.orders, []),
    notepad: r.notepad,
    tasksDone: parseJson<number[]>(r.tasks_done, []),
    diagnosis: r.diagnosis,
    note: r.note,
    // Older feedback on a silent attempt may still hold the case diagnosis and expected tests.
    feedback: feedback && !spoke(messages) ? withoutAnswerKey(feedback) : feedback,
    prosody: (() => {
      const m = parseJson<ProsodyMetrics | null>(r.prosody, null);
      const ai = parseJson<ProsodyAi | null>(r.prosody_ai, null);
      return m || ai ? ({ ...(m ?? ({} as ProsodyMetrics)), ai } as ProsodyMetrics) : null;
    })(),
    startedAt: r.started_at,
    endedAt: r.ended_at,
    brief: briefFrom(snap),
    comments,
    studentName,
    levels: snap.config.levels,
  };
}

/**
 * Columns for encounter lists (alias the table `e`). D1 picks the few fields a list needs out of the
 * transcript, snapshot and feedback JSON, so the Worker never parses them: a course's results can be a
 * thousand rows, far beyond the free plan's CPU time if parsed here.
 */
export const SUMMARY_SQL = `e.id, e.mode, e.status, e.started_at, e.ended_at, e.config_id,
  json_extract(e.snapshot, '$.caseName') AS case_name, json_extract(e.snapshot, '$.configName') AS config_name,
  json_extract(e.snapshot, '$.config.levels') AS levels,
  (CASE WHEN json_valid(e.messages) THEN (SELECT COUNT(*) FROM json_each(e.messages) WHERE json_extract(value, '$.role') = 'doctor') ELSE 0 END) AS doctor_turns,
  (CASE WHEN json_valid(e.feedback) THEN json_extract(e.feedback, '$.provider') END) AS graded_by,
  (CASE WHEN json_valid(e.feedback) THEN json_extract(e.feedback, '$.diagnosisVerdict') END) AS verdict,
  (CASE WHEN json_valid(e.feedback) THEN json_extract(e.feedback, '$.diagnosisSupport') END) AS support,
  (CASE WHEN json_valid(e.feedback) THEN (SELECT json_group_array(json_object('category', json_extract(value, '$.category'), 'level', json_extract(value, '$.level')))
    FROM json_each(e.feedback, '$.rubric')) END) AS scores`;

export interface SummaryRow {
  id: string;
  mode: string;
  status: string;
  started_at: number;
  ended_at: number | null;
  config_id: string | null;
  case_name: string | null;
  config_name: string | null;
  levels: string | null;
  doctor_turns: number;
  graded_by: string | null;
  verdict: string | null;
  support: string | null;
  scores: string | null;
  course_name?: string | null;
  student_name?: string;
  student_email?: string;
}

const SUPPORTS = new Set(["supported", "partly", "unsupported", "n/a"]);
// A course's results can be a thousand rows sharing a few level lists, so each list is read once.
const levelsSeen = new Map<string, string[]>();
function levelsOf(raw: string | null): string[] {
  const key = raw ?? "";
  let levels = levelsSeen.get(key);
  if (!levels) {
    levels = normalizeConfig({ levels: parseJson<unknown>(raw, []) }).levels;
    if (levelsSeen.size >= 100) levelsSeen.clear();
    levelsSeen.set(key, levels);
  }
  return [...levels];
}

export function summaryOf(r: SummaryRow): EncounterSummary {
  return {
    id: r.id,
    caseName: r.case_name ?? "Case",
    configId: r.config_id ?? "",
    configName: r.config_name ?? "",
    courseName: r.course_name ?? null,
    studentName: r.student_name,
    studentEmail: r.student_email,
    mode: r.mode,
    status: r.status,
    startedAt: r.started_at,
    endedAt: r.ended_at,
    levels: levelsOf(r.levels),
    scores: parseJson<EncounterSummary["scores"]>(r.scores, []),
    diagnosisVerdict: r.verdict ?? undefined,
    diagnosisSupport: SUPPORTS.has(r.support ?? "") ? (r.support as EncounterSummary["diagnosisSupport"]) : undefined,
    doctorTurns: r.doctor_turns,
    // "none" means nothing graded it (no conversation, or the AI was unavailable).
    gradedBy: r.graded_by && r.graded_by !== "none" ? r.graded_by : undefined,
  };
}

function timeLeftMs(r: EncounterRow, snap: Snapshot): number {
  const limits = [snap.config.timeLimitMin, r.mode === "text" ? 0 : VOICE_LIMIT_MIN].filter((m) => m > 0);
  if (!limits.length) return Infinity;
  return Math.min(...limits) * 60_000 + 120_000 - (Date.now() - r.started_at); // two minutes of grace
}

// ---------- tests ----------

// Typed orders are matched word by word against the case's test names, which put common synonyms in
// brackets ("Complete blood count (CBC, hemoglobin, white cells, platelets)"). Both sides go through the
// same steps: everyday phrases and abbreviations become the words case authors use, plurals lose their
// "s", and filler words drop out. Every specific word of the order must appear in the test; generic
// words (blood, test, panel...) can't make a match on their own and only break ties.

/** Multi-word phrases, rewritten before words are split (on lowercased text with punctuation removed). */
const PHRASES: [RegExp, string][] = [
  [/\bx ?rays?\b/g, "xray"],
  [/\bfull blood count\b/g, "cbc"],
  [/\bblood count\b/g, "cbc"],
  [/\bblood (sugar|glucose)\b/g, "glucose"],
  [/\bsed rate\b/g, "esr"],
  [/\burine (dip|dipstick|analysis)\b/g, "urinalysis"],
  [/\bdipstick\b/g, "urinalysis"],
  [/\bheart rate\b/g, "pulse"],
  [/\b(respiratory|resp|breathing) rate\b/g, "breathing rate"],
  [/\bpulse ox(imetry)?\b/g, "oxygen saturation"],
  [/\b(o2|oxygen) sats?\b/g, "oxygen saturation"],
  [/\bchem ?7\b/g, "bmp"],
  [/\bchem ?(10|12|14|20)\b/g, "cmp"],
  [/\bu (and )?es?\b/g, "electrolytes"],
  [/\b12 lead\b/g, "ecg"],
  [/\bchest film\b/g, "chest xray"],
  [/\b(heart sounds?|murmurs?)\b/g, "listen heart"],
  [/\bbreath sounds?\b/g, "listen lung"],
];

/** Abbreviations and everyday words, mapped to the words case authors use. */
const ABBREV: Record<string, string> = {
  cbc: "complete blood count",
  fbc: "complete blood count",
  wbc: "complete blood count",
  hb: "hemoglobin",
  hgb: "hemoglobin",
  bmp: "basic metabolic panel",
  cmp: "comprehensive metabolic panel",
  chem: "metabolic panel",
  lft: "liver function tests",
  lfts: "liver function tests",
  tft: "thyroid function tests",
  tfts: "thyroid function tests",
  lytes: "electrolytes",
  neuro: "neurological",
  neurologic: "neurological",
  resp: "respiratory",
  abdo: "abdomen",
  abdominal: "abdomen",
  belly: "abdomen",
  tummy: "abdomen",
  cardiac: "heart",
  cardio: "heart",
  cvs: "heart",
  pulmonary: "lung",
  renal: "kidney",
  hepatic: "liver",
  ent: "heent",
  csf: "lumbar puncture",
  lp: "lumbar puncture",
  sats: "oxygen saturation",
  spo2: "oxygen saturation",
  o2: "oxygen",
  cxr: "chest xray",
  ecg: "ecg",
  ekg: "ecg",
  ua: "urinalysis",
  crp: "reactive protein",
  esr: "erythrocyte sedimentation rate",
  tsh: "tsh",
  ct: "ct",
  mri: "mri",
  vitals: "vital signs",
  obs: "vital signs",
  observations: "vital signs",
  bp: "blood pressure",
  hr: "pulse",
  rr: "breathing rate",
  temp: "temperature",
  pt: "coagulation",
  inr: "coagulation",
  coag: "coagulation",
  coags: "coagulation",
  hcg: "pregnancy",
  ck: "creatine kinase",
  cpk: "creatine kinase",
  trop: "troponin",
  sugar: "glucose",
  echo: "echocardiogram",
  hep: "hepatitis",
  gcs: "glasgow coma scale",
  uds: "urine drug screen",
};

/** Words that say nothing about which test is meant. */
const STOP = new Set(
  ("a an the of and or for to on in at with without non no from by please pls order orders ordering request get do done " +
    "perform performing run send i id like want would could can will we you me my your his her their our him them " +
    "patient some any all also just now quick quickly urgent stat repeat routine set two one see show what how " +
    "does is are be have has there it this that results result findings left right both bilateral")
    .split(" "),
);
/** Words that name a kind of test rather than a test. They never match on their own. */
const GENERIC = new Set(
  ("exam examination test panel screen screening level blood serum plasma urine free vitamin function rate scan study " +
    "check count lab work workup imaging investigation analysis profile assessment measurement value physical")
    .split(" "),
);
/** Words that ask for a physical exam (the order is then matched against exams and vital signs only). */
const EXAM_WORDS = new Set(
  "exam examination examine examining physical listen auscultate auscultation palpate palpation percuss percussion inspect inspection look feel".split(" "),
);
/** Single letters that belong to the word before them ("vitamin d", "hepatitis b"). */
const LETTER_HEADS = new Set(["vitamin", "hepatitis"]);
/** Specimen words: an order for a urine test never matches a blood test, and the other way round. */
const SPECIMEN: Record<string, string> = { blood: "blood", serum: "blood", plasma: "blood", urine: "urine", sputum: "sputum", stool: "stool" };

const stem = (w: string): string => {
  if (w.length <= 3 || /\d/.test(w)) return w;
  if (w.endsWith("ies") && w.length > 4) return `${w.slice(0, -3)}y`;
  if (/(ss|x|ch|sh|us)es$/.test(w)) return w.slice(0, -2);
  if (w.endsWith("s") && !/(ss|us|is)$/.test(w)) return w.slice(0, -1);
  return w;
};

/** Lowercased text with everyday phrases rewritten ("blood sugar" becomes "glucose"). */
const phrased = (text: string) => PHRASES.reduce((s, [re, to]) => s.replace(re, to), normText(text));
const asksForExam = (text: string) => phrased(text).split(" ").some((w) => EXAM_WORDS.has(w));

/** Words of a test name or order, with abbreviations expanded, plurals singular and filler dropped. */
function orderWords(text: string, examIntent = false): string[] {
  const out: string[] = [];
  for (const raw of phrased(text).split(" ")) {
    // "pt" is a coagulation test, unless the order is to examine the patient.
    if (!raw || STOP.has(raw) || (examIntent && raw === "pt")) continue;
    if (/^[a-z]$/.test(raw)) {
      // "vitamin d" is one test; other lone letters ("c reactive", "d dimer") carry no meaning alone.
      const prev = out[out.length - 1];
      if (prev && LETTER_HEADS.has(prev)) out.push(`${prev}${raw}`);
      continue;
    }
    const w = stem(raw);
    const mapped = ABBREV[raw] ?? ABBREV[w];
    if (mapped) out.push(...mapped.split(" ").map(stem));
    else if (!STOP.has(w) && (w.length > 2 || /\d/.test(w))) out.push(w);
  }
  return out;
}

const isSpecific = (w: string) => !GENERIC.has(w) && !EXAM_WORDS.has(w);

interface TestWords {
  test: TestItem;
  /** The main name (before the brackets) first, then each synonym, as word strings. */
  phrases: string[];
  words: Set<string>;
  primary: Set<string>;
  /** Number of distinct specific words in the whole name. */
  specific: number;
  specimens: Set<string>;
  exam: boolean;
}

function testWords(t: TestItem): TestWords {
  const main = t.name.split("(")[0];
  const synonyms = (t.name.match(/\(([^)]*)\)/)?.[1] ?? "").split(/,|\bor\b/);
  const all = orderWords(t.name);
  const words = new Set(all);
  // Joined forms too, so "phq9" finds "PHQ-9" and "covid19" finds "COVID-19".
  all.forEach((w, i) => {
    const next = all[i + 1];
    if (next && (/^\d+$/.test(next) || /^\d+$/.test(w))) words.add(`${w}${next}`);
  });
  const specimens = new Set(all.map((w) => SPECIMEN[w]).filter(Boolean));
  // A lab test that names no specimen is a blood test.
  if (/^lab/i.test(t.category.trim()) && !specimens.size) specimens.add("blood");
  return {
    test: t,
    phrases: [main, ...synonyms].map((p) => orderWords(p).join(" ")).filter(Boolean),
    words,
    primary: new Set(orderWords(main)),
    specific: new Set(all.filter(isSpecific)).size || 1,
    specimens,
    exam: /^(physical exam|vital signs)$/i.test(t.category.trim()) || words.has("exam") || words.has("examination"),
  };
}

/** True when an order names no particular exam or test ("blood test", "labs"), so nothing can match it. */
export function vagueOrder(query: string): boolean {
  return !asksForExam(query) && !orderWords(query).some(isSpecific);
}

/** Two typed orders mean the same thing ("urine dip" and "urinalysis"). */
export const sameOrder = (a: string, b: string) => orderWords(a).join(" ") === orderWords(b).join(" ");

/** "Listen to heart and lungs" or "CBC, BMP": more than one order at once. Names that are one test ("Weight and BMI", "U&E") aren't. */
export function severalOrders(query: string): boolean {
  if (!/\band\b|[,+;]|\s&\s/i.test(query)) return false;
  const q = normText(query);
  return !TEST_CATALOG.some((x) => [x.name, ...x.synonyms].some((n) => normText(n) === q));
}

/** Lexicographic comparison: is score a better than score b? */
const beats = (a: number[], b: number[]) => {
  const i = a.findIndex((v, j) => v !== b[j]);
  return i >= 0 && a[i] > b[i];
};

/**
 * The case test a typed order means, or undefined when the case file doesn't include it. Specific words
 * must all match; a vague exam-only order ("physical exam", "examine the patient") gets the case's first
 * physical exam item, which every seed case keeps harmless (general appearance).
 */
export function findTest(tests: TestItem[], query: string): TestItem | undefined {
  const examIntent = asksForExam(query);
  const q = orderWords(query, examIntent);
  const items = tests.map(testWords);
  // 1. Exactly a test's name or one of its synonyms (a main name wins over a synonym).
  const key = q.join(" ");
  const exact = key ? (items.find((it) => it.phrases[0] === key) ?? items.find((it) => it.phrases.includes(key))) : undefined;
  if (exact) return exact.test;
  const specific = q.filter(isSpecific);
  if (!specific.length) return examIntent ? tests.find((t) => /^physical exam$/i.test(t.category.trim())) : undefined;
  // 2. Every specific word appears in the name. Ties go to the test that also has the generic words
  //    ("thyroid function" finds the TSH, not the thyroid exam), then to words in the main name, then to
  //    the shortest name, then to the first listed.
  const qSpecimens = new Set(q.filter((w) => GENERIC.has(w) && SPECIMEN[w]).map((w) => SPECIMEN[w]));
  let best: { it: TestWords; score: number[] } | undefined;
  for (const it of items) {
    if (examIntent && !it.exam) continue;
    if (!specific.every((w) => it.words.has(w))) continue;
    if (qSpecimens.size && it.specimens.size && ![...qSpecimens].some((s) => it.specimens.has(s))) continue;
    const score = [q.filter((w) => it.words.has(w)).length, specific.filter((w) => it.primary.has(w)).length, specific.length / it.specific];
    if (!best || beats(score, best.score)) best = { it, score };
  }
  return best?.it.test;
}

// ---------- patient replies ----------

const EMO = new Set<string>(EMOTIONS);

// Words a model may write for each emotion, in a tag like "[worried]" or "[emotion: scared]".
const EMOTION_WORDS: [RegExp, string][] = [
  [/^(pain|pained|painful|hurt|hurts|hurting|aching|achy|sore|agony|agonized|agonised|wincing|grimacing|uncomfortable|discomfort)$/, "in_pain"],
  [/^(anxiety|worry|worried|worrying|nervous|scared|afraid|frightened|fearful|panicked|panicky|panicking|tense|uneasy|apprehensive|concerned|alarmed|stressed)$/, "anxious"],
  [/^(upset|tearful|teary|crying|down|depressed|unhappy|sorrowful|hopeless|despondent|distressed|emotional|grieving|miserable)$/, "sad"],
  [/^(anger|irritated|irritable|frustrated|annoyed|mad|furious|defensive|hostile|impatient|agitated)$/, "angry"],
  [/^(confusion|puzzled|unsure|uncertain|bewildered|perplexed|disoriented)$/, "confused"],
  [/^(relief|reassured|grateful|thankful|hopeful)$/, "relieved"],
  [/^(ashamed|awkward|shy|sheepish|self_conscious|bashful|hesitant|reluctant|guarded)$/, "embarrassed"],
  [/^(relaxed|composed|steady|content|comfortable|at_ease|stoic|cheerful|friendly|happy|pleased)$/, "calm"],
  [/^(normal|flat|matter_of_fact)$/, "neutral"],
];
// Softeners a model may put around the feeling: "[a bit worried]", "[very anxious]", "[feeling scared]".
const EMOTION_FILLER = new Set(["a", "bit", "little", "very", "slightly", "somewhat", "quite", "really", "more", "less", "mildly", "extremely", "still", "now", "so", "rather", "feeling", "feels", "sounding", "looking", "getting", "visibly", "increasingly"]);

/** One emotion named in a word or two ("in pain", "a bit worried"), or undefined when it names none. */
function emotionWord(raw: string): string | undefined {
  const words = raw.trim().toLowerCase().split(/[\s_-]+/).filter(Boolean);
  if (!words.length || words.length > 3) return undefined;
  const whole = words.join("_");
  if (EMO.has(whole)) return whole;
  const core = words.filter((w) => !EMOTION_FILLER.has(w)).join("_");
  if (!core) return undefined;
  if (EMO.has(core)) return core;
  return EMOTION_WORDS.find(([re]) => re.test(core) || re.test(whole))?.[1];
}

/** The emotion in a tag's inside: "emotion: anxious", or a bare "anxious", "in pain", "worried, in pain". */
function tagEmotion(inner: string): string | undefined {
  const named = /^\s*emotion\s*(?::|=|\s)\s*([^\]]*)$/i.exec(inner);
  if (named) return normalizeEmotion(named[1]);
  const parts = inner.split(/[,;/&]|\band\b/i);
  if (parts.length > 2) return undefined;
  const found = parts.map(emotionWord);
  return found.every(Boolean) ? found[0] : undefined;
}

/** Maps what a model wrote for a feeling to one of EMOTIONS, falling back to neutral. */
export function normalizeEmotion(raw: string): string {
  const exact = raw.split(/[,;/&]|\band\b/i).map(emotionWord).find(Boolean);
  if (exact) return exact;
  const e = raw.trim().toLowerCase().replace(/\s+/g, "_");
  if (/pain|hurt/.test(e)) return "in_pain";
  if (/worr|nerv|scared|fear|anx/.test(e)) return "anxious";
  if (/upset|sad|tear|cry/.test(e)) return "sad";
  if (/irrit|frustr|mad|ang/.test(e)) return "angry";
  return "neutral";
}

/**
 * Splits the emotion tags off the start of a reply: "[emotion: in_pain]" as asked, or a bare "[in_pain]",
 * "[worried]" or "[in pain]". Ordinary bracketed text that names no emotion stays in the reply. While
 * streaming, `pending` says the start is still undecided (an unclosed "[" or nothing but tags so far).
 */
export function splitLeadingEmotion(text: string): { emotion?: string; rest: string; pending: boolean } {
  let emotion: string | undefined;
  let rest = text.trimStart();
  for (;;) {
    if (!rest) return { emotion, rest, pending: true };
    if (!rest.startsWith("[")) return { emotion, rest, pending: false };
    const close = rest.indexOf("]");
    if (close < 0) return { emotion, rest, pending: rest.length < 60 && !rest.includes("\n") };
    const found = tagEmotion(rest.slice(1, close));
    if (!found) return { emotion, rest, pending: false };
    emotion ??= found;
    rest = rest.slice(close + 1).trimStart();
  }
}

export function cleanPatientText(text: string, patientName: string): { text: string; emotion?: string } {
  const first = patientName.split(/\s+/)[0];
  const label = new RegExp(`^\\s*(patient|${first ? first.replace(/[^\p{L}]/gu, "") || "patient" : "patient"})\\s*:\\s*`, "iu");
  // A tag may come before or after a "Name:" label; the first one found sets the emotion.
  const lead = splitLeadingEmotion(text);
  const after = splitLeadingEmotion(lead.rest.replace(label, ""));
  let emotion = lead.emotion ?? after.emotion;
  const t = after.rest.replace(/\[\s*emotion\s*:\s*([^\]]*)\]/gi, (_m, e: string) => {
    emotion ??= normalizeEmotion(e);
    return "";
  });
  return { text: t.replace(/^\s+|\s+$/g, "").replace(/\n{3,}/g, "\n\n"), emotion };
}

async function replyStream(c: import("hono").Context<AppEnv>, row: EncounterRow, doctorText: string) {
  const env = c.env;
  const user = c.get("user");
  const snap = snapshotOf(row);
  const t = Date.now() - row.started_at;
  const history: Message[] = [...parseJson<Message[]>(row.messages, []), { role: "doctor", text: doctorText, t }];
  const targets = targetsFor(env, "actor", await keysFor(env, user, row.course_id));
  const voice = row.mode !== "text";

  let opened;
  try {
    opened = await stream(
      env,
      targets,
      {
        task: "actor",
        // Pseudonymity: the model only ever sees the student's first name.
        system: actorSystemPrompt(snap.profile, snap.config, languageName(row.language), voice, null, firstName(user.name)),
        messages: actorMessages(pseudonymize(history, user.name)),
        temperature: 0.8,
        maxTokens: 1024,
        mock: () => mockPatient(snap.profile, history),
      },
      { waitUntil: (p) => c.executionCtx.waitUntil(p) },
    );
  } catch (err) {
    if (err instanceof AiUnavailableError) {
      fail(503, "The free AI is busy or out of daily capacity. Wait a moment and send your message again, or ask your instructor to add a course AI key.");
    }
    throw err;
  }

  // Save the clinician's line now that a patient reply is on its way.
  await env.DB.prepare(`UPDATE encounters SET messages = ? WHERE id = ?`).bind(JSON.stringify(history), row.id).run();

  const { readable, writable } = new TransformStream<Uint8Array, Uint8Array>();
  const writer = writable.getWriter();
  const enc = new TextEncoder();
  let clientGone = false;
  const send = async (obj: object) => {
    if (clientGone) return;
    try {
      await writer.write(enc.encode(`data: ${JSON.stringify(obj)}\n\n`));
    } catch {
      clientGone = true;
    }
  };

  const pump = async () => {
    let full = "";
    let head = "";
    let headDone = false;
    // Em and en dashes become commas as text streams. Trailing spaces wait for the next chunk so a dash
    // split across chunks (a space, then the dash) still reads "word, next".
    let carry = "";
    let started = false;
    const sendText = async (text: string) => {
      const out = noDashes(/^\s/.test(text) && !carry.includes("\n") ? text : carry + text, !started);
      const end = out.search(/\s+$/);
      carry = end >= 0 ? out.slice(end) : "";
      const now = end >= 0 ? out.slice(0, end) : out;
      if (now) {
        started = true;
        await send({ t: now });
      }
    };
    // Hold back the leading emotion tag ("[emotion: x]" or a bare "[x]") so it never flashes on screen,
    // and send the emotion before any text. Bracketed text that is not an emotion streams as it is.
    const flushHead = async (final: boolean) => {
      const lead = splitLeadingEmotion(head);
      if (lead.pending && !final) return;
      headDone = true;
      if (lead.emotion) await send({ emotion: lead.emotion });
      if (lead.rest) await sendText(lead.rest);
    };
    try {
      for await (const chunk of opened.chunks) {
        full += chunk;
        if (!headDone) {
          head += chunk;
          await flushHead(false);
          continue;
        }
        await sendText(chunk);
      }
    } catch (err) {
      console.warn("stream interrupted", err);
    }
    if (!headDone) await flushHead(true);
    const cleaned = cleanPatientText(full, snap.profile.demographics.name);
    // Saved text: no em or en dashes, and at most one *action* (the stream may briefly show more).
    const patientMsg: Message = { role: "patient", text: oneAction(noDashes(cleaned.text)) || "...", t: Date.now() - row.started_at, emotion: cleaned.emotion ?? "neutral" };
    // Re-read so a test ordered meanwhile is not lost.
    const latest = await loadEncounter(env, row.id);
    const msgs = parseJson<Message[]>(latest?.messages, history);
    msgs.push(patientMsg);
    await env.DB.prepare(`UPDATE encounters SET messages = ? WHERE id = ?`).bind(JSON.stringify(msgs), row.id).run();
    await send({ done: true, message: patientMsg, demo: opened.target.provider === "mock" });
    if (!clientGone) await writer.close().catch(() => undefined);
  };
  c.executionCtx.waitUntil(pump());

  return new Response(readable, {
    headers: { "content-type": "text/event-stream; charset=utf-8", "cache-control": "no-cache, no-transform", "x-accel-buffering": "no" },
  });
}

/** "a 39-year-old woman" style description for voice delivery. */
export function personaOf(p: ProfileData): string {
  const age = parseInt(p.demographics.age, 10);
  const sex = p.demographics.sex.toLowerCase();
  const who = /^f|woman|female/.test(sex) ? "woman" : /^m|man|male/.test(sex) ? "man" : "person";
  return Number.isFinite(age) ? `a ${age}-year-old ${age < 13 ? (who === "woman" ? "girl" : who === "man" ? "boy" : "child") : who} patient` : `a ${who} patient`;
}

// ---------- grading ----------

async function gradeEncounter(c: import("hono").Context<AppEnv>, row: EncounterRow): Promise<Feedback> {
  const env = c.env;
  const snap = snapshotOf(row);
  const config = snap.config.rubric.length ? snap.config : { ...snap.config, rubric: DEFAULT_RUBRIC };
  const messages = parseJson<Message[]>(row.messages, []);
  const orders = parseJson<Order[]>(row.orders, []);
  const ctx: FeedbackContext = { profile: snap.profile, config, messages, orders, diagnosis: row.diagnosis };

  // Nothing said: no AI call, and buildFeedback leaves out the answer key.
  if (!spoke(messages)) return buildFeedback({}, ctx, "none");

  const owner = await env.DB.prepare(`SELECT id, email, name, role, ai_key_enc FROM users WHERE id = ?`).bind(row.user_id).first<DbUser>();
  let remaining = targetsFor(env, "grader", owner ? await keysFor(env, owner, row.course_id) : []);
  // Pseudonymity: the grader sees the student's lines with only their first name; quotes are mapped back.
  ctx.studentName = owner?.name ?? "";
  const prompt = graderPrompt({
    profile: snap.profile,
    config,
    messages: pseudonymize(messages, ctx.studentName),
    orders,
    diagnosis: row.diagnosis,
    note: firstNameOnly(row.note, ctx.studentName),
    languageName: languageName(row.language),
    durationMs: (row.ended_at ?? Date.now()) - row.started_at,
  });
  try {
    // Unreadable JSON gets one more model, not every model: each round re-checks every model's shared cooldown,
    // and the free plan allows 50 subrequests (fetches, cache reads and database queries) per request.
    for (let round = 0; round < 2 && remaining.length; round++) {
      const { text, target } = await complete(
        env,
        remaining,
        {
          task: "grader",
          system: GRADER_SYSTEM,
          messages: [{ role: "user", content: prompt }],
          json: true,
          temperature: 0,
          maxTokens: 8192,
          mock: () => mockFeedback(config, messages),
        },
        { waitUntil: (p) => c.executionCtx.waitUntil(p) },
      );
      const raw = parseLooseJson(text);
      if (raw) return buildFeedback(raw, ctx, target.provider === "mock" ? "demo" : `${target.provider}/${target.model}`);
      remaining = remaining.filter((t) => t !== target);
    }
  } catch (err) {
    if (!(err instanceof AiUnavailableError)) throw err;
  }
  return {
    ...buildFeedback({}, ctx, "none"),
    error: "The free AI couldn't grade this encounter right now (it may be busy or out of daily capacity). Your transcript is saved; press Retry feedback in a minute.",
  };
}

// ---------- routes ----------

const PROSODY_KEYS: Exclude<keyof ProsodyMetrics, "ai">[] = [
  "speakingSeconds",
  "wordsPerMinute",
  "avgPauseSec",
  "longPauses",
  "pitchVariation",
  "loudnessVariation",
  "talkShare",
  "fillerWords",
];

function cleanProsody(v: unknown): ProsodyMetrics | null {
  if (!v || typeof v !== "object") return null;
  const o = v as Record<string, unknown>;
  const out = {} as ProsodyMetrics;
  for (const k of PROSODY_KEYS) {
    const n = Number(o[k]);
    out[k] = Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;
  }
  return out;
}

/**
 * One grading run per encounter at a time, shared by /end and /grade ("Get feedback now"). It is released
 * when the run finishes and lapses by itself if a run was cut off, so an interrupted encounter can be retried.
 */
const GRADE_LEASE_SEC = 180;
const gradeLease = (id: string) => `grade:${id}`;
const BEING_GRADED = "This encounter is already being graded. Check again in a minute.";

/**
 * Grades and saves the feedback. waitUntil lets the run finish if the student closes the tab meanwhile, so
 * the encounter isn't left half graded. On an unexpected error `undo` runs, then the error is rethrown.
 */
async function gradeAndSave(c: import("hono").Context<AppEnv>, row: EncounterRow, undo?: () => Promise<unknown>): Promise<Feedback> {
  const env = c.env;
  const run = (async () => {
    try {
      const feedback = await gradeEncounter(c, row);
      await env.DB.prepare(`UPDATE encounters SET status = 'done', feedback = ? WHERE id = ?`).bind(JSON.stringify(feedback), row.id).run();
      return feedback;
    } catch (err) {
      await undo?.().catch(() => undefined);
      throw err;
    } finally {
      await clearLimit(env, gradeLease(row.id)).catch(() => undefined);
    }
  })();
  c.executionCtx.waitUntil(run.catch(() => undefined));
  return run;
}

export const encounterRoutes = new Hono<AppEnv>()
  .use("*", requireUser)
  .get("/", async (c) => {
    const u = c.get("user");
    const rows = await c.env.DB.prepare(
      `SELECT ${SUMMARY_SQL}, co.name AS course_name FROM encounters e LEFT JOIN courses co ON co.id = e.course_id
       WHERE e.user_id = ? ORDER BY e.started_at DESC LIMIT 200`,
    )
      .bind(u.id)
      .all<SummaryRow>();
    return c.json(rows.results.map(summaryOf));
  })
  .post("/", async (c) => {
    const u = c.get("user");
    const b = await body(c.req);
    const asg = await c.env.DB.prepare(`SELECT id, course_id, case_id, config_id FROM assignments WHERE id = ?`)
      .bind(str(b.assignmentId, 40))
      .first<{ id: string; course_id: string; case_id: string; config_id: string }>();
    if (!asg) fail(404, "Assignment not found.");
    const archived = await c.env.DB.prepare(`SELECT archived, code FROM courses WHERE id = ?`).bind(asg.course_id).first<{ archived: number; code: string }>();
    const role = await courseRole(c.env, u, asg.course_id);
    if (!role) fail(403, "Join this course first.");
    if (archived?.archived) fail(403, "This course has been archived by the instructor.");
    // An admin can close the shared demo course to keep the free AI quota for real courses.
    if (role === "student" && archived?.code === DEMO_COURSE_CODE && (await getSetting(c.env, "demo_course_open", "1")) === "0") {
      fail(403, "The demo course is closed on this site. Ask your instructor for a course code.");
    }
    const id = await createEncounter(c.env, u, {
      caseId: asg.case_id,
      configId: asg.config_id,
      assignmentId: asg.id,
      courseId: asg.course_id,
      mode: b.mode,
      language: b.language,
    });
    return c.json({ id });
  })
  .get("/:id", async (c) => {
    const u = c.get("user");
    const { row } = await access(c.env, u, c.req.param("id"));
    const [comments, student] = await c.env.DB.batch([
      c.env.DB.prepare(
        `SELECT cm.id, cm.message_idx AS messageIdx, us.name AS authorName, cm.body, cm.created_at AS createdAt
         FROM comments cm JOIN users us ON us.id = cm.author_id WHERE cm.encounter_id = ? ORDER BY cm.created_at`,
      ).bind(row.id),
      c.env.DB.prepare(`SELECT name FROM users WHERE id = ?`).bind(row.user_id),
    ]);
    return c.json(toEncounter(row, comments.results as unknown as Comment[], (student.results[0] as { name?: string })?.name));
  })
  .post("/:id/begin", async (c) => {
    // The clock starts when the student clicks "Start conversation", not while they read the brief.
    const row = await owned(c.env, c.get("user"), c.req.param("id"));
    if (row.status === "active" && row.messages === "[]") {
      await c.env.DB.prepare(`UPDATE encounters SET started_at = ? WHERE id = ?`).bind(Date.now(), row.id).run();
    }
    return c.json({ ok: true });
  })
  .post("/:id/message", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    if (row.status !== "active") fail(409, "This encounter has ended.");
    if (timeLeftMs(row, snapshotOf(row)) <= 0) fail(409, "Time is up for this encounter. End it to get your feedback.");
    const text = str((await body(c.req)).text, 2000);
    if (!text) fail(400, "Type a message first.");
    if (row.messages.length > MAX_TRANSCRIPT_CHARS) fail(409, TRANSCRIPT_FULL);
    return replyStream(c, row, text);
  })
  .post("/:id/orders", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    if (row.status !== "active") fail(409, "This encounter has ended.");
    if (row.messages.length > MAX_TRANSCRIPT_CHARS) fail(409, TRANSCRIPT_FULL);
    const b = await body(c.req);
    const snap = snapshotOf(row);
    const orders = parseJson<Order[]>(row.orders, []);
    const query = str(b.query, 200).trim();
    const test = b.testId ? snap.profile.tests.find((t) => t.id === b.testId) : findTest(snap.profile.tests, query);
    if (!test && !query) fail(400, "Choose a test.");
    if (!test && vagueOrder(query)) fail(400, "Name one exam or test, for example CBC or chest X-ray.");
    if (!test && severalOrders(query)) fail(400, "Order one exam or test at a time.");
    const t = Date.now() - row.started_at;
    // Asking again for the same test (or the same test this case doesn't have) returns the first result.
    const already = test ? orders.find((o) => o.testId === test.id) : orders.find((o) => !o.testId && sameOrder(o.name, query));
    if (already) return c.json({ order: already, repeated: true });
    const order: Order = test
      ? { testId: test.id, name: test.name, category: test.category, result: test.result, t }
      : { testId: "", name: query.charAt(0).toUpperCase() + query.slice(1), category: "Requested", result: "The case file doesn't include this exam or test.", t };
    const msgs = parseJson<Message[]>(row.messages, []);
    msgs.push({ role: "exam", text: `${order.name}: ${order.result}`, t, test: order.name });
    orders.push(order);
    await c.env.DB.prepare(`UPDATE encounters SET orders = ?, messages = ? WHERE id = ?`).bind(JSON.stringify(orders), JSON.stringify(msgs), row.id).run();
    return c.json({ order, message: msgs[msgs.length - 1] });
  })
  .patch("/:id", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    const b = await body(c.req);
    const notepad = typeof b.notepad === "string" ? b.notepad.slice(0, 20000) : row.notepad;
    const tasks = Array.isArray(b.tasksDone) ? b.tasksDone.map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n < 50) : parseJson<number[]>(row.tasks_done, []);
    await c.env.DB.prepare(`UPDATE encounters SET notepad = ?, tasks_done = ? WHERE id = ?`).bind(notepad, JSON.stringify(tasks), row.id).run();
    return c.json({ ok: true });
  })
  .post("/:id/end", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    if (row.status === "done") return c.json(toEncounter(row));
    if (row.status === "grading") fail(409, BEING_GRADED);
    const b = await body(c.req);
    const endedAt = row.ended_at ?? Date.now();
    const diagnosis = str(b.diagnosis, 500);
    const note = str(b.note, 15000);
    const prosody = cleanProsody(b.prosody);
    // Claim the encounter atomically so two simultaneous "End" requests never grade it twice.
    const claim = await c.env.DB.prepare(
      `UPDATE encounters SET status = 'grading', diagnosis = ?, note = ?, prosody = ?, ended_at = ? WHERE id = ? AND status = 'active'`,
    )
      .bind(diagnosis, note, prosody ? JSON.stringify(prosody) : null, endedAt, row.id)
      .run();
    if (!claim.meta.changes) {
      const latest = await loadEncounter(c.env, row.id);
      if (latest?.status === "done") return c.json(toEncounter(latest));
      fail(409, BEING_GRADED);
    }
    // Only fails if a "Get feedback now" slipped in right after the claim; that run grades it instead.
    if (!(await rateLimit(c.env, gradeLease(row.id), 1, GRADE_LEASE_SEC))) fail(409, BEING_GRADED);
    const updated: EncounterRow = { ...row, status: "grading", diagnosis, note, prosody: prosody ? JSON.stringify(prosody) : null, ended_at: endedAt };
    // If grading breaks unexpectedly, reopen the encounter so the student can end it again.
    const reopen = () => c.env.DB.prepare(`UPDATE encounters SET status = 'active' WHERE id = ? AND status = 'grading'`).bind(row.id).run();
    const feedback = await gradeAndSave(c, updated, reopen);
    return c.json(toEncounter({ ...updated, status: "done", feedback: JSON.stringify(feedback) }));
  })
  .post("/:id/grade", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    if (row.status === "active") fail(409, "End the encounter first.");
    // Never two runs at once: this also refuses while /end is still grading.
    if (!(await rateLimit(c.env, gradeLease(row.id), 1, GRADE_LEASE_SEC))) fail(409, BEING_GRADED);
    const feedback = await gradeAndSave(c, row);
    return c.json(toEncounter({ ...row, status: "done", feedback: JSON.stringify(feedback) }));
  })
  .post("/:id/tts", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    const b = await body<{ text?: unknown; emotion?: unknown }>(c.req);
    const text = str(b.text, 1500);
    if (!text) fail(400, "Nothing to say.");
    const keys = geminiKeys(c.env, await keysFor(c.env, u, row.course_id));
    if (!keys.length) fail(503, "Natural voice needs a Google AI key.");
    const p = snapshotOf(row).profile;
    const persona = personaOf(p);
    // The patient's line goes to Google; it never carries more of the student's name than their first name.
    const line = firstNameOnly(text, u.name);
    try {
      const upstream = await ttsStream(c.env, keys, deliveryPrompt(line, normalizeEmotion(str(b.emotion, 30) || "neutral"), persona), p.voice.liveVoice || "Sulafat", (x) => c.executionCtx.waitUntil(x));
      return new Response(upstream.body, { headers: { "content-type": "text/event-stream", "cache-control": "no-cache, no-transform" } });
    } catch {
      fail(503, "Natural voice is busy right now.");
    }
  })
  .post("/:id/live-token", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    if (row.status !== "active") fail(409, "This encounter has ended.");
    const keys = geminiKeys(c.env, await keysFor(c.env, u, row.course_id));
    if (!keys.length) fail(503, "Emotive voice needs a Google AI key.");
    const snap = snapshotOf(row);
    // Pseudonymity: the live model gets the student's first name only, also in the conversation so far.
    const history = pseudonymize(parseJson<Message[]>(row.messages, []), u.name);
    const system = actorSystemPrompt(snap.profile, snap.config, languageName(row.language), true, { history }, firstName(u.name));
    try {
      const t = await liveToken(c.env, keys, system, snap.profile.voice.liveVoice || "Kore", (p) => c.executionCtx.waitUntil(p));
      return c.json(t);
    } catch (err) {
      console.warn("live token failed", err);
      fail(503, "Emotive voice is busy right now. Switching to standard voice.");
    }
  })
  .post("/:id/transcript", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    // Only emotive voice talks to Google directly and reports its lines here; other modes are saved by the server.
    if (row.mode !== "emotive") fail(400, "Transcript lines can only be added to emotive voice encounters.");
    if (row.status !== "active") fail(409, "This encounter has ended.");
    if (row.messages.length > MAX_TRANSCRIPT_CHARS) fail(409, TRANSCRIPT_FULL);
    const b = await body<{ doctor?: unknown; patient?: unknown; emotion?: unknown }>(c.req);
    const t = Date.now() - row.started_at;
    const msgs = parseJson<Message[]>(row.messages, []);
    const doctor = str(b.doctor, 3000);
    const patient = str(b.patient, 3000);
    if (doctor) msgs.push({ role: "doctor", text: doctor, t: Math.max(0, t - 1500) });
    if (patient) msgs.push({ role: "patient", text: patient, t, emotion: normalizeEmotion(str(b.emotion, 30) || "neutral") });
    if (doctor || patient) await c.env.DB.prepare(`UPDATE encounters SET messages = ? WHERE id = ?`).bind(JSON.stringify(msgs), row.id).run();
    return c.json({ ok: true, count: msgs.length });
  })
  .post("/:id/stt", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    if (row.status !== "active") fail(409, "This encounter has ended.");
    const wav = await c.req.arrayBuffer();
    if (wav.byteLength < 1000) return c.json({ text: "" });
    if (wav.byteLength > 1_100_000) fail(400, "That recording is too long. Please speak in shorter turns.");
    const keys = geminiKeys(c.env, await keysFor(c.env, u, row.course_id));
    if (!keys.length) fail(503, "Speech recognition here needs a Google AI key. Please type instead.");
    try {
      return c.json({ text: await transcribe(c.env, keys, wav, languageName(row.language), (p) => c.executionCtx.waitUntil(p)) });
    } catch {
      fail(503, "Couldn't transcribe right now. Please try again or type.");
    }
  })
  .post("/:id/prosody-audio", async (c) => {
    const u = c.get("user");
    const row = await owned(c.env, u, c.req.param("id"));
    const wav = await c.req.arrayBuffer();
    if (wav.byteLength > 9_000_000) fail(400, "Recording too large.");
    // The recording holds only the student's own speech, so its length is their speaking time.
    const seconds = wavSeconds(wav);
    if (seconds < MIN_SPEECH_SEC) {
      const ai = { ...TOO_LITTLE_SPEECH };
      await c.env.DB.prepare(`UPDATE encounters SET prosody_ai = ? WHERE id = ?`).bind(JSON.stringify(ai), row.id).run();
      return c.json(ai);
    }
    const keys = geminiKeys(c.env, await keysFor(c.env, u, row.course_id));
    if (!keys.length) fail(503, "Voice analysis needs a Google AI key.");
    // Prefer the pace the browser measured (it is what the feedback page shows): sent as ?wpm=, or saved by
    // /end, which the browser sends right after starting this upload (so wait a few seconds for it). Otherwise:
    // the student's words over the recording's minutes. The browser keeps at most 4 minutes of audio, so a
    // full recording can't give a fair estimate.
    const sent = Number(c.req.query("wpm"));
    const given = sent >= 30 && sent <= 400;
    const reread = () => c.env.DB.prepare(`SELECT status, prosody, messages FROM encounters WHERE id = ?`).bind(row.id).first<{ status: string; prosody: string | null; messages: string }>();
    let latest = await reread();
    for (let i = 0; i < 3 && !given && latest?.status === "active" && !latest.prosody; i++) {
      await new Promise((r) => setTimeout(r, 1000));
      latest = await reread();
    }
    const shown = given ? sent : (parseJson<ProsodyMetrics | null>(latest?.prosody ?? row.prosody, null)?.wordsPerMinute ?? 0);
    const words = parseJson<Message[]>(latest?.messages ?? row.messages, [])
      .filter((m) => m.role === "doctor")
      .reduce((n, m) => n + m.text.split(/\s+/).filter(Boolean).length, 0);
    const wpm = shown > 0 ? Math.round(shown) : seconds < 235 && words > 0 ? Math.round(words / (seconds / 60)) : null;
    try {
      const ai = await analyzeVoice(c.env, keys, wav, { seconds, wpm }, (p) => c.executionCtx.waitUntil(p));
      await c.env.DB.prepare(`UPDATE encounters SET prosody_ai = ? WHERE id = ?`).bind(JSON.stringify(ai), row.id).run();
      return c.json(ai);
    } catch (err) {
      console.warn("voice analysis failed", err);
      fail(503, "Voice analysis is unavailable right now.");
    }
  })
  .post("/:id/comments", async (c) => {
    const u = c.get("user");
    const { row, owner } = await access(c.env, u, c.req.param("id"));
    if (owner && u.role === "student") fail(403, "Only instructors can comment.");
    const b = await body(c.req);
    const text = str(b.body, 2000);
    // A comment on a line that doesn't exist becomes a general comment (-1).
    const n = Number(b.messageIdx);
    const idx = Number.isInteger(n) && n >= 0 && n < parseJson<Message[]>(row.messages, []).length ? n : -1;
    if (!text) fail(400, "Write a comment first.");
    const id = newId();
    const now = Date.now();
    await c.env.DB.batch([
      c.env.DB.prepare(`INSERT INTO comments (id, encounter_id, message_idx, author_id, body, created_at) VALUES (?, ?, ?, ?, ?, ?)`).bind(id, row.id, idx, u.id, text, now),
      // No notice for comments on your own encounter (an educator's test run).
      ...(owner
        ? []
        : [
            c.env.DB.prepare(`INSERT INTO notifications (id, user_id, kind, ref_id, body, created_at) VALUES (?, ?, 'comment', ?, ?, ?)`).bind(
              newId(),
              row.user_id,
              row.id,
              `${u.name} commented on your encounter "${snapshotOf(row).caseName}"`,
              now,
            ),
          ]),
    ]);
    return c.json({ id, messageIdx: idx, authorName: u.name, body: text, createdAt: now } satisfies Comment);
  });
