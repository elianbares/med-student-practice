import { Hono } from "hono";
import type { AppEnv } from "../env";
import { requireAdmin, requireEducator, requireUser } from "../auth";
import { validKeyInput } from "../access";
import { deleteAccount, exportAccount } from "../account";
import { encryptText } from "../crypto";
import { getSecrets, setSetting } from "../db";
import { body, fail } from "../util";
import { aiStatus } from "../ai/router";
import { capacityInfo, demoCourseOpen } from "./courses";

export const meRoutes = new Hono<AppEnv>()
  .use("*", requireUser)
  // Privacy: download everything stored about me, or delete my account and data (see account.ts).
  .get("/export", (c) => exportAccount(c))
  .delete("/", (c) => deleteAccount(c))
  .put("/ai-key", async (c) => {
    const b = await body(c.req);
    const k = validKeyInput(b.provider, b.key);
    if (!k) fail(400, "That doesn't look like a valid key. Copy the whole key from Google AI Studio (it starts with AIza or AQ.); Groq keys start with gsk_.");
    await c.env.DB.prepare(`UPDATE users SET ai_key_enc = ? WHERE id = ?`)
      .bind(await encryptText(JSON.stringify(k), (await getSecrets(c.env)).encKey), c.get("user").id)
      .run();
    return c.json({ hasOwnKey: true });
  })
  .delete("/ai-key", async (c) => {
    await c.env.DB.prepare(`UPDATE users SET ai_key_enc = NULL WHERE id = ?`).bind(c.get("user").id).run();
    return c.json({ hasOwnKey: false });
  })
  .get("/notifications", async (c) => {
    const rows = await c.env.DB.prepare(
      `SELECT id, kind, ref_id AS refId, body, read, created_at AS createdAt FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 30`,
    )
      .bind(c.get("user").id)
      .all();
    return c.json(rows.results);
  })
  .post("/notifications/read", async (c) => {
    await c.env.DB.prepare(`UPDATE notifications SET read = 1 WHERE user_id = ?`).bind(c.get("user").id).run();
    return c.json({ ok: true });
  });

export const adminRoutes = new Hono<AppEnv>()
  .use("*", requireUser)
  // Educators see capacity too, in their course settings.
  .get("/capacity", requireEducator, async (c) => c.json(await capacityInfo(c.env)))
  // Every route below is for admins only, including any added later.
  .use("*", requireAdmin)
  .put("/settings", async (c) => {
    const b = await body(c.req);
    if (b.demoCourseOpen !== undefined) {
      if (typeof b.demoCourseOpen !== "boolean") fail(400, "demoCourseOpen must be true or false.");
      await setSetting(c.env, "demo_course_open", b.demoCourseOpen ? "1" : "0");
    }
    return c.json({ demoCourseOpen: await demoCourseOpen(c.env) });
  })
  .get("/status", async (c) => {
    const env = c.env;
    const since = new Date(Date.now() - 7 * 86400_000).toISOString().slice(0, 10);
    const [usage, counts] = await env.DB.batch([
      env.DB.prepare(`SELECT * FROM usage WHERE day >= ? ORDER BY day DESC, provider, model`).bind(since),
      env.DB.prepare(
        `SELECT (SELECT COUNT(*) FROM users) AS users, (SELECT COUNT(*) FROM users WHERE role != 'student') AS educators,
           (SELECT COUNT(*) FROM encounters) AS encounters, (SELECT COUNT(*) FROM courses) AS courses`,
      ),
    ]);
    let geminiModels: string[] | string = "No platform Google key set.";
    if (env.GEMINI_API_KEY) {
      try {
        const res = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", { headers: { "x-goog-api-key": env.GEMINI_API_KEY } });
        const data = (await res.json()) as { models?: { name: string; supportedGenerationMethods?: string[] }[]; error?: { message: string } };
        geminiModels = data.error
          ? `Key error: ${data.error.message}`
          : (data.models ?? []).filter((m) => m.supportedGenerationMethods?.includes("generateContent")).map((m) => m.name.replace(/^models\//, ""));
      } catch (err) {
        geminiModels = `Could not reach Google: ${(err as Error).message}`;
      }
    }
    return c.json({
      ai: aiStatus(env),
      configured: {
        gemini: Boolean(env.GEMINI_API_KEY),
        groq: Boolean(env.GROQ_API_KEY),
        workersAi: Boolean(env.AI),
        educatorKey: Boolean(env.EDUCATOR_ACCESS_KEY),
        actorModels: env.GEMINI_ACTOR_MODELS,
        graderModels: env.GEMINI_GRADER_MODELS,
      },
      geminiModels,
      usage: usage.results,
      counts: counts.results[0],
    });
  });
