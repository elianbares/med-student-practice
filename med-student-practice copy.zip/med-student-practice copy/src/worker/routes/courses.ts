import { Hono } from "hono";
import { HTTPException } from "hono/http-exception";
import type { AppEnv, DbUser, Env } from "../env";
import type { Assignment, CapacityInfo, Course } from "../../shared/types";
import { lookOf, normalizeConfig, normalizeProfile, patientLabel } from "../../shared/defaults";
import { requireEducator, requireUser } from "../auth";
import { canSee, courseRole, keysFor, validKeyInput } from "../access";
import { encryptText, newCourseCode, newId, newResetCode, sha256Hex } from "../crypto";
import { getSecrets, getSetting } from "../db";
import { rateLimit } from "../limits";
import { DEMO_COURSE_CODE } from "../seed";
import { body, fail, parseJson, str, today } from "../util";
import { complete, targetsFor } from "../ai/router";
import { DAILY_POOL_LIMIT, SUMMARY_SQL, summaryOf, type SummaryRow } from "./encounters";

/** The public demo course created by seed.ts. Admins can close it (setting "demo_course_open" = "0"). */
const DEMO_COURSE_ID = "seed-course-demo";
const NAME_MAX = 120;
const DESCRIPTION_MAX = 2000;
const RETENTION_MAX_DAYS = 3650;

interface CourseRow {
  id: string;
  owner_id: string;
  name: string;
  description: string;
  banner: string;
  code: string;
  enrollment_open: number;
  archived: number;
  ai_key_enc: string | null;
  retention_days?: number;
  student_count?: number;
  case_count?: number;
}

/** retentionDays: days encounters are kept (0 = keep), shown to staff only. */
type CourseOut = Course & { retentionDays?: number };

const toCourse = (r: CourseRow, staff: boolean): CourseOut => ({
  id: r.id,
  name: r.name,
  description: r.description,
  banner: r.banner,
  code: staff ? r.code : "",
  enrollmentOpen: r.enrollment_open === 1,
  archived: r.archived === 1,
  hasKey: staff ? Boolean(r.ai_key_enc) : undefined,
  studentCount: r.student_count,
  caseCount: r.case_count,
  retentionDays: staff ? (r.retention_days ?? 0) : undefined,
});

/** Course names are required and at most 120 characters; nothing is silently cut or kept. */
function courseName(v: unknown): string {
  const name = typeof v === "string" ? v.trim() : "";
  if (!name) fail(400, "Give the course a name.");
  if (name.length > NAME_MAX) fail(400, `Course names can be at most ${NAME_MAX} characters (this one has ${name.length}).`);
  return name;
}

function courseDescription(v: unknown): string {
  const text = typeof v === "string" ? v.trim() : "";
  if (text.length > DESCRIPTION_MAX) fail(400, `Course descriptions can be at most ${DESCRIPTION_MAX} characters (this one has ${text.length}).`);
  return text;
}

function retentionDays(v: unknown): number {
  const n = typeof v === "string" && v.trim() ? Number(v) : v;
  if (typeof n !== "number" || !Number.isInteger(n) || n < 0 || n > RETENTION_MAX_DAYS) {
    fail(400, `Set how long to keep encounters as a whole number of days from 1 to ${RETENTION_MAX_DAYS}, or 0 to keep them.`);
  }
  return n;
}

const isDemo = (r: Pick<CourseRow, "id" | "code">) => r.id === DEMO_COURSE_ID || r.code === DEMO_COURSE_CODE;
export const demoCourseOpen = async (env: Env) => (await getSetting(env, "demo_course_open", "1")) !== "0";

const COUNTS = `(SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id) AS student_count,
  (SELECT COUNT(*) FROM assignments a WHERE a.course_id = c.id) AS case_count`;

async function staffCourse(env: Env, user: DbUser, id: string): Promise<CourseRow> {
  if ((await courseRole(env, user, id)) !== "staff") fail(404, "Course not found.");
  return (await env.DB.prepare(`SELECT c.*, ${COUNTS} FROM courses c WHERE c.id = ?`).bind(id).first<CourseRow>())!;
}

async function uniqueCode(env: Env): Promise<string> {
  for (let i = 0; i < 8; i++) {
    const code = newCourseCode();
    if (!(await env.DB.prepare(`SELECT 1 FROM courses WHERE code = ?`).bind(code).first())) return code;
  }
  fail(500, "Could not create a course code. Please try again.");
}

async function assignments(env: Env, courseId: string, userId?: string): Promise<Assignment[]> {
  const rows = await env.DB.prepare(
    `SELECT a.id, a.course_id, a.case_id, a.config_id, c.name AS case_name, c.description, cf.name AS config_name, cf.data AS config, p.data AS profile,
       ${userId ? `(SELECT COUNT(*) FROM encounters e WHERE e.assignment_id = a.id AND e.user_id = ?)` : "0"} AS attempts
     FROM assignments a JOIN cases c ON c.id = a.case_id JOIN configurations cf ON cf.id = a.config_id JOIN profiles p ON p.id = c.profile_id
     WHERE a.course_id = ? ORDER BY a.position, a.created_at`,
  )
    .bind(...(userId ? [userId, courseId] : [courseId]))
    .all<{ id: string; course_id: string; case_id: string; config_id: string; case_name: string; description: string; config_name: string; config: string; profile: string; attempts: number }>();
  return rows.results.map((r) => {
    const p = normalizeProfile(parseJson(r.profile, {}));
    return {
      id: r.id,
      courseId: r.course_id,
      caseId: r.case_id,
      configId: r.config_id,
      caseName: r.case_name,
      caseDescription: r.description,
      configName: r.config_name,
      chiefComplaint: p.chiefComplaint,
      patientLabel: patientLabel(p),
      attempts: r.attempts,
      look: lookOf(p),
      diagnosisType: normalizeConfig(parseJson(r.config, {})).diagnosisType,
    };
  });
}

export const courseRoutes = new Hono<AppEnv>()
  .use("*", requireUser)
  .get("/", async (c) => {
    const u = c.get("user");
    const educator = u.role !== "student";
    const sql = educator
      ? `SELECT c.*, ${COUNTS} FROM courses c WHERE c.owner_id = ? OR c.id IN (SELECT course_id FROM course_staff WHERE user_id = ?)
           ${u.role === "admin" ? "OR c.owner_id = 'system'" : ""} ORDER BY c.archived, c.created_at DESC`
      : `SELECT c.*, ${COUNTS} FROM courses c JOIN enrollments e ON e.course_id = c.id WHERE e.user_id = ? ORDER BY e.joined_at DESC`;
    const rows = await c.env.DB.prepare(sql)
      .bind(...(educator ? [u.id, u.id] : [u.id]))
      .all<CourseRow>();
    return c.json(rows.results.map((r) => toCourse(r, educator)));
  })
  .post("/enroll", async (c) => {
    const u = c.get("user");
    const code = str((await body(c.req)).code, 12).toUpperCase().replace(/[^A-Z0-9]/g, "");
    const course = code ? await c.env.DB.prepare(`SELECT * FROM courses WHERE code = ?`).bind(code).first<CourseRow>() : null;
    // Opening a course you are already in is not a join attempt, so it never counts against the limit.
    if (course && (await c.env.DB.prepare(`SELECT 1 FROM enrollments WHERE course_id = ? AND user_id = ?`).bind(course.id, u.id).first())) {
      return c.json({ id: course.id, name: course.name });
    }
    if (!(await rateLimit(c.env, `enroll:user:${u.id}`, 20, 3600))) {
      // Retry-After (set by the error handler from `cause`) is the longest wait; the client won't auto-retry it.
      throw new HTTPException(429, { message: "Too many attempts to join a course. Please wait an hour and try again.", cause: { retryAfter: 3600 } });
    }
    if (!course) fail(404, "No course has that code. Check the code with your instructor.");
    if (isDemo(course) && !(await demoCourseOpen(c.env))) fail(403, "The demo course is closed.");
    if (!course.enrollment_open || course.archived) fail(403, "Enrollment for this course is closed.");
    await c.env.DB.prepare(`INSERT OR IGNORE INTO enrollments (course_id, user_id, joined_at) VALUES (?, ?, ?)`).bind(course.id, u.id, Date.now()).run();
    return c.json({ id: course.id, name: course.name });
  })
  .post("/", requireEducator, async (c) => {
    const u = c.get("user");
    const b = await body(c.req);
    const name = courseName(b.name);
    const description = courseDescription(b.description);
    const id = newId();
    await c.env.DB.prepare(`INSERT INTO courses (id, owner_id, name, description, banner, code, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`)
      .bind(id, u.id, name, description, str(b.banner, 150_000), await uniqueCode(c.env), Date.now())
      .run();
    return c.json(toCourse(await staffCourse(c.env, u, id), true));
  })
  .get("/:id", async (c) => {
    const u = c.get("user");
    const id = c.req.param("id");
    const role = await courseRole(c.env, u, id);
    if (!role) fail(404, "Course not found.");
    const row = (await c.env.DB.prepare(`SELECT c.*, ${COUNTS} FROM courses c WHERE c.id = ?`).bind(id).first<CourseRow>())!;
    return c.json({ course: toCourse(row, role === "staff"), role, assignments: await assignments(c.env, id, role === "student" ? u.id : undefined) });
  })
  .on(["PUT", "PATCH"], "/:id", requireEducator, async (c) => {
    // Fields left out keep their value; a name that is sent must be valid.
    const u = c.get("user");
    const row = await staffCourse(c.env, u, c.req.param("id"));
    const b = await body(c.req);
    const name = b.name === undefined ? row.name : courseName(b.name);
    const description = typeof b.description === "string" ? courseDescription(b.description) : row.description;
    const retention = b.retentionDays === undefined ? (row.retention_days ?? 0) : retentionDays(b.retentionDays);
    await c.env.DB.prepare(`UPDATE courses SET name = ?, description = ?, banner = ?, retention_days = ? WHERE id = ?`)
      .bind(name, description, typeof b.banner === "string" ? str(b.banner, 150_000) : row.banner, retention, row.id)
      .run();
    return c.json(toCourse(await staffCourse(c.env, u, row.id), true));
  })
  .delete("/:id", requireEducator, async (c) => {
    // Students keep their encounters in their own history; only the link to the course goes.
    const u = c.get("user");
    const row = await staffCourse(c.env, u, c.req.param("id"));
    if (row.owner_id !== u.id && u.role !== "admin") fail(403, "Only the course owner can delete it.");
    if (isDemo(row)) fail(409, "The demo course can't be deleted. An admin can close it instead.");
    if (!row.archived) fail(409, "Archive the course first.");
    const db = c.env.DB;
    await db.batch([
      db.prepare(`UPDATE encounters SET course_id = NULL, assignment_id = NULL WHERE course_id = ?`).bind(row.id),
      db.prepare(`DELETE FROM assignments WHERE course_id = ?`).bind(row.id),
      db.prepare(`DELETE FROM enrollments WHERE course_id = ?`).bind(row.id),
      db.prepare(`DELETE FROM course_staff WHERE course_id = ?`).bind(row.id),
      db.prepare(`DELETE FROM courses WHERE id = ?`).bind(row.id),
    ]);
    return c.json({ ok: true });
  })
  .post("/:id/toggle-enrollment", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    await c.env.DB.prepare(`UPDATE courses SET enrollment_open = ? WHERE id = ?`).bind(row.enrollment_open ? 0 : 1, row.id).run();
    return c.json({ enrollmentOpen: !row.enrollment_open });
  })
  .post("/:id/archive", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    await c.env.DB.prepare(`UPDATE courses SET archived = ? WHERE id = ?`).bind(row.archived ? 0 : 1, row.id).run();
    return c.json({ archived: !row.archived });
  })
  .post("/:id/code", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    // Sign-up joins the demo course by this code, and its description names it.
    if (isDemo(row)) fail(409, `The demo course keeps the code ${DEMO_COURSE_CODE}. An admin can close it instead.`);
    const code = await uniqueCode(c.env);
    await c.env.DB.prepare(`UPDATE courses SET code = ? WHERE id = ?`).bind(code, row.id).run();
    return c.json({ code });
  })
  .post("/:id/leave", async (c) => {
    await c.env.DB.prepare(`DELETE FROM enrollments WHERE course_id = ? AND user_id = ?`).bind(c.req.param("id"), c.get("user").id).run();
    return c.json({ ok: true });
  })
  .post("/:id/assignments", requireEducator, async (c) => {
    const u = c.get("user");
    const row = await staffCourse(c.env, u, c.req.param("id"));
    const b = await body(c.req);
    const caseId = str(b.caseId, 40);
    const configId = str(b.configId, 40);
    const kase = await c.env.DB.prepare(`SELECT owner_id, is_public FROM cases WHERE id = ?`).bind(caseId).first<{ owner_id: string; is_public: number }>();
    if (!kase || !canSee(u, kase)) fail(400, "Choose a case from your library.");
    if (!(await c.env.DB.prepare(`SELECT 1 FROM case_configs WHERE case_id = ? AND config_id = ?`).bind(caseId, configId).first())) {
      fail(400, "Choose one of this case's configurations.");
    }
    // One statement, so two quick clicks can't add the same pair twice.
    const added = await c.env.DB.prepare(
      `INSERT INTO assignments (id, course_id, case_id, config_id, position, created_at)
       SELECT ?1, ?2, ?3, ?4, (SELECT COALESCE(MAX(position), -1) + 1 FROM assignments WHERE course_id = ?2), ?5
       WHERE NOT EXISTS (SELECT 1 FROM assignments WHERE course_id = ?2 AND case_id = ?3 AND config_id = ?4)`,
    )
      .bind(newId(), row.id, caseId, configId, Date.now())
      .run();
    if (!added.meta.changes) fail(409, "That case and configuration are already in this course.");
    return c.json(await assignments(c.env, row.id));
  })
  .delete("/:id/assignments/:aid", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    await c.env.DB.prepare(`DELETE FROM assignments WHERE id = ? AND course_id = ?`).bind(c.req.param("aid"), row.id).run();
    return c.json(await assignments(c.env, row.id));
  })
  .get("/:id/roster", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    const rows = await c.env.DB.prepare(
      `SELECT u.id, u.name, u.email, e.joined_at AS joinedAt,
         (SELECT COUNT(*) FROM encounters x WHERE x.user_id = u.id AND x.course_id = e.course_id) AS encounters,
         (SELECT MAX(started_at) FROM encounters x WHERE x.user_id = u.id AND x.course_id = e.course_id) AS lastActive
       FROM enrollments e JOIN users u ON u.id = e.user_id WHERE e.course_id = ? ORDER BY u.name`,
    )
      .bind(row.id)
      .all();
    return c.json(rows.results);
  })
  .delete("/:id/roster/:uid", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    await c.env.DB.prepare(`DELETE FROM enrollments WHERE course_id = ? AND user_id = ?`).bind(row.id, c.req.param("uid")).run();
    return c.json({ ok: true });
  })
  .post("/:id/roster/:uid/reset-code", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    const uid = c.req.param("uid");
    const student = await c.env.DB.prepare(`SELECT u.role FROM enrollments e JOIN users u ON u.id = e.user_id WHERE e.course_id = ? AND e.user_id = ?`)
      .bind(row.id, uid)
      .first<{ role: string }>();
    if (!student || student.role !== "student") fail(404, "Student not found in this course.");
    const code = newResetCode();
    const expiresAt = Date.now() + 24 * 3600_000;
    await c.env.DB.prepare(`INSERT INTO reset_codes (code_hash, user_id, expires_at) VALUES (?, ?, ?)`).bind(await sha256Hex(`reset:${code}`), uid, expiresAt).run();
    return c.json({ code, expiresAt });
  })
  .get("/:id/encounters", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    const rows = await c.env.DB.prepare(
      `SELECT ${SUMMARY_SQL}, u.name AS student_name, u.email AS student_email FROM encounters e JOIN users u ON u.id = e.user_id
       WHERE e.course_id = ? ORDER BY e.started_at DESC LIMIT 1000`,
    )
      .bind(row.id)
      .all<SummaryRow>();
    return c.json(rows.results.map(summaryOf));
  })
  .put("/:id/ai-key", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    const b = await body(c.req);
    const k = validKeyInput(b.provider, b.key);
    if (!k) fail(400, "That doesn't look like a valid key. Copy the whole key from Google AI Studio (it starts with AIza or AQ.); Groq keys start with gsk_.");
    await c.env.DB.prepare(`UPDATE courses SET ai_key_enc = ? WHERE id = ?`).bind(await encryptText(JSON.stringify(k), (await getSecrets(c.env)).encKey), row.id).run();
    return c.json({ hasKey: true });
  })
  .delete("/:id/ai-key", requireEducator, async (c) => {
    const row = await staffCourse(c.env, c.get("user"), c.req.param("id"));
    await c.env.DB.prepare(`UPDATE courses SET ai_key_enc = NULL WHERE id = ?`).bind(row.id).run();
    return c.json({ hasKey: false });
  })
  .post("/:id/ai-key/test", requireEducator, async (c) => {
    const u = c.get("user");
    const row = await staffCourse(c.env, u, c.req.param("id"));
    return c.json(await testCourseKey(c.env, row));
  });

async function testCourseKey(env: Env, row: CourseRow) {
  const keys = (await keysFor(env, { id: "", email: "", name: "", role: "educator", ai_key_enc: null }, row.id)).filter((k) => k.source === "course");
  if (!keys.length) return { ok: false, message: "No course key saved." };
  const targets = targetsFor({ ...env, GEMINI_API_KEY: undefined, GROQ_API_KEY: undefined, AI: undefined, AI_MODE: "real" }, "actor", keys);
  try {
    const { target } = await complete(env, targets, { task: "judge", system: "Reply with the single word OK.", messages: [{ role: "user", content: "Say OK." }], maxTokens: 20, mock: () => "OK" });
    return { ok: true, message: `Key works (${target.model}).` };
  } catch (err) {
    return { ok: false, message: `The key did not work: ${(err as Error).message.slice(0, 200)}` };
  }
}

// ---------- capacity ----------

/** Usage-table task names (router.ts and audio.ts) in plain words, singular and plural. */
const TASK_LABEL: Record<string, [string, string]> = {
  actor: ["patient reply", "patient replies"],
  grader: ["feedback report", "feedback reports"],
  assistant: ["profile draft", "profile drafts"],
  judge: ["key test", "key tests"],
  tts: ["natural voice clip", "natural voice clips"],
  stt: ["transcription", "transcriptions"],
  live: ["emotive voice session", "emotive voice sessions"],
  prosody: ["voice analysis", "voice analyses"],
};

/** What the current AI setup can handle, in plain words, for Admin and course settings. All numbers are estimates. */
export async function capacityInfo(env: Env): Promise<CapacityInfo> {
  const db = env.DB;
  const [keyRows, usageRows] = await db.batch([
    db.prepare(
      `SELECT (SELECT COUNT(*) FROM courses WHERE ai_key_enc IS NOT NULL AND archived = 0) AS courses,
         (SELECT COUNT(*) FROM users WHERE ai_key_enc IS NOT NULL AND role = 'student') AS students`,
    ),
    db.prepare(`SELECT task, SUM(requests) AS requests, SUM(errors) AS errors FROM usage WHERE day = ? GROUP BY task ORDER BY SUM(requests) DESC`).bind(today()),
  ]);
  const counts = (keyRows.results[0] ?? { courses: 0, students: 0 }) as { courses: number; students: number };
  const usage = usageRows.results as { task: string; requests: number; errors: number }[];
  const keys = { platform: Boolean(env.GEMINI_API_KEY), courses: counts.courses, students: counts.students };
  // In the order the router tries them after Google (see targetsFor).
  const overflow = [...(env.GROQ_API_KEY ? ["groq"] : []), ...(env.AI ? ["workers-ai"] : [])];
  const demoOpen = await demoCourseOpen(env);
  const n = (count: number, word: string) => `${count} ${word}${count === 1 ? "" : "s"}`;

  const guidance: string[] = [];
  guidance.push(
    keys.platform
      ? "One free Google key comfortably supports roughly 10 to 15 students practicing at the same time, and a few hundred patient replies a day before Google's free daily limits are reached. These are estimates: Google sets the limits and changes them from time to time."
      : "No platform Google key is set, so students need a course key or their own key to talk to a real AI patient.",
  );
  if (keys.courses || keys.students) {
    guidance.push(`${n(keys.courses, "course key")} and ${n(keys.students, "student key")} add their own quota on top, because each Google key has separate limits.`);
  }
  guidance.push(
    "For a live lab of 100 students, either have each student add their own free key in Settings (each key brings its own quota), or add a paid Google key to the course. On a paid key, Flash-Lite costs roughly one to three cents per encounter.",
  );
  const names = overflow.map((p) => (p === "workers-ai" ? "Cloudflare Workers AI" : "Groq"));
  guidance.push(
    `When a model reaches its limit, the next one takes over: other Gemini and Gemma models${names.length ? `, then ${names.join(" and ")}` : ""}. If all of them are busy, students see a clear "busy, try again in a minute" message and nothing they typed is lost.`,
  );
  if (!names.length) guidance.push("Adding a free Groq key, or turning on Cloudflare Workers AI for the site, gives extra room when Google is busy.");
  guidance.push(`Students without their own key or a course key can start up to ${DAILY_POOL_LIMIT} encounters a day on the shared key, so one student can't use up everyone's quota.`);
  guidance.push("Natural and emotive voice use Google's much smaller audio allowances. On one free key, plan for only a few students in voice modes at the same time; course or student keys raise this.");
  guidance.push(
    demoOpen
      ? "The public demo course is open, so anyone who signs up can practice on the shared key. An admin can close it while you run a class."
      : "The public demo course is closed to new students.",
  );
  const done = usage.reduce((a, u) => a + u.requests, 0);
  const failed = usage.reduce((a, u) => a + u.errors, 0);
  if (done || failed) {
    const parts = usage.filter((u) => TASK_LABEL[u.task] && u.requests).map((u) => `${u.requests} ${TASK_LABEL[u.task][u.requests === 1 ? 0 : 1]}`);
    guidance.push(`So far today (UTC): ${parts.length ? parts.join(", ") : n(done, "AI request")}.`);
    if (failed > 0.2 * (done + failed)) {
      guidance.push(`${failed} of ${done + failed} AI requests failed today, which usually means the free limits are nearly used up. A course key or student keys will help.`);
    }
  }

  return {
    keys,
    today: usage.map((u) => ({ task: u.task, requests: u.requests, errors: u.errors })),
    guidance,
    demoCourseOpen: demoOpen,
    overflow,
  };
}
