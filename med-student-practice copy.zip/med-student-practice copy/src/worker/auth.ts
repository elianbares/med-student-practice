import { Hono, type Context, type MiddlewareHandler } from "hono";
import { getCookie, setCookie, deleteCookie } from "hono/cookie";
import type { AppEnv, DbUser, Env } from "./env";
import type { Role, User } from "../shared/types";
import { getSecrets, getSetting } from "./db";
import { hashClientHash, newId, randomHex, safeEqual, sha256Hex, signToken, verifyToken } from "./crypto";
import { clearLimit, clientIp, ipKey, overLimit, rateLimit, recordFailures } from "./limits";
import { DEMO_COURSE_CODE } from "./seed";
import { body, fail, str } from "./util";
import { aiStatus } from "./ai/router";

const COOKIE = "apa_session";
const SESSION_DAYS = 30;
const HEX64 = /^[0-9a-f]{64}$/;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const FIFTEEN_MIN = 900;
const HOUR = 3600;
const SIGNIN_LIMIT = "Too many sign-in attempts. Wait 15 minutes or reset your password.";
const SIGNUP_LIMIT = "Too many sign-ups from this network. Try again in an hour.";
// Sign-ups per network per hour. A class signs up together from one campus address, so a valid course
// code gets its own allowance. Wrong codes are capped like course joins, so sign-up is no faster way to guess codes.
const OPEN_SIGNUPS = 5;
const CLASS_SIGNUPS = 200;
const WRONG_CODES = 20;

interface SessionPayload {
  uid: string;
  exp: number;
  /** users.session_version when the token was issued; bumping the column ends the session. */
  v?: number;
}

export function publicUser(u: DbUser): User {
  return { id: u.id, email: u.email, name: u.name, role: u.role, hasOwnKey: Boolean(u.ai_key_enc) };
}

async function startSession(c: Context<AppEnv>, userId: string, version: number) {
  const { sessionSecret } = await getSecrets(c.env);
  const exp = Date.now() + SESSION_DAYS * 86400_000;
  const token = await signToken({ uid: userId, exp, v: version } satisfies SessionPayload, sessionSecret);
  setCookie(c, COOKIE, token, {
    httpOnly: true,
    secure: new URL(c.req.url).protocol === "https:",
    sameSite: "Lax",
    path: "/",
    maxAge: SESSION_DAYS * 86400,
  });
}

/** Removes the session cookie from this browser. Server-side revocation is a session_version bump. */
export function clearSessionCookie(c: Context<AppEnv>) {
  deleteCookie(c, COOKIE, { path: "/" });
}

async function currentUser(c: Context<AppEnv>): Promise<DbUser | null> {
  const token = getCookie(c, COOKIE);
  if (!token) return null;
  const { sessionSecret } = await getSecrets(c.env);
  const payload = await verifyToken<SessionPayload>(token, sessionSecret);
  if (!payload || payload.exp < Date.now()) return null;
  const user = await c.env.DB.prepare(`SELECT id, email, name, role, ai_key_enc, session_version FROM users WHERE id = ?`)
    .bind(payload.uid)
    .first<DbUser & { session_version: number }>();
  // Tokens from before session versions existed carry no v and count as version 0.
  if (!user || user.session_version !== (payload.v ?? 0)) return null;
  return user;
}

export const requireUser: MiddlewareHandler<AppEnv> = async (c, next) => {
  const user = await currentUser(c);
  if (!user) fail(401, "Please sign in.");
  c.set("user", user);
  await next();
};

export const requireEducator: MiddlewareHandler<AppEnv> = async (c, next) => {
  const role = c.get("user").role;
  if (role !== "educator" && role !== "admin") fail(403, "Educator account required.");
  await next();
};

export const requireAdmin: MiddlewareHandler<AppEnv> = async (c, next) => {
  if (c.get("user").role !== "admin") fail(403, "Admin account required.");
  await next();
};

function adminEmails(env: Env): string[] {
  return (env.ADMIN_EMAILS ?? "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

function allowedDomains(env: Env): string[] {
  return (env.ALLOWED_EMAIL_DOMAINS ?? "")
    .split(",")
    .map((d) => d.trim().toLowerCase().replace(/^@/, ""))
    .filter(Boolean);
}

/** True when sign-ups are open to this address. Subdomains count (student.uni.edu matches uni.edu). */
function domainAllowed(env: Env, email: string): boolean {
  const list = allowedDomains(env);
  if (!list.length || adminEmails(env).includes(email)) return true;
  const domain = email.slice(email.lastIndexOf("@") + 1);
  return list.some((d) => domain === d || domain.endsWith(`.${d}`));
}

function domainMessage(env: Env): string {
  const list = allowedDomains(env);
  const names = list.length > 1 ? `${list.slice(0, -1).join(", ")} or ${list[list.length - 1]}` : list[0];
  return `Sign-ups here are limited to ${names} email addresses.`;
}

/** Cloudflare Turnstile check, only when TURNSTILE_SECRET is set. */
async function turnstileOk(c: Context<AppEnv>, token: string): Promise<boolean> {
  if (!token) return false;
  const form = new FormData();
  form.append("secret", c.env.TURNSTILE_SECRET!);
  form.append("response", token);
  const ip = clientIp(c);
  if (ip !== "local") form.append("remoteip", ip);
  try {
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body: form,
      signal: AbortSignal.timeout(8000),
    });
    return ((await res.json()) as { success?: boolean }).success === true;
  } catch {
    return false;
  }
}

/** The open, unarchived course with this join code. The demo course counts only while an admin keeps it open. */
async function openCourseId(env: Env, code: string): Promise<string | null> {
  if (!code || (code === DEMO_COURSE_CODE && (await getSetting(env, "demo_course_open", "1")) === "0")) return null;
  const row = await env.DB.prepare(`SELECT id FROM courses WHERE code = ? AND enrollment_open = 1 AND archived = 0`).bind(code).first<{ id: string }>();
  return row?.id ?? null;
}

/**
 * Counts a sign-up against its network's hourly allowance (one upsert per check). `classCourse` is the course a
 * valid join code named; `wrongCode` is true when a code was given that names no open course.
 */
async function checkSignupLimit(c: Context<AppEnv>, classCourse: string | null, wrongCode: boolean): Promise<void> {
  const codeKey = ipKey(c, "signup-code");
  if (!codeKey) return; // local dev, see ipKey
  if (classCourse) {
    // Past the wrong-code cap even a right code is refused, so guesses stay capped at WRONG_CODES an hour.
    if (await overLimit(c.env, [{ key: codeKey, max: WRONG_CODES }], HOUR)) fail(429, SIGNUP_LIMIT);
    if (!(await rateLimit(c.env, ipKey(c, `signup:course:${classCourse}`)!, CLASS_SIGNUPS, HOUR))) fail(429, SIGNUP_LIMIT);
    return;
  }
  if (wrongCode && !(await rateLimit(c.env, codeKey, WRONG_CODES, HOUR))) fail(429, SIGNUP_LIMIT);
  if (!(await rateLimit(c.env, ipKey(c, "signup")!, OPEN_SIGNUPS, HOUR))) fail(429, SIGNUP_LIMIT);
}

/**
 * Checks the signed-in user's password (the same client hash sign-in sends) before account changes.
 * Wrong answers are throttled per user and answered with 403, so the client keeps the session.
 */
export async function confirmPassword(env: Env, userId: string, clientHash: string): Promise<void> {
  const key = `password:user:${userId}`;
  if (await overLimit(env, [{ key, max: 10 }], FIFTEEN_MIN)) fail(429, "Too many attempts. Wait 15 minutes and try again.");
  const row = await env.DB.prepare(`SELECT pw_salt, pw_hash FROM users WHERE id = ?`).bind(userId).first<{ pw_salt: string; pw_hash: string }>();
  if (!row || !HEX64.test(clientHash) || !safeEqual(await hashClientHash(clientHash, row.pw_salt), row.pw_hash)) {
    await recordFailures(env, [key], FIFTEEN_MIN);
    fail(403, "That password is not correct.");
  }
}

/** Stores a new password and ends every existing session of that user. Returns the new session version. */
async function setPassword(env: Env, userId: string, clientHash: string): Promise<number> {
  const salt = randomHex(16);
  const row = await env.DB.prepare(`UPDATE users SET pw_salt = ?, pw_hash = ?, session_version = session_version + 1 WHERE id = ? RETURNING session_version`)
    .bind(salt, await hashClientHash(clientHash, salt), userId)
    .first<{ session_version: number }>();
  return row?.session_version ?? 0;
}

export const authRoutes = new Hono<AppEnv>()
  .get("/me", async (c) => {
    const user = await currentUser(c);
    return c.json({
      user: user ? publicUser(user) : null,
      ai: aiStatus(c.env),
      educatorSignup: Boolean(c.env.EDUCATOR_ACCESS_KEY),
      // Only sent when the server also enforces the check.
      turnstileSiteKey: c.env.TURNSTILE_SECRET && c.env.TURNSTILE_SITE_KEY ? c.env.TURNSTILE_SITE_KEY : null,
      emailDomains: allowedDomains(c.env),
    });
  })
  // Early sign-up checks so the form can point at the failing field before the last step.
  .post("/check", async (c) => {
    const ip = ipKey(c, "check");
    if (ip && !(await rateLimit(c.env, ip, 30, FIFTEEN_MIN))) fail(429, "Too many checks. Wait 15 minutes and try again.");
    const b = await body(c.req);
    const email = str(b.email, 200).toLowerCase();
    const valid = EMAIL.test(email);
    const taken = valid ? await c.env.DB.prepare(`SELECT 1 AS x FROM users WHERE email = ?`).bind(email).first() : null;
    const accessKey = str(b.accessKey, 200);
    const expected = c.env.EDUCATOR_ACCESS_KEY ?? "";
    return c.json({
      emailAvailable: valid && !taken,
      emailAllowed: valid && domainAllowed(c.env, email),
      accessKeyValid: b.role === "educator" && accessKey ? Boolean(expected) && safeEqual(accessKey, expected) : null,
    });
  })
  .post("/signup", async (c) => {
    const b = await body(c.req);
    const email = str(b.email, 200).toLowerCase();
    const name = str(b.name, 100);
    const clientHash = str(b.clientHash, 64);
    let role: Role = b.role === "educator" ? "educator" : "student";
    if (!EMAIL.test(email)) fail(400, "Enter a valid email address.");
    if (name.length < 2) fail(400, "Enter your name.");
    if (!HEX64.test(clientHash)) fail(400, "Invalid password data.");
    if (b.consent !== true) fail(400, "Please accept the terms to continue.");
    if (!domainAllowed(c.env, email)) fail(403, domainMessage(c.env));
    // Students can carry a course join code (for example from a /join link). The demo code is not a class code.
    const joinCode = role === "student" ? str(b.joinCode, 12).toUpperCase().replace(/[^A-Z0-9]/g, "") : "";
    const classCode = joinCode && joinCode !== DEMO_COURSE_CODE ? joinCode : "";
    const classCourse = classCode ? await openCourseId(c.env, classCode) : null;
    // Counted before the access key and duplicate checks so neither can be probed without limit.
    await checkSignupLimit(c, classCourse, Boolean(classCode) && !classCourse);
    if (role === "educator") {
      const expected = c.env.EDUCATOR_ACCESS_KEY ?? "";
      if (!expected) fail(403, "Educator sign-up is not enabled on this site yet.");
      if (!safeEqual(str(b.accessKey, 200), expected)) fail(403, "That educator access key is not correct.");
      if (adminEmails(c.env).includes(email)) role = "admin";
    }
    const exists = await c.env.DB.prepare(`SELECT id FROM users WHERE email = ?`).bind(email).first();
    if (exists) fail(409, "An account with this email already exists. Sign in instead.");
    if (c.env.TURNSTILE_SECRET && !(await turnstileOk(c, str(b.turnstileToken, 4096)))) {
      fail(403, "Complete the security check and try again.");
    }
    // New students land in the course their join code names, else in the demo course while it is open.
    const courseId = role === "student" ? (classCourse ?? (await openCourseId(c.env, DEMO_COURSE_CODE))) : null;
    const id = newId();
    const salt = randomHex(16);
    const now = Date.now();
    const db = c.env.DB;
    await db.batch([
      db
        .prepare(`INSERT INTO users (id, email, name, role, pw_salt, pw_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`)
        .bind(id, email, name, role, salt, await hashClientHash(clientHash, salt), now),
      ...(courseId ? [db.prepare(`INSERT OR IGNORE INTO enrollments (course_id, user_id, joined_at) VALUES (?, ?, ?)`).bind(courseId, id, now)] : []),
    ]);
    await startSession(c, id, 0);
    return c.json({ user: publicUser({ id, email, name, role, ai_key_enc: null }), enrolledCourseId: courseId });
  })
  .post("/signin", async (c) => {
    const b = await body(c.req);
    const email = str(b.email, 200).toLowerCase();
    const clientHash = str(b.clientHash, 64);
    const emailKey = `signin:email:${email}`;
    const ip = ipKey(c, "signin");
    const limits = [{ key: emailKey, max: 10 }, ...(ip ? [{ key: ip, max: 30 }] : [])];
    if (await overLimit(c.env, limits, FIFTEEN_MIN)) fail(429, SIGNIN_LIMIT);
    const row = await c.env.DB.prepare(
      `SELECT id, email, name, role, ai_key_enc, pw_salt, pw_hash, session_version FROM users WHERE email = ?`,
    )
      .bind(email)
      .first<DbUser & { pw_salt: string; pw_hash: string; session_version: number }>();
    if (!row || !HEX64.test(clientHash) || !safeEqual(await hashClientHash(clientHash, row.pw_salt), row.pw_hash)) {
      await recordFailures(c.env, limits.map((l) => l.key), FIFTEEN_MIN);
      fail(401, "Email or password is incorrect.");
    }
    await clearLimit(c.env, emailKey);
    await startSession(c, row.id, row.session_version);
    return c.json({ user: publicUser(row) });
  })
  .post("/signout", async (c) => {
    // Ends this user's sessions on every device, not just this browser's cookie.
    const user = await currentUser(c);
    if (user) await c.env.DB.prepare(`UPDATE users SET session_version = session_version + 1 WHERE id = ?`).bind(user.id).run();
    clearSessionCookie(c);
    return c.json({ ok: true });
  })
  .post("/password", async (c) => {
    const user = await currentUser(c);
    if (!user) fail(401, "Please sign in.");
    const b = await body(c.req);
    const newHash = str(b.newHash, 64);
    if (!HEX64.test(newHash)) fail(400, "Invalid password data.");
    await confirmPassword(c.env, user.id, str(b.currentHash, 64));
    await startSession(c, user.id, await setPassword(c.env, user.id, newHash));
    return c.json({ ok: true });
  })
  .post("/reset", async (c) => {
    const b = await body(c.req);
    const email = str(b.email, 200).toLowerCase();
    const code = str(b.code, 20).toUpperCase().replace(/\s/g, "");
    const clientHash = str(b.clientHash, 64);
    if (!HEX64.test(clientHash)) fail(400, "Invalid password data.");
    const emailKey = `reset:email:${email}`;
    const ip = ipKey(c, "reset");
    const limits = [{ key: emailKey, max: 10 }, ...(ip ? [{ key: ip, max: 30 }] : [])];
    if (await overLimit(c.env, limits, FIFTEEN_MIN)) fail(429, "Too many reset attempts. Wait 15 minutes and try again.");
    const codeHash = await sha256Hex(`reset:${code}`);
    const row = await c.env.DB.prepare(
      `SELECT r.user_id FROM reset_codes r JOIN users u ON u.id = r.user_id WHERE r.code_hash = ? AND u.email = ? AND r.expires_at > ?`,
    )
      .bind(codeHash, email, Date.now())
      .first<{ user_id: string }>();
    if (!row) {
      await recordFailures(c.env, limits.map((l) => l.key), FIFTEEN_MIN);
      fail(400, "That reset code is not valid or has expired. Ask your instructor for a new one.");
    }
    const version = await setPassword(c.env, row.user_id, clientHash);
    await c.env.DB.batch([
      c.env.DB.prepare(`DELETE FROM reset_codes WHERE user_id = ?`).bind(row.user_id),
      c.env.DB.prepare(`DELETE FROM auth_attempts WHERE key IN (?, ?)`).bind(emailKey, `signin:email:${email}`),
    ]);
    await startSession(c, row.user_id, version);
    return c.json({ ok: true });
  });
