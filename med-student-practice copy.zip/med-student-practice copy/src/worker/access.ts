import type { DbUser, Env } from "./env";
import type { StoredKey } from "./ai/router";
import { getSecrets } from "./db";
import { decryptText } from "./crypto";

export type CourseRole = "staff" | "student" | null;

export async function courseRole(env: Env, user: DbUser, courseId: string): Promise<CourseRole> {
  const course = await env.DB.prepare(`SELECT owner_id FROM courses WHERE id = ?`).bind(courseId).first<{ owner_id: string }>();
  if (!course) return null;
  if (user.role === "admin" || course.owner_id === user.id) return "staff";
  const [staff, enrolled] = await env.DB.batch([
    env.DB.prepare(`SELECT 1 AS x FROM course_staff WHERE course_id = ? AND user_id = ?`).bind(courseId, user.id),
    env.DB.prepare(`SELECT 1 AS x FROM enrollments WHERE course_id = ? AND user_id = ?`).bind(courseId, user.id),
  ]);
  if (staff.results.length) return "staff";
  if (enrolled.results.length) return "student";
  return null;
}

/** Library items are visible when public or owned; editable only by the owner or an admin. */
export const canSee = (user: DbUser, row: { owner_id: string; is_public: number }) =>
  row.is_public === 1 || row.owner_id === user.id || user.role === "admin";
export const canEdit = (user: DbUser, row: { owner_id: string }) => row.owner_id === user.id || user.role === "admin";

/** Tries each key in turn (ENC_KEY first, then the older database key) so rows from before ENC_KEY still decrypt. */
export async function decryptStored(enc: string, keys: string[]): Promise<string | null> {
  for (const k of keys) {
    const plain = await decryptText(enc, k);
    if (plain !== null) return plain;
  }
  return null;
}

async function readKey(enc: string | null, keys: string[], source: StoredKey["source"]): Promise<StoredKey | null> {
  if (!enc) return null;
  const plain = await decryptStored(enc, keys);
  if (!plain) return null;
  try {
    const k = JSON.parse(plain) as { provider: StoredKey["provider"]; key: string };
    return k.key ? { provider: k.provider === "groq" ? "groq" : "gemini", key: k.key, source } : null;
  } catch {
    return null;
  }
}

/** The student's own key first, then the course key. Platform keys are added by the router. */
export async function keysFor(env: Env, user: DbUser, courseId: string | null): Promise<StoredKey[]> {
  const { decryptKeys } = await getSecrets(env);
  const out: StoredKey[] = [];
  const mine = await readKey(user.ai_key_enc, decryptKeys, "student");
  if (mine) out.push(mine);
  if (courseId) {
    const row = await env.DB.prepare(`SELECT ai_key_enc FROM courses WHERE id = ?`).bind(courseId).first<{ ai_key_enc: string | null }>();
    const ck = await readKey(row?.ai_key_enc ?? null, decryptKeys, "course");
    if (ck) out.push(ck);
  }
  return out;
}

export function validKeyInput(provider: unknown, key: unknown): { provider: StoredKey["provider"]; key: string } | null {
  const k = typeof key === "string" ? key.trim() : "";
  // Google issues both classic "AIza…" keys and newer "AQ.…" keys.
  if (provider === "gemini" && /^[A-Za-z0-9._-]{30,200}$/.test(k)) return { provider, key: k };
  if (provider === "groq" && /^gsk_[A-Za-z0-9]{20,80}$/.test(k)) return { provider, key: k };
  return null;
}
