// Fixed-window throttling kept in D1 (table auth_attempts), so limits hold across Worker instances.
// Each check is a single upsert, which keeps D1 writes and Worker CPU low on the free plan.
import type { Context } from "hono";
import type { AppEnv, Env } from "./env";

const UPSERT = `INSERT INTO auth_attempts (key, window_start, count) VALUES (?1, ?2, 1)
  ON CONFLICT(key) DO UPDATE SET
    count = CASE WHEN auth_attempts.window_start <= ?2 - ?3 THEN 1 ELSE auth_attempts.count + 1 END,
    window_start = CASE WHEN auth_attempts.window_start <= ?2 - ?3 THEN ?2 ELSE auth_attempts.window_start END
  RETURNING count`;

/** The visitor's IP as Cloudflare reports it, or "local" when the header is missing (local dev). */
export function clientIp(c: Context<AppEnv>): string {
  return c.req.header("cf-connecting-ip")?.trim() || "local";
}

/**
 * Per-IP limits only apply to a real client address. Local dev has no CF-Connecting-IP (or a loopback
 * one), and every test script there would otherwise share one bucket. On Cloudflare the header is
 * always set, so production is never exempt.
 */
export function ipKey(c: Context<AppEnv>, scope: string): string | null {
  const ip = clientIp(c);
  return ip === "local" || ip === "127.0.0.1" || ip === "::1" ? null : `${scope}:ip:${ip}`;
}

function prune(env: Env, now: number) {
  // Old windows are useless; clear them now and then instead of on every request.
  if (Math.random() < 0.02) return env.DB.prepare(`DELETE FROM auth_attempts WHERE window_start < ?`).bind(now - 86400_000).run();
}

/**
 * Counts one event for `key` and reports whether it is still within `max` per `windowSec`.
 * Example: 20 course joins per user per hour is rateLimit(c.env, "enroll:user:" + u.id, 20, 3600).
 */
export async function rateLimit(env: Env, key: string, max: number, windowSec: number): Promise<boolean> {
  const now = Date.now();
  const row = await env.DB.prepare(UPSERT).bind(key, now, windowSec * 1000).first<{ count: number }>();
  await prune(env, now);
  return (row?.count ?? 0) <= max;
}

/** Counts one failure for each key (one upsert each, sent as a single batch). */
export async function recordFailures(env: Env, keys: string[], windowSec: number): Promise<void> {
  if (!keys.length) return;
  const now = Date.now();
  await env.DB.batch(keys.map((k) => env.DB.prepare(UPSERT).bind(k, now, windowSec * 1000)));
  await prune(env, now);
}

/** True when any key already reached its limit in the current window, without counting a new event. */
export async function overLimit(env: Env, limits: { key: string; max: number }[], windowSec: number): Promise<boolean> {
  if (!limits.length) return false;
  const rows = await env.DB.prepare(`SELECT key, count FROM auth_attempts WHERE key IN (${limits.map(() => "?").join(", ")}) AND window_start > ?`)
    .bind(...limits.map((l) => l.key), Date.now() - windowSec * 1000)
    .all<{ key: string; count: number }>();
  return rows.results.some((r) => r.count >= (limits.find((l) => l.key === r.key)?.max ?? Infinity));
}

export async function clearLimit(env: Env, key: string): Promise<void> {
  await env.DB.prepare(`DELETE FROM auth_attempts WHERE key = ?`).bind(key).run();
}
