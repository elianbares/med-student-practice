import { HTTPException } from "hono/http-exception";

export function fail(status: 400 | 401 | 403 | 404 | 409 | 429 | 500 | 502 | 503, message: string): never {
  throw new HTTPException(status, { message });
}

export function parseJson<T>(text: string | null | undefined, fallback: T): T {
  if (!text) return fallback;
  try {
    return JSON.parse(text) as T;
  } catch {
    return fallback;
  }
}

export function str(v: unknown, max = 5000): string {
  if (typeof v !== "string") return "";
  return v.trim().slice(0, max);
}

export async function body<T = Record<string, unknown>>(req: { json: () => Promise<unknown> }): Promise<T> {
  try {
    const b = await req.json();
    return (b && typeof b === "object" ? b : {}) as T;
  } catch {
    return {} as T;
  }
}

export const today = () => new Date().toISOString().slice(0, 10);
