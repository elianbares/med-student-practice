// Small WebCrypto helpers. Everything here is cheap enough for the Workers free-plan CPU budget.

const B62 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no I, O, 0, 1

const enc = new TextEncoder();
const dec = new TextDecoder();

function randomString(len: number, alphabet: string): string {
  const bytes = crypto.getRandomValues(new Uint8Array(len));
  let out = "";
  for (const b of bytes) out += alphabet[b % alphabet.length];
  return out;
}

export const newId = (len = 14) => randomString(len, B62);
export const newCourseCode = () => randomString(6, CODE_ALPHABET);
export const newResetCode = () => randomString(8, CODE_ALPHABET);

export function toHex(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

function fromHex(hex: string): Uint8Array {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

function b64url(bytes: Uint8Array): string {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromB64url(s: string): Uint8Array {
  const b = atob(s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4));
  return Uint8Array.from(b, (c) => c.charCodeAt(0));
}

export const randomHex = (bytes: number) => toHex(crypto.getRandomValues(new Uint8Array(bytes)));

export async function sha256Hex(text: string): Promise<string> {
  return toHex(await crypto.subtle.digest("SHA-256", enc.encode(text)));
}

export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/**
 * Passwords are stretched with PBKDF2 in the browser (see client/crypto.ts), so the server only
 * receives a 64-hex "client hash" and stores sha256(salt + clientHash).
 */
export async function hashClientHash(clientHash: string, salt: string): Promise<string> {
  return sha256Hex(`${salt}:${clientHash}`);
}

async function hmacKey(secret: string): Promise<CryptoKey> {
  return crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

export async function signToken(payload: object, secret: string): Promise<string> {
  const body = b64url(enc.encode(JSON.stringify(payload)));
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", await hmacKey(secret), enc.encode(body)));
  return `${body}.${b64url(sig)}`;
}

export async function verifyToken<T>(token: string, secret: string): Promise<T | null> {
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  try {
    const ok = await crypto.subtle.verify("HMAC", await hmacKey(secret), fromB64url(sig), enc.encode(body));
    if (!ok) return null;
    return JSON.parse(dec.decode(fromB64url(body))) as T;
  } catch {
    return null;
  }
}

async function aesKey(hexKey: string): Promise<CryptoKey> {
  return crypto.subtle.importKey("raw", fromHex(hexKey), "AES-GCM", false, ["encrypt", "decrypt"]);
}

export async function encryptText(plain: string, hexKey: string): Promise<string> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await aesKey(hexKey), enc.encode(plain)));
  return `${b64url(iv)}.${b64url(ct)}`;
}

export async function decryptText(blob: string, hexKey: string): Promise<string | null> {
  const [iv, ct] = blob.split(".");
  if (!iv || !ct) return null;
  try {
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromB64url(iv) }, await aesKey(hexKey), fromB64url(ct));
    return dec.decode(pt);
  } catch {
    return null;
  }
}
