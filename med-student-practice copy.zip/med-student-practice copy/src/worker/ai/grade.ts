// Turns the grader model's JSON into a complete, trustworthy Feedback object.
// Test-ordering review is computed here from the logs, not by the model, so it is always accurate.
import type { ConfigData, Feedback, Message, Order, ProfileData, RubricScore } from "../../shared/types";
import { firstNameOnly } from "./prompts";

export function parseLooseJson(text: string): unknown | null {
  const t = text
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/```\s*$/, "");
  const start = t.indexOf("{");
  const end = t.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  const slice = t.slice(start, end + 1);
  for (const candidate of [slice, slice.replace(/,\s*([}\]])/g, "$1")]) {
    try {
      return JSON.parse(candidate);
    } catch {
      /* try the next repair */
    }
  }
  return null;
}

export const normText = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();

/**
 * Em and en dashes (and their figure-dash and bar cousins) become commas; number ranges keep a hyphen
 * ("7–10" becomes "7-10"). Used on AI text before anyone sees it.
 * `start` is false for a streamed chunk that continues earlier text, so a leading dash stays a comma.
 */
export function noDashes(text: string, start = true): string {
  if (!/[‒-―]/.test(text)) return text;
  const out = text
    .replace(/(\d)\s*[‒-―]\s*(?=\d)/g, "$1-")
    .replace(/\s*[‒-―]+\s*/g, ", ")
    .replace(/,\s*([,.;:!?)])/g, "$1");
  return start ? out.replace(/^,\s*/, "") : out;
}

/** Keeps the first *action* in a patient reply and drops any others ("at most one short action"). */
export function oneAction(text: string): string {
  let n = 0;
  const out = text.replace(/[ \t]*\*[^*\n]+\*/g, (m) => (n++ === 0 ? m : ""));
  return n > 1 ? out.replace(/^[ \t]+/gm, "").replace(/[ \t]{2,}/g, " ").trim() : text;
}

// Third-person references to the learner, rewritten to "you" with the verb that follows.
const WHO = String.raw`(?:the|this)\s+(?:medical\s+)?(?:trainee|clinician|student|learner|examinee|candidate|interviewer)`;
const ADVERB = String.raw`(?:(?:\w+ly|also|only|never|always|then|still|just|often|perhaps|sometimes|again|now|seldom)\s+)?`;
// Where a sentence's subject can start: the verb after it is turned into the "you" form.
const SUBJECT_START = String.raw`(^|[.!?;:]\s+|\n\s*|[,(]\s*|\b(?:and|but|because|when|while|that|if|as|so|although|though|since|where|whereas|once|until|after|before)\s+)`;
const BE: Record<string, string> = {
  is: "are",
  was: "were",
  "isn't": "aren't",
  "wasn't": "weren't",
  has: "have",
  "hasn't": "haven't",
  does: "do",
  "doesn't": "don't",
};
/** "asks" -> "ask", "establishes" -> "establish", "tries" -> "try". Leaves other words alone. */
function baseVerb(w: string): string {
  const l = w.toLowerCase();
  if (BE[l]) return BE[l];
  if (l.length < 4 || !l.endsWith("s") || /(?:ss|us|is)$/.test(l)) return w;
  if (l === "focuses") return w.slice(0, -2);
  if (/ies$/.test(l)) return w.slice(0, -3) + "y";
  if (/(?:sh|ch|x|zz|ss|o)es$/.test(l)) return w.slice(0, -2);
  return w.slice(0, -1);
}

const cap = (s: string, upper: boolean) => (upper ? s[0].toUpperCase() + s.slice(1) : s);
const POSSESSIVE = new RegExp(`\\b${WHO}(?:'s|’s)`, "gi");
const SUBJECT = new RegExp(`${SUBJECT_START}(${WHO})\\s+(${ADVERB})([A-Za-z']+)`, "gi");
// Any other mention; a "be" or "have" verb right after it still agrees with "you" ("shows the trainee is" -> "shows you are").
const ANY = new RegExp(`\\b${WHO}\\b(?:\\s+(${Object.keys(BE).join("|")})\\b)?`, "gi");

/** "The trainee asks" -> "You ask", "the clinician's tone" -> "your tone", "thanked the student" -> "thanked you". Cheap regex passes only. */
export function secondPerson(text: string): string {
  if (!/\b(?:trainee|clinician|student|learner|examinee|candidate|interviewer)\b/i.test(text)) return text;
  return text
    .replace(POSSESSIVE, (m) => cap("your", m[0] === "T"))
    .replace(SUBJECT, (_m, pre: string, who: string, adv: string, verb: string) => `${pre}${cap("you", who[0] === "T")} ${adv}${baseVerb(verb)}`)
    .replace(ANY, (m, be: string | undefined) => cap("you", m[0] === "T") + (be ? ` ${BE[be.toLowerCase()]}` : ""))
    .replace(/\b([Yy]ou(?:\s+\w+){1,2}?\s+)(?:themselves|himself|herself)\b/g, "$1yourself");
}

/** Every user-facing string from the grader goes through this. */
export const tidy = (text: string) =>
  secondPerson(noDashes(text))
    .trim()
    .replace(/,$/, "");

const strArr = (v: unknown, max = 10, clean: (t: string) => string = tidy): string[] =>
  Array.isArray(v) ? v.map((x) => (typeof x === "string" ? clean(x).trim() : "")).filter(Boolean).slice(0, max) : [];
const s = (v: unknown) => (typeof v === "string" ? v.trim() : "");

export function testsReview(profile: ProfileData, orders: Order[]) {
  const ordered = new Set(orders.filter((o) => o.testId).map((o) => o.testId));
  const expected = profile.tests.filter((t) => t.expected);
  const unnecessary = orders
    .filter((o) => !o.testId || !expected.some((t) => t.id === o.testId))
    .map((o) => o.name)
    .filter((n, i, a) => a.indexOf(n) === i);
  return {
    orderedExpected: expected.filter((t) => ordered.has(t.id)).map((t) => t.name),
    missedExpected: expected.filter((t) => !ordered.has(t.id)).map((t) => t.name),
    unnecessary,
  };
}

/** Whether the student said anything to the patient. Without that there is no attempt to give feedback on. */
export const spoke = (messages: Message[]) => messages.some((m) => m.role === "doctor" && typeof m.text === "string" && m.text.trim() !== "");

export const SILENT_SUMMARY = "No conversation took place, so there is nothing to grade yet. Start a new attempt and talk with the patient.";

/**
 * Feedback for an attempt with no conversation carries no answer key: no case diagnosis, verdict, expected or
 * unnecessary tests, differential or missed questions, so ending a silent attempt can't be used to peek at the
 * case. Every skill stays Not assessed. Also applied when reading older feedback saved before this rule.
 */
export function withoutAnswerKey(fb: Feedback): Feedback {
  return {
    ...fb,
    correctDiagnosis: "",
    diagnosisVerdict: "n/a",
    diagnosisComment: "",
    rubric: fb.rubric.map((r) => ({ category: r.category, level: "Not assessed", evidence: [], strengths: "", improve: "" })),
    historyMissed: [],
    testsReview: { orderedExpected: [], missedExpected: [], unnecessary: [], comment: "" },
    differential: [],
    notesFeedback: "",
    nextSteps: [],
  };
}

function matchLevel(raw: string, levels: string[]): string {
  const r = raw.trim().toLowerCase();
  if (!r) return "Not assessed";
  const exact = levels.find((l) => l.toLowerCase() === r);
  if (exact) return exact;
  const contained = [...levels].sort((a, b) => b.length - a.length).find((l) => r.includes(l.toLowerCase()));
  if (contained) return contained;
  const n = parseInt(r, 10);
  if (Number.isFinite(n) && n >= 1 && n <= levels.length) return levels[n - 1];
  return "Not assessed";
}

export interface FeedbackContext {
  profile: ProfileData;
  config: ConfigData;
  messages: Message[];
  orders: Order[];
  /** The student's stated diagnosis, used to judge whether it was supported. */
  diagnosis?: string;
  /** The student's full name. The AI saw their lines with it cut to the first name (see pseudonymize). */
  studentName?: string;
}

const words = (t: string) => new Set(normText(t).split(" ").filter(Boolean));

function jaccard(a: Set<string>, b: Set<string>): number {
  if (!a.size || !b.size) return 0;
  let both = 0;
  for (const w of a) if (b.has(w)) both++;
  return both / (a.size + b.size - both);
}

type Support = NonNullable<Feedback["diagnosisSupport"]>;
type Kind = "praise" | "improve";
/** The model's diagnosisSupport, tolerating wording such as "not supported" or "partially supported". */
const supportOf = (v: string): Support | undefined =>
  /\b(?:un|not\s+)supported\b/.test(v) ? "unsupported" : /partial|partly/.test(v) ? "partly" : /supported/.test(v) ? "supported" : /^n\/?a$|not applicable/.test(v) ? "n/a" : undefined;
const REASONING = /reason|diagnos|differential/i;
const TESTING = /test|exam|investigat|order|stewardship|reason/i;
const TEST_WORDS = /\b(?:order|ordered|ordering|test|tests|exam|exams|examined|x-?ray|lab|labs|imaging)\b/i;
// Out-of-role or rude remarks a real patient would find upsetting. The grader is told to flag them; this makes sure.
// Only remarks aimed at the patient count, so "that's not a stupid question" or "are you a machine operator?" don't.
const YOU_ARE = String.raw`(?:you(?:'re|’re| are)|are you)\s+(?:just\s+|only\s+|really\s+|simply\s+|so\s+|being\s+|such\s+)?(?:an?\s+)?`;
const UNPROFESSIONAL = new RegExp(
  String.raw`\b(?:${YOU_ARE}(?:(?:ai|bot|robot|chat ?bot|language model|llm|computer program|stupid|dumb|idiot|moron|pathetic)\b|a\.i\.?(?!\w)|(?:computer|machine|program)(?=\s*(?:[?.!,;]|$)))|shut up\b|ignore (?:all |your |the |previous )*instructions)`,
  "i",
);
const CONDUCT = [/profession/i, /communicat/i, /empath|rapport|engag/i];
const CONDUCT_TIP = "Remarks like the one quoted would upset a real patient and break their trust, so stay in your clinician role and keep every remark respectful.";

export function buildFeedback(raw: unknown, ctx: FeedbackContext, provider: string): Feedback {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const rawRubric = Array.isArray(r.rubric) ? (r.rubric as Record<string, unknown>[]) : [];
  const doctorLines = ctx.messages.filter((m) => m.role === "doctor").map((m) => m.text.trim()).filter(Boolean);
  const doctorText = ` ${normText(doctorLines.join(" \n "))} `;
  // Candidate quotes: your sentences and whole lines, for replacing misquotes with the closest real line.
  const candidates = doctorLines
    .flatMap((line) => {
      // Sentence ends, but not after a title ("Hello Mr. Bell" stays whole).
      const parts = line.split(/(?<=[.!?])(?<!\b(?:Mr|Mrs|Ms|Dr|Prof)\.)\s+/i).filter((p) => p.length > 3);
      return parts.length > 1 ? [...parts, line] : [line];
    })
    .map((text) => ({ text, words: words(text) }));
  const fullName = ctx.studentName?.trim() ?? "";
  const levels = ctx.config.levels;
  const lowest = levels[0] ?? "Not assessed";

  /** The quote as you said it, or null. Never a paraphrase: a misquote becomes your closest real line or is dropped. */
  const verify = (quote: string): string | null => {
    const q = normText(quote);
    if (!q) return null;
    if (doctorText.includes(` ${q} `)) return quote;
    // The AI saw your lines with only your first name, so match those too and show the line as you typed it.
    if (fullName) {
      const hit = candidates.find((c) => ` ${normText(firstNameOnly(c.text, fullName))} `.includes(` ${q} `));
      if (hit) return hit.text;
    }
    const qw = words(quote);
    let best: { text: string; score: number } | null = null;
    for (const c of candidates) {
      const score = jaccard(qw, c.words);
      if (score > (best?.score ?? 0)) best = { text: c.text, score };
    }
    return best && best.score >= 0.5 ? best.text : null;
  };

  // Is the diagnosis backed by data gathered in this encounter? The model judges; thin encounters are caught here too.
  const supportRaw = supportOf(s(r.diagnosisSupport).toLowerCase());
  const gaveDiagnosis = ctx.config.diagnosisType === "diagnosis" && Boolean((ctx.diagnosis ?? "").trim());
  const thin = doctorLines.length <= 2 && ctx.orders.length === 0;
  const support: Support | undefined = !gaveDiagnosis ? "n/a" : thin ? "unsupported" : supportRaw !== "n/a" ? supportRaw : undefined;
  // In very short encounters no skill can be shown well, whatever the model says.
  const ceiling = doctorLines.length <= 2 ? Math.floor((levels.length - 1) / 2) : levels.length - 1;
  const rude = doctorLines.filter((l) => UNPROFESSIONAL.test(l)).slice(0, 2);
  const conductIdx = rude.length ? CONDUCT.map((re) => ctx.config.rubric.findIndex((c) => re.test(c.name))).find((i) => i >= 0) ?? -1 : -1;

  const rubric: RubricScore[] = ctx.config.rubric.map((cat, i) => {
    const item =
      rawRubric.find((x) => normText(s(x?.category)) === normText(cat.name)) ??
      rawRubric.find((x) => normText(s(x?.category)).includes(normText(cat.name).split(" ")[0] ?? "")) ??
      rawRubric[i] ??
      {};
    let level = matchLevel(s(item.level), levels);
    if (levels.indexOf(level) > ceiling) level = levels[ceiling];
    // A diagnosis named without supporting data earns no reasoning credit.
    const guessed = support === "unsupported" && REASONING.test(cat.name);
    if (guessed) level = lowest;
    const idx = levels.indexOf(level);

    const seen: string[] = [];
    let evidence: RubricScore["evidence"] = (Array.isArray(item.evidence) ? item.evidence : [])
      .slice(0, 4)
      .flatMap((e: unknown) => {
        const o = (e && typeof e === "object" ? e : { quote: e }) as { quote?: unknown; kind?: unknown };
        const quote = verify(s(o.quote));
        const n = quote ? normText(quote) : "";
        if (!quote || seen.some((x) => x.includes(n) || n.includes(x))) return [];
        seen.push(n);
        const given = s(o.kind).toLowerCase();
        // Untagged quotes: the model's own advice or strength that repeats the quote decides; otherwise only the
        // top level counts as praise, so a strength is never invented from an untagged quote.
        const kind: Kind =
          given === "praise" || given === "improve"
            ? given
            : ` ${normText(s(item.improve))} `.includes(` ${n} `)
              ? "improve"
              : ` ${normText(s(item.strengths))} `.includes(` ${n} `) || (idx === levels.length - 1 && idx > 0)
                ? "praise"
                : "improve";
        return [{ quote, verified: true, kind }];
      })
      .slice(0, 3);
    if (guessed) evidence = evidence.filter((e) => e.kind !== "praise");

    let improve = tidy(s(item.improve));
    if (i === conductIdx) {
      for (const line of rude) if (!evidence.some((e) => normText(e.quote) === normText(line))) evidence.unshift({ quote: line, verified: true, kind: "improve" });
      evidence = evidence.slice(0, 3);
      const top = levels.length - 1;
      if (top > 0 && levels.indexOf(level) >= top) level = levels[top - 1];
      if (!/profession|respect|rude|trust|in role|\bAI\b|\bbot\b/i.test(improve)) improve = `${improve} ${CONDUCT_TIP}`.trim();
    }

    // A strength must rest on something you actually said (a praise quote, or a real line quoted in the
    // strength itself) or, for testing skills, on tests you ordered. Otherwise none is shown.
    let strengths = tidy(s(item.strengths));
    const quotedInStrength = [...strengths.matchAll(/["“]([^"”]{4,})["”]/g)].some((m) => verify(m[1]) !== null);
    const backed =
      evidence.some((e) => e.kind !== "improve") || quotedInStrength || (ctx.orders.length > 0 && TESTING.test(cat.name) && TEST_WORDS.test(strengths));
    if (guessed || !backed) strengths = "";
    return { category: cat.name, level, evidence, strengths, improve };
  });

  const verdictRaw = s(r.diagnosisVerdict).toLowerCase();
  const verdict =
    ctx.config.diagnosisType === "none"
      ? "n/a"
      : verdictRaw === "correct" || verdictRaw === "partial" || verdictRaw === "incorrect"
        ? verdictRaw
        : "n/a";

  let diagnosisComment = tidy(s(r.diagnosisComment));
  if (support === "unsupported" && (supportRaw !== "unsupported" || !/support|guess|enough|little|without/i.test(diagnosisComment))) {
    // Overruled or silent model: say plainly that the label was not earned by the data.
    const why = "gathered too little history, exam findings or test results in this encounter to support it, so it reads as a guess rather than a reasoned conclusion.";
    diagnosisComment =
      verdict === "correct"
        ? `Your diagnosis matches the case, but you ${why}`
        : verdict === "partial"
          ? `Your diagnosis is close to the case diagnosis, but you ${why}`
          : verdict === "incorrect"
            ? `Your diagnosis does not match the case, and you ${why}`
            : `You ${why.replace("support it", "support your diagnosis")}`;
  }

  const feedback: Feedback = {
    correctDiagnosis: ctx.profile.diagnosis,
    diagnosisVerdict: verdict,
    ...(support ? { diagnosisSupport: support } : {}),
    diagnosisComment,
    rubric,
    // Questions to the patient and diagnosis names: only dashes are cleaned (no "you" rewriting).
    historyMissed: strArr(r.historyMissed, 8, noDashes),
    testsReview: { ...testsReview(ctx.profile, ctx.orders), comment: tidy(s(r.testsComment)) },
    differential: strArr(r.differential, 6, noDashes),
    notesFeedback: ctx.config.notesFeedback.enabled ? tidy(s(r.notesFeedback)) : "",
    summary: tidy(s(r.summary)),
    nextSteps: strArr(r.nextSteps, 5),
    provider,
  };
  return doctorLines.length ? feedback : { ...withoutAnswerKey(feedback), summary: SILENT_SUMMARY };
}
