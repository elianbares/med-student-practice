// AI router: tries each available free provider in order and falls through on errors or rate limits.
// Order: the student's own key, the course's key, the platform keys, Workers AI, then the demo AI.
import type { Env } from "../env";
import type { AiStatus } from "../../shared/types";
import { today } from "../util";

export type Task = "actor" | "grader" | "assistant" | "judge";

export interface ChatMsg {
  role: "user" | "assistant";
  content: string;
}

export interface LLMRequest {
  task: Task;
  system: string;
  messages: ChatMsg[];
  json?: boolean;
  temperature?: number;
  maxTokens?: number;
  /** Produces the demo-AI answer when no real provider is configured. */
  mock: () => string;
}

export interface StoredKey {
  provider: "gemini" | "groq";
  key: string;
  source: "student" | "course";
}

export interface Target {
  provider: "gemini" | "groq" | "workers-ai" | "mock";
  model: string;
  key?: string;
  source: "student" | "course" | "platform" | "builtin";
}

export interface RouterOpts {
  waitUntil?: (p: Promise<unknown>) => void;
}

export class AiUnavailableError extends Error {}

class ProviderError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

// Measured on the free tier (Oct 2026): Flash-Lite answers in ~1s; the newest Flash models are often
// "high demand" (503); Gemma is slower but has a larger daily allowance.
const DEFAULT_ACTOR = "gemini-flash-lite-latest,gemini-3.1-flash-lite,gemma-4-26b-a4b-it,gemma-4-31b-it";
// Flash-Lite grades first: its large free daily quota means every student is graded by the same model, so
// grades stay comparable. 3.6 Flash allows only about 20 free requests a day, so it is a fallback.
export const DEFAULT_GRADER = "gemini-flash-lite-latest,gemini-3.1-flash-lite,gemini-3.6-flash,gemini-flash-latest,gemma-4-26b-a4b-it";
const DEFAULT_GROQ = "llama-3.3-70b-versatile,openai/gpt-oss-120b";
/** A long-lived Workers AI model, used as overflow when the env.AI binding exists. */
export const DEFAULT_WORKERS_AI = "@cf/meta/llama-3.3-70b-instruct-fp8-fast";

/** Full Flash models think by default, which can take minutes on the free tier; keep it short. */
const thinkingFor = (model: string, task: Task) =>
  /^gemini-(3\.\d+-flash|flash-latest)$/.test(model) ? { thinkingLevel: task === "actor" ? "minimal" : "low" } : null;

// Models that just failed (overloaded or out of quota) are skipped for a while so students don't wait on them.
// Each Worker instance remembers this in memory, and shares it with the other instances in the same data
// center through the Cache API (best effort: the cache can be missing, e.g. in tests or some previews).
const cooling = new Map<string, number>();
const coolKey = (t: Target) => `${t.provider}:${t.model}:${(t.key ?? "").slice(-6)}`;

/** Synthetic cache key for one provider + model + key suffix. Never fetched; .invalid cannot resolve. */
export const cooldownUrl = (provider: string, model: string, key = "") =>
  `https://cooldown.invalid/${encodeURIComponent(provider)}/${encodeURIComponent(model)}/${encodeURIComponent(key.slice(-6)) || "-"}`;

function sharedCache(): Cache | null {
  try {
    return (globalThis as unknown as { caches?: { default?: Cache } }).caches?.default ?? null;
  } catch {
    return null;
  }
}

/** Remembers a cooldown for other Worker instances until `until` (ms since epoch). */
export function shareCooldown(url: string, until: number, waitUntil?: (p: Promise<unknown>) => void) {
  const cache = sharedCache();
  const secs = Math.ceil((until - Date.now()) / 1000);
  if (!cache || secs < 1) return;
  const p = cache.put(url, new Response(String(until), { headers: { "cache-control": `max-age=${secs}` } })).catch(() => undefined);
  waitUntil?.(p);
}

/** Cooldown end times (ms) found in the shared cache, one batched lookup. Missing or expired entries are left out. */
export async function sharedCooldowns(urls: string[]): Promise<Map<string, number>> {
  const out = new Map<string, number>();
  const cache = sharedCache();
  if (!cache || !urls.length) return out;
  const unique = [...new Set(urls)];
  const hits = await Promise.all(unique.map((u) => cache.match(u).then((r) => (r ? r.text() : null)).catch(() => null)));
  const now = Date.now();
  hits.forEach((v, i) => {
    const until = Number(v);
    if (v && until > now) out.set(unique[i], until);
  });
  return out;
}

function cool(t: Target, err: unknown, opts: RouterOpts = {}) {
  const status = err instanceof ProviderError ? err.status : 0;
  const msg = err instanceof Error ? err.message : "";
  const daily = /per day|daily/i.test(msg);
  // Google says when a used-up daily quota resets ("Please retry in 4h27m54s"); trust it, capped at 12 h.
  const retry = /retry in (?:(\d+)h)?(?:(\d+)m)?(?:([\d.]+)s)?/i.exec(msg);
  const retryMs = retry ? ((+(retry[1] ?? 0) * 60 + +(retry[2] ?? 0)) * 60 + +(retry[3] ?? 0)) * 1000 : 0;
  const timedOut = err instanceof Error && err.name === "AbortError";
  const ms = daily
    ? Math.min(Math.max(retryMs, 30 * 60_000), 12 * 3600_000)
    : status === 429 || status === 503 || status === 500
      ? Math.max(retryMs, 60_000)
      : status === 404
        ? 6 * 3600_000
        : timedOut
          ? 5 * 60_000
          : 20_000;
  const until = Date.now() + ms;
  cooling.set(coolKey(t), until);
  if (t.provider !== "mock") shareCooldown(cooldownUrl(t.provider, t.model, t.key), until, opts.waitUntil);
}

/** Healthy targets first; cooling ones (here or in another instance) are kept at the end as a last resort. */
async function ordered(targets: Target[]): Promise<Target[]> {
  const real = targets.filter((t) => t.provider !== "mock");
  const shared = await sharedCooldowns(real.map((t) => cooldownUrl(t.provider, t.model, t.key)));
  for (const t of real) {
    const until = shared.get(cooldownUrl(t.provider, t.model, t.key));
    if (until && until > (cooling.get(coolKey(t)) ?? 0)) cooling.set(coolKey(t), until);
  }
  const now = Date.now();
  const ok = targets.filter((t) => (cooling.get(coolKey(t)) ?? 0) <= now);
  return ok.length ? [...ok, ...targets.filter((t) => !ok.includes(t))] : targets;
}

const list = (s: string | undefined, d: string) =>
  (s?.trim() ? s : d)
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);

export function targetsFor(env: Env, task: Task, extraKeys: StoredKey[] = []): Target[] {
  if (env.AI_MODE === "mock") return [{ provider: "mock", model: "demo", source: "builtin" }];
  const gemini = task === "actor" ? list(env.GEMINI_ACTOR_MODELS, DEFAULT_ACTOR) : list(env.GEMINI_GRADER_MODELS, DEFAULT_GRADER);
  const groq = list(env.GROQ_MODELS, DEFAULT_GROQ);
  const out: Target[] = [];
  const add = (provider: "gemini" | "groq", key: string, source: Target["source"]) => {
    for (const model of provider === "gemini" ? gemini : groq) out.push({ provider, model, key, source });
  };
  for (const k of extraKeys) add(k.provider, k.key, k.source);
  if (env.GEMINI_API_KEY) add("gemini", env.GEMINI_API_KEY, "platform");
  if (env.GROQ_API_KEY) add("groq", env.GROQ_API_KEY, "platform");
  if (env.AI) out.push({ provider: "workers-ai", model: env.WORKERS_AI_MODEL || DEFAULT_WORKERS_AI, source: "platform" });
  if (out.length === 0 && env.AI_MODE !== "real") out.push({ provider: "mock", model: "demo", source: "builtin" });
  return out;
}

export function aiStatus(env: Env): AiStatus {
  const providers = targetsFor(env, "actor")
    .map((t) => t.provider)
    .filter((p, i, a) => a.indexOf(p) === i);
  return { mode: providers.includes("mock") ? "demo" : "real", providers, live: Boolean(env.GEMINI_API_KEY) && env.AI_MODE !== "mock" };
}

// ---------- public API ----------

export async function complete(env: Env, targets: Target[], req: LLMRequest, opts: RouterOpts = {}) {
  const errors: string[] = [];
  // Each model gets its own timeout, and the whole fallback chain has a budget so a student never
  // waits minutes for feedback while overloaded models time out one after another.
  const perTry = req.task === "actor" ? 20_000 : req.task === "assistant" ? 90_000 : 35_000;
  const budget = req.task === "actor" ? 40_000 : req.task === "assistant" ? 150_000 : 75_000;
  const started = Date.now();
  for (const t of await ordered(targets)) {
    const left = budget - (Date.now() - started);
    if (left < 4_000) break;
    const t0 = Date.now();
    try {
      const text = await withTimeout(Math.min(perTry, left), (signal) => callOnce(env, t, req, signal));
      if (!text.trim()) throw new ProviderError(502, "empty response");
      logUsage(env, t, req.task, true, opts);
      return { text, target: t };
    } catch (err) {
      console.warn(`AI ${req.task} ${t.provider}/${t.model} failed after ${Date.now() - t0} ms: ${describe(err)}`);
      errors.push(`${t.provider}/${t.model}: ${describe(err)}`);
      cool(t, err, opts);
      logUsage(env, t, req.task, false, opts);
    }
  }
  console.warn("AI unavailable", errors);
  throw new AiUnavailableError(errors.join(" | ") || "No AI provider configured.");
}

/** Streams text chunks. Falls back to the next provider only if the current one fails before its first chunk. */
export async function stream(env: Env, targets: Target[], req: LLMRequest, opts: RouterOpts = {}) {
  const errors: string[] = [];
  for (const t of await ordered(targets)) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15_000);
    try {
      const it = openStream(env, t, req, ctrl.signal)[Symbol.asyncIterator]();
      let first = await untilAborted(it.next(), ctrl.signal);
      while (!first.done && !first.value) first = await untilAborted(it.next(), ctrl.signal);
      if (first.done) throw new ProviderError(502, "empty response");
      clearTimeout(timer);
      logUsage(env, t, req.task, true, opts);
      const firstChunk = first.value;
      const chunks = (async function* () {
        yield firstChunk;
        const overall = setTimeout(() => ctrl.abort(), 90_000);
        try {
          while (true) {
            const n = await untilAborted(it.next(), ctrl.signal);
            if (n.done) break;
            if (n.value) yield n.value;
          }
        } finally {
          clearTimeout(overall);
        }
      })();
      return { target: t, chunks };
    } catch (err) {
      clearTimeout(timer);
      ctrl.abort();
      errors.push(`${t.provider}/${t.model}: ${describe(err)}`);
      cool(t, err, opts);
      logUsage(env, t, req.task, false, opts);
    }
  }
  console.warn("AI unavailable", errors);
  throw new AiUnavailableError(errors.join(" | ") || "No AI provider configured.");
}

// ---------- providers ----------

async function callOnce(env: Env, t: Target, req: LLMRequest, signal: AbortSignal): Promise<string> {
  switch (t.provider) {
    case "mock":
      return req.mock();
    case "gemini": {
      const data = (await (await geminiFetch(t, req, false, signal)).json()) as GeminiResponse;
      return geminiText(data);
    }
    case "groq": {
      const data = (await (await groqFetch(t, req, false, signal)).json()) as OpenAIResponse;
      return data.choices?.[0]?.message?.content ?? "";
    }
    case "workers-ai": {
      const out = (await env.AI!.run(t.model as never, workersInput(req, false) as never)) as unknown;
      return workersText(out);
    }
  }
}

async function* openStream(env: Env, t: Target, req: LLMRequest, signal: AbortSignal): AsyncGenerator<string> {
  switch (t.provider) {
    case "mock": {
      const words = req.mock().split(/(?<=\s)/);
      for (const w of words) {
        await new Promise((r) => setTimeout(r, 12));
        yield w;
      }
      return;
    }
    case "gemini": {
      const res = await geminiFetch(t, req, true, signal);
      for await (const d of sseData(res.body!)) yield geminiText(JSON.parse(d) as GeminiResponse);
      return;
    }
    case "groq": {
      const res = await groqFetch(t, req, true, signal);
      for await (const d of sseData(res.body!)) {
        const j = JSON.parse(d) as OpenAIResponse;
        yield j.choices?.[0]?.delta?.content ?? "";
      }
      return;
    }
    case "workers-ai": {
      const out = (await env.AI!.run(t.model as never, workersInput(req, true) as never)) as unknown;
      if (!(out instanceof ReadableStream)) {
        yield workersText(out);
        return;
      }
      for await (const d of sseData(out as ReadableStream<Uint8Array>)) yield workersText(JSON.parse(d));
      return;
    }
  }
}

interface GeminiResponse {
  candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] }; finishReason?: string }[];
  promptFeedback?: { blockReason?: string };
}

interface OpenAIResponse {
  choices?: { message?: { content?: string }; delta?: { content?: string } }[];
}

function geminiText(d: GeminiResponse): string {
  if (d.promptFeedback?.blockReason) throw new ProviderError(400, `blocked: ${d.promptFeedback.blockReason}`);
  const parts = d.candidates?.[0]?.content?.parts ?? [];
  return parts
    .filter((p) => !p.thought && typeof p.text === "string")
    .map((p) => p.text)
    .join("");
}

async function geminiFetch(t: Target, req: LLMRequest, streaming: boolean, signal: AbortSignal) {
  // Gemma models on the Gemini API take no system instruction or JSON mode, so fold them into the prompt.
  const isGemma = t.model.toLowerCase().startsWith("gemma");
  const contents = req.messages.map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] }));
  if (isGemma && contents.length) contents[0].parts[0].text = `${req.system}\n\n---\n\n${contents[0].parts[0].text}`;
  const generationConfig: Record<string, unknown> = {
    temperature: req.temperature ?? 0.7,
    maxOutputTokens: req.maxTokens ?? 2048,
  };
  if (req.json && !isGemma) generationConfig.responseMimeType = "application/json";
  const thinking = thinkingFor(t.model, req.task);
  if (thinking) generationConfig.thinkingConfig = thinking;
  const payload: Record<string, unknown> = { contents, generationConfig };
  if (!isGemma) payload.systemInstruction = { parts: [{ text: req.system }] };
  const action = streaming ? "streamGenerateContent?alt=sse" : "generateContent";
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(t.model)}:${action}`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-goog-api-key": t.key! },
    body: JSON.stringify(payload),
    signal,
  });
  if (!res.ok) throw new ProviderError(res.status, (await res.text()).slice(0, 300));
  return res;
}

async function groqFetch(t: Target, req: LLMRequest, streaming: boolean, signal: AbortSignal) {
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${t.key}` },
    body: JSON.stringify({
      model: t.model,
      messages: [{ role: "system", content: req.system }, ...req.messages],
      temperature: req.temperature ?? 0.7,
      max_tokens: req.maxTokens ?? 2048,
      stream: streaming,
      ...(req.json ? { response_format: { type: "json_object" } } : {}),
    }),
    signal,
  });
  if (!res.ok) throw new ProviderError(res.status, (await res.text()).slice(0, 300));
  return res;
}

// Workers AI JSON mode needs a schema and can't stream, so JSON is asked for in the prompt instead;
// the grader's reply is parsed leniently either way.
function workersInput(req: LLMRequest, streaming: boolean) {
  const system = req.json ? `${req.system}\n\nReply with one valid JSON object only: no markdown fences and no text before or after it.` : req.system;
  return {
    messages: [{ role: "system", content: system }, ...req.messages],
    max_tokens: Math.min(req.maxTokens ?? 2048, 4096),
    temperature: req.temperature ?? 0.7,
    stream: streaming,
  };
}

function workersText(out: unknown): string {
  if (typeof out === "string") return out;
  const o = out as { response?: unknown; choices?: { message?: { content?: string }; delta?: { content?: string } }[] };
  if (typeof o?.response === "string") return o.response;
  if (o?.response && typeof o.response === "object") return JSON.stringify(o.response);
  return o?.choices?.[0]?.delta?.content ?? o?.choices?.[0]?.message?.content ?? "";
}

export async function* sseData(body: ReadableStream<Uint8Array>): AsyncGenerator<string> {
  const reader = body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  const take = (line: string) => {
    const l = line.trim();
    if (!l.startsWith("data:")) return null;
    const d = l.slice(5).trim();
    return d && d !== "[DONE]" ? d : null;
  };
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let idx: number;
    while ((idx = buf.indexOf("\n")) >= 0) {
      const d = take(buf.slice(0, idx));
      buf = buf.slice(idx + 1);
      if (d) yield d;
    }
  }
  const d = take(buf);
  if (d) yield d;
}

// ---------- helpers ----------

const timeoutError = () => Object.assign(new Error("timeout"), { name: "AbortError" });

/** Rejects as a timeout when `signal` aborts, for calls that ignore the signal themselves (the Workers AI binding does). */
function untilAborted<T>(p: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) return Promise.reject(timeoutError());
  let onAbort = () => {};
  const aborted = new Promise<never>((_, reject) => {
    onAbort = () => reject(timeoutError());
    signal.addEventListener("abort", onAbort, { once: true });
  });
  return Promise.race([p, aborted]).finally(() => signal.removeEventListener("abort", onAbort));
}

/** Aborts the call after `ms`, and gives up waiting even if the call ignores the signal (the Workers AI binding does). */
async function withTimeout<T>(ms: number, fn: (signal: AbortSignal) => Promise<T>): Promise<T> {
  const ctrl = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      ctrl.abort();
      reject(timeoutError());
    }, ms);
  });
  try {
    return await Promise.race([fn(ctrl.signal), timeout]);
  } finally {
    if (timer !== undefined) clearTimeout(timer);
  }
}

function describe(err: unknown): string {
  if (err instanceof ProviderError) return `${err.status} ${err.message.replace(/\s+/g, " ").slice(0, 160)}`;
  if (err instanceof Error) return err.name === "AbortError" ? "timeout" : err.message.slice(0, 160);
  return String(err);
}

function logUsage(env: Env, t: Target, task: Task, ok: boolean, opts: RouterOpts) {
  if (t.provider === "mock") return;
  const p = env.DB.prepare(
    `INSERT INTO usage (day, provider, model, task, requests, errors) VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(day, provider, model, task) DO UPDATE SET requests = requests + excluded.requests, errors = errors + excluded.errors`,
  )
    .bind(today(), `${t.provider}:${t.source}`, t.model, task, ok ? 1 : 0, ok ? 0 : 1)
    .run()
    .catch(() => undefined);
  if (opts.waitUntil) opts.waitUntil(p);
}
