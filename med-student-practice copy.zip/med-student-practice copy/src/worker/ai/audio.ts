// Audio features on the free Gemini API: live-voice tokens, speech-to-text, and voice analysis.
import type { Env } from "../env";
import type { ProsodyAi } from "../../shared/types";
import type { StoredKey } from "./router";
import { cooldownUrl, shareCooldown, sharedCooldowns } from "./router";
import { PACE_FAST, PACE_SLOW, prosodyPrompt, type SpeechMeasures } from "./prompts";
import { parseLooseJson, tidy } from "./grade";
import { today } from "../util";

const API = "https://generativelanguage.googleapis.com";
// Measured Oct 2026: 3.8 Live answers fastest; the others are working fallbacks.
export const LIVE_MODELS = ["gemini-3.8-live", "gemini-3.1-flash-live-preview", "gemini-2.5-flash-native-audio-latest"];

/** Gemini keys in priority order: the student's, the course's, then the platform's. */
export function geminiKeys(env: Env, keys: StoredKey[]): string[] {
  const out = keys.filter((k) => k.provider === "gemini").map((k) => k.key);
  if (env.GEMINI_API_KEY) out.push(env.GEMINI_API_KEY);
  return [...new Set(out)];
}

function count(env: Env, model: string, task: string, ok: boolean, waitUntil?: (p: Promise<unknown>) => void) {
  const p = env.DB.prepare(
    `INSERT INTO usage (day, provider, model, task, requests, errors) VALUES (?, 'gemini:audio', ?, ?, ?, ?)
     ON CONFLICT(day, provider, model, task) DO UPDATE SET requests = requests + excluded.requests, errors = errors + excluded.errors`,
  )
    .bind(today(), model, task, ok ? 1 : 0, ok ? 0 : 1)
    .run()
    .catch(() => undefined);
  waitUntil?.(p);
}

/** One-use token for a browser Live session with the patient's instructions locked server-side. */
export async function liveToken(env: Env, keys: string[], system: string, voiceName: string, waitUntil?: (p: Promise<unknown>) => void) {
  const now = Date.now();
  let lastError = "No Google AI key is configured.";
  for (const key of keys) {
    for (const model of LIVE_MODELS) {
      const body = {
        uses: 1,
        expireTime: new Date(now + 35 * 60_000).toISOString(),
        newSessionExpireTime: new Date(now + 2 * 60_000).toISOString(),
        bidiGenerateContentSetup: {
          model: `models/${model}`,
          generationConfig: { responseModalities: ["AUDIO"], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } } },
          systemInstruction: { parts: [{ text: system }] },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          sessionResumption: {},
          contextWindowCompression: { slidingWindow: {} },
        },
      };
      const res = await fetch(`${API}/v1beta/auth_tokens`, { method: "POST", headers: { "content-type": "application/json", "x-goog-api-key": key }, body: JSON.stringify(body) });
      const data = (await res.json().catch(() => ({}))) as { name?: string; error?: { message?: string } };
      count(env, model, "live", res.ok, waitUntil);
      if (res.ok && data.name) return { token: data.name, model };
      lastError = data.error?.message ?? `HTTP ${res.status}`;
    }
  }
  throw new Error(lastError);
}

function toBase64(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

async function generate(key: string, model: string, parts: unknown[], json: boolean) {
  const generationConfig: Record<string, unknown> = { temperature: 0 };
  if (json) generationConfig.responseMimeType = "application/json";
  if (/^gemini-3\.\d+-flash$/.test(model)) generationConfig.thinkingConfig = { thinkingLevel: "low" };
  const res = await fetch(`${API}/v1beta/models/${model}:generateContent`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-goog-api-key": key },
    body: JSON.stringify({ contents: [{ role: "user", parts }], generationConfig }),
    signal: AbortSignal.timeout(45_000),
  });
  if (!res.ok) throw new Error(`${res.status} ${(await res.text()).slice(0, 160)}`);
  const d = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
  return (d.candidates?.[0]?.content?.parts ?? [])
    .filter((p) => !p.thought)
    .map((p) => p.text ?? "")
    .join("");
}

/** Uploads audio to the Files API. The body is passed through untouched, so it costs almost no Worker CPU. */
async function uploadAudio(key: string, wav: ArrayBuffer): Promise<{ fileData: { mimeType: string; fileUri: string } }> {
  const up = await fetch(`${API}/upload/v1beta/files?uploadType=media`, { method: "POST", headers: { "content-type": "audio/wav", "x-goog-api-key": key }, body: wav });
  const file = ((await up.json()) as { file?: { uri: string; mimeType: string } }).file;
  if (!up.ok || !file) throw new Error(`upload ${up.status}`);
  return { fileData: { mimeType: file.mimeType, fileUri: file.uri } };
}

// Base64-encoding audio costs about 1.6 ms of CPU per 100 KB. Cloudflare's free plan allows 10 ms per
// request, so only short clips (under ~9 s) are sent inline; longer ones go through the Files API.
const INLINE_MAX = 300_000;

export async function transcribe(env: Env, keys: string[], wav: ArrayBuffer, languageName: string, waitUntil?: (p: Promise<unknown>) => void): Promise<string> {
  const prompt = { text: `Transcribe this speech exactly as spoken (expected language: ${languageName}). Return only the words, with no labels or commentary. If there is no speech, return nothing.` };
  const inline = wav.byteLength <= INLINE_MAX ? { inlineData: { mimeType: "audio/wav", data: toBase64(wav) } } : null;
  let last = "";
  for (const key of keys) {
    let audio: unknown = inline;
    if (!audio) {
      try {
        audio = await uploadAudio(key, wav);
      } catch (err) {
        last = (err as Error).message;
        continue;
      }
    }
    for (const model of ["gemini-flash-lite-latest", "gemini-3.1-flash-lite"]) {
      try {
        const text = await generate(key, model, [audio, prompt], false);
        count(env, model, "stt", true, waitUntil);
        return text.trim().replace(/^["“]|["”]$/g, "");
      } catch (err) {
        count(env, model, "stt", false, waitUntil);
        last = (err as Error).message;
      }
    }
  }
  throw new Error(last || "No Google AI key is configured.");
}

/** Below this much of the student's own speech, tone ratings are not fair, so no AI is asked. */
export const MIN_SPEECH_SEC = 30;

export const TOO_LITTLE_SPEECH: ProsodyAi = {
  dimensions: [],
  summary: "Not enough of your speech was recorded to rate your tone fairly. Speak for at least 30 seconds in a voice encounter to get tone ratings.",
  tips: [],
  insufficient: true,
};

/** Seconds of audio in a PCM WAV, read from its header (the browser sends 16 kHz 16-bit mono with a 44-byte header). */
export function wavSeconds(buf: ArrayBuffer): number {
  if (buf.byteLength < 44) return 0;
  const v = new DataView(buf);
  let byteRate = 32_000;
  let dataBytes = buf.byteLength - 44;
  if (v.getUint32(0, false) === 0x52494646 /* RIFF */) {
    // Walk the few chunks for "fmt " (byte rate) and "data" (length).
    for (let off = 12, i = 0; off + 8 <= buf.byteLength && i < 16; i++) {
      const id = v.getUint32(off, false);
      const size = v.getUint32(off + 4, true);
      if (id === 0x666d7420 /* fmt */ && off + 20 <= buf.byteLength) byteRate = v.getUint32(off + 16, true) || byteRate;
      if (id === 0x64617461 /* data */) {
        dataBytes = Math.min(size, buf.byteLength - off - 8);
        break;
      }
      off += 8 + size + (size & 1);
    }
  }
  return Math.max(0, dataBytes) / byteRate;
}

const PACE_NAME = /pace|speed|rate|tempo/i;

/** The Pace rating must agree with the measured pace: outside 110-170 words per minute it is at most 3 and says so. */
export function clampPace(dims: ProsodyAi["dimensions"], wpm: number | null): ProsodyAi["dimensions"] {
  if (wpm === null || (wpm <= PACE_FAST && wpm >= PACE_SLOW)) return dims;
  const fast = wpm > PACE_FAST;
  const said = `You spoke at about ${wpm} words per minute, ${fast ? `faster than the comfortable ${PACE_SLOW} to ${PACE_FAST}. Slow down, especially when explaining or giving news.` : `slower than the usual ${PACE_SLOW} to ${PACE_FAST}. That suits difficult news; otherwise keep the conversation moving.`}`;
  const i = dims.findIndex((d) => PACE_NAME.test(d.name));
  if (i < 0) return [...dims, { name: "Pace", score: 2, comment: said }];
  const d = dims[i];
  const named = d.comment.includes(String(wpm)) && new RegExp(fast ? "fast|quick|rush|hurr" : "slow", "i").test(d.comment);
  return dims.map((x, j) => (j === i ? { ...x, score: Math.min(3, x.score), comment: named ? x.comment : said } : x));
}

/** A listening model rates how the student sounds; the measured pace is passed in so the two can't disagree. */
export async function analyzeVoice(env: Env, keys: string[], wav: ArrayBuffer, measured: SpeechMeasures, waitUntil?: (p: Promise<unknown>) => void): Promise<ProsodyAi> {
  if (measured.seconds < MIN_SPEECH_SEC) return { ...TOO_LITTLE_SPEECH };
  const prompt = { text: prosodyPrompt(measured) };
  let last = "";
  for (const key of keys) {
    try {
      const audio = await uploadAudio(key, wav);
      // Flash-Lite first: full Flash allows only about 20 free requests a day, so it is kept for grading.
      for (const model of ["gemini-flash-lite-latest", "gemini-3.1-flash-lite", "gemini-3.6-flash"]) {
        try {
          const text = await generate(key, model, [audio, prompt], true);
          const raw = parseLooseJson(text) as Partial<ProsodyAi> | null;
          const dims = (Array.isArray(raw?.dimensions) ? raw.dimensions : [])
            .map((d) => ({ name: tidy(String(d?.name ?? "")).slice(0, 40), score: Math.max(1, Math.min(5, Math.round(Number(d?.score) || 0))), comment: tidy(String(d?.comment ?? "")).slice(0, 300) }))
            .filter((d) => d.name)
            .slice(0, 6);
          if (!raw || !dims.length) throw new Error("unreadable JSON");
          count(env, model, "prosody", true, waitUntil);
          return {
            dimensions: clampPace(dims, measured.wpm),
            summary: tidy(String(raw.summary ?? "")).slice(0, 600),
            tips: (Array.isArray(raw.tips) ? raw.tips : []).map((t) => tidy(String(t)).slice(0, 300)).filter(Boolean).slice(0, 4),
            provider: `gemini/${model}`,
          };
        } catch (err) {
          count(env, model, "prosody", false, waitUntil);
          last = (err as Error).message;
        }
      }
    } catch (err) {
      last = (err as Error).message;
    }
  }
  throw new Error(last || "No Google AI key is configured.");
}

// ---------- natural text-to-speech ----------

// All four answered on the free tier with human-sounding, emotional speech (Oct 2026); each has its own quota.
export const TTS_MODELS = ["gemini-3.8-flash-lite-tts", "gemini-2.5-flash-preview-tts", "gemini-3.1-flash-tts-preview", "gemini-3.8-flash-tts"];

const DELIVERY: Record<string, string> = {
  anxious: "in a worried, slightly shaky voice",
  in_pain: "slowly, through real discomfort, with small pained breaths",
  sad: "quietly and sadly",
  angry: "in a frustrated, clipped voice",
  confused: "uncertainly, a little hesitant",
  relieved: "with audible relief",
  embarrassed: "a bit awkwardly, softer than usual",
  calm: "calmly and naturally",
  neutral: "naturally, like a real person talking to their doctor",
};

/** The spoken line plus a short stage direction the TTS model follows but does not read aloud. */
export function deliveryPrompt(text: string, emotion: string, persona: string): string {
  const clean = text.replace(/\*[^*]*\*/g, " ").replace(/\[[^\]]*\]/g, " ").replace(/\s+/g, " ").trim();
  return `Say ${DELIVERY[emotion] ?? DELIVERY.neutral}, as ${persona}: ${clean}`;
}

// Cooldowns per model AND key (each key has its own quota), shared across instances through the Cache API.
const ttsCooling = new Map<string, number>();
const ttsUrl = (model: string, key: string) => cooldownUrl("gemini-tts", model, key);

/** Streams Gemini TTS audio (server-sent events) straight through to the browser. */
export async function ttsStream(env: Env, keys: string[], prompt: string, voiceName: string, waitUntil?: (p: Promise<unknown>) => void): Promise<Response> {
  let last = "No Google AI key is configured.";
  const now = Date.now();
  const shared = await sharedCooldowns(keys.flatMap((k) => TTS_MODELS.map((m) => ttsUrl(m, k))));
  for (const [url, until] of shared) if (until > (ttsCooling.get(url) ?? 0)) ttsCooling.set(url, until);
  const cooling = (model: string, key: string) => Number((ttsCooling.get(ttsUrl(model, key)) ?? 0) > now);
  for (const key of keys) {
    const models = [...TTS_MODELS].sort((a, b) => cooling(a, key) - cooling(b, key));
    for (const model of models) {
      const res = await fetch(`${API}/v1beta/models/${model}:streamGenerateContent?alt=sse`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { responseModalities: ["AUDIO"], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } } },
        }),
        signal: AbortSignal.timeout(20_000),
      }).catch((e: Error) => ({ ok: false, status: 0, text: async () => e.message }) as unknown as Response);
      count(env, model, "tts", res.ok, waitUntil);
      if (res.ok && res.body) return res;
      last = `${res.status} ${(await res.text()).slice(0, 160)}`;
      const until = Date.now() + (res.status === 429 ? 10 * 60_000 : 60_000);
      ttsCooling.set(ttsUrl(model, key), until);
      shareCooldown(ttsUrl(model, key), until, waitUntil);
    }
  }
  throw new Error(last);
}
