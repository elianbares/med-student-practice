// Demo AI used when no free key is configured. It answers from the case text with simple keyword
// rules so every screen can be tried and tested; a real key replaces it automatically.
import type { ConfigData, Message, ProfileData } from "../../shared/types";
import type { AssistantInput } from "./prompts";

const sentences = (t: string) =>
  t
    .split(/(?<=[.!?])\s+/)
    .map((x) => x.trim())
    .filter(Boolean);

const TOPICS: { re: RegExp; field: (p: ProfileData) => string; pick?: RegExp }[] = [
  { re: /allerg/, field: (p) => p.medsAllergies, pick: /allerg/i },
  { re: /medic|pill|tablet|prescri|take any|taking/, field: (p) => p.medsAllergies },
  { re: /family|mother|father|mom|dad|parent|sibling|brother|sister|run in/, field: (p) => p.familyHistory },
  { re: /smok|alcohol|drink|drug|work|job|live|married|partner|exercise|diet|sexual|home/, field: (p) => p.socialHistory },
  { re: /medical history|medical problems|conditions|surgery|operation|hospital|diagnosed|health problems/, field: (p) => p.pmh },
  { re: /when|how long|start|began|first notice|onset/, field: (p) => p.hpi, pick: /\d|ago|day|week|month|morning|night|yesterday/i },
  { re: /pain|hurt|ache|where|describe|severe|scale|worse|better/, field: (p) => p.hpi, pick: /pain|hurt|ache|worse|better|sharp|dull|scale/i },
  { re: /what brings|how can i help|what's going on|what is going on|tell me|go on|anything else|more about/, field: (p) => p.hpi },
];

const SYMPTOM = /fever|weight|sleep|appetite|nause|vomit|bowel|stool|urin|cough|breath|chest|head|dizz|vision|rash|bleed|tired|fatigue|cold|sweat|numb|weak/;

export function mockPatient(p: ProfileData, messages: Message[]): string {
  const doctor = messages.filter((m) => m.role === "doctor");
  const last = (doctor[doctor.length - 1]?.text ?? "").toLowerCase();
  const emotion = p.initialEmotion || (p.personality.neuroticism === "high" ? "anxious" : "calm");
  const say = (text: string, e = emotion) => `[emotion: ${e}] ${text}`;

  if (/^(hi|hello|good (morning|afternoon|evening))\b|my name is|i'm dr|i am dr|nice to meet/.test(last) && doctor.length <= 2) {
    return say(`Hello, doctor. I came in because ${p.chiefComplaint.replace(/^i\s/i, "I ") || "I haven't been feeling well"}.`);
  }
  if (/examin|exam |listen to|check your|blood test|x-ray|scan|order/.test(last)) return say("Sure, go ahead.");
  if (/diagnos|you have|it looks like|i think you|this is likely/.test(last)) return say("Oh... okay. What does that mean for me?", "anxious");
  if (/worr|concern|scared|afraid|expect|hoping/.test(last)) return say("Honestly, I'm worried it could be something serious.", "anxious");
  if (/thank|bye|that's all|see you/.test(last)) return say("Thank you, doctor. I appreciate it.", "relieved");

  for (const topic of TOPICS) {
    if (!topic.re.test(last)) continue;
    const all = sentences(topic.field(p));
    const pool = topic.pick ? all.filter((x) => topic.pick!.test(x)) : all;
    const options = pool.length ? pool : all;
    if (!options.length) return say("No, nothing like that.");
    const asked = doctor.slice(0, -1).filter((m) => topic.re.test(m.text.toLowerCase())).length;
    return say(firstPerson(options[asked % options.length]));
  }
  const symptom = last.match(SYMPTOM)?.[0];
  if (symptom) {
    const hit = sentences(`${p.hpi} ${p.ros}`).find((x) => x.toLowerCase().includes(symptom));
    return say(hit ? firstPerson(hit) : "No, I haven't noticed anything like that.");
  }
  return say("Sorry, I'm not sure what you mean. Could you ask that another way?", "confused");
}

/** Case text is written by clinicians in the third person; make it sound like the patient. */
function firstPerson(s: string): string {
  return s
    .replace(/\b[Tt]he patient\b|\b[Ss]he\b|\b[Hh]e\b/g, "I")
    .replace(/\b[Hh]er\b|\b[Hh]is\b/g, "my")
    .replace(/\bI (reports|describes|denies|notes|states|has|is|was)\b/g, (_m, v: string) => `I ${{ reports: "have", describes: "would describe", denies: "don't have", notes: "noticed", states: "say", has: "have", is: "am", was: "was" }[v]}`);
}

export function mockFeedback(cfg: ConfigData, messages: Message[]): string {
  const doctor = messages.filter((m) => m.role === "doctor").map((m) => m.text);
  const openQs = doctor.filter((t) => /^(what|how|tell me|describe|can you tell|could you tell)/i.test(t.trim()));
  const intro = doctor.find((t) => /my name is|i'm (dr|doctor)|i am (dr|a)|medical student/i.test(t));
  const top = cfg.levels.length - 1;
  const lvl = (score: number) => cfg.levels[Math.max(0, Math.min(top, score))];
  const base = doctor.length < 3 ? 0 : doctor.length < 8 ? 1 : 2;
  // Strengths only where a real line shows them; the demo never invents praise.
  const praise = (i: number) => (i === 0 && intro ? { quote: intro, text: "You introduced yourself and your role." } : i === 1 && openQs[0] ? { quote: openQs[0], text: "You used an open question to let the patient tell their story." } : null);
  const rubric = cfg.rubric.map((r, i) => {
    const good = praise(i);
    return {
      category: r.name,
      level: lvl(i === 0 ? base + (intro ? 1 : -1) : i === 1 ? base + (openQs.length >= 2 ? 1 : 0) : base),
      evidence: good ? [{ quote: good.quote, kind: "praise" }] : doctor.slice(i, i + 1).map((quote) => ({ quote, kind: "improve" })),
      strengths: good?.text ?? "",
      improve: "Try an open question such as \"Can you tell me more about that?\" before narrowing down.",
    };
  });
  return JSON.stringify({
    diagnosisVerdict: cfg.diagnosisType === "diagnosis" ? "partial" : "n/a",
    diagnosisSupport: cfg.diagnosisType !== "diagnosis" ? "n/a" : doctor.length < 4 ? "unsupported" : doctor.length < 8 ? "partly" : "supported",
    diagnosisComment: "Demo feedback: compare your diagnosis with the correct one shown above.",
    rubric,
    historyMissed: ["Did you ask about medications and allergies?", "Did you ask about family history?"],
    differential: ["(Demo) Add a free AI key to get a real differential"],
    testsComment: "Demo feedback: review which tests were expected.",
    notesFeedback: cfg.notesFeedback.enabled ? "Demo feedback on your note: organize it as Subjective, Objective, Assessment and Plan." : "",
    summary: `Demo AI feedback based on ${doctor.length} questions. Add a free Google AI key to get real, detailed coaching.`,
    nextSteps: ["Introduce yourself and your role", "Start with an open question", "Summarize what you heard before closing"],
  });
}

export function mockProfile(a: AssistantInput): string {
  const dx = a.diagnosis || "Community-acquired pneumonia";
  return JSON.stringify({
    name: `${dx.slice(0, 40)} (demo draft)`,
    profile: {
      demographics: { name: "Jordan Lee", age: "45", sex: "Female", occupation: "Office manager", other: "" },
      voice: { gender: "female", age: "adult" },
      diagnosis: dx,
      patientKnowsDiagnosis: false,
      chiefComplaint: "I just haven't been feeling right",
      hpi: `Demo draft for: ${dx}. Replace this with the onset, timing, severity and associated symptoms. Add a free AI key to have the assistant write a full, realistic history.`,
      pmh: "Hypertension.",
      medsAllergies: "Lisinopril 10 mg daily. No known drug allergies.",
      familyHistory: "Mother with type 2 diabetes.",
      socialHistory: "Never smoker. Drinks a glass of wine on weekends. Lives with partner.",
      ros: "Denies weight loss.",
      personality: { openness: "medium", conscientiousness: "medium", extraversion: "medium", agreeableness: "high", neuroticism: "medium", notes: a.big5 },
      communication: a.communication,
      other: "",
      tests: [
        { category: "Vital signs", name: "Vital signs", result: "BP 132/84 mmHg, HR 88, RR 16, T 37.1 °C, SpO2 98% on room air", expected: true },
        { category: "Physical exam", name: "General appearance", result: "Alert, in no acute distress", expected: true },
        { category: "Laboratory", name: "Complete blood count", result: "WBC 7.2 x10^9/L, Hb 13.5 g/dL, platelets 250 x10^9/L", expected: true },
      ],
    },
  });
}
