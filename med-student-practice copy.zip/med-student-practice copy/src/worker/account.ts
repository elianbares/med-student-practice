// "Download my data" and "Delete my account". The export is assembled as JSON inside D1 (json_object),
// so the Worker only joins strings and stays well inside the free-plan CPU budget.
import type { Context } from "hono";
import type { AppEnv } from "./env";
import { clearSessionCookie, confirmPassword } from "./auth";
import { body, fail, str } from "./util";

const iso = (col: string) => `CASE WHEN ${col} IS NULL THEN NULL ELSE strftime('%Y-%m-%dT%H:%M:%SZ', ${col} / 1000, 'unixepoch') END`;
const raw = (col: string) => `CASE WHEN json_valid(${col}) THEN json(${col}) ELSE NULL END`;

/** GET /api/me/export: everything stored about the signed-in user, as a JSON download. */
export async function exportAccount(c: Context<AppEnv>): Promise<Response> {
  const u = c.get("user");
  const db = c.env.DB;
  const [account, enrollments, encounters, written, notifications] = await db.batch<{ j: string }>([
    db
      .prepare(
        `SELECT json_object('id', id, 'email', email, 'name', name, 'role', role, 'createdAt', ${iso("created_at")},
           'hasOwnAiKey', json(CASE WHEN ai_key_enc IS NULL THEN 'false' ELSE 'true' END)) AS j FROM users WHERE id = ?`,
      )
      .bind(u.id),
    db
      .prepare(
        `SELECT json_object('courseId', e.course_id, 'courseName', co.name, 'joinedAt', ${iso("e.joined_at")}) AS j
         FROM enrollments e LEFT JOIN courses co ON co.id = e.course_id WHERE e.user_id = ? ORDER BY e.joined_at`,
      )
      .bind(u.id),
    // The case snapshot is left out: it holds the hidden case details (diagnosis, unrevealed results).
    db
      .prepare(
        `SELECT json_object('id', e.id, 'courseId', e.course_id, 'courseName', co.name,
           'caseName', json_extract(e.snapshot, '$.caseName'), 'configurationName', json_extract(e.snapshot, '$.configName'),
           'mode', e.mode, 'language', e.language, 'status', e.status,
           'startedAt', ${iso("e.started_at")}, 'endedAt', ${iso("e.ended_at")},
           'messages', ${raw("e.messages")}, 'orders', ${raw("e.orders")}, 'tasksDone', ${raw("e.tasks_done")},
           'notepad', e.notepad, 'diagnosis', e.diagnosis, 'note', e.note,
           'feedback', ${raw("e.feedback")}, 'voiceMetrics', ${raw("e.prosody")}, 'voiceAnalysis', ${raw("e.prosody_ai")},
           'comments', json((SELECT json_group_array(json_object('author', us.name, 'messageIndex', cm.message_idx, 'body', cm.body, 'createdAt', ${iso("cm.created_at")}))
             FROM comments cm LEFT JOIN users us ON us.id = cm.author_id WHERE cm.encounter_id = e.id))) AS j
         FROM encounters e LEFT JOIN courses co ON co.id = e.course_id WHERE e.user_id = ? ORDER BY e.started_at`,
      )
      .bind(u.id),
    db
      .prepare(
        `SELECT json_object('encounterId', encounter_id, 'messageIndex', message_idx, 'body', body, 'createdAt', ${iso("created_at")}) AS j
         FROM comments WHERE author_id = ? ORDER BY created_at`,
      )
      .bind(u.id),
    db
      .prepare(
        `SELECT json_object('kind', kind, 'body', body, 'read', json(CASE WHEN read = 1 THEN 'true' ELSE 'false' END), 'createdAt', ${iso("created_at")}) AS j
         FROM notifications WHERE user_id = ? ORDER BY created_at`,
      )
      .bind(u.id),
  ]);
  const list = (r: D1Result<{ j: string }>) => `[${r.results.map((x) => x.j).join(",")}]`;
  const now = new Date().toISOString();
  const json =
    `{"app":"Med Student Practice AI","exportedAt":"${now}","account":${account.results[0]?.j ?? "null"},` +
    `"enrollments":${list(enrollments)},"encounters":${list(encounters)},"commentsWritten":${list(written)},"notifications":${list(notifications)}}`;
  return new Response(json, {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "content-disposition": `attachment; filename="med-student-practice-ai-data-${now.slice(0, 10)}.json"`,
      "cache-control": "no-store",
    },
  });
}

/**
 * DELETE /api/me with { passwordHash }: removes the account and the student's data.
 * Educators first archive or hand over courses that still have students; their empty courses are
 * deleted, archived courses with students pass to the site admins, private unused library items are
 * deleted and the rest (public or used in a course) pass to the site.
 */
export async function deleteAccount(c: Context<AppEnv>): Promise<Response> {
  const u = c.get("user");
  const b = await body(c.req);
  await confirmPassword(c.env, u.id, str(b.passwordHash ?? b.clientHash, 64));
  const db = c.env.DB;
  if (u.role === "admin") {
    const admins = await db.prepare(`SELECT COUNT(*) AS n FROM users WHERE role = 'admin'`).first<{ n: number }>();
    if ((admins?.n ?? 0) <= 1) fail(409, "This is the only admin account, so it can't be deleted. Set up another admin first.");
  }
  const busy = await db
    .prepare(`SELECT 1 AS x FROM courses c WHERE c.owner_id = ? AND c.archived = 0 AND EXISTS (SELECT 1 FROM enrollments e WHERE e.course_id = c.id) LIMIT 1`)
    .bind(u.id)
    .first();
  if (busy) fail(409, "Archive or hand over your courses before deleting your account.");
  const empty = `SELECT id FROM courses c WHERE c.owner_id = ?1 AND NOT EXISTS (SELECT 1 FROM enrollments e WHERE e.course_id = c.id)`;
  const unusedCases = `SELECT id FROM cases WHERE owner_id = ?1 AND is_public = 0 AND id NOT IN (SELECT case_id FROM assignments)`;
  const mine = `SELECT id FROM encounters WHERE user_id = ?1`;
  const sql = [
    // Courses. Students who left an empty course keep its encounters in their own history, as with deleting a course.
    `UPDATE encounters SET course_id = NULL, assignment_id = NULL WHERE course_id IN (${empty})`,
    `DELETE FROM assignments WHERE course_id IN (${empty})`,
    `DELETE FROM course_staff WHERE course_id IN (${empty})`,
    `DELETE FROM courses WHERE id IN (${empty})`,
    `UPDATE courses SET owner_id = 'system' WHERE owner_id = ?1`,
    // Library
    `DELETE FROM case_configs WHERE case_id IN (${unusedCases})`,
    `DELETE FROM cases WHERE id IN (${unusedCases})`,
    `DELETE FROM profiles WHERE owner_id = ?1 AND is_public = 0 AND id NOT IN (SELECT profile_id FROM cases)`,
    `DELETE FROM configurations WHERE owner_id = ?1 AND is_public = 0 AND id NOT IN (SELECT config_id FROM assignments) AND id NOT IN (SELECT config_id FROM case_configs)`,
    `UPDATE cases SET owner_id = 'system' WHERE owner_id = ?1`,
    `UPDATE profiles SET owner_id = 'system' WHERE owner_id = ?1`,
    `UPDATE configurations SET owner_id = 'system' WHERE owner_id = ?1`,
    // Practice data
    `DELETE FROM notifications WHERE ref_id IN (${mine})`,
    `DELETE FROM comments WHERE encounter_id IN (${mine})`,
    `DELETE FROM encounters WHERE user_id = ?1`,
    `DELETE FROM comments WHERE author_id = ?1`,
    `DELETE FROM enrollments WHERE user_id = ?1`,
    `DELETE FROM course_staff WHERE user_id = ?1`,
    `DELETE FROM notifications WHERE user_id = ?1`,
    `DELETE FROM reset_codes WHERE user_id = ?1`,
    `DELETE FROM auth_attempts WHERE key IN ('signin:email:' || ?2, 'reset:email:' || ?2, 'password:user:' || ?1)`,
    // The account itself, with its stored AI key
    `DELETE FROM users WHERE id = ?1`,
  ];
  // D1 runs a batch as one transaction, so a failure leaves the account untouched.
  await db.batch(sql.map((s) => db.prepare(s).bind(...(s.includes("?2") ? [u.id, u.email] : [u.id]))));
  clearSessionCookie(c);
  return c.json({ ok: true });
}
