// Database schema, self-migration and app secrets. The Worker creates its own tables on first run,
// so deploying needs no separate migration step.
import type { Env } from "./env";
import { randomHex, sha256Hex } from "./crypto";
import { SEED_VERSION, seedDatabase } from "./seed";

const SCHEMA_VERSION = "3";

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, role TEXT NOT NULL,
    pw_salt TEXT NOT NULL, pw_hash TEXT NOT NULL, ai_key_enc TEXT, created_at INTEGER NOT NULL,
    session_version INTEGER NOT NULL DEFAULT 0)`,
  `CREATE TABLE IF NOT EXISTS profiles (
    id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, name TEXT NOT NULL, data TEXT NOT NULL,
    is_public INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS configurations (
    id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, name TEXT NOT NULL, data TEXT NOT NULL,
    is_public INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS cases (
    id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
    profile_id TEXT NOT NULL, is_public INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS case_configs (case_id TEXT NOT NULL, config_id TEXT NOT NULL, PRIMARY KEY (case_id, config_id))`,
  `CREATE TABLE IF NOT EXISTS courses (
    id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
    banner TEXT NOT NULL DEFAULT '', code TEXT NOT NULL UNIQUE, enrollment_open INTEGER NOT NULL DEFAULT 1,
    archived INTEGER NOT NULL DEFAULT 0, ai_key_enc TEXT, created_at INTEGER NOT NULL,
    retention_days INTEGER NOT NULL DEFAULT 0)`,
  `CREATE TABLE IF NOT EXISTS course_staff (course_id TEXT NOT NULL, user_id TEXT NOT NULL, PRIMARY KEY (course_id, user_id))`,
  `CREATE TABLE IF NOT EXISTS assignments (
    id TEXT PRIMARY KEY, course_id TEXT NOT NULL, case_id TEXT NOT NULL, config_id TEXT NOT NULL,
    position INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_assignments_course ON assignments(course_id)`,
  `CREATE TABLE IF NOT EXISTS enrollments (course_id TEXT NOT NULL, user_id TEXT NOT NULL, joined_at INTEGER NOT NULL, PRIMARY KEY (course_id, user_id))`,
  `CREATE INDEX IF NOT EXISTS idx_enrollments_user ON enrollments(user_id)`,
  `CREATE TABLE IF NOT EXISTS encounters (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL, assignment_id TEXT, course_id TEXT, case_id TEXT NOT NULL,
    config_id TEXT NOT NULL, mode TEXT NOT NULL, language TEXT NOT NULL, status TEXT NOT NULL,
    messages TEXT NOT NULL DEFAULT '[]', orders TEXT NOT NULL DEFAULT '[]', notepad TEXT NOT NULL DEFAULT '',
    tasks_done TEXT NOT NULL DEFAULT '[]', diagnosis TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
    feedback TEXT, prosody TEXT, snapshot TEXT NOT NULL, started_at INTEGER NOT NULL, ended_at INTEGER)`,
  `CREATE INDEX IF NOT EXISTS idx_encounters_user ON encounters(user_id, started_at)`,
  `CREATE INDEX IF NOT EXISTS idx_encounters_course ON encounters(course_id, started_at)`,
  `CREATE TABLE IF NOT EXISTS comments (
    id TEXT PRIMARY KEY, encounter_id TEXT NOT NULL, message_idx INTEGER NOT NULL, author_id TEXT NOT NULL,
    body TEXT NOT NULL, created_at INTEGER NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_comments_encounter ON comments(encounter_id)`,
  `CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL, kind TEXT NOT NULL, ref_id TEXT NOT NULL, body TEXT NOT NULL,
    read INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, read)`,
  `CREATE TABLE IF NOT EXISTS reset_codes (code_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS usage (
    day TEXT NOT NULL, provider TEXT NOT NULL, model TEXT NOT NULL, task TEXT NOT NULL,
    requests INTEGER NOT NULL DEFAULT 0, errors INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (day, provider, model, task))`,
  // Sign-in, sign-up and enrollment throttling (see limits.ts). One row per key and time window.
  `CREATE TABLE IF NOT EXISTS auth_attempts (key TEXT PRIMARY KEY, window_start INTEGER NOT NULL, count INTEGER NOT NULL)`,
];

/** Columns added after the first release, so existing databases are migrated in place. */
const ADDED_COLUMNS: [table: string, column: string, definition: string][] = [
  // v2: AI voice analysis is stored separately so it can arrive after grading.
  ["encounters", "prosody_ai", "TEXT"],
  // v3: bumping the version ends every session of that user (sign-out, password reset or change).
  ["users", "session_version", "INTEGER NOT NULL DEFAULT 0"],
  // v3: days to keep encounters in a course; 0 keeps them forever.
  ["courses", "retention_days", "INTEGER NOT NULL DEFAULT 0"],
];

let ready: Promise<void> | null = null;

export function ensureSchema(env: Env): Promise<void> {
  if (!ready) {
    ready = migrate(env).catch((err) => {
      ready = null; // retry on the next request
      throw err;
    });
  }
  return ready;
}

async function migrate(env: Env): Promise<void> {
  const db = env.DB;
  const current = await db
    .prepare(`SELECT value FROM meta WHERE key = 'schema_version'`)
    .first<{ value: string }>()
    .catch(() => null);
  if (current?.value !== SCHEMA_VERSION) {
    await db.batch(SCHEMA.map((sql) => db.prepare(sql)));
    for (const [table, column, definition] of ADDED_COLUMNS) {
      const cols = await db.prepare(`PRAGMA table_info(${table})`).all<{ name: string }>();
      if (!cols.results.some((c) => c.name === column)) await db.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run();
    }
    await db
      .prepare(`INSERT INTO meta (key, value) VALUES ('schema_version', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`)
      .bind(SCHEMA_VERSION)
      .run();
  }
  const seeded = await db.prepare(`SELECT value FROM meta WHERE key = 'seed_version'`).first<{ value: string }>();
  if (seeded?.value !== SEED_VERSION) {
    await seedDatabase(db);
    await db
      .prepare(`INSERT INTO meta (key, value) VALUES ('seed_version', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`)
      .bind(SEED_VERSION)
      .run();
  }
}

export interface Secrets {
  sessionSecret: string;
  /** Key used for new encryption: ENC_KEY when set, otherwise the generated key in the database. */
  encKey: string;
  /** Keys to try when decrypting, newest first, so rows written before ENC_KEY was set still decrypt. */
  decryptKeys: string[];
}

let secrets: Secrets | null = null;

const HEX64 = /^[0-9a-f]{64}$/i;

/**
 * Session-signing and key-encryption secrets. SESSION_SECRET and ENC_KEY (Worker secrets) win;
 * otherwise values generated once and kept in the meta table are used, which is fine for local dev.
 */
export async function getSecrets(env: Env): Promise<Secrets> {
  if (secrets) return secrets;
  const db = env.DB;
  const envSession = env.SESSION_SECRET?.trim() || "";
  const envEnc = env.ENC_KEY?.trim() ? (HEX64.test(env.ENC_KEY.trim()) ? env.ENC_KEY.trim().toLowerCase() : await sha256Hex(`enc:${env.ENC_KEY.trim()}`)) : "";
  const missing: D1PreparedStatement[] = [];
  if (!envSession) missing.push(db.prepare(`INSERT OR IGNORE INTO meta (key, value) VALUES ('session_secret', ?)`).bind(randomHex(32)));
  if (!envEnc) missing.push(db.prepare(`INSERT OR IGNORE INTO meta (key, value) VALUES ('enc_key', ?)`).bind(randomHex(32)));
  if (missing.length) await db.batch(missing);
  const rows = await db
    .prepare(`SELECT key, value FROM meta WHERE key IN ('session_secret', 'enc_key')`)
    .all<{ key: string; value: string }>();
  const map: Record<string, string | undefined> = Object.fromEntries(rows.results.map((r) => [r.key, r.value]));
  const encKey = envEnc || map.enc_key!;
  secrets = {
    sessionSecret: envSession || map.session_secret!,
    encKey,
    decryptKeys: [encKey, map.enc_key].filter((k, i, all): k is string => Boolean(k) && all.indexOf(k) === i),
  };
  return secrets;
}

const SETTING_PREFIX = "setting:";

/** Site settings an admin can change at runtime, kept in the meta table under a "setting:" prefix. */
export async function getSetting(env: Env, key: string, fallback: string | null = null): Promise<string | null> {
  const row = await env.DB.prepare(`SELECT value FROM meta WHERE key = ?`).bind(SETTING_PREFIX + key).first<{ value: string }>();
  return row ? row.value : fallback;
}

export async function setSetting(env: Env, key: string, value: string): Promise<void> {
  await env.DB.prepare(`INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`)
    .bind(SETTING_PREFIX + key, value)
    .run();
}
