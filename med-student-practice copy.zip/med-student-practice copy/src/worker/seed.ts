// Starter content: public configurations every educator can copy, and five demo cases (four patients)
// in a demo course (join code MEDSIM) so anyone can try the platform immediately.
import type { ConfigData, ProfileData, TestItem } from "../shared/types";
import { DEFAULT_LEVELS, normalizeConfig, normalizeProfile } from "../shared/defaults";

export const DEMO_COURSE_CODE = "MEDSIM";
/** Bump to refresh the built-in public content in existing databases. */
export const SEED_VERSION = "8";
const SYSTEM = "system";
const DEMO_COURSE_ID = "seed-course-demo";

// Rows are [category, name, result, expected]. Categories match TEST_CATEGORIES. Each name starts with the
// standard term and adds, in brackets, the words students often type instead, so search-mode orders find an
// authored result. General appearance is the first exam in every case and is also called the general exam, so a
// vague request ("physical exam") gets it rather than a finding that gives the case away.
// Vital signs are on the door note, so they are never "expected"; expected marks what a strong student orders.
const tests = (rows: [string, string, string, boolean][]): TestItem[] =>
  rows.map(([category, name, result, expected], i) => ({ id: `t${i + 1}`, category, name, result, expected }));

// Names shared by several cases, so the same order reads the same everywhere.
const VITALS = "Vital signs (blood pressure, pulse, temperature, breathing rate, oxygen saturation or SpO2)";
const WEIGHT = "Weight and BMI (body mass index)";
const GENERAL = "General appearance (general exam)";
const CBC = "Complete blood count (CBC, hemoglobin, white cells, platelets)";
const BMP = "Basic metabolic panel (electrolytes, kidney function, creatinine, glucose)";
const CMP = "Comprehensive metabolic panel (electrolytes, kidney function, creatinine, glucose, calcium, liver function tests)";
const CXR = "Chest X-ray (PA and lateral chest radiograph)";
const ECG = "ECG (electrocardiogram)";

const CONFIGS: { id: string; name: string; data: Partial<ConfigData> }[] = [
  {
    id: "seed-cfg-osce",
    name: "OSCE: History and diagnosis",
    data: {
      contextGoal:
        "You are seeing a new patient in an outpatient clinic. Take a focused, patient-centered history, order the exams and tests you need, then share your leading diagnosis and next steps with the patient. You have 15 minutes.",
      encounterTasks: [
        "Introduce yourself and your role, and set an agenda",
        "Elicit the patient's main concern and any other concerns",
        "Explore the history of the present illness",
        "Take past medical, medication and allergy history",
        "Take family and social history",
        "Order the exams and tests you need",
        "Summarize, share your leading diagnosis and next steps, and check understanding",
      ],
      // The End dialog asks for the diagnosis, so it is not repeated as a post-encounter task.
      postEncounterTasks: [],
      diagnosisType: "diagnosis",
      timeLimitMin: 15,
      testOrdering: "search",
      feedbackInstructions:
        "Be encouraging but honest and speak directly to the student as \"you\". Prioritize the two or three changes that would most improve the next encounter.",
      rubric: [
        {
          name: "Rapport and agenda",
          description: "Introduces self and role, uses the patient's name, sets an agenda, elicits all concerns, and shows genuine interest in the patient as a person.",
          levelDescriptors: [
            "Does not introduce self or role, or starts straight into questions with no agenda.",
            "Introduces self and greets the patient, but sets no agenda or does not ask about other concerns.",
            "Introduces self and role, uses the patient's name, asks about all concerns, and agrees on an agenda.",
          ],
        },
        {
          name: "Open-ended inquiry",
          description: "Begins with open questions, lets the patient talk without interrupting, then narrows to focused questions; avoids leading and stacked questions.",
          levelDescriptors: [
            "Mostly closed, leading or stacked questions from the start; interrupts the patient.",
            "Opens with an open question, but switches to closed questions early or interrupts at times.",
            "Opens with open questions, lets the patient finish, then narrows to focused questions with no leading or stacked questions.",
          ],
        },
        {
          name: "History of present illness",
          description: "Characterizes the main symptom (onset, location, duration, character, modifying factors, radiation, timing, severity) and asks about associated symptoms and pertinent negatives.",
          levelDescriptors: [
            "Asks about only one or two features of the main symptom and misses key associated symptoms.",
            "Covers most features of the main symptom, but misses some associated symptoms or pertinent negatives.",
            "Fully characterizes the main symptom and asks about the associated symptoms and pertinent negatives that matter for this case.",
          ],
        },
        {
          name: "Background history",
          description: "Covers past medical history, medications, allergies, family history, and social history including tobacco, alcohol, drugs, work and home situation.",
          levelDescriptors: [
            "Leaves out most of the past medical, medication, allergy, family and social history.",
            "Covers some background areas, but misses one that matters for this case, such as allergies or tobacco use.",
            "Covers past medical history, medications, allergies, family and social history, and quantifies tobacco, alcohol and drug use.",
          ],
        },
        {
          name: "Clinical reasoning and testing",
          description: "Asks hypothesis-driven questions, orders appropriate exams and tests without unnecessary ones, and reaches a reasonable leading diagnosis.",
          levelDescriptors: [
            "Questions and orders follow no clear hypothesis; misses key tests or orders many unnecessary ones; no reasonable leading diagnosis.",
            "Orders some key tests and names a plausible diagnosis, but misses an important test or orders several low-value ones.",
            "Asks hypothesis-driven questions, orders the key exams and tests with few unnecessary ones, and reaches a diagnosis the findings support.",
          ],
        },
        {
          name: "Communication and closure",
          description: "Uses plain language, responds to emotion with empathy, summarizes, explains next steps, and checks the patient's understanding and questions.",
          levelDescriptors: [
            "Uses jargon, passes over emotional cues, and ends without a summary or plan.",
            "Mostly plain language with some empathy; gives a summary or plan but does not check understanding.",
            "Uses plain language, responds to emotion, summarizes, explains next steps, and checks understanding and questions.",
          ],
        },
      ],
    },
  },
  {
    id: "seed-cfg-spikes",
    name: "Breaking bad news (SPIKES)",
    data: {
      contextGoal:
        "You are meeting the patient to share a serious diagnosis. The results are shown on this brief: read them before you begin, then deliver the news with compassion and agree on next steps together. You have 15 minutes.",
      encounterTasks: [
        "Read the results on the brief before you begin",
        "Set up: introduce yourself, ensure privacy, sit down",
        "Find out what the patient already knows",
        "Ask how much information the patient wants",
        "Give a warning shot, then share the news clearly in plain language",
        "Respond to emotions with empathy and allow silence",
        "Summarize and agree on a plan and follow-up",
      ],
      diagnosisType: "none",
      timeLimitMin: 15,
      testOrdering: "search",
      showResultsInBrief: true,
      roleplayInstructions:
        "You have come to receive test results. React to bad news realistically for your personality: shock, silence, tears or anger are all possible. If the clinician is abrupt or uses jargon, become more upset or confused; if they are warm and give you time, you gradually settle and ask practical questions.",
      feedbackInstructions:
        "Speak directly to the student as \"you\". Organize your comments around the SPIKES steps and quote the student's exact words when praising or suggesting alternatives.",
      rubric: [
        {
          name: "Setting",
          description: "Prepares the conversation: introduces self, ensures privacy and time, sits down, offers to include a support person, and builds rapport.",
          levelDescriptors: [
            "Starts giving information without an introduction or any check on privacy or time.",
            "Introduces self and is courteous, but misses privacy, sitting down, or the offer of a support person.",
            "Introduces self, ensures privacy and time, sits down, offers to include a support person, and builds rapport first.",
          ],
        },
        {
          name: "Perception",
          description: "Asks what the patient already knows or suspects before giving information.",
          levelDescriptors: [
            "Does not ask what the patient knows or suspects.",
            "Asks what the patient knows, but does not use the answer to shape what comes next.",
            "Asks what the patient knows or suspects and builds on the patient's own words.",
          ],
        },
        {
          name: "Invitation",
          description: "Asks how much and what kind of information the patient wants.",
          levelDescriptors: [
            "Does not ask how much information the patient wants.",
            "Asks briefly, but does not adjust to the patient's answer.",
            "Asks how much and what kind of information the patient wants, and follows the patient's lead.",
          ],
        },
        {
          name: "Knowledge",
          description: "Gives a warning shot, then delivers the news clearly in small pieces, in plain language without jargon, checking understanding.",
          levelDescriptors: [
            "Delivers the news abruptly or buried in jargon, with no warning shot.",
            "Gives a warning shot and states the news, but in large chunks or with some jargon, and does not check understanding.",
            "Gives a warning shot, names the diagnosis clearly in plain words, shares information in small pieces, and checks understanding.",
          ],
        },
        {
          name: "Emotions and empathy",
          description: "Notices and names emotions, allows silence, validates feelings, and responds with empathy before moving on to facts.",
          levelDescriptors: [
            "Talks over or ignores the patient's emotions and moves straight on to facts.",
            "Acknowledges emotion briefly, but moves on quickly or fills every silence.",
            "Names and validates emotions, allows silence, and responds with empathy before returning to facts.",
          ],
        },
        {
          name: "Strategy and summary",
          description: "Summarizes, explains next steps, invites questions, involves the patient in planning, and arranges follow-up and support.",
          levelDescriptors: [
            "Ends without a summary, a plan or follow-up.",
            "Mentions next steps, but does not involve the patient or invite questions.",
            "Summarizes, explains next steps, invites questions, plans together with the patient, and arranges follow-up and support.",
          ],
        },
      ],
    },
  },
  {
    id: "seed-cfg-mi",
    name: "Counseling: Motivational interviewing",
    data: {
      contextGoal:
        "This is a follow-up visit. The patient's acute problem has been treated and they feel better. Use motivational interviewing to explore one health behavior they could change (for example smoking, alcohol, diet or taking medication) and agree on a realistic next step. You have 15 minutes.",
      encounterTasks: [
        "Re-establish rapport and ask permission to discuss the behavior",
        "Use open questions and reflective listening",
        "Explore the patient's own reasons for and against change",
        "Assess importance and confidence (for example on 0 to 10 scales)",
        "Offer information or advice only with permission",
        "Agree on a specific, patient-chosen next step",
      ],
      diagnosisType: "none",
      timeLimitMin: 15,
      testOrdering: "search",
      roleplayInstructions:
        "This is a follow-up visit after your recent treatment; you are feeling much better. You are ambivalent about changing the habit the clinician raises: you have tried before and it didn't last. If the clinician lectures or pushes, become defensive. If they listen, reflect and ask about your own reasons, gradually open up and consider a small step.",
      feedbackInstructions:
        "Speak directly to the student as \"you\". Use motivational interviewing language (OARS, change talk, righting reflex) and give example phrasings the student could use.",
      rubric: [
        {
          name: "Engaging",
          description: "Builds a respectful partnership, asks permission, and uses open questions to understand the patient's perspective.",
          levelDescriptors: [
            "Raises the behavior without rapport or permission and asks mostly closed questions.",
            "Builds some rapport and asks a few open questions, but sets the agenda without asking permission.",
            "Re-establishes rapport, asks permission before raising the behavior, and uses open questions to understand the patient's view.",
          ],
        },
        {
          name: "Reflective listening",
          description: "Uses simple and complex reflections and summaries more often than questions; the patient feels heard.",
          levelDescriptors: [
            "Few or no reflections; the visit is mostly questions and statements.",
            "Uses some simple reflections, but questions still outnumber reflections and there are no summaries.",
            "Reflections, including complex ones, outnumber questions, and summaries pull together what the patient said.",
          ],
        },
        {
          name: "Evoking change talk",
          description: "Draws out the patient's own reasons, values and confidence for change, for example with importance and confidence rulers.",
          levelDescriptors: [
            "Gives the clinician's own reasons for change and never asks for the patient's.",
            "Asks about the patient's reasons or uses a ruler, but does not explore or reflect the change talk that follows.",
            "Draws out the patient's own reasons, explores importance and confidence, and reflects change talk back.",
          ],
        },
        {
          name: "Avoiding the righting reflex",
          description: "Does not lecture, argue, or push; offers information only with permission and respects autonomy.",
          levelDescriptors: [
            "Lectures, warns or argues, and gives advice without permission.",
            "Mostly respectful, but slips into unasked-for advice or pushes when the patient resists.",
            "Offers information only with permission, rolls with resistance, and affirms the patient's choice.",
          ],
        },
        {
          name: "Planning",
          description: "Collaboratively agrees on a specific, realistic next step chosen by the patient and summarizes the plan.",
          levelDescriptors: [
            "No plan, or a plan the clinician imposes.",
            "A plan is discussed, but it stays vague or is mostly the clinician's idea.",
            "The patient chooses a specific, realistic next step, and the clinician summarizes it and arranges follow-up.",
          ],
        },
      ],
    },
  },
  {
    id: "seed-cfg-clerkship",
    name: "Clerkship: Focused differential and SOAP note",
    data: {
      contextGoal:
        "You are a clerkship student seeing an acutely unwell patient. Work efficiently: take a hypothesis-driven history, screen for red flags, order targeted tests, commit to a diagnosis, and write a brief SOAP note afterwards. You have 20 minutes.",
      encounterTasks: [
        "Introduce yourself and identify the chief concern",
        "Ask hypothesis-driven questions to narrow your differential",
        "Screen for red-flag features",
        "Order targeted exams and tests",
        "Explain your working diagnosis and immediate plan to the patient",
      ],
      postEncounterTasks: ["Write a SOAP note"],
      diagnosisType: "diagnosis",
      timeLimitMin: 20,
      testOrdering: "search",
      feedbackInstructions: "Speak directly to the student as \"you\". Be specific about patient safety: name any red flag that was missed and what it should have prompted.",
      notesFeedback: {
        enabled: true,
        criteria:
          "Subjective: concise HPI with pertinent positives and negatives. Objective: vitals, exam and test results actually obtained. Assessment: leading diagnosis with reasoning plus two or three ranked alternatives. Plan: specific, safe next steps. Point out any findings that were not actually obtained in the encounter.",
      },
      rubric: [
        {
          name: "Hypothesis-driven history",
          description: "Questions are clearly aimed at distinguishing between likely diagnoses; covers onset, character and associated features efficiently.",
          levelDescriptors: [
            "Unfocused, checklist-style questions that do not narrow the differential.",
            "Some targeted questions, but misses features that separate the likely diagnoses.",
            "Efficient, targeted questions on onset, character and associated features that clearly separate the leading diagnoses.",
          ],
        },
        {
          name: "Red flags and safety",
          description: "Screens for dangerous features and recognizes urgency appropriately.",
          levelDescriptors: [
            "Does not screen for dangerous features, or misses the urgency.",
            "Screens for some red flags, but does not act on them or convey urgency.",
            "Screens for the key red flags, recognizes the urgency, and puts immediate safety first.",
          ],
        },
        {
          name: "Test stewardship",
          description: "Orders the tests that change management and avoids low-value tests.",
          levelDescriptors: [
            "Misses the key tests or orders many low-value ones.",
            "Orders most key tests, but misses one or adds several low-value tests.",
            "Orders the tests that change management, in a sensible order, with few or no low-value tests.",
          ],
        },
        {
          name: "Diagnostic reasoning",
          description: "Synthesizes findings into a prioritized differential and commits to a well-supported leading diagnosis.",
          levelDescriptors: [
            "No leading diagnosis, or one the findings do not support.",
            "A reasonable leading diagnosis, but a narrow differential or reasoning not linked to the findings.",
            "Commits to a leading diagnosis supported by the history, exam and tests, with ranked alternatives.",
          ],
        },
        {
          name: "Patient communication",
          description: "Explains findings and the immediate plan in plain language, with empathy, and checks understanding.",
          levelDescriptors: [
            "Uses jargon, or does not explain the findings or plan.",
            "Explains the plan in mostly plain language, but does not check understanding or address worries.",
            "Explains findings and the immediate plan in plain language, with empathy, and checks understanding.",
          ],
        },
      ],
    },
  },
];

const MARCUS_LOOK: Pick<ProfileData, "voice" | "appearance"> = {
  voice: { gender: "male", age: "adult", pitch: 0.95, rate: 1.05, liveVoice: "Puck" },
  appearance: { skin: "ae5d29", top: "shortRound", hairColor: "2c1b18", facialHair: "beardLight", accessories: "none" },
};

const PROFILES: { id: string; name: string; data: Partial<ProfileData> }[] = [
  {
    id: "seed-pro-pneumonia",
    name: "Cough and fever, 46M",
    data: {
      demographics: { name: "Marcus Bell", age: "46", sex: "Male", occupation: "High school history teacher", other: "" },
      ...MARCUS_LOOK,
      diagnosis: "Community-acquired pneumonia of the right lower lobe (likely Streptococcus pneumoniae), low severity (CURB-65 score 0)",
      chiefComplaint: "I've had this awful cough and fever for almost a week",
      doorNote: "Urgent care clinic. BP 126/78, HR 108, T 38.7 °C, RR 24, SpO2 92% on room air.",
      initialEmotion: "in_pain",
      hpi: "Five days ago he developed a dry cough after his daughter had a cold. Over the last three days the cough has become productive of thick yellow-green sputum, sometimes rust-colored. He has had fevers up to 38.9 °C (102 °F) at home with chills and night sweats. Since yesterday he has a sharp pain in the right lower chest that is worse with deep breaths and coughing, about 7 out of 10. He gets short of breath climbing the stairs at school. Acetaminophen helps the fever for a few hours. He denies coughing up frank blood, leg swelling, or recent long trips. No hospital stays or antibiotics in the last three months.",
      pmh: "Mild intermittent asthma since childhood; uses his inhaler a few times a year. No hospitalizations. Appendectomy at age 19.",
      medsAllergies: "Albuterol inhaler as needed (used twice this week without much help). Acetaminophen 1000 mg every 6 to 8 hours for fever. Allergy: penicillin, which gave him hives as a child.",
      familyHistory: "Father, 74, has COPD after a lifetime of heavy smoking and uses oxygen at home. Mother has high blood pressure. Two sisters are healthy.",
      socialHistory: "Smokes about a pack a day and has for about 25 years; this week he has managed only a few cigarettes a day because smoking makes him cough. He has tried to quit twice. Drinks 3 to 4 beers on weekends. No recreational drugs. Married with two children aged 8 and 12. Several of his students have been out sick. He skipped this year's flu shot and has never had a pneumonia vaccine. No recent travel.",
      ros: "Fatigue, poor appetite, headache with the fevers, and muscle aches. Denies vomiting, diarrhea, rash, urinary symptoms, neck stiffness, confusion, or weight loss before this illness.",
      personality: { openness: "medium", conscientiousness: "low", extraversion: "high", agreeableness: "high", neuroticism: "medium", notes: "Jokes to downplay how sick he feels; worried about missing more work." },
      communication: "Friendly and chatty, uses humor, and gets slightly winded during long answers. Downplays his smoking at first (\"I smoke a little\") and only admits it is about a pack a day if asked specifically.",
      tests: tests([
        ["Vital signs", VITALS, "BP 126/78 mmHg, HR 108/min, T 38.7 °C (101.7 °F), RR 24/min, SpO2 92% on room air", false],
        ["Physical exam", GENERAL, "Flushed, tired-looking man who is mildly sweaty; alert and speaks in full sentences; holds his right side when he coughs", false],
        ["Physical exam", "Respiratory exam (lung and chest)", "Reduced expansion on the right; dullness to percussion, increased tactile fremitus, bronchial breath sounds and coarse crackles over the right lower posterior chest; egophony at the right base; no wheeze; left lung clear", true],
        ["Physical exam", "Cardiac exam (heart, cardiovascular system and legs)", "Fast regular rhythm, normal S1 and S2, no murmurs, rubs or gallops; JVP not raised; no leg swelling; calves soft and non-tender", true],
        ["Physical exam", "HEENT exam (throat, ears, sinuses and neck lymph nodes)", "Dry mucous membranes; throat mildly red without exudate; ears normal; no sinus tenderness; no enlarged neck lymph nodes; neck supple", false],
        ["Physical exam", "Abdominal exam (abdomen)", "Soft and non-tender; no liver or spleen enlargement; normal bowel sounds", false],
        ["Physical exam", "Neurological exam (neuro exam, mental status, neck stiffness)", "Alert and oriented to time, place and person; no neck stiffness; Kernig sign negative; cranial nerves, strength and sensation normal", false],
        ["Laboratory", CBC, "WBC 16.4 x10^9/L (84% neutrophils, 8% bands), Hb 14.6 g/dL, platelets 298 x10^9/L", true],
        ["Laboratory", BMP, "Na 136, K 4.1, Cl 101, HCO3 23 mmol/L; BUN 18 mg/dL (urea 6.4 mmol/L); creatinine 1.0 mg/dL; glucose 112 mg/dL", true],
        ["Laboratory", "C-reactive protein (CRP)", "142 mg/L (reference below 5)", false],
        ["Laboratory", "Procalcitonin", "1.9 ng/mL (raised; above 0.25 suggests a bacterial infection)", false],
        ["Laboratory", "Blood cultures (two sets)", "Two sets drawn; no growth so far at 48 hours", false],
        ["Laboratory", "Sputum Gram stain and culture", "Good-quality sample (many neutrophils, few epithelial cells) with many Gram-positive lancet-shaped diplococci; culture pending", false],
        ["Laboratory", "Respiratory viral panel (nasal swab PCR for influenza or flu, COVID-19 and RSV)", "Negative for influenza A and B, SARS-CoV-2 and RSV", false],
        ["Laboratory", "Arterial blood gas (ABG)", "On room air: pH 7.46, PaCO2 33 mmHg, PaO2 64 mmHg, HCO3 23 mmol/L, SaO2 93%", false],
        ["Laboratory", "D-dimer", "0.42 mg/L FEU (normal; reference below 0.50)", false],
        ["Laboratory", "Troponin (high-sensitivity troponin I)", "Below 5 ng/L (normal)", false],
        ["Imaging", CXR, "Dense consolidation of the right lower lobe with air bronchograms; the right hemidiaphragm is obscured and the right heart border is clear; no pleural effusion or pneumothorax; normal heart size", true],
        ["Imaging", "CT chest (CT pulmonary angiogram, CTPA)", "No pulmonary embolism. Right lower lobe consolidation with air bronchograms; no cavity, mass, pleural effusion or enlarged lymph nodes", false],
        ["Other tests", ECG, "Sinus tachycardia at 106/min; normal axis and intervals; no ST-segment or T-wave changes", false],
      ]),
    },
  },
  {
    id: "seed-pro-pneumonia-followup",
    name: "Cough and fever follow-up visit, 46M",
    data: {
      demographics: { name: "Marcus Bell", age: "46", sex: "Male", occupation: "High school history teacher", other: "" },
      ...MARCUS_LOOK,
      diagnosis:
        "Resolving right lower lobe community-acquired pneumonia after 7 days of outpatient doxycycline; tobacco use disorder (about 20 cigarettes a day for 25 years, 25 pack-years), ambivalent about quitting (contemplation stage)",
      patientKnowsDiagnosis: true,
      chiefComplaint: "I'm back for my follow-up. The cough is a lot better.",
      doorNote: "Primary care clinic, follow-up visit. BP 124/78, HR 78, T 36.8 °C, RR 14, SpO2 97% on room air.",
      initialEmotion: "relieved",
      hpi: "Ten days ago he was seen at urgent care with five days of fever, a productive cough and right-sided chest pain on breathing in. A chest X-ray showed pneumonia in the lower part of the right lung. Because of his penicillin allergy he was treated at home with doxycycline 100 mg twice a day for 7 days. He took every dose with food (it upset his stomach a little) and finished three days ago. The fever went away on the third day of treatment and has not come back. The chest pain is gone. He still has a mild cough, mostly in the morning, bringing up a little white phlegm, and it gets better every day. He tires more easily than usual in the afternoons, but he went back to teaching four days ago and can climb the stairs at school without stopping. While he was sick he cut down to a few cigarettes a day because smoking made him cough; since the cough eased he is back to about a pack a day.",
      pmh: "Right lower lobe pneumonia 10 days ago, treated as an outpatient. Mild intermittent asthma since childhood; uses his inhaler a few times a year. No hospitalizations. Appendectomy at age 19.",
      medsAllergies: "Finished doxycycline 100 mg twice daily for 7 days three days ago. Albuterol inhaler as needed; not used since the infection settled. Allergy: penicillin, which gave him hives as a child.",
      familyHistory: "Father, 74, has COPD after a lifetime of heavy smoking and has needed oxygen at home for two years; Marcus visits him every Sunday and hates seeing him struggle for breath. Mother has high blood pressure. Two sisters are healthy.",
      socialHistory: "Smokes about a pack a day and has for about 25 years. His first cigarette is within 30 minutes of waking, in the car on the way to school. He smokes mostly in the car, after school, and on the back porch in the evening after the kids are in bed; it is how he unwinds. He tried to quit twice: cold turkey five years ago (lasted three weeks, restarted during a stressful exam season) and with nicotine gum two years ago (disliked the taste, lasted a week). He has never tried patches, prescription medicines or a quit line. His 12-year-old daughter learned about smoking in health class and keeps asking him to stop. Cigarettes cost him about $250 a month. Worried about gaining weight if he quits. Drinks 3 to 4 beers on weekends and smokes more when he drinks. No recreational drugs. Married with two children aged 8 and 12. Has not had this year's flu shot or a pneumonia vaccine.",
      ros: "Mild tiredness in the afternoons and a mild morning cough with a little white phlegm. Denies fever, chills, night sweats, chest pain, shortness of breath at rest, wheeze, coughing up blood, leg swelling, or weight loss.",
      personality: {
        openness: "medium",
        conscientiousness: "low",
        extraversion: "high",
        agreeableness: "high",
        neuroticism: "medium",
        notes: "Relieved to feel better. A little defensive about smoking because he has \"heard it all before\"; softens when the clinician is curious rather than preachy.",
      },
      communication:
        "Friendly and chatty, uses humor. Brings up smoking only if asked. His first response to smoking advice is a joke or a deflection (\"Everyone needs one vice\"). If lectured or warned, he gets defensive and changes the subject to work. If the clinician asks permission, reflects and is curious, he talks about his father on oxygen, his daughter asking him to quit, and how scared he felt when he could not climb the stairs. Importance of quitting is about 7 out of 10; confidence is about 3 out of 10 because past attempts failed. He will not set a quit date today unless the clinician has really listened, but he might agree to a small step such as not smoking in the car, trying nicotine patches, or calling the quit line.",
      other:
        "If the clinician offers, with permission, to talk about medicines to help quitting, he is curious about patches but worried about vivid dreams he has heard about with \"that pill\". He is happy to have a flu shot and a pneumonia vaccine if offered.",
      // A counseling visit: nothing is expected, but common follow-up orders still get a realistic answer.
      tests: tests([
        ["Vital signs", VITALS, "BP 124/78 mmHg, HR 78/min, T 36.8 °C (98.2 °F), RR 14/min, SpO2 97% on room air", false],
        ["Vital signs", WEIGHT, "Weight 88 kg; height 178 cm; BMI 27.8", false],
        ["Physical exam", GENERAL, "Well-looking, relaxed man; speaks in full sentences without breathlessness; smells of cigarette smoke; nicotine staining on the right index and middle fingers", false],
        ["Physical exam", "Respiratory exam (lung and chest)", "Good air entry on both sides; a few fine crackles at the right base that partly clear after coughing; no bronchial breathing, dullness or wheeze", false],
        ["Physical exam", "Cardiac exam (heart, cardiovascular system and legs)", "Regular rhythm at 78/min, normal heart sounds, no murmurs; no leg swelling", false],
        ["Laboratory", CBC, "WBC 8.1 x10^9/L, Hb 15.0 g/dL, platelets 352 x10^9/L", false],
        ["Laboratory", BMP, "Na 139, K 4.3, Cl 103, HCO3 25 mmol/L; BUN 14 mg/dL; creatinine 0.9 mg/dL; glucose 94 mg/dL", false],
        ["Laboratory", "C-reactive protein (CRP)", "9 mg/L (reference below 5), down from 142 mg/L at the urgent care visit", false],
        ["Laboratory", "Lipid panel (lipids, cholesterol)", "Total cholesterol 214, LDL 138, HDL 38, triglycerides 190 mg/dL", false],
        ["Laboratory", "Hemoglobin A1c (HbA1c)", "5.6% (normal)", false],
        ["Imaging", CXR, "Not repeated today: he is improving, and repeat imaging this early is not needed. A repeat film about 6 weeks after treatment is reasonable if symptoms or chest signs persist, given his smoking history.", false],
        ["Imaging", "Low-dose CT chest (lung cancer screening)", "Not indicated yet: yearly low-dose CT screening for lung cancer starts at age 50 for people with at least 20 pack-years who smoke or quit within the past 15 years. He will qualify in four years.", false],
        ["Other tests", "Exhaled carbon monoxide (CO breath test)", "22 ppm (consistent with daily smoking; non-smokers are usually below 7 ppm)", false],
        ["Other tests", "Spirometry (lung function tests, PFTs)", "Not done today: best done once he has fully recovered, at least 6 weeks after the infection. Worth arranging then, given his smoking and his father's COPD.", false],
      ]),
    },
  },
  {
    id: "seed-pro-sah",
    name: "Sudden severe headache, 39F",
    data: {
      demographics: { name: "Priya Nair", age: "39", sex: "Female", occupation: "Software project manager", other: "" },
      voice: { gender: "female", age: "adult", pitch: 1.05, rate: 0.9, liveVoice: "Achernar" },
      appearance: { skin: "d08b5b", top: "straight01", hairColor: "2c1b18", facialHair: "none", accessories: "none" },
      diagnosis: "Aneurysmal subarachnoid hemorrhage from a 7 mm anterior communicating artery aneurysm (Hunt and Hess grade 2)",
      chiefComplaint: "This headache hit me out of nowhere at the gym and it's the worst pain I've ever had",
      doorNote: "Emergency department. BP 178/102, HR 96, T 37.2 °C, RR 18, SpO2 98% on room air.",
      initialEmotion: "in_pain",
      hpi: "About three hours ago, while lifting weights at the gym, she had a sudden explosive headache at the back of her head that reached full strength within seconds, \"like being hit with a bat\". It is 10 out of 10, constant, and ibuprofen 400 mg did nothing. She has vomited twice. Her neck is stiff and painful to bend forward, and light bothers her. She felt \"foggy\" for about a minute at the start but did not pass out. No weakness, numbness, trouble speaking, double vision or loss of vision. She gets occasional mild tension headaches that feel nothing like this.",
      pmh: "High blood pressure diagnosed two years ago; she often forgets her medication. No previous surgeries.",
      medsAllergies: "Amlodipine 5 mg daily (often missed) and a combined oral contraceptive pill. No blood thinners. No known drug allergies.",
      familyHistory: "Her mother died suddenly at 52 of \"a bleed in the brain\". Her father has type 2 diabetes.",
      socialHistory: "Smokes about five cigarettes a day for 20 years. Drinks 2 to 3 glasses of wine a week. No recreational drugs, including no cocaine. Lives with her husband and 10-year-old son. Works long, stressful hours.",
      ros: "Nausea and vomiting, sensitivity to light, neck stiffness. Denies fever, recent infection, head injury, seizures, rash or chest pain.",
      personality: { openness: "medium", conscientiousness: "high", extraversion: "low", agreeableness: "medium", neuroticism: "high", notes: "Frightened; keeps her eyes closed because of the light; wants pain relief right away." },
      communication: "Speaks softly in short sentences because talking makes the pain worse. May ask to dim the lights. Gets irritated if asked the same thing twice.",
      tests: tests([
        ["Vital signs", VITALS, "BP 178/102 mmHg, HR 96/min, T 37.2 °C, RR 18/min, SpO2 98% on room air", false],
        ["Physical exam", GENERAL, "Lying still on the stretcher with her eyes closed, holding her head; photophobic and uncomfortable but alert", false],
        ["Physical exam", "Neurological exam (neuro exam, GCS, pupils, cranial nerves, strength, sensation, reflexes)", "GCS 15 (E4 V5 M6); alert and oriented but slow to answer. Pupils 3 mm, equal and reactive to light; eye movements full with no ptosis; no facial droop; strength 5/5 in all limbs; sensation intact; no pronator drift; finger-to-nose normal; reflexes 2+ and symmetric; plantar responses flexor", true],
        ["Physical exam", "Neck exam and meningeal signs (neck stiffness, Kernig, Brudzinski)", "Marked neck stiffness on passive flexion; Kernig and Brudzinski signs positive", true],
        ["Physical exam", "Fundoscopy (eye exam, fundus, ophthalmoscopy)", "Sharp optic discs with no papilledema; no retinal or subhyaloid hemorrhages", false],
        ["Physical exam", "Cardiac exam (heart, cardiovascular system and legs)", "Regular rhythm, normal heart sounds, no murmurs; no carotid bruits; peripheral pulses equal; no leg swelling", false],
        ["Physical exam", "Respiratory exam (lung and chest)", "Clear lungs with good air entry on both sides; no crackles or wheeze", false],
        ["Physical exam", "Skin exam (rash)", "No rash, petechiae or purpura", false],
        ["Laboratory", CBC, "WBC 10.8 x10^9/L, Hb 13.1 g/dL, platelets 241 x10^9/L", true],
        ["Laboratory", "Coagulation panel (coags, PT/INR, aPTT)", "INR 1.0, aPTT 29 s (normal)", true],
        ["Laboratory", BMP, "Na 139, K 3.9, Cl 104, HCO3 24 mmol/L; BUN 12 mg/dL; creatinine 0.8 mg/dL; glucose 118 mg/dL", true],
        ["Laboratory", "Type and screen (blood type, group and save, crossmatch)", "Blood group A positive; antibody screen negative", false],
        ["Laboratory", "Troponin (high-sensitivity troponin I)", "24 ng/L (mildly raised; upper reference limit for women 16 ng/L)", false],
        ["Laboratory", "Urine pregnancy test (hCG)", "Negative", false],
        ["Laboratory", "Urine drug screen (toxicology, tox screen)", "Negative, including cocaine and amphetamines", false],
        // MRI comes before the CT scans so "MRI head" finds it rather than the CT head.
        ["Imaging", "MRI brain", "Not available tonight. The attending suggests a CT head without contrast, the first-line scan for a sudden severe headache.", false],
        ["Imaging", "CT head without contrast (non-contrast CT brain, head CT)", "Diffuse subarachnoid blood in the basal cisterns and both Sylvian fissures, thickest in the anterior interhemispheric fissure; no intraparenchymal hematoma; ventricles normal size; no midline shift", true],
        ["Imaging", "CT angiography of the head and neck (CTA, angiogram)", "7 mm saccular aneurysm of the anterior communicating artery; no other aneurysm; no vessel narrowing", true],
        ["Imaging", CXR, "Clear lungs; normal heart size; no pulmonary edema", false],
        ["Other tests", "Lumbar puncture (LP, spinal tap, CSF analysis, xanthochromia)", "Deferred: the attending asks you to review the CT head first and then decide whether a lumbar puncture is still needed", false],
        ["Other tests", ECG, "Sinus rhythm at 94/min; deep symmetric T-wave inversions in V2 to V5; QTc 470 ms", false],
      ]),
    },
  },
  {
    id: "seed-pro-thyroid",
    name: "Tired all the time, 34F",
    data: {
      demographics: { name: "Elena Morales", age: "34", sex: "Female", occupation: "Graphic designer", other: "" },
      voice: { gender: "female", age: "young", pitch: 1.1, rate: 1, liveVoice: "Sulafat" },
      appearance: { skin: "edb98a", top: "curly", hairColor: "4a312c", facialHair: "none", accessories: "none" },
      diagnosis: "Primary hypothyroidism due to Hashimoto thyroiditis",
      chiefComplaint: "I'm exhausted all the time, no matter how much I sleep",
      doorNote: "Primary care clinic. BP 128/86, HR 56, T 36.3 °C, RR 14, SpO2 99% on room air. Weight 74 kg, BMI 27.2.",
      initialEmotion: "sad",
      hpi: "Over the past five months she has felt progressively tired. She sleeps 9 to 10 hours but wakes unrefreshed and needs naps on weekends. She has gained about 6 kg (13 lb) without changing her diet. She always feels cold and wears a sweater at the office when others don't. She is constipated, with bowel movements every 3 to 4 days instead of daily. Her skin is dry and her hair seems thinner, with more coming out in the shower. Her periods have become heavier and last seven days instead of four. She feels foggy and slow at work and missed two deadlines. Her mood is a bit flat because she is frustrated, but she still enjoys time with friends and her hobbies, and she has no thoughts of harming herself.",
      pmh: "Vitiligo on her hands diagnosed at 25. One uncomplicated pregnancy; her son is 6. Otherwise healthy.",
      medsAllergies: "Daily multivitamin. She started an over-the-counter iron supplement herself a month ago. No known drug allergies.",
      familyHistory: "Her mother has \"thyroid problems\" and takes a small pill every morning. A maternal aunt has type 1 diabetes. Her father is healthy.",
      socialHistory: "Never smoked. One glass of wine a week. No drugs. Lives with her husband and son. Used to run three times a week but stopped three months ago because she was too tired. Eats mostly home-cooked meals including meat. Uses condoms and is not trying to get pregnant.",
      ros: "Mild muscle aches and stiffness, an occasionally hoarse voice, and puffy eyes in the morning. Denies fever, night sweats, palpitations, heat intolerance, snoring or witnessed pauses in breathing, chest pain, shortness of breath, blood in the stool, or weight loss.",
      personality: { openness: "high", conscientiousness: "high", extraversion: "medium", agreeableness: "high", neuroticism: "medium", notes: "Frustrated that friends say she just needs more coffee; worried she is being lazy." },
      communication: "Articulate and detailed when asked open questions. Apologizes for \"complaining\". May mention she read online that it could be depression and ask whether she should take antidepressants.",
      tests: tests([
        ["Vital signs", VITALS, "BP 128/86 mmHg, HR 56/min, T 36.3 °C (97.3 °F), RR 14/min, SpO2 99% on room air", false],
        ["Vital signs", WEIGHT, "Weight 74 kg, up from 68 kg a year ago; height 165 cm; BMI 27.2", false],
        ["Physical exam", GENERAL, "Tired-looking but well; mild puffiness around the eyes; voice slightly hoarse; answers questions appropriately", false],
        ["Physical exam", "Thyroid and neck exam (thyroid gland, goiter, neck lymph nodes)", "Diffusely enlarged, firm, rubbery, non-tender thyroid that moves with swallowing; no discrete nodules, bruit or enlarged lymph nodes", true],
        ["Physical exam", "Skin and hair exam", "Dry, coarse skin and cool hands; thinning of the outer third of the eyebrows; dry, thin scalp hair; vitiligo patches on the backs of both hands", false],
        ["Physical exam", "Neurological exam (neuro exam, reflexes, strength, sensation)", "Delayed relaxation phase of the ankle and biceps reflexes; strength 5/5 in all limbs; sensation normal; no tremor", false],
        ["Physical exam", "Cardiac exam (heart, cardiovascular system and legs)", "Slow regular rhythm at 56/min, normal heart sounds, no murmurs; no pitting ankle swelling", false],
        ["Physical exam", "Respiratory exam (lung and chest)", "Clear lungs with good air entry on both sides; no crackles or wheeze", false],
        ["Physical exam", "Abdominal exam (abdomen)", "Soft and non-tender; no masses; no liver or spleen enlargement; normal bowel sounds", false],
        ["Laboratory", CBC, "Hb 11.2 g/dL, MCV 88 fL, WBC 6.1 x10^9/L, platelets 265 x10^9/L", true],
        ["Laboratory", CMP, "Na 135, K 4.2, Cl 102, HCO3 25 mmol/L; BUN 12 mg/dL; creatinine 0.9 mg/dL; glucose 88 mg/dL; calcium 9.3 mg/dL; albumin 4.1 g/dL; ALT 31, AST 29, alkaline phosphatase 74 U/L; bilirubin 0.5 mg/dL", true],
        ["Laboratory", "TSH (thyroid stimulating hormone, thyroid function tests, thyroid panel)", "18.6 mIU/L (reference 0.4 to 4.0)", true],
        ["Laboratory", "Free T4 (free thyroxine, FT4)", "0.5 ng/dL (reference 0.8 to 1.8)", true],
        ["Laboratory", "Thyroid peroxidase antibodies (anti-TPO, thyroid antibodies)", "420 IU/mL (positive; reference below 35)", false],
        ["Laboratory", "Iron studies (ferritin, iron panel)", "Ferritin 22 ng/mL (low normal; reference 15 to 150); iron 58 µg/dL; transferrin saturation 17%", false],
        ["Laboratory", "Vitamin B12 and folate", "B12 410 pg/mL (normal); folate 11 ng/mL (normal)", false],
        ["Laboratory", "Lipid panel (lipids, cholesterol)", "Total cholesterol 248, LDL 165, HDL 52, triglycerides 155 mg/dL", false],
        ["Laboratory", "Hemoglobin A1c (HbA1c)", "5.2%", false],
        ["Laboratory", "ESR and CRP (inflammatory markers, sed rate)", "ESR 16 mm/h (normal); CRP 2 mg/L (normal)", false],
        ["Laboratory", "Morning cortisol (8 am cortisol)", "16 µg/dL at 8 am (normal)", false],
        ["Laboratory", "Urine pregnancy test (hCG)", "Negative", false],
        ["Imaging", "Thyroid ultrasound (neck ultrasound)", "Diffusely enlarged, heterogeneous, hypoechoic gland; no nodules", false],
        ["Imaging", CXR, "Clear lungs; normal heart size; no masses or enlarged lymph nodes in the chest", false],
        ["Other tests", "PHQ-9 depression screen (depression screening)", "Score 6 (mild symptoms); item 9 (thoughts of self-harm) scored 0", false],
        ["Other tests", ECG, "Sinus bradycardia at 56/min; normal axis and intervals; no ST-segment changes", false],
      ]),
    },
  },
  {
    id: "seed-pro-crc",
    name: "Biopsy results visit, 63M",
    data: {
      demographics: { name: "Robert \"Bob\" Kowalski", age: "63", sex: "Male", occupation: "Retired electrician", other: "" },
      voice: { gender: "male", age: "older", pitch: 0.85, rate: 0.95, liveVoice: "Algenib" },
      appearance: { skin: "ffdbb4", top: "sides", hairColor: "e8e1e1", facialHair: "moustacheFancy", accessories: "prescription02" },
      diagnosis: "Adenocarcinoma of the sigmoid colon with two enlarged regional lymph nodes and no distant spread on staging CT (likely stage III)",
      patientKnowsDiagnosis: false,
      chiefComplaint: "I'm here to get the results from my colonoscopy",
      doorNote: "Outpatient clinic, results visit. BP 142/88, HR 84, T 36.8 °C, RR 14, SpO2 97% on room air.",
      initialEmotion: "anxious",
      hpi: "Two weeks ago he had a colonoscopy after his primary care doctor found iron-deficiency anemia on routine blood work and he mentioned blood mixed in his stool on and off for about three months. Afterwards the gastroenterologist said they \"found a growth and took samples\" and that someone would go over the results. He has been anxious and sleeping poorly since. His stools have become thinner, with some constipation. He feels more tired than usual. His belt is looser; he has lost about 4 kg in three months without trying.",
      pmh: "Type 2 diabetes for 10 years, high blood pressure, high cholesterol. Never had a screening colonoscopy before (\"I kept putting it off\"). Knee replacement three years ago.",
      medsAllergies: "Metformin 1000 mg twice daily, lisinopril 20 mg daily, atorvastatin 40 mg at night. No allergies.",
      familyHistory: "His older brother had \"polyps\" removed. His father died at 70 of a heart attack. His mother died at 81 of \"old age\".",
      socialHistory: "Quit smoking 15 years ago after 30 years of a pack a day. Drinks two beers most evenings. Married 38 years to Linda, who has early Parkinson's disease and depends on him for driving and errands. Two adult daughters live out of state. Enjoys fishing and his grandchildren.",
      ros: "Fatigue and occasional crampy lower abdominal pain. Denies nausea, vomiting, yellowing of the skin, or fevers.",
      personality: { openness: "low", conscientiousness: "medium", extraversion: "medium", agreeableness: "medium", neuroticism: "high", notes: "Masks fear with gruff humor. His biggest worry is who will take care of his wife." },
      communication: "Opens with small talk and jokes (\"So how bad is it, doc?\"). Wants straight talk without medical jargon. If given bad news abruptly he goes quiet, then gets angry (\"Why didn't anyone catch this sooner?\"). Responds well to silence, empathy and a clear plan. Will ask \"Am I going to die?\" and \"Can they just cut it out?\" Asks whether his wife needs to know right away.",
      // Shown on the brief (showResultsInBrief), so none are "expected" orders.
      tests: tests([
        ["Other tests", "Colonoscopy report", "Ulcerated, partly obstructing mass in the sigmoid colon about 25 cm from the anal verge; biopsied and marked with ink. The scope passed beyond it. Two small polyps removed from the ascending colon. The rest of the colon looked normal.", false],
        ["Laboratory", "Biopsy pathology report (histology)", "Sigmoid colon mass: invasive adenocarcinoma, moderately differentiated; mismatch repair proteins intact. Ascending colon polyps: two tubular adenomas, completely removed.", false],
        ["Imaging", "Staging CT chest, abdomen and pelvis (CT scan)", "4 cm mass in the sigmoid colon with two enlarged nearby lymph nodes (largest 1.2 cm); no spread to the liver or lungs; no fluid in the abdomen", false],
        ["Laboratory", "CEA (carcinoembryonic antigen, tumor marker)", "6.8 ng/mL (mildly raised; reference below 3.0)", false],
        ["Laboratory", CBC, "Hb 10.4 g/dL, MCV 76 fL (small red cells), WBC 7.0 x10^9/L, platelets 410 x10^9/L", false],
        ["Laboratory", "Iron studies (ferritin, iron panel)", "Ferritin 8 ng/mL (low); transferrin saturation 6% (low)", false],
        ["Laboratory", CMP, "Na 138, K 4.4, Cl 102, HCO3 24 mmol/L; BUN 16 mg/dL; creatinine 1.0 mg/dL; glucose 146 mg/dL; calcium 9.2 mg/dL; albumin 3.8 g/dL; liver tests normal (ALT 22, AST 19, alkaline phosphatase 88 U/L, bilirubin 0.6 mg/dL)", false],
        ["Vital signs", VITALS, "BP 142/88 mmHg, HR 84/min, T 36.8 °C (98.2 °F), RR 14/min, SpO2 97% on room air", false],
        ["Vital signs", WEIGHT, "Weight 84 kg, down from 88 kg three months ago; height 180 cm; BMI 25.9", false],
      ]),
    },
  },
];

const CASES = [
  { id: "seed-case-cough", name: "Cough and fever", description: "A teacher comes to clinic feeling unwell for most of a week.", profileId: "seed-pro-pneumonia", configs: ["seed-cfg-osce"] },
  {
    id: "seed-case-cough-followup",
    name: "Cough and fever: follow-up visit",
    description: "Marcus comes back about 10 days after being treated for his cough and fever.",
    profileId: "seed-pro-pneumonia-followup",
    configs: ["seed-cfg-mi"],
  },
  { id: "seed-case-headache", name: "Sudden headache", description: "A woman comes to the emergency department with a severe headache.", profileId: "seed-pro-sah", configs: ["seed-cfg-clerkship"] },
  { id: "seed-case-fatigue", name: "Tired all the time", description: "A young professional wants to know why she is always tired.", profileId: "seed-pro-thyroid", configs: ["seed-cfg-osce"] },
  {
    id: "seed-case-results",
    name: "Results visit",
    description: "Mr. Kowalski comes back to hear the results of his colonoscopy and biopsy.",
    profileId: "seed-pro-crc",
    configs: ["seed-cfg-spikes"],
  },
];

/** Case and configuration pairs that earlier seed versions linked and that no longer fit (the follow-up visit now has its own case). */
const STALE_LINKS: [string, string][] = [["seed-case-cough", "seed-cfg-mi"]];

const ASSIGNMENTS: [string, string][] = [
  ["seed-case-cough", "seed-cfg-osce"],
  ["seed-case-fatigue", "seed-cfg-osce"],
  ["seed-case-headache", "seed-cfg-clerkship"],
  ["seed-case-results", "seed-cfg-spikes"],
  ["seed-case-cough-followup", "seed-cfg-mi"],
];

export async function seedDatabase(db: D1Database): Promise<void> {
  const now = Date.now();
  const stmts: D1PreparedStatement[] = [];
  for (const c of CONFIGS) {
    const data: ConfigData = normalizeConfig({ levels: DEFAULT_LEVELS, ...c.data });
    stmts.push(
      db
        .prepare(`INSERT INTO configurations (id, owner_id, name, data, is_public, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?) ON CONFLICT(id) DO UPDATE SET name = excluded.name, data = excluded.data, updated_at = excluded.updated_at WHERE configurations.owner_id = 'system'`)
        .bind(c.id, SYSTEM, c.name, JSON.stringify(data), now, now),
    );
  }
  for (const p of PROFILES) {
    stmts.push(
      db
        .prepare(`INSERT INTO profiles (id, owner_id, name, data, is_public, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?) ON CONFLICT(id) DO UPDATE SET name = excluded.name, data = excluded.data, updated_at = excluded.updated_at WHERE profiles.owner_id = 'system'`)
        .bind(p.id, SYSTEM, p.name, JSON.stringify(normalizeProfile(p.data)), now, now),
    );
  }
  for (const c of CASES) {
    stmts.push(
      db
        .prepare(`INSERT INTO cases (id, owner_id, name, description, profile_id, is_public, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?) ON CONFLICT(id) DO UPDATE SET name = excluded.name, description = excluded.description, profile_id = excluded.profile_id, updated_at = excluded.updated_at WHERE cases.owner_id = 'system'`)
        .bind(c.id, SYSTEM, c.name, c.description, c.profileId, now, now),
    );
    for (const cfg of c.configs) {
      stmts.push(db.prepare(`INSERT OR IGNORE INTO case_configs (case_id, config_id) VALUES (?, ?)`).bind(c.id, cfg));
    }
  }
  for (const [caseId, configId] of STALE_LINKS) {
    stmts.push(
      db
        .prepare(`DELETE FROM case_configs WHERE case_id = ? AND config_id = ? AND EXISTS (SELECT 1 FROM cases WHERE id = ? AND owner_id = 'system')`)
        .bind(caseId, configId, caseId),
    );
  }
  // The demo course: name and description follow the seed, but its join code, enrollment and archived
  // state stay as an admin left them. (A plain insert plus update, so a clash on the unique code can never fail the batch.)
  const demoName = "Demo course";
  const demoDescription = "Four practice patients and five cases to try Med Student Practice AI. Anyone can join with code MEDSIM.";
  stmts.push(
    db
      .prepare(`INSERT OR IGNORE INTO courses (id, owner_id, name, description, banner, code, enrollment_open, archived, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, 0, ?)`)
      .bind(DEMO_COURSE_ID, SYSTEM, demoName, demoDescription, "teal", DEMO_COURSE_CODE, now),
    db.prepare(`UPDATE courses SET name = ?, description = ? WHERE id = ? AND owner_id = 'system'`).bind(demoName, demoDescription, DEMO_COURSE_ID),
  );
  // Demo assignments keep their ids and positions; the case and configuration follow the seed.
  ASSIGNMENTS.forEach(([caseId, configId], i) =>
    stmts.push(
      db
        .prepare(`INSERT OR IGNORE INTO assignments (id, course_id, case_id, config_id, position, created_at) VALUES (?, ?, ?, ?, ?, ?)`)
        .bind(`seed-asg-${i + 1}`, DEMO_COURSE_ID, caseId, configId, i, now),
      db
        .prepare(`UPDATE assignments SET case_id = ?, config_id = ? WHERE id = ? AND course_id = ?`)
        .bind(caseId, configId, `seed-asg-${i + 1}`, DEMO_COURSE_ID),
    ),
  );
  await db.batch(stmts);
}
