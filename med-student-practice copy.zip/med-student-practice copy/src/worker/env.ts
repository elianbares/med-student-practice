import type { Role } from "../shared/types";

export interface Env {
  DB: D1Database;
  AI?: Ai;
  AI_MODE?: string; // "auto" (default) | "mock" | "real"
  ADMIN_EMAILS?: string;
  GEMINI_API_KEY?: string;
  GROQ_API_KEY?: string;
  EDUCATOR_ACCESS_KEY?: string;
  GEMINI_ACTOR_MODELS?: string;
  GEMINI_GRADER_MODELS?: string;
  GROQ_MODELS?: string;
  WORKERS_AI_MODEL?: string;
  // Secrets kept out of the database. When unset (local dev), generated values in the meta table are used.
  SESSION_SECRET?: string;
  ENC_KEY?: string; // 64 hex characters; any other string is hashed into a key
  // Optional sign-up protection.
  TURNSTILE_SITE_KEY?: string;
  TURNSTILE_SECRET?: string;
  ALLOWED_EMAIL_DOMAINS?: string; // comma list, e.g. "dartmouth.edu,hitchcock.org"
}

export interface DbUser {
  id: string;
  email: string;
  name: string;
  role: Role;
  ai_key_enc: string | null;
}

export type AppEnv = { Bindings: Env; Variables: { user: DbUser } };
