import { Hono } from "hono";
import { HTTPException } from "hono/http-exception";
import type { AppEnv, Env } from "./env";
import { ensureSchema } from "./db";
import { authRoutes } from "./auth";
import { libraryRoutes } from "./routes/library";
import { courseRoutes } from "./routes/courses";
import { encounterRoutes } from "./routes/encounters";
import { adminRoutes, meRoutes } from "./routes/me";
import { AiUnavailableError } from "./ai/router";

/**
 * Seconds a client should wait before retrying when the AI is busy. The client retries by itself only when
 * this is 8 s or less (src/client/api.ts), and the spread keeps a whole class from retrying in the same second.
 */
const busyRetryAfter = () => 5 + Math.floor(Math.random() * 4);
const AI_BUSY = "The free AI is busy right now. Your work is saved; please try again in a minute.";

const app = new Hono<AppEnv>().basePath("/api");

app.use("*", async (c, next) => {
  await ensureSchema(c.env);
  // CSRF guard: browsers can't add this header cross-site without a CORS preflight, which we never allow.
  if (c.req.method !== "GET" && c.req.header("x-requested-with") !== "apa") {
    return c.json({ error: "Missing request header." }, 400);
  }
  await next();
});

// ---------- health ----------

interface GoogleHealth {
  google: "ok" | "missing" | "error";
  detail?: string;
}

const HEALTH_TTL_MS = 60_000;
// Only finished results are kept: a Worker can't safely await another request's pending fetch.
let health: { at: number; value: GoogleHealth } | null = null;

/** Lists one model with the platform key: proves the key works without using any generation quota. */
async function checkGoogle(env: Env): Promise<GoogleHealth> {
  const key = env.GEMINI_API_KEY;
  if (!key) return { google: "missing", detail: "No platform Google key is set." };
  const scrub = (s: string) => s.split(key).join("[key]").slice(0, 200);
  try {
    const res = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1", {
      headers: { "x-goog-api-key": key },
      signal: AbortSignal.timeout(8000),
    });
    if (res.ok) return { google: "ok" };
    const data = (await res.json().catch(() => ({}))) as { error?: { message?: string } };
    return { google: "error", detail: scrub(`Google answered ${res.status}: ${data.error?.message ?? res.statusText}`) };
  } catch (err) {
    return { google: "error", detail: scrub(`Could not reach Google: ${(err as Error).message}`) };
  }
}

async function googleHealth(env: Env): Promise<GoogleHealth> {
  if (health && Date.now() - health.at < HEALTH_TTL_MS) return health.value;
  const value = await checkGoogle(env);
  health = { at: Date.now(), value };
  return value;
}

app.get("/health", async (c) => {
  c.header("cache-control", "no-store");
  return c.json({ ok: true, ai: await googleHealth(c.env) });
});

app.route("/auth", authRoutes);
app.route("/library", libraryRoutes);
app.route("/courses", courseRoutes);
app.route("/encounters", encounterRoutes);
app.route("/me", meRoutes);
app.route("/admin", adminRoutes);

app.notFound((c) => c.json({ error: "Not found." }, 404));
app.onError((err, c) => {
  if (err instanceof AiUnavailableError) return c.json({ error: AI_BUSY }, 503, { "Retry-After": String(busyRetryAfter()) });
  if (err instanceof HTTPException) {
    // Retry-After comes from `cause: { retryAfter }`, or defaults for a busy AI (503). A 503 that says a feature
    // "needs a Google AI key" is a setup problem that retrying won't fix.
    const cause = err.cause as { retryAfter?: number } | undefined;
    const retryAfter = cause?.retryAfter ?? (err.status === 503 && !/needs a google ai key/i.test(err.message) ? busyRetryAfter() : 0);
    return c.json({ error: err.message }, err.status, retryAfter ? { "Retry-After": String(retryAfter) } : undefined);
  }
  console.error(err);
  return c.json({ error: "Something went wrong on our side. Please try again." }, 500);
});

// ---------- retention ----------

const PURGE_BATCH = 50;
const PURGE_MAX_BATCHES = 8; // about 32 queries per run, well inside the free plan's per-invocation limit

/** Deletes encounters (with their comments and notifications) older than their course's retention_days. */
export async function purgeExpiredEncounters(env: Env, now = Date.now()): Promise<number> {
  await ensureSchema(env);
  const db = env.DB;
  let deleted = 0;
  for (let i = 0; i < PURGE_MAX_BATCHES; i++) {
    const rows = await db
      .prepare(
        `SELECT e.id FROM encounters e JOIN courses c ON c.id = e.course_id
         WHERE c.retention_days > 0 AND e.started_at < ? - c.retention_days * 86400000 LIMIT ${PURGE_BATCH}`,
      )
      .bind(now)
      .all<{ id: string }>();
    const ids = rows.results.map((r) => r.id);
    if (!ids.length) break;
    const marks = ids.map(() => "?").join(", ");
    await db.batch([
      db.prepare(`DELETE FROM comments WHERE encounter_id IN (${marks})`).bind(...ids),
      db.prepare(`DELETE FROM notifications WHERE ref_id IN (${marks})`).bind(...ids),
      db.prepare(`DELETE FROM encounters WHERE id IN (${marks})`).bind(...ids),
    ]);
    deleted += ids.length;
    if (ids.length < PURGE_BATCH) break;
  }
  return deleted;
}

export default {
  fetch: app.fetch,
  // Runs on the daily cron trigger in wrangler.jsonc. Anything left over is picked up the next day.
  scheduled(_controller, env, ctx) {
    ctx.waitUntil(
      purgeExpiredEncounters(env).then(
        (n) => n && console.log(`Retention: deleted ${n} expired encounters.`),
        (err) => console.error("Retention purge failed", err),
      ),
    );
  },
} satisfies ExportedHandler<Env>;
