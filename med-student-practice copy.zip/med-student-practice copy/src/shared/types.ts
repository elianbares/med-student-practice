// Data shapes shared by the browser app and the Worker API.

export type Role = "student" | "educator" | "admin";
export type Level3 = "low" | "medium" | "high";

export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
  hasOwnKey?: boolean;
}

export interface TestItem {
  id: string;
  category: string;
  name: string;
  result: string;
  /** Educator expects the student to order this test. */
  expected: boolean;
}

export interface VoiceSettings {
  gender: "female" | "male" | "neutral";
  age: "child" | "young" | "adult" | "older";
  pitch: number; // 0.5 - 1.5
  rate: number; // 0.7 - 1.3
  /** Gemini Live HD voice name for emotive mode. */
  liveVoice?: string;
}

/** How the illustrated patient looks. Empty strings mean "choose automatically". */
export interface Appearance {
  skin: string;
  top: string;
  hairColor: string;
  facialHair: string;
  accessories: string;
}

/** Everything needed to draw a patient's face. */
export interface PatientLook {
  name: string;
  voice: VoiceSettings;
  appearance: Appearance;
}

export interface ProfileData {
  demographics: { name: string; age: string; sex: string; occupation: string; other: string };
  voice: VoiceSettings;
  appearance: Appearance;
  diagnosis: string;
  /** If true the patient already knows their diagnosis (e.g. follow-up visits). */
  patientKnowsDiagnosis: boolean;
  chiefComplaint: string;
  hpi: string;
  pmh: string;
  medsAllergies: string;
  familyHistory: string;
  socialHistory: string;
  ros: string;
  personality: {
    openness: Level3;
    conscientiousness: Level3;
    extraversion: Level3;
    agreeableness: Level3;
    neuroticism: Level3;
    notes: string;
  };
  communication: string;
  other: string;
  tests: TestItem[];
  /** Door note shown on the brief, like an OSCE door sign: vitals and setting, e.g. "BP 128/82, HR 104, T 38.7 °C". */
  doorNote: string;
  /** How the patient feels as the visit starts (one of EMOTIONS; "" means neutral). */
  initialEmotion: string;
}

export interface RubricCategory {
  name: string;
  description: string;
  /** Optional: what each level looks like for this skill, in the same order as ConfigData.levels. */
  levelDescriptors?: string[];
}

export interface ConfigData {
  contextGoal: string;
  encounterTasks: string[];
  postEncounterTasks: string[];
  diagnosisType: "diagnosis" | "none";
  roleplayInstructions: string;
  feedbackInstructions: string;
  notesFeedback: { enabled: boolean; criteria: string };
  rubric: RubricCategory[];
  levels: string[];
  timeLimitMin: number; // 0 = no limit
  /** "search": students type the exam or test they want (default, gives nothing away). "menu": the case's tests are listed. */
  testOrdering: "search" | "menu";
  /** Show the case's test results on the brief before the encounter (for results-delivery or bad-news visits). */
  showResultsInBrief: boolean;
}

export interface LibraryItem<T> {
  id: string;
  ownerId: string;
  name: string;
  isPublic: boolean;
  data: T;
  updatedAt: number;
  mine?: boolean;
}

export interface CaseItem {
  id: string;
  ownerId: string;
  name: string;
  description: string;
  profileId: string;
  profileName?: string;
  chiefComplaint?: string;
  configIds: string[];
  configNames?: string[];
  isPublic: boolean;
  mine?: boolean;
  look?: PatientLook;
}

export interface Course {
  id: string;
  name: string;
  description: string;
  banner: string;
  code: string;
  enrollmentOpen: boolean;
  archived: boolean;
  hasKey?: boolean;
  studentCount?: number;
  caseCount?: number;
  /** Staff only: delete encounters older than this many days (0 keeps them). */
  retentionDays?: number;
}

export interface Assignment {
  id: string;
  courseId: string;
  caseId: string;
  configId: string;
  caseName: string;
  caseDescription: string;
  configName: string;
  chiefComplaint: string;
  patientLabel: string;
  attempts?: number;
  look: PatientLook;
  diagnosisType: "diagnosis" | "none";
}

/** What a student is allowed to see before and during an encounter. */
export interface StudentBrief {
  caseName: string;
  caseDescription: string;
  configName: string;
  patient: { name: string; age: string; sex: string; occupation: string; chiefComplaint: string };
  contextGoal: string;
  encounterTasks: string[];
  postEncounterTasks: string[];
  diagnosisType: "diagnosis" | "none";
  notesEnabled: boolean;
  timeLimitMin: number;
  voice: VoiceSettings;
  appearance: Appearance;
  /** Only filled when the configuration uses testOrdering "menu"; empty in search mode so nothing is given away. */
  tests: { id: string; category: string; name: string }[];
  testOrdering: "search" | "menu";
  /** Door note (vitals, setting) shown on the brief. */
  doorNote: string;
  /** Starting expression for the patient's face. */
  initialEmotion: string;
  /** Results the student reviews before starting (only when the configuration enables showResultsInBrief). */
  briefResults?: { category: string; name: string; result: string }[];
  /** Whether emotive (Gemini Live) voice can be offered for this encounter. */
  emotiveAvailable?: boolean;
}

export type MessageRole = "doctor" | "patient" | "exam" | "system";

export interface Message {
  role: MessageRole;
  text: string;
  /** Milliseconds since encounter start. */
  t: number;
  emotion?: string;
  /** For exam messages: the test or exam name. */
  test?: string;
}

export interface Order {
  testId: string;
  name: string;
  category: string;
  result: string;
  t: number;
}

export interface RubricScore {
  category: string;
  level: string;
  /** kind: "praise" = an example of doing it well, "improve" = an example to do differently. */
  evidence: { quote: string; verified: boolean; kind?: "praise" | "improve" }[];
  /** Empty when nothing in the transcript supports a strength for this skill (never invented). */
  strengths: string;
  improve: string;
}

export interface Feedback {
  correctDiagnosis: string;
  diagnosisVerdict: "correct" | "partial" | "incorrect" | "n/a";
  /** Whether the history and tests the student actually gathered support their diagnosis. */
  diagnosisSupport?: "supported" | "partly" | "unsupported" | "n/a";
  diagnosisComment: string;
  rubric: RubricScore[];
  historyMissed: string[];
  testsReview: { orderedExpected: string[]; missedExpected: string[]; unnecessary: string[]; comment: string };
  differential: string[];
  notesFeedback: string;
  summary: string;
  nextSteps: string[];
  provider?: string;
  error?: string;
}

export interface ProsodyMetrics {
  speakingSeconds: number;
  wordsPerMinute: number;
  avgPauseSec: number;
  longPauses: number;
  pitchVariation: number; // semitones std-dev
  loudnessVariation: number;
  talkShare: number; // doctor share of words 0..1
  fillerWords: number;
  /** AI listen-back of the clinician's recorded voice (optional). */
  ai?: ProsodyAi | null;
}

export interface ProsodyAi {
  dimensions: { name: string; score: number; comment: string }[];
  summary: string;
  tips: string[];
  provider?: string;
  /** True when there was too little of the student's speech to rate tone fairly (dimensions is then empty). */
  insufficient?: boolean;
}

export interface Encounter {
  id: string;
  userId: string;
  assignmentId: string | null;
  caseId: string;
  configId: string;
  mode: "text" | "voice" | "emotive";
  language: string;
  status: "active" | "grading" | "done";
  messages: Message[];
  orders: Order[];
  notepad: string;
  tasksDone: number[];
  diagnosis: string;
  note: string;
  feedback: Feedback | null;
  prosody: ProsodyMetrics | null;
  startedAt: number;
  endedAt: number | null;
  brief: StudentBrief;
  studentName?: string;
  comments?: Comment[];
  levels?: string[];
}

export interface Comment {
  id: string;
  messageIdx: number;
  authorName: string;
  body: string;
  createdAt: number;
}

export interface EncounterSummary {
  id: string;
  caseName: string;
  /** The configuration it ran under, so results can be grouped by configuration even when two share a name. */
  configId: string;
  configName: string;
  courseName: string | null;
  studentName?: string;
  studentEmail?: string;
  mode: string;
  status: string;
  startedAt: number;
  endedAt: number | null;
  levels: string[];
  scores: { category: string; level: string }[];
  diagnosisVerdict?: string;
  /** Whether the history and tests gathered support the diagnosis given (from the feedback), when graded. */
  diagnosisSupport?: Feedback["diagnosisSupport"];
  /** Number of things the student said; 0 means the attempt was abandoned without talking. */
  doctorTurns?: number;
  /** Which AI model graded it, e.g. "gemini/gemini-3.6-flash". */
  gradedBy?: string;
}

/** What the free AI can handle, for the Admin page and course settings. */
export interface CapacityInfo {
  /** Google keys in use: the platform key plus any course or student keys. */
  keys: { platform: boolean; courses: number; students: number };
  /** Requests and errors today (UTC) per job, summed over models. */
  today: { task: string; requests: number; errors: number }[];
  /** Plain-language guidance about how many students the current setup supports. */
  guidance: string[];
  /** Whether the public demo course (code MEDSIM) is open to anyone. */
  demoCourseOpen: boolean;
  /** Overflow providers configured besides Google (e.g. "workers-ai", "groq"). */
  overflow: string[];
}

export interface AiStatus {
  mode: "real" | "demo";
  providers: string[];
  /** Emotive (Gemini Live) voice can be offered. */
  live: boolean;
}
