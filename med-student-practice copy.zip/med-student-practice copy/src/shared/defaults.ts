import type { Appearance, ConfigData, PatientLook, ProfileData } from "./types";

/** Product name shown in the interface. */
export const APP_NAME = "Med Student Practice AI";
export const INSPIRED_BY = "Heavily inspired by Dartmouth's AI Patient Actor";
export const NOT_AFFILIATED = "Independent project, not affiliated with or endorsed by Dartmouth College.";

/** Options for the illustrated patient (DiceBear "Avataaars", free for personal and commercial use). */
export const LOOK_OPTIONS = {
  skin: [
    ["ffdbb4", "Light"],
    ["edb98a", "Fair"],
    ["d08b5b", "Medium"],
    ["ae5d29", "Tan"],
    ["614335", "Deep"],
  ],
  top: [
    ["bob", "Bob"],
    ["bun", "Bun"],
    ["curly", "Curly"],
    ["curvy", "Wavy, long"],
    ["longButNotTooLong", "Shoulder length"],
    ["straight01", "Long straight"],
    ["straightAndStrand", "Straight with strand"],
    ["bigHair", "Big hair"],
    ["fro", "Afro"],
    ["froBand", "Afro with band"],
    ["dreads", "Locs, long"],
    ["hijab", "Hijab"],
    ["turban", "Turban"],
    ["shortFlat", "Short, flat"],
    ["shortRound", "Short, round"],
    ["shortWaved", "Short, waved"],
    ["shortCurly", "Short, curly"],
    ["theCaesar", "Caesar cut"],
    ["theCaesarAndSidePart", "Side part"],
    ["sides", "Balding"],
    ["shavedSides", "Shaved sides"],
    ["dreads01", "Locs, short"],
    ["frizzle", "Frizzy"],
    ["shaggy", "Shaggy"],
  ],
  hairColor: [
    ["2c1b18", "Black"],
    ["4a312c", "Dark brown"],
    ["724133", "Brown"],
    ["a55728", "Auburn"],
    ["b58143", "Light brown"],
    ["d6b370", "Blonde"],
    ["c93305", "Red"],
    ["e8e1e1", "Gray"],
  ],
  facialHair: [
    ["none", "None"],
    ["beardLight", "Light beard"],
    ["beardMedium", "Beard"],
    ["moustacheFancy", "Moustache"],
  ],
  accessories: [
    ["none", "None"],
    ["prescription01", "Glasses"],
    ["prescription02", "Thin glasses"],
    ["round", "Round glasses"],
  ],
} as const;

export const emptyAppearance = (): Appearance => ({ skin: "", top: "", hairColor: "", facialHair: "", accessories: "" });

export const lookOf = (p: Pick<ProfileData, "demographics" | "voice" | "appearance">): PatientLook => ({
  name: p.demographics.name,
  voice: p.voice,
  appearance: p.appearance ?? emptyAppearance(),
});

export const DEFAULT_LEVELS = ["Needs improvement", "Developing", "Proficient"];

/** "Needs Improvement" -> "Needs improvement". For labels that may come from older data or educators. */
export function sentenceCase(s: string): string {
  const t = s.trim();
  if (!t) return t;
  return t[0].toUpperCase() + t.slice(1).replace(/\b([A-Z])([a-z]+)/g, (_, a: string, b: string) => a.toLowerCase() + b);
}

/** Level names compare case-insensitively ("Needs Improvement" and "Needs improvement" are the same level). */
export const sameLevel = (a: string, b: string) => a.trim().toLowerCase() === b.trim().toLowerCase();

/** Used when a configuration has no rubric of its own. levelDescriptors follow DEFAULT_LEVELS order. */
export const DEFAULT_RUBRIC = [
  {
    name: "Rapport and introduction",
    description: "Introduces self and role, sets an agenda, shows interest in the patient as a person, and elicits all of their concerns.",
    levelDescriptors: [
      "Does not introduce self or role and starts straight into questions.",
      "Introduces self, but sets no agenda or does not ask about other concerns.",
      "Introduces self and role, sets an agenda, shows interest in the person, and elicits all of their concerns.",
    ],
  },
  {
    name: "Open-ended inquiry",
    description: "Starts with open questions and lets the patient tell their story before narrowing down; avoids leading or stacked questions.",
    levelDescriptors: [
      "Mostly closed, leading or stacked questions; interrupts the patient.",
      "Starts with an open question, but narrows too early or interrupts at times.",
      "Starts open, lets the patient tell their story, then narrows with focused questions; no leading or stacked questions.",
    ],
  },
  {
    name: "Focused history",
    description: "Gathers the history of the presenting problem plus past medical, medication, allergy, family and social history relevant to the case.",
    levelDescriptors: [
      "Misses most of the presenting problem or most of the background history.",
      "Covers the presenting problem, but misses relevant background such as medications, allergies or social history.",
      "Covers the presenting problem and the relevant past medical, medication, allergy, family and social history.",
    ],
  },
  {
    name: "Communication and empathy",
    description: "Uses plain language, acknowledges emotions, checks understanding, summarizes, and stays professional.",
    levelDescriptors: [
      "Uses jargon, passes over emotional cues, and does not check understanding.",
      "Mostly plain language with some empathy, but misses cues or does not summarize.",
      "Uses plain language, acknowledges emotions, summarizes, checks understanding, and stays professional.",
    ],
  },
];

export const TEST_CATEGORIES = ["Vital signs", "Physical exam", "Laboratory", "Imaging", "Other tests"];

/** Maps any capitalisation of a category (e.g. older "Vital Signs") to its canonical name. */
export function canonicalCategory(c: string): string {
  return TEST_CATEGORIES.find((x) => x.toLowerCase() === c.trim().toLowerCase()) ?? (c.trim() || "Other tests");
}

export const EMOTIONS = ["neutral", "calm", "anxious", "sad", "angry", "confused", "in_pain", "relieved", "embarrassed"] as const;

/** Google's natural HD voices (used for both voice modes), with gender and character. */
export const HD_VOICES: { name: string; gender: "female" | "male"; style: string }[] = [
  { name: "Achernar", gender: "female", style: "soft" },
  { name: "Aoede", gender: "female", style: "breezy" },
  { name: "Autonoe", gender: "female", style: "bright" },
  { name: "Callirrhoe", gender: "female", style: "easy-going" },
  { name: "Despina", gender: "female", style: "smooth" },
  { name: "Erinome", gender: "female", style: "clear" },
  { name: "Gacrux", gender: "female", style: "mature" },
  { name: "Kore", gender: "female", style: "firm" },
  { name: "Laomedeia", gender: "female", style: "upbeat" },
  { name: "Leda", gender: "female", style: "youthful" },
  { name: "Pulcherrima", gender: "female", style: "forward" },
  { name: "Sulafat", gender: "female", style: "warm" },
  { name: "Vindemiatrix", gender: "female", style: "gentle" },
  { name: "Zephyr", gender: "female", style: "bright" },
  { name: "Achird", gender: "male", style: "friendly" },
  { name: "Algenib", gender: "male", style: "gravelly" },
  { name: "Algieba", gender: "male", style: "smooth" },
  { name: "Alnilam", gender: "male", style: "firm" },
  { name: "Charon", gender: "male", style: "informative" },
  { name: "Enceladus", gender: "male", style: "breathy" },
  { name: "Fenrir", gender: "male", style: "excitable" },
  { name: "Iapetus", gender: "male", style: "clear" },
  { name: "Orus", gender: "male", style: "firm" },
  { name: "Puck", gender: "male", style: "upbeat" },
  { name: "Rasalgethi", gender: "male", style: "informative" },
  { name: "Sadachbia", gender: "male", style: "lively" },
  { name: "Sadaltager", gender: "male", style: "knowledgeable" },
  { name: "Schedar", gender: "male", style: "even" },
  { name: "Umbriel", gender: "male", style: "easy-going" },
  { name: "Zubenelgenubi", gender: "male", style: "casual" },
];
export const LIVE_VOICES = HD_VOICES.map((v) => v.name);

/** A sensible natural voice for a patient's gender and age. */
export function defaultVoiceFor(gender: string, age: string): string {
  if (gender === "male") return age === "older" ? "Algenib" : age === "young" || age === "child" ? "Puck" : "Achird";
  return age === "older" ? "Gacrux" : age === "young" || age === "child" ? "Leda" : "Sulafat";
}

export function emptyProfile(): ProfileData {
  return {
    demographics: { name: "", age: "", sex: "", occupation: "", other: "" },
    voice: { gender: "female", age: "adult", pitch: 1, rate: 1, liveVoice: "Sulafat" },
    appearance: emptyAppearance(),
    diagnosis: "",
    patientKnowsDiagnosis: false,
    chiefComplaint: "",
    hpi: "",
    pmh: "",
    medsAllergies: "",
    familyHistory: "",
    socialHistory: "",
    ros: "",
    personality: {
      openness: "medium",
      conscientiousness: "medium",
      extraversion: "medium",
      agreeableness: "medium",
      neuroticism: "medium",
      notes: "",
    },
    communication: "",
    other: "",
    tests: [],
    doorNote: "",
    initialEmotion: "",
  };
}

export function emptyConfig(): ConfigData {
  return {
    contextGoal: "",
    encounterTasks: [],
    postEncounterTasks: [],
    diagnosisType: "diagnosis",
    roleplayInstructions: "",
    feedbackInstructions: "",
    notesFeedback: { enabled: false, criteria: "" },
    rubric: [],
    levels: [...DEFAULT_LEVELS],
    timeLimitMin: 0,
    testOrdering: "search",
    showResultsInBrief: false,
  };
}

/** Fill any missing fields so older or AI-drafted JSON is always complete. */
export function normalizeProfile(input: unknown): ProfileData {
  const base = emptyProfile();
  const p = (input && typeof input === "object" ? input : {}) as Partial<ProfileData>;
  const str = (v: unknown, d = "") => (typeof v === "string" ? v : v == null ? d : String(v));
  const lvl = (v: unknown) => (v === "low" || v === "high" ? v : "medium");
  const per = (p.personality ?? {}) as Partial<ProfileData["personality"]>;
  const dem = (p.demographics ?? {}) as Partial<ProfileData["demographics"]>;
  const voice = (p.voice ?? {}) as Partial<ProfileData["voice"]>;
  return {
    demographics: {
      name: str(dem.name),
      age: str(dem.age),
      sex: str(dem.sex),
      occupation: str(dem.occupation),
      other: str(dem.other),
    },
    voice: {
      gender: voice.gender === "male" || voice.gender === "neutral" ? voice.gender : "female",
      age: (["child", "young", "adult", "older"] as const).includes(voice.age as never) ? voice.age! : "adult",
      pitch: clampNum(voice.pitch, 0.5, 1.5, 1),
      rate: clampNum(voice.rate, 0.7, 1.3, 1),
      liveVoice: LIVE_VOICES.includes(str(voice.liveVoice)) ? str(voice.liveVoice) : defaultVoiceFor(str(voice.gender), str(voice.age)),
    },
    appearance: normalizeAppearance(p.appearance),
    diagnosis: str(p.diagnosis),
    patientKnowsDiagnosis: Boolean(p.patientKnowsDiagnosis),
    chiefComplaint: str(p.chiefComplaint),
    hpi: str(p.hpi),
    pmh: str(p.pmh),
    medsAllergies: str(p.medsAllergies),
    familyHistory: str(p.familyHistory),
    socialHistory: str(p.socialHistory),
    ros: str(p.ros),
    personality: {
      openness: lvl(per.openness),
      conscientiousness: lvl(per.conscientiousness),
      extraversion: lvl(per.extraversion),
      agreeableness: lvl(per.agreeableness),
      neuroticism: lvl(per.neuroticism),
      notes: str(per.notes),
    },
    communication: str(p.communication),
    other: str(p.other),
    tests: Array.isArray(p.tests)
      ? p.tests
          .filter((t) => t && typeof t === "object")
          .map((t, i) => ({
            id: str(t.id) || `t${i + 1}`,
            category: canonicalCategory(str(t.category)),
            name: str(t.name),
            result: str(t.result),
            expected: Boolean(t.expected),
          }))
          .filter((t) => t.name)
      : [],
    doorNote: str(p.doorNote),
    initialEmotion: (EMOTIONS as readonly string[]).includes(str(p.initialEmotion)) ? str(p.initialEmotion) : "",
  };
}

export function normalizeConfig(input: unknown): ConfigData {
  const c = (input && typeof input === "object" ? input : {}) as Partial<ConfigData>;
  const strs = (v: unknown) => (Array.isArray(v) ? v.map((x) => String(x ?? "").trim()).filter(Boolean) : []);
  const levels = strs(c.levels);
  return {
    contextGoal: typeof c.contextGoal === "string" ? c.contextGoal : "",
    encounterTasks: strs(c.encounterTasks),
    postEncounterTasks: strs(c.postEncounterTasks),
    diagnosisType: c.diagnosisType === "none" ? "none" : "diagnosis",
    roleplayInstructions: typeof c.roleplayInstructions === "string" ? c.roleplayInstructions : "",
    feedbackInstructions: typeof c.feedbackInstructions === "string" ? c.feedbackInstructions : "",
    notesFeedback: {
      enabled: Boolean(c.notesFeedback?.enabled),
      criteria: typeof c.notesFeedback?.criteria === "string" ? c.notesFeedback.criteria : "",
    },
    rubric: Array.isArray(c.rubric)
      ? c.rubric
          .map((r) => {
            const name = String(r?.name ?? "").trim();
            const description = String(r?.description ?? "").trim();
            const descriptors = Array.isArray(r?.levelDescriptors) ? r.levelDescriptors.map((d) => String(d ?? "").trim()) : [];
            return descriptors.some(Boolean) ? { name, description, levelDescriptors: descriptors } : { name, description };
          })
          .filter((r) => r.name)
      : [],
    levels: levels.length >= 2 ? levels.map((l) => (DEFAULT_LEVELS.some((d) => sameLevel(d, l)) ? DEFAULT_LEVELS.find((d) => sameLevel(d, l))! : l)) : [...DEFAULT_LEVELS],
    timeLimitMin: clampNum(c.timeLimitMin, 0, 120, 0),
    testOrdering: c.testOrdering === "menu" ? "menu" : "search",
    showResultsInBrief: Boolean(c.showResultsInBrief),
  };
}

function normalizeAppearance(v: unknown): Appearance {
  const a = (v && typeof v === "object" ? v : {}) as Partial<Appearance>;
  const pick = (key: keyof typeof LOOK_OPTIONS, val: unknown) =>
    typeof val === "string" && (LOOK_OPTIONS[key] as readonly (readonly [string, string])[]).some(([k]) => k === val) ? val : "";
  return {
    skin: pick("skin", a.skin),
    top: pick("top", a.top),
    hairColor: pick("hairColor", a.hairColor),
    facialHair: pick("facialHair", a.facialHair),
    accessories: pick("accessories", a.accessories),
  };
}

function clampNum(v: unknown, min: number, max: number, d: number): number {
  const n = typeof v === "number" ? v : Number(v);
  if (!Number.isFinite(n)) return d;
  return Math.min(max, Math.max(min, n));
}

export function patientLabel(p: ProfileData): string {
  const d = p.demographics;
  return [d.name, d.age && `${d.age}`, d.sex].filter(Boolean).join(", ");
}
