import { defineConfig } from "vitest/config";

// Unit tests run in plain Node; the Cloudflare dev plugin is only for `npm run dev` and builds.
export default defineConfig({ test: { include: ["tests/**/*.test.ts"] } });
