import { beforeAll, describe, expect, it } from "vitest";
import { seedDatabase } from "../src/worker/seed";
import { findTest, sameOrder, severalOrders, vagueOrder } from "../src/worker/routes/encounters";
import { TEST_CATALOG } from "../src/shared/testCatalog";
import type { ProfileData, TestItem } from "../src/shared/types";

// The real seed cases, read by running the seed against a stand-in database that records what it writes.
const cases: Record<string, TestItem[]> = {};
beforeAll(async () => {
  const db = {
    prepare: (sql: string) => ({
      bind: (...args: unknown[]) => {
        if (sql.startsWith("INSERT INTO profiles")) cases[String(args[0]).replace("seed-pro-", "")] = (JSON.parse(String(args[3])) as ProfileData).tests;
        return {};
      },
    }),
    batch: async () => [],
  } as unknown as D1Database;
  await seedDatabase(db);
});

/** The main name of the test an order finds in a seed case, or null when the case file doesn't include it. */
const order = (caseKey: string, query: string) => findTest(cases[caseKey], query)?.name.split(" (")[0] ?? null;

describe("typed orders against the seed cases", () => {
  it("loads every seed case", () => {
    expect(Object.keys(cases).sort()).toEqual(["crc", "pneumonia", "pneumonia-followup", "sah", "thyroid"]);
  });

  // [case, what the student types, the test it should find or null]
  const rows: [string, string, string | null][] = [
    // Misses from the wave 1 seed review
    ["sah", "CT", "CT head without contrast"],
    ["thyroid", "CT", null],
    ["pneumonia", "CT", "CT chest"],
    ["pneumonia", "FBC", "Complete blood count"],
    ["thyroid", "LFTs", "Comprehensive metabolic panel"],
    ["pneumonia", "LFTs", null],
    ["thyroid", "TFTs", "TSH"],
    ["thyroid", "T3", null],
    ["thyroid", "free T3", null],
    ["thyroid", "T4", "Free T4"],
    ["pneumonia", "listen to lungs", "Respiratory exam"],
    ["pneumonia-followup", "listen to the lungs", "Respiratory exam"],
    ["thyroid", "vitamin D", null],
    ["thyroid", "vitamin B12", "Vitamin B12 and folate"],
    ["thyroid", "drug screen", null],
    ["sah", "drug screen", "Urine drug screen"],
    ["pneumonia", "blood cultures", "Blood cultures"],
    ["thyroid", "blood cultures", null],
    ["pneumonia", "blood sugar", "Basic metabolic panel"],
    ["thyroid", "blood sugar", "Comprehensive metabolic panel"],
    ["thyroid", "sed rate", "ESR and CRP"],
    ["pneumonia", "sed rate", null],
    ["thyroid", "HIV test", null],
    ["sah", "HIV test", null],
    ["thyroid", "urine dip", null],
    ["sah", "urine dip", null],
    ["thyroid", "CK", null],
    // Exams
    ["pneumonia", "physical exam", "General appearance"],
    ["thyroid", "examine the patient", "General appearance"],
    ["sah", "exam", "General appearance"],
    ["thyroid", "lung exam", "Respiratory exam"],
    ["thyroid", "cardiac exam", "Cardiac exam"],
    ["thyroid", "abdominal exam", "Abdominal exam"],
    ["thyroid", "neuro exam", "Neurological exam"],
    ["thyroid", "thyroid exam", "Thyroid and neck exam"],
    ["pneumonia", "heart sounds", "Cardiac exam"],
    ["pneumonia", "examine abdomen", "Abdominal exam"],
    ["pneumonia", "look in the ears", "HEENT exam"],
    ["pneumonia", "ENT exam", "HEENT exam"],
    ["pneumonia", "neck stiffness", "Neurological exam"],
    ["sah", "neck stiffness", "Neck exam and meningeal signs"],
    ["sah", "check pupils", "Neurological exam"],
    ["sah", "GCS", "Neurological exam"],
    ["sah", "eye exam", "Fundoscopy"],
    ["pneumonia", "rectal exam", null],
    // Vital signs
    ["pneumonia", "vitals", "Vital signs"],
    ["pneumonia", "BP", "Vital signs"],
    ["pneumonia", "heart rate", "Vital signs"],
    ["pneumonia", "sats", "Vital signs"],
    ["pneumonia", "temp", "Vital signs"],
    ["thyroid", "BMI", "Weight and BMI"],
    // Labs
    ["pneumonia", "CBC", "Complete blood count"],
    ["pneumonia", "full blood count", "Complete blood count"],
    ["thyroid", "Hb", "Complete blood count"],
    ["thyroid", "hemoglobin", "Complete blood count"],
    ["thyroid", "HbA1c", "Hemoglobin A1c"],
    ["thyroid", "hemoglobin A1c", "Hemoglobin A1c"],
    ["pneumonia", "U&Es", "Basic metabolic panel"],
    ["pneumonia", "lytes", "Basic metabolic panel"],
    ["pneumonia", "renal function", "Basic metabolic panel"],
    ["pneumonia", "CRP", "C-reactive protein"],
    ["thyroid", "CRP", "ESR and CRP"],
    ["thyroid", "ESR", "ESR and CRP"],
    ["pneumonia", "ABG", "Arterial blood gas"],
    ["pneumonia", "blood gas", "Arterial blood gas"],
    ["pneumonia", "trop", "Troponin"],
    ["pneumonia", "d-dimer", "D-dimer"],
    ["pneumonia", "sputum culture", "Sputum Gram stain and culture"],
    ["pneumonia", "urine culture", null],
    ["pneumonia", "flu swab", "Respiratory viral panel"],
    ["pneumonia", "COVID-19 test", "Respiratory viral panel"],
    ["thyroid", "thyroid function", "TSH"],
    ["thyroid", "anti-TPO", "Thyroid peroxidase antibodies"],
    ["thyroid", "ferritin", "Iron studies"],
    ["thyroid", "cholesterol", "Lipid panel"],
    ["thyroid", "pregnancy test", "Urine pregnancy test"],
    ["thyroid", "serum hCG", null],
    ["thyroid", "PHQ9", "PHQ-9 depression screen"],
    ["sah", "coags", "Coagulation panel"],
    ["sah", "INR", "Coagulation panel"],
    ["sah", "group and save", "Type and screen"],
    ["sah", "tox screen", "Urine drug screen"],
    ["crc", "CEA", "CEA"],
    ["crc", "CT scan", "Staging CT chest, abdomen and pelvis"],
    // Imaging and other tests
    ["pneumonia", "CXR", "Chest X-ray"],
    ["pneumonia", "chest x-ray", "Chest X-ray"],
    ["pneumonia", "chest", "Chest X-ray"],
    ["pneumonia", "CTPA", "CT chest"],
    ["sah", "head CT", "CT head without contrast"],
    ["sah", "CTA", "CT angiography of the head and neck"],
    ["sah", "MRI", "MRI brain"],
    ["sah", "MRI spine", null],
    ["sah", "CT chest", null],
    ["thyroid", "neck ultrasound", "Thyroid ultrasound"],
    ["thyroid", "renal ultrasound", null],
    ["thyroid", "abdominal ultrasound", null],
    ["thyroid", "CT abdomen", null],
    ["pneumonia", "EKG", "ECG"],
    ["pneumonia", "12 lead ECG", "ECG"],
    ["sah", "LP", "Lumbar puncture"],
    ["sah", "spinal tap", "Lumbar puncture"],
    ["sah", "CSF", "Lumbar puncture"],
    ["pneumonia-followup", "PFTs", "Spirometry"],
    ["pneumonia-followup", "lung function", "Spirometry"],
    ["pneumonia-followup", "lung cancer screening", "Low-dose CT chest"],
  ];
  it.each(rows)("%s: %s", (caseKey, query, expected) => {
    expect(order(caseKey, query)).toBe(expected);
  });

  it("finds every seed test by its own main name", () => {
    for (const [key, tests] of Object.entries(cases)) {
      for (const t of tests) expect(findTest(tests, t.name.split(" (")[0])?.id, `${key}: ${t.name}`).toBe(t.id);
    }
  });

  it("never matches a catalog suggestion to a different kind of test", () => {
    for (const [key, tests] of Object.entries(cases)) {
      for (const c of TEST_CATALOG) {
        const hit = findTest(tests, c.name);
        if (hit) expect(hit.category, `${key}: ${c.name} -> ${hit.name}`).toBe(c.category);
      }
    }
  });
});

describe("test catalog", () => {
  it("offers about 150 distinct exams and tests in the standard categories", () => {
    expect(TEST_CATALOG.length).toBeGreaterThanOrEqual(140);
    expect(new Set(TEST_CATALOG.map((c) => c.name.toLowerCase())).size).toBe(TEST_CATALOG.length);
    for (const c of TEST_CATALOG) {
      expect(["Vital signs", "Physical exam", "Laboratory", "Imaging", "Other tests"]).toContain(c.category);
      expect(vagueOrder(c.name), c.name).toBe(false);
    }
  });

  it("tells one order from several", () => {
    for (const q of ["listen to heart and lungs", "CBC, BMP", "CBC & BMP", "ESR and CRP"]) expect(severalOrders(q), q).toBe(true);
    for (const q of ["Weight and BMI", "group and save", "U&E", "PT/INR", "Chlamydia and gonorrhea test", "chest x-ray"]) expect(severalOrders(q), q).toBe(false);
  });

  it("treats two wordings of the same unknown order as one", () => {
    expect(sameOrder("urine dip", "Urinalysis")).toBe(true);
    expect(sameOrder("urine culture", "blood culture")).toBe(false);
    expect(sameOrder("HIV test", "HIV  test ")).toBe(true);
  });

  it("flags orders that name no particular test", () => {
    for (const q of ["blood test", "labs", "bloods", "imaging", "test", "please"]) expect(vagueOrder(q), q).toBe(true);
    for (const q of ["physical exam", "CBC", "urinalysis", "vitamin D"]) expect(vagueOrder(q), q).toBe(false);
  });
});
