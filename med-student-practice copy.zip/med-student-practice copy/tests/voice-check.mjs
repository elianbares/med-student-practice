// Checks the voice features end to end through the app's own API (needs a Google key in .dev.vars; about 6 AI calls).
// Usage: node tests/voice-check.mjs <path-to-16kHz-wav> [baseUrl]
import { readFileSync } from "node:fs";
import { clientHash } from "./test-admin.mjs";

const wavPath = process.argv[2];
const BASE = process.argv[3] ?? "http://127.0.0.1:5173";
let cookie = "";
let failures = 0;
const check = (ok, label, extra) => {
  console.log(`${ok ? "PASS" : "FAIL"}  ${label}${extra !== undefined ? `  -> ${String(extra).slice(0, 220)}` : ""}`);
  if (!ok) failures++;
};
async function call(method, path, body, headers = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: { "x-requested-with": "apa", ...(body instanceof Uint8Array ? {} : { "content-type": "application/json" }), ...headers, ...(cookie ? { cookie } : {}) },
    body: body === undefined ? undefined : body instanceof Uint8Array ? body : JSON.stringify(body),
  });
  const set = res.headers.get("set-cookie");
  if (set) cookie = set.split(";")[0];
  return { status: res.status, data: await res.json().catch(() => ({})) };
}

/** The format and samples of a PCM WAV file. */
function readWav(bytes) {
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let fmt = null;
  for (let off = 12; off + 8 <= bytes.byteLength; ) {
    const id = String.fromCharCode(...bytes.subarray(off, off + 4));
    const size = v.getUint32(off + 4, true);
    if (id === "fmt ") fmt = { channels: v.getUint16(off + 10, true), rate: v.getUint32(off + 12, true), bits: v.getUint16(off + 22, true) };
    if (id === "data" && fmt) {
      const samples = bytes.subarray(off + 8, Math.min(bytes.byteLength, off + 8 + size));
      const byteRate = fmt.rate * fmt.channels * (fmt.bits / 8);
      return { ...fmt, byteRate, samples, seconds: samples.byteLength / byteRate };
    }
    off += 8 + size + (size & 1);
  }
  throw new Error(`${wavPath} is not a PCM WAV file.`);
}

/** A WAV at least `minSeconds` long: the clip's samples repeated under a new 44-byte header. */
function longerWav(wav, minSeconds) {
  const times = Math.ceil(minSeconds / wav.seconds);
  const size = wav.samples.byteLength * times;
  const out = new Uint8Array(44 + size);
  const v = new DataView(out.buffer);
  const text = (at, s) => [...s].forEach((ch, i) => (out[at + i] = ch.charCodeAt(0)));
  text(0, "RIFF");
  v.setUint32(4, 36 + size, true);
  text(8, "WAVE");
  text(12, "fmt ");
  v.setUint32(16, 16, true); // fmt chunk size
  v.setUint16(20, 1, true); // PCM
  v.setUint16(22, wav.channels, true);
  v.setUint32(24, wav.rate, true);
  v.setUint32(28, wav.byteRate, true);
  v.setUint16(32, wav.channels * (wav.bits / 8), true);
  v.setUint16(34, wav.bits, true);
  text(36, "data");
  v.setUint32(40, size, true);
  for (let i = 0; i < times; i++) out.set(wav.samples, 44 + i * wav.samples.byteLength);
  return out;
}

const email = `voice-${Date.now().toString(36)}@test.local`;
const password = "pw-voicecheck";
const su = await call("POST", "/api/auth/signup", { email, name: "Vera Voice", clientHash: await clientHash(email, password), consent: true });
// New students land in the demo course; joining it again only returns its id.
const courseId = su.data.enrolledCourseId ?? (await call("POST", "/api/courses/enroll", { code: "MEDSIM" })).data.id;
const view = await call("GET", `/api/courses/${courseId}`);
const asg = view.data.assignments.find((a) => a.caseName === "Cough and fever");

// 1) Emotive voice: token from our server, then a real Live exchange.
const enc = await call("POST", "/api/encounters", { assignmentId: asg.id, mode: "emotive", language: "en-US" });
await call("POST", `/api/encounters/${enc.data.id}/begin`, {});
const tok = await call("POST", `/api/encounters/${enc.data.id}/live-token`, {});
check(tok.status === 200 && tok.data.token?.startsWith("auth_tokens/"), `live token minted (${tok.data.model})`, tok.status !== 200 ? JSON.stringify(tok.data) : undefined);
if (tok.data.token) {
  const r = await new Promise((resolve) => {
    const ws = new WebSocket(`wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained?access_token=${encodeURIComponent(tok.data.token)}`);
    const out = { setup: false, audio: 0, text: "" };
    const timer = setTimeout(() => (ws.close(), resolve(out)), 30000);
    ws.onopen = () => ws.send(JSON.stringify({ setup: { model: `models/${tok.data.model}` } }));
    ws.onmessage = async (ev) => {
      const m = JSON.parse(typeof ev.data === "string" ? ev.data : await ev.data.text());
      if (m.setupComplete) {
        out.setup = true;
        ws.send(JSON.stringify({ realtimeInput: { text: "Hello Mr. Bell, I'm Dr. Lee. What brings you in today?" } }));
      }
      for (const p of m.serverContent?.modelTurn?.parts ?? []) if (p.inlineData) out.audio += p.inlineData.data.length * 0.75;
      if (m.serverContent?.outputTranscription?.text) out.text += m.serverContent.outputTranscription.text;
      if (m.serverContent?.turnComplete) (clearTimeout(timer), ws.close(), resolve(out));
    };
    ws.onclose = () => (clearTimeout(timer), resolve(out));
  });
  check(r.setup && r.audio > 20000, `live patient spoke (${Math.round(r.audio / 1024)} KB audio)`, r.text);
  check(/cough|fever|week/i.test(r.text), "live patient stayed in the case (mentions cough/fever)", r.text);
  check(!/pneumonia/i.test(r.text), "live patient did not reveal the diagnosis", r.text);
  const tr = await call("POST", `/api/encounters/${enc.data.id}/transcript`, { doctor: "Hello Mr. Bell, I'm Dr. Lee. What brings you in today?", patient: r.text, emotion: "anxious" });
  check(tr.status === 200 && tr.data.count === 2, "live turn saved to transcript", JSON.stringify(tr.data));
}

// 2) Speech-to-text fallback.
const bytes = new Uint8Array(readFileSync(wavPath));
const clip = readWav(bytes);
const stt = await call("POST", `/api/encounters/${enc.data.id}/stt`, bytes, { "content-type": "audio/wav" });
check(stt.status === 200 && /doctor|lee|cough/i.test(stt.data.text ?? ""), "speech-to-text transcribes the clip", stt.data.text ?? JSON.stringify(stt.data));

// 3) AI voice analysis: under 30 s of the student's speech is not rated (and asks no AI); a longer recording is,
// and its Pace rating must agree with the pace the browser measured (sent as ?wpm=).
const short = await call("POST", `/api/encounters/${enc.data.id}/prosody-audio`, bytes, { "content-type": "audio/wav" });
check(
  clip.seconds < 30 && short.status === 200 && short.data.insufficient === true && Array.isArray(short.data.dimensions) && short.data.dimensions.length === 0 && short.data.summary,
  `a ${clip.seconds.toFixed(1)} s recording is too short to rate`,
  JSON.stringify(short.data),
);
const long = longerWav(clip, 31);
const longSeconds = readWav(long).seconds;
const wpm = 190; // faster than the comfortable 110 to 170, so the Pace rating is capped at 3 and names it
const pa = await call("POST", `/api/encounters/${enc.data.id}/prosody-audio?wpm=${wpm}`, long, { "content-type": "audio/wav" });
check(pa.status === 200 && !pa.data.insufficient && pa.data.dimensions?.length >= 4, `AI voice analysis of ${longSeconds.toFixed(1)} s (${pa.data.provider})`, pa.data.summary ?? JSON.stringify(pa.data));
const pace = pa.data.dimensions?.find((d) => /pace|speed|rate|tempo/i.test(d.name));
check(pace && pace.score <= 3 && pace.comment.includes(String(wpm)), `pace rating agrees with the measured ${wpm} words per minute`, JSON.stringify(pace ?? pa.data.dimensions));

const prosody = { speakingSeconds: Math.round(longSeconds), wordsPerMinute: wpm, avgPauseSec: 1.2, longPauses: 0, pitchVariation: 2.4, loudnessVariation: 3, talkShare: 0.4, fillerWords: 2 };
const end = await call("POST", `/api/encounters/${enc.data.id}/end`, { diagnosis: "", note: "", prosody });
check(end.status === 200 && end.data.prosody?.ai?.dimensions?.length >= 4 && end.data.prosody?.wordsPerMinute === wpm, "feedback merges voice metrics with AI analysis");
check(end.data.feedback && !end.data.feedback.error, `emotive encounter graded (${end.data.feedback?.provider})`, end.data.feedback?.error);

const gone = await call("DELETE", "/api/me", { passwordHash: await clientHash(email, password) });
check(gone.status === 200, "test account deleted", gone.status !== 200 ? JSON.stringify(gone.data) : undefined);

console.log(failures ? `\n${failures} check(s) FAILED` : "\nAll voice checks passed");
process.exit(failures ? 1 : 0);
