// Checks natural-voice streaming for every demo patient through the app's API (one TTS call per demo case).
// Usage: node tests/tts-check.mjs [baseUrl]
import { clientHash } from "./test-admin.mjs";

const BASE = process.argv[2] ?? "http://127.0.0.1:5173";
let cookie = "";
const call = async (method, path, body, raw = false) => {
  const res = await fetch(BASE + path, { method, headers: { "content-type": "application/json", "x-requested-with": "apa", ...(cookie ? { cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const set = res.headers.get("set-cookie");
  if (set) cookie = set.split(";")[0];
  return raw ? res : { status: res.status, data: await res.json().catch(() => ({})) };
};
const email = `tts-${Date.now().toString(36)}@test.local`;
const password = "pw-tts-check";
const su = await call("POST", "/api/auth/signup", { email, name: "Tess TTS", clientHash: await clientHash(email, password), consent: true });
// New students land in the demo course; joining it again only returns its id.
const courseId = su.data.enrolledCourseId ?? (await call("POST", "/api/courses/enroll", { code: "MEDSIM" })).data.id;
const { assignments = [] } = (await call("GET", `/api/courses/${courseId}`)).data;
let failures = assignments.length ? 0 : 1;
if (!assignments.length) console.log("FAIL  the demo course has no cases");
for (const a of assignments.filter((x, i, arr) => arr.findIndex((y) => y.caseId === x.caseId) === i)) {
  const e = await call("POST", "/api/encounters", { assignmentId: a.id, mode: "voice", language: "en-US" });
  const t0 = Date.now();
  const res = await call("POST", `/api/encounters/${e.data.id}/tts`, { text: "Hi doctor. Honestly, I'm a little worried about all this.", emotion: "anxious" }, true);
  let first = 0, bytes = 0, mime = "";
  if (res.ok) {
    const text = await res.text();
    for (const line of text.split("\n")) {
      if (!line.startsWith("data:")) continue;
      for (const p of JSON.parse(line.slice(5)).candidates?.[0]?.content?.parts ?? []) if (p.inlineData) { bytes += p.inlineData.data.length * 0.75; mime = p.inlineData.mimeType; first ||= Date.now() - t0; }
    }
  }
  const ok = res.ok && bytes > 30000;
  if (!ok) failures++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${String(a.patientLabel ?? a.caseName).padEnd(32)} ${res.status} ${Math.round(bytes / 1024)} KB ${mime} total ${Date.now() - t0}ms`);
}
const gone = await call("DELETE", "/api/me", { passwordHash: await clientHash(email, password) });
if (gone.status !== 200) (failures++, console.log(`FAIL  test account not deleted (${gone.status})`));
process.exit(failures ? 1 : 0);
