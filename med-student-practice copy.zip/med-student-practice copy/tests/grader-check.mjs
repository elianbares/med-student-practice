// Grader sanity check against a running dev server with a real AI key (uses about 11 AI calls).
// A strong interviewer and a guesser both see the "Cough and fever" OSCE case and name the right diagnosis.
// The guesser must be called out as unsupported and score lower; feedback must speak to "you" without dashes,
// quote only real lines, and the patient must never learn more than the student's first name.
// Usage: node tests/grader-check.mjs [baseUrl]
const BASE = process.argv[2] ?? "http://127.0.0.1:5173";
const run = Date.now().toString(36);
let failures = 0;

function check(cond, label, extra) {
  console.log(`${cond ? "PASS" : "FAIL"}  ${label}${!cond && extra !== undefined ? `  -> ${JSON.stringify(extra).slice(0, 400)}` : ""}`);
  if (!cond) failures++;
}
const info = (label, value) => console.log(`INFO  ${label}: ${typeof value === "string" ? value : JSON.stringify(value)}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Same client-side password hashing as the app (and tests/smoke.mjs).
async function clientHash(email, password) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: enc.encode(`ai-patient-actor:${email.trim().toLowerCase()}`), iterations: 210000 },
    key,
    256,
  );
  return Buffer.from(bits).toString("hex");
}

function client() {
  let cookie = "";
  async function call(method, path, body, raw = false) {
    const res = await fetch(BASE + path, {
      method,
      headers: { "content-type": "application/json", "x-requested-with": "apa", ...(cookie ? { cookie } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const set = res.headers.get("set-cookie");
    if (set) cookie = set.split(";")[0];
    if (raw) return res;
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
    return { status: res.status, data };
  }
  /** Posts raw bytes (for audio uploads) with the session cookie. */
  async function upload(path, bytes, type) {
    const res = await fetch(BASE + path, { method: "POST", headers: { "content-type": type, "x-requested-with": "apa", cookie }, body: bytes });
    return { status: res.status, data: await res.json().catch(() => null) };
  }
  return { call, upload };
}

/** A silent 16 kHz, 16-bit mono WAV with the usual 44-byte header, like the browser records. */
function silentWav(seconds, rate = 16000) {
  const bytes = seconds * rate * 2;
  const b = Buffer.alloc(44 + bytes);
  b.write("RIFF", 0);
  b.writeUInt32LE(36 + bytes, 4);
  b.write("WAVEfmt ", 8);
  b.writeUInt32LE(16, 16);
  b.writeUInt16LE(1, 20);
  b.writeUInt16LE(1, 22);
  b.writeUInt32LE(rate, 24);
  b.writeUInt32LE(rate * 2, 28);
  b.writeUInt16LE(2, 32);
  b.writeUInt16LE(16, 34);
  b.write("data", 36);
  b.writeUInt32LE(bytes, 40);
  return b;
}

/** Sends one line and waits for the whole patient reply; retries twice if the free AI is busy. */
async function say(c, encId, text) {
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await c.call("POST", `/api/encounters/${encId}/message`, { text }, true);
    if (res.status === 503 && attempt < 2) {
      await sleep(6000);
      continue;
    }
    if (!res.ok) return { status: res.status, error: await res.text() };
    const events = (await res.text())
      .split("\n\n")
      .map((b) => b.trim())
      .filter((b) => b.startsWith("data:"))
      .map((b) => JSON.parse(b.slice(5)));
    return { status: res.status, streamed: events.filter((e) => e.t).map((e) => e.t).join(""), done: events.find((e) => e.done) };
  }
}

function strings(v, out = []) {
  if (typeof v === "string") out.push(v);
  else if (Array.isArray(v)) v.forEach((x) => strings(x, out));
  else if (v && typeof v === "object") Object.values(v).forEach((x) => strings(x, out));
  return out;
}

const stu = client();
const email = `grader-${run}@test.local`;
const su = await stu.call("POST", "/api/auth/signup", { email, name: "Grace Check", clientHash: await clientHash(email, "pw-grader-check"), role: "student", consent: true });
check(su.status === 200, "student signup", su);
// New students land in the demo course while it is open; joining again by code just returns it.
const demo = await stu.call("POST", "/api/courses/enroll", { code: "MEDSIM" });
check(demo.status === 200 && demo.data.id, "join demo course MEDSIM", demo);
if (su.data?.enrolledCourseId) check(su.data.enrolledCourseId === demo.data.id, "sign-up enrolled the student in the demo course", su.data);
const course = await stu.call("GET", `/api/courses/${demo.data.id}`);
const asg = course.data.assignments?.find((a) => /^cough and fever/i.test(a.caseName) && (a.configId === "seed-cfg-osce" || /osce/i.test(a.configName)));
check(Boolean(asg), "found the Cough and fever OSCE assignment", course.data.assignments?.map((a) => `${a.caseName} / ${a.configName}`));
if (!asg) process.exit(1);

async function encounter(label, lines, orders) {
  const start = await stu.call("POST", "/api/encounters", { assignmentId: asg.id, mode: "text", language: "en-US" });
  check(start.status === 200 && start.data.id, `${label}: start encounter`, start);
  const id = start.data.id;
  await stu.call("POST", `/api/encounters/${id}/begin`);
  for (const [i, text] of lines.entries()) {
    const r = await say(stu, id, text);
    if (!(r.status === 200 && r.done?.message?.text)) check(false, `${label}: patient replied to line ${i + 1}`, r);
    else {
      if (/[\u2013\u2014]/.test(r.done.message.text + r.streamed)) check(false, `${label}: patient reply has no em or en dash`, r.done.message.text);
      // Pseudonymity: the patient only ever learns the student's first name.
      if (/Grace Check|\b(?:Ms|Mrs|Miss|Dr|Doctor)\.?\s+Check\b/.test(r.done.message.text)) check(false, `${label}: patient never uses the student's surname`, r.done.message.text);
      if ((r.done.message.text.match(/\*[^*]+\*/g) ?? []).length > 1) check(false, `${label}: at most one *action* per reply`, r.done.message.text);
    }
    if (i === lines.length - 2) {
      for (const q of orders) {
        const o = await stu.call("POST", `/api/encounters/${id}/orders`, { query: q });
        check(o.status === 200 && o.data?.order?.testId, `${label}: ordered "${q}" and got the case's result`, o);
      }
    }
  }
  const end = await stu.call("POST", `/api/encounters/${id}/end`, { diagnosis: "Community-acquired pneumonia", note: "" });
  check(end.status === 200 && end.data.feedback && !end.data.feedback.error, `${label}: graded`, end.data?.feedback?.error ?? end);
  return end.data;
}

const strong = await encounter(
  "strong",
  [
    "Hello Mr. Bell, I'm Grace Check, a medical student working with the team today. Is it alright if I ask you some questions about what brought you in?",
    "What brings you in today? Tell me about it in your own words.",
    "When did the cough start, and how has it changed since then? Are you bringing anything up?",
    "Have you had fevers, chills or night sweats? How high has your temperature been?",
    "Do you have any chest pain or trouble breathing? Where is the pain and what makes it worse?",
    "Do you have any medical conditions, take any medicines, or have any allergies to medicines?",
    "Do you smoke or drink alcohol? About how much each day or week?",
    "Thank you, that is really helpful. Your exam, blood count and chest X-ray point to a pneumonia in the lower part of your right lung. Because of your penicillin allergy we will choose a safe antibiotic for you. What questions do you have?",
  ],
  ["Vital signs", "Respiratory exam", "Complete blood count", "Chest X-ray"],
);
const guess = await encounter("guesser", ["Hi there."], []);

// Tone ratings need 30 seconds of your own speech: a 4-second recording gets a plain notice and no AI call.
const short = await stu.upload(`/api/encounters/${guess?.id}/prosody-audio`, silentWav(4), "audio/wav");
check(
  short.status === 200 && short.data?.insufficient === true && short.data.dimensions?.length === 0 && /^Not enough of your speech was recorded/.test(short.data.summary),
  "voice analysis under 30 seconds: no ratings, plain notice",
  short,
);
const saved = await stu.call("GET", `/api/encounters/${guess?.id}`);
check(saved.data?.prosody?.ai?.insufficient === true, "voice notice is saved with the encounter", saved.data?.prosody);

const levels = strong?.levels?.length ? strong.levels : ["Needs improvement", "Developing", "Proficient"];
const avg = (fb) => (fb?.rubric?.length ? fb.rubric.reduce((n, r) => n + Math.max(0, levels.indexOf(r.level)), 0) / fb.rubric.length : -1);
const sf = strong?.feedback;
const gf = guess?.feedback;
info("graded by", [sf?.provider, gf?.provider]);
info("strong levels", sf?.rubric?.map((r) => `${r.category}: ${r.level}`));
info("guesser levels", gf?.rubric?.map((r) => `${r.category}: ${r.level}`));
info("strong diagnosis", `${sf?.diagnosisVerdict} / ${sf?.diagnosisSupport}: ${sf?.diagnosisComment}`);
info("guesser diagnosis", `${gf?.diagnosisVerdict} / ${gf?.diagnosisSupport}: ${gf?.diagnosisComment}`);

check(gf?.diagnosisSupport === "unsupported", "guesser's diagnosis is marked unsupported", gf?.diagnosisSupport);
const reasoning = gf?.rubric?.find((r) => /reason/i.test(r.category));
check(reasoning?.level === levels[0], `guesser's clinical reasoning is at the lowest level (${levels[0]})`, reasoning);
check(!gf?.rubric?.some((r) => /reason/i.test(r.category) && r.strengths), "guesser gets no reasoning strength", reasoning?.strengths);
check(sf?.diagnosisSupport && sf.diagnosisSupport !== "unsupported", "strong interviewer's diagnosis is supported", sf?.diagnosisSupport);
check(avg(sf) > avg(gf), `strong interviewer's average level (${avg(sf).toFixed(2)}) is higher than the guesser's (${avg(gf).toFixed(2)})`);

const all = [...strings(sf), ...strings(gf)];
const dashed = all.filter((x) => /[\u2013\u2014]/.test(x));
check(dashed.length === 0, "no feedback string contains an em or en dash", dashed);
const third = all.filter((x) => /\bthe (?:medical )?trainee\b/i.test(x));
check(third.length === 0, 'no feedback string says "the trainee"', third);
const otherThird = all.filter((x) => /\bthe (?:medical )?(?:clinician|student|learner)\b/i.test(x));
if (otherThird.length) info("other third-person phrases", otherThird);
const norm = (t) => t.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
for (const [label, enc] of [["strong", strong], ["guesser", guess]]) {
  const said = ` ${norm((enc?.messages ?? []).filter((m) => m.role === "doctor").map((m) => m.text).join(" "))} `;
  const quotes = (enc?.feedback?.rubric ?? []).flatMap((r) => r.evidence ?? []);
  const fake = quotes.filter((e) => !e.verified || !said.includes(` ${norm(e.quote)} `));
  check(fake.length === 0, `${label}: every evidence quote (${quotes.length}) is something you actually said`, fake);
  info(`${label} strengths`, (enc?.feedback?.rubric ?? []).filter((r) => r.strengths).map((r) => `${r.category}: ${r.strengths}`));
  info(`${label} summary`, enc?.feedback?.summary ?? "");
}
const evidence = [...(sf?.rubric ?? []), ...(gf?.rubric ?? [])].flatMap((r) => r.evidence ?? []);
check(evidence.every((e) => e.kind === "praise" || e.kind === "improve"), "every evidence quote is tagged praise or improve", evidence.filter((e) => !e.kind));

console.log(failures ? `\n${failures} check(s) failed` : "\nAll grader checks passed");
process.exit(failures ? 1 : 0);
