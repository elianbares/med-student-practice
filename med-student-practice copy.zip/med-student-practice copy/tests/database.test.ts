// The server's own SQL (schema, upgrades, demo content, retention purge) run on a real SQLite database through a
// small D1 stand-in, so a broken query fails here instead of in the daily cron job or on a new deployment.
import { beforeAll, describe, expect, it, vi } from "vitest";
import { ensureSchema } from "../src/worker/db";
import { DEMO_COURSE_CODE, seedDatabase } from "../src/worker/seed";
import { purgeExpiredEncounters } from "../src/worker/index";
import type { Env } from "../src/worker/env";

// node:sqlite is built into Node 22 and later. @types/node isn't installed, so the few parts used are typed here.
interface SqliteStatement {
  get(...params: unknown[]): Record<string, unknown> | undefined;
  all(...params: unknown[]): Record<string, unknown>[];
  run(...params: unknown[]): { changes: number | bigint };
}
interface SqliteDb {
  prepare(sql: string): SqliteStatement;
  exec(sql: string): void;
}
const sqliteModule = "node:sqlite";
const { DatabaseSync } = (await import(/* @vite-ignore */ sqliteModule)) as { DatabaseSync: new (path: string) => SqliteDb };

/** The D1 calls the Worker makes (prepare, bind, first, all, run, batch), on an in-memory SQLite database. */
function memoryD1(): { DB: D1Database; sql: SqliteDb } {
  const sql = new DatabaseSync(":memory:");
  // D1 stores booleans as 1 and 0; node:sqlite refuses them.
  const value = (v: unknown) => (typeof v === "boolean" ? Number(v) : v === undefined ? null : v);
  const statement = (text: string, params: unknown[] = []) => {
    const args = params.map(value);
    return {
      bind: (...p: unknown[]) => statement(text, p),
      first: async (column?: string) => {
        const row = sql.prepare(text).get(...args) ?? null;
        return row && column ? row[column] : row;
      },
      all: async () => ({ results: sql.prepare(text).all(...args), success: true, meta: {} }),
      run: async () => ({ results: [], success: true, meta: { changes: Number(sql.prepare(text).run(...args).changes) } }),
      rows: () => sql.prepare(text).all(...args),
    };
  };
  const DB = {
    prepare: (text: string) => statement(text),
    // Like D1, a batch is one transaction.
    batch: async (stmts: { rows(): Record<string, unknown>[] }[]) => {
      sql.exec("BEGIN");
      try {
        const out = stmts.map((s) => ({ results: s.rows(), success: true, meta: {} }));
        sql.exec("COMMIT");
        return out;
      } catch (err) {
        sql.exec("ROLLBACK");
        throw err;
      }
    },
  } as unknown as D1Database;
  return { DB, sql };
}

const count = (sql: SqliteDb, query: string, ...params: unknown[]) => Number(sql.prepare(query).get(...params)?.n);
const ids = (sql: SqliteDb, query: string, ...params: unknown[]) => sql.prepare(query).all(...params).map((r) => String(r.id));

describe("a new database", () => {
  const { DB, sql } = memoryD1();
  const env = { DB } as Env;
  beforeAll(() => ensureSchema(env));

  it("gets every table and the demo content: 4 configurations, 5 patients and the open demo course", () => {
    expect(count(sql, `SELECT COUNT(*) AS n FROM configurations WHERE owner_id = 'system' AND is_public = 1`)).toBe(4);
    expect(count(sql, `SELECT COUNT(*) AS n FROM profiles WHERE owner_id = 'system'`)).toBe(5);
    const demo = sql.prepare(`SELECT id, enrollment_open, archived, retention_days FROM courses WHERE code = ?`).get(DEMO_COURSE_CODE);
    expect(demo).toMatchObject({ enrollment_open: 1, archived: 0, retention_days: 0 });
    expect(count(sql, `SELECT COUNT(*) AS n FROM assignments WHERE course_id = ?`, demo?.id)).toBe(5);
    // Every demo assignment points at a seeded case and one of that case's configurations.
    expect(
      count(
        sql,
        `SELECT COUNT(*) AS n FROM assignments a JOIN cases c ON c.id = a.case_id JOIN case_configs cc ON cc.case_id = a.case_id AND cc.config_id = a.config_id WHERE a.course_id = ?`,
        demo?.id,
      ),
    ).toBe(5);
  });

  it("seeds again without duplicating anything or changing demo ids", async () => {
    const tables = ["configurations", "profiles", "cases", "case_configs", "courses", "assignments"];
    const before = tables.map((t) => count(sql, `SELECT COUNT(*) AS n FROM ${t}`));
    const assignmentIds = ids(sql, `SELECT id FROM assignments ORDER BY id`);
    await seedDatabase(DB);
    expect(tables.map((t) => count(sql, `SELECT COUNT(*) AS n FROM ${t}`))).toEqual(before);
    expect(ids(sql, `SELECT id FROM assignments ORDER BY id`)).toEqual(assignmentIds);
  });

  describe("retention purge", () => {
    const DAY = 86_400_000;
    const NOW = Date.UTC(2026, 9, 28, 3);
    const addCourse = (id: string, retentionDays: number) =>
      sql.prepare(`INSERT INTO courses (id, owner_id, name, code, created_at, retention_days) VALUES (?, 'u-edu', ?, ?, ?, ?)`).run(id, id, id.toUpperCase(), NOW, retentionDays);
    const addEncounter = (id: string, courseId: string | null, daysAgo: number) =>
      sql
        .prepare(
          `INSERT INTO encounters (id, user_id, course_id, case_id, config_id, mode, language, status, snapshot, started_at)
           VALUES (?, 'u-stu', ?, 'seed-case-cough', 'seed-cfg-osce', 'text', 'en-US', 'done', '{}', ?)`,
        )
        .run(id, courseId, NOW - daysAgo * DAY);
    const addNotes = (encounterId: string) => {
      sql.prepare(`INSERT INTO comments (id, encounter_id, message_idx, author_id, body, created_at) VALUES (?, ?, 0, 'u-edu', 'Nice intro', ?)`).run(`c-${encounterId}`, encounterId, NOW);
      sql.prepare(`INSERT INTO notifications (id, user_id, kind, ref_id, body, created_at) VALUES (?, 'u-stu', 'comment', ?, 'New comment', ?)`).run(`n-${encounterId}`, encounterId, NOW);
    };

    it("deletes encounters older than their course keeps them, with their comments and notifications, and nothing else", async () => {
      addCourse("ret-30", 30);
      addCourse("ret-keep", 0);
      addEncounter("e-old", "ret-30", 31);
      addEncounter("e-edge", "ret-30", 30);
      addEncounter("e-new", "ret-30", 29);
      addEncounter("e-keep", "ret-keep", 400); // 0 means keep
      addEncounter("e-solo", null, 400); // practice outside a course has no retention setting
      for (const id of ["e-old", "e-new"]) addNotes(id);

      expect(await purgeExpiredEncounters(env, NOW)).toBe(1);
      expect(ids(sql, `SELECT id FROM encounters WHERE id LIKE 'e-%' ORDER BY id`)).toEqual(["e-edge", "e-keep", "e-new", "e-solo"]);
      expect(ids(sql, `SELECT id FROM comments ORDER BY id`)).toEqual(["c-e-new"]);
      expect(ids(sql, `SELECT id FROM notifications ORDER BY id`)).toEqual(["n-e-new"]);
      // Nothing else is due, so a second run deletes nothing.
      expect(await purgeExpiredEncounters(env, NOW)).toBe(0);
    });

    it("works through a backlog over several runs, at most 400 encounters a run", async () => {
      addCourse("ret-1", 1);
      for (let i = 0; i < 450; i++) addEncounter(`b-${i}`, "ret-1", 2);
      expect(await purgeExpiredEncounters(env, NOW)).toBe(400);
      expect(await purgeExpiredEncounters(env, NOW)).toBe(50);
      expect(await purgeExpiredEncounters(env, NOW)).toBe(0);
      expect(count(sql, `SELECT COUNT(*) AS n FROM encounters WHERE course_id = 'ret-1'`)).toBe(0);
    });
  });
});

describe("upgrading an older database", () => {
  it("adds the columns later versions need and keeps existing rows", async () => {
    const { DB, sql } = memoryD1();
    // Tables as they were before session versions, voice analysis and retention were added.
    sql.exec(`
      CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
      INSERT INTO meta (key, value) VALUES ('schema_version', '1');
      CREATE TABLE users (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, role TEXT NOT NULL,
        pw_salt TEXT NOT NULL, pw_hash TEXT NOT NULL, ai_key_enc TEXT, created_at INTEGER NOT NULL);
      CREATE TABLE courses (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
        banner TEXT NOT NULL DEFAULT '', code TEXT NOT NULL UNIQUE, enrollment_open INTEGER NOT NULL DEFAULT 1,
        archived INTEGER NOT NULL DEFAULT 0, ai_key_enc TEXT, created_at INTEGER NOT NULL);
      CREATE TABLE encounters (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, assignment_id TEXT, course_id TEXT, case_id TEXT NOT NULL,
        config_id TEXT NOT NULL, mode TEXT NOT NULL, language TEXT NOT NULL, status TEXT NOT NULL,
        messages TEXT NOT NULL DEFAULT '[]', orders TEXT NOT NULL DEFAULT '[]', notepad TEXT NOT NULL DEFAULT '',
        tasks_done TEXT NOT NULL DEFAULT '[]', diagnosis TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
        feedback TEXT, prosody TEXT, snapshot TEXT NOT NULL, started_at INTEGER NOT NULL, ended_at INTEGER);
      INSERT INTO users (id, email, name, role, pw_salt, pw_hash, created_at) VALUES ('u-old', 'old@test.local', 'Olga', 'educator', 's', 'h', 1);
      INSERT INTO courses (id, owner_id, name, code, created_at) VALUES ('c-old', 'u-old', 'Old course', 'OLDOLD', 1);
      INSERT INTO encounters (id, user_id, course_id, case_id, config_id, mode, language, status, snapshot, started_at)
        VALUES ('e-old', 'u-old', 'c-old', 'x', 'y', 'voice', 'en-US', 'done', '{}', 1);
    `);
    // db.ts remembers that it has migrated once per Worker instance, so load a fresh copy for this database.
    vi.resetModules();
    const fresh = await import("../src/worker/db");
    await fresh.ensureSchema({ DB } as Env);

    const columns = (table: string) => sql.prepare(`PRAGMA table_info(${table})`).all().map((c) => String(c.name));
    expect(columns("users")).toContain("session_version");
    expect(columns("courses")).toContain("retention_days");
    expect(columns("encounters")).toContain("prosody_ai");
    expect(sql.prepare(`SELECT session_version FROM users WHERE id = 'u-old'`).get()).toMatchObject({ session_version: 0 });
    expect(sql.prepare(`SELECT name, retention_days FROM courses WHERE id = 'c-old'`).get()).toMatchObject({ name: "Old course", retention_days: 0 });
    expect(count(sql, `SELECT COUNT(*) AS n FROM encounters WHERE id = 'e-old'`)).toBe(1);
    expect(sql.prepare(`SELECT value FROM meta WHERE key = 'schema_version'`).get()?.value).not.toBe("1");
    // The demo content arrives too.
    expect(count(sql, `SELECT COUNT(*) AS n FROM courses WHERE code = ?`, DEMO_COURSE_CODE)).toBe(1);
  });
});
