// The local test admin used by e2e.mjs and fidelity.mjs. It only exists in a local dev database
// (never on a deployed site). On a fresh machine it is created through the normal educator sign-up,
// which needs EDUCATOR_ACCESS_KEY in .dev.vars and admin@test.local listed in ADMIN_EMAILS.
import { readFileSync } from "node:fs";

export const ADMIN_EMAIL = "admin@test.local";
export const ADMIN_PASSWORD = "localtest-admin-1";

/** Settings from .dev.vars (empty when the file is missing). */
export const devVars = () => {
  try {
    return Object.fromEntries(
      readFileSync(new URL("../.dev.vars", import.meta.url), "utf8")
        .split("\n")
        .filter((l) => /^[A-Z_]+\s*=/.test(l))
        .map((l) => [l.slice(0, l.indexOf("=")).trim(), l.slice(l.indexOf("=") + 1).trim().replace(/^"|"$/g, "")]),
    );
  } catch {
    return {};
  }
};

/** The same client-side hash the app sends instead of the password. */
export async function clientHash(email, password) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: enc.encode(`ai-patient-actor:${email.toLowerCase()}`), iterations: 210_000, hash: "SHA-256" }, key, 256);
  return [...new Uint8Array(bits)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** Signs in as the test admin, creating the account first if this database doesn't have it. */
export async function ensureTestAdmin(base) {
  const post = (path, body) =>
    fetch(base + path, { method: "POST", headers: { "content-type": "application/json", "x-requested-with": "apa" }, body: JSON.stringify(body) });
  const hash = await clientHash(ADMIN_EMAIL, ADMIN_PASSWORD);
  if ((await post("/api/auth/signin", { email: ADMIN_EMAIL, clientHash: hash })).ok) return;
  const vars = { ...devVars(), ...process.env };
  const res = await post("/api/auth/signup", { email: ADMIN_EMAIL, name: "Test Admin", clientHash: hash, role: "educator", accessKey: vars.EDUCATOR_ACCESS_KEY ?? "", consent: true });
  if (!res.ok) throw new Error(`Couldn't create the test admin (${res.status}): ${await res.text()}. Set EDUCATOR_ACCESS_KEY and ADMIN_EMAILS=${ADMIN_EMAIL} in .dev.vars.`);
}
