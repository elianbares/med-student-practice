// End-to-end API walkthrough against a running dev server: accounts, library, courses, encounters, privacy and admin.
// Usage: node tests/smoke.mjs [baseUrl]   (reads EDUCATOR_ACCESS_KEY from .dev.vars; about 4 live AI calls)
// Everything it creates is deleted again at the end, and the demo course is left open. It closes the demo course
// for a moment to check the admin switch, so avoid running it while someone else signs up students locally.
import { ADMIN_EMAIL, ADMIN_PASSWORD, clientHash, devVars, ensureTestAdmin } from "./test-admin.mjs";

const BASE = process.argv[2] ?? "http://127.0.0.1:5173";
const vars = { ...devVars(), ...process.env };
const run = Date.now().toString(36);
let failures = 0;

function check(cond, label, extra) {
  console.log(`${cond ? "PASS" : "FAIL"}  ${label}${!cond && extra !== undefined ? `  -> ${JSON.stringify(extra).slice(0, 300)}` : ""}`);
  if (!cond) failures++;
}

/** A cookie-keeping API client. Pass a saved cookie to replay an old session. */
function client(cookie = "") {
  async function call(method, path, body, raw = false) {
    const res = await fetch(BASE + path, {
      method,
      headers: { "content-type": "application/json", "x-requested-with": "apa", ...(cookie ? { cookie } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const set = res.headers.get("set-cookie");
    if (set) cookie = set.split(";")[0];
    if (raw) return res;
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
    return { status: res.status, data, headers: res.headers };
  }
  return {
    call,
    get cookie() {
      return cookie;
    },
  };
}

async function sse(c, path, body) {
  const res = await c.call("POST", path, body, true);
  if (!res.ok) return { status: res.status, error: await res.text(), headers: res.headers };
  const text = await res.text();
  const events = text
    .split("\n\n")
    .map((b) => b.trim())
    .filter((b) => b.startsWith("data:"))
    .map((b) => JSON.parse(b.slice(5)));
  return { status: res.status, events, streamed: events.filter((e) => e.t).map((e) => e.t).join(""), done: events.find((e) => e.done) };
}

/** Retries like the app does while the free AI is busy (503 with a short Retry-After), at most twice. */
async function retryBusy(send) {
  for (let i = 0; ; i++) {
    const res = await send();
    const wait = Number(res.headers?.get("retry-after") ?? 0);
    if (res.status !== 503 || i >= 2 || !wait || wait > 10) return res;
    console.log(`      (AI busy, retrying in ${wait} s)`);
    await new Promise((ok) => setTimeout(ok, wait * 1000));
  }
}

/** Accounts this run made, with their current password, so even a crash deletes them. */
const accounts = new Map();
let courseId = null;

async function signup(c, email, name, password, extra = {}) {
  const res = await c.call("POST", "/api/auth/signup", { email, name, clientHash: await clientHash(email, password), consent: true, ...extra });
  if (res.status === 200) accounts.set(email, password);
  return res;
}
const signin = async (c, email, password) => c.call("POST", "/api/auth/signin", { email, clientHash: await clientHash(email, password) });
const deleteAccount = async (c, email, password) => c.call("DELETE", "/api/me", { passwordHash: await clientHash(email, password) });

/** The server's quote check: lowercase letters and digits only. */
const normText = (s) =>
  String(s ?? "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
const keysOf = (v) => (Array.isArray(v) ? v.flatMap(keysOf) : v && typeof v === "object" ? Object.entries(v).flatMap(([k, x]) => [k, ...keysOf(x)]) : []);
const list = (res) => (Array.isArray(res.data) ? res.data : []);

const edu = client();
const stu = client();
const other = client();
const late = client(); // signs up while the demo course is closed
const admin = client();

// A result the student never orders: it must never reach the brief or the data download.
const UNSEEN = "Trace free fluid beside the cecum";

try {
  // ---------- public ----------
  const me0 = await client().call("GET", "/api/auth/me");
  check(me0.status === 200 && me0.data.user === null, "me (signed out)", me0);
  check(me0.data.ai?.mode === "demo" || me0.data.ai?.mode === "real", `AI status reported (${me0.data.ai?.mode})`, me0.data);
  check(
    typeof me0.data.educatorSignup === "boolean" && Array.isArray(me0.data.emailDomains) && (me0.data.turnstileSiteKey === null || typeof me0.data.turnstileSiteKey === "string"),
    "me reports the sign-up options (educator sign-up, email domains, security check)",
    me0.data,
  );
  const health = await client().call("GET", "/api/health");
  check(health.status === 200 && health.data.ok === true && ["ok", "missing"].includes(health.data.ai?.google), `health check (Google key: ${health.data.ai?.google})`, health.data);
  check(health.headers.get("cache-control") === "no-store", "health check is never cached", health.headers.get("cache-control"));
  const noHeader = await fetch(BASE + "/api/auth/signout", { method: "POST" });
  check(noHeader.status === 400, "CSRF header required on POST");

  // ---------- the test admin; the demo course starts open ----------
  await ensureTestAdmin(BASE);
  const adminIn = await signin(admin, ADMIN_EMAIL, ADMIN_PASSWORD);
  check(adminIn.status === 200 && adminIn.data.user?.role === "admin", "test admin signs in", adminIn);
  const demoOn = await admin.call("PUT", "/api/admin/settings", { demoCourseOpen: true });
  check(demoOn.status === 200 && demoOn.data.demoCourseOpen === true, "admin opens the demo course", demoOn);

  // ---------- educator sign-up ----------
  const eduEmail = `edu-${run}@test.local`;
  const eduPw = "pw-12345678";
  const chk1 = await client().call("POST", "/api/auth/check", { email: eduEmail, role: "educator", accessKey: "wrong" });
  check(chk1.status === 200 && chk1.data.emailAvailable === true && chk1.data.emailAllowed === true && chk1.data.accessKeyValid === false, "sign-up check: new email is free, wrong access key flagged", chk1);
  const chk2 = await client().call("POST", "/api/auth/check", { email: eduEmail, role: "educator", accessKey: vars.EDUCATOR_ACCESS_KEY });
  check(chk2.data.accessKeyValid === true, "sign-up check: right access key accepted", chk2);
  const chk3 = await client().call("POST", "/api/auth/check", { email: "not-an-email", role: "student", accessKey: "anything" });
  check(chk3.status === 200 && chk3.data.emailAvailable === false && chk3.data.emailAllowed === false && chk3.data.accessKeyValid === null, "sign-up check: invalid email flagged, students need no key", chk3);
  const badKey = await edu.call("POST", "/api/auth/signup", { email: eduEmail, name: "Dr Edu", clientHash: await clientHash(eduEmail, eduPw), role: "educator", accessKey: "wrong", consent: true });
  check(badKey.status === 403, "educator signup rejects wrong access key", badKey);
  const su = await signup(edu, eduEmail, "Dr Edu", eduPw, { role: "educator", accessKey: vars.EDUCATOR_ACCESS_KEY });
  check(su.status === 200 && su.data.user?.role === "educator" && su.data.enrolledCourseId === null, "educator signup (joins no course)", su);
  const chk4 = await client().call("POST", "/api/auth/check", { email: eduEmail.toUpperCase(), role: "student" });
  check(chk4.data.emailAvailable === false, "sign-up check: taken email flagged, in any case", chk4);
  const dup = await signup(client(), eduEmail, "Xavier", "pw-xxxxxxxx");
  check(dup.status === 409, "duplicate email rejected", dup);

  // Capacity is for educators; the demo switch is for admins.
  const cap = await edu.call("GET", "/api/admin/capacity");
  check(
    cap.status === 200 &&
      typeof cap.data.keys?.platform === "boolean" &&
      Array.isArray(cap.data.today) &&
      cap.data.guidance?.length > 0 &&
      cap.data.demoCourseOpen === true &&
      Array.isArray(cap.data.overflow),
    "educator reads the AI capacity",
    cap,
  );
  check((await edu.call("PUT", "/api/admin/settings", { demoCourseOpen: false })).status === 403, "only admins can close the demo course");

  // ---------- library ----------
  const configs = await edu.call("GET", "/api/library/configurations");
  check(configs.status === 200 && configs.data.length >= 4, `public configurations seeded (${configs.data.length})`, configs);
  const profiles = await edu.call("GET", "/api/library/profiles");
  check(profiles.data.length >= 4, `demo profiles seeded (${profiles.data.length})`, profiles);

  const draft = await retryBusy(() => edu.call("POST", "/api/library/profiles/assist", { diagnosis: "Acute appendicitis", goal: "ED visit", big5: "high neuroticism", communication: "anxious" }));
  check(draft.status === 200 && draft.data.data?.demographics, "AI profile assistant drafts a profile", draft);
  const caseTests = [
    { id: "t1", category: "Laboratory", name: "Complete blood count", result: "WBC 14.2", expected: true },
    { id: "t2", category: "Imaging", name: "CT abdomen and pelvis with contrast", result: "Inflamed appendix 11 mm", expected: true },
    { id: "t3", category: "Laboratory", name: "Lipase", result: "Normal", expected: false },
    { id: "t4", category: "Imaging", name: "Abdominal ultrasound", result: UNSEEN, expected: false },
  ];
  const prof = await edu.call("POST", "/api/library/profiles", {
    name: "Appendicitis 22M",
    data: { ...draft.data?.data, diagnosis: "Acute appendicitis", chiefComplaint: "My stomach hurts on the right side", tests: caseTests },
  });
  check(prof.status === 200 && prof.data.mine, "create profile", prof);

  const cfgData = {
    contextGoal: "Take a history",
    encounterTasks: ["Introduce yourself", "Take a history"],
    rubric: [
      { name: "Rapport", description: "Introduces self" },
      { name: "History", description: "Complete history" },
    ],
    diagnosisType: "diagnosis",
    notesFeedback: { enabled: true, criteria: "SOAP" },
  };
  const badConfig = (data, name = "Bad config") => edu.call("POST", "/api/library/configurations", { name, data: { ...cfgData, ...data } });
  const oneLevel = await badConfig({ levels: ["Pass"] });
  check(oneLevel.status === 400 && /at least 2 score levels/.test(oneLevel.data.error), "configuration with one score level rejected", oneLevel);
  const blankRubric = await badConfig({ rubric: [{ name: "Rapport", description: "" }, { name: "  ", description: "No name" }] });
  check(blankRubric.status === 400 && /category 2 needs a name/.test(blankRubric.data.error), "rubric category without a name rejected", blankRubric);
  const longTime = await badConfig({ timeLimitMin: 999 });
  check(longTime.status === 400 && /at most 120 minutes/.test(longTime.data.error), "999-minute time limit rejected", longTime);
  const longName = await badConfig({}, "x".repeat(121));
  check(longName.status === 400 && /at most 120 characters/.test(longName.data.error), "configuration name over 120 characters rejected", longName);
  check(list(await edu.call("GET", "/api/library/configurations")).length === configs.data.length, "rejected configurations were not saved");

  const cfg = await edu.call("POST", "/api/library/configurations", { name: "My OSCE", data: { ...cfgData, testOrdering: "menu" } });
  check(cfg.status === 200 && cfg.data.data.rubric.length === 2 && cfg.data.data.testOrdering === "menu", "create configuration (tests from a menu)", cfg);
  check(JSON.stringify(cfg.data.data?.levels) === JSON.stringify(["Needs improvement", "Developing", "Proficient"]), "default score levels in sentence case", cfg.data.data?.levels);
  const badEdit = await edu.call("PUT", `/api/library/configurations/${cfg.data.id}`, { data: { ...cfg.data.data, levels: ["Pass"] } });
  const afterBadEdit = await edu.call("GET", `/api/library/configurations/${cfg.data.id}`);
  check(badEdit.status === 400 && afterBadEdit.data.data?.levels?.length === 3, "editing a configuration is checked the same way", badEdit);
  const cfgSearch = await edu.call("POST", "/api/library/configurations", { name: "My OSCE, typed orders", data: cfgData });
  check(cfgSearch.status === 200 && cfgSearch.data.data.testOrdering === "search", "configurations order tests by typing unless set to a menu", cfgSearch);
  const kase = await edu.call("POST", "/api/library/cases", { name: "Belly pain", description: "A student with belly pain", profileId: prof.data.id, configIds: [cfg.data.id, cfgSearch.data.id] });
  check(kase.status === 200 && kase.data.configIds.length === 2 && kase.data.chiefComplaint, "create case with two configurations", kase);

  // ---------- course ----------
  const noName = await edu.call("POST", "/api/courses", { name: "   " });
  check(noName.status === 400 && /name/i.test(noName.data.error), "course without a name rejected", noName);
  const longCourse = await edu.call("POST", "/api/courses", { name: "C".repeat(121) });
  check(longCourse.status === 400 && /at most 120 characters/.test(longCourse.data.error), "course name over 120 characters rejected", longCourse);
  const course = await edu.call("POST", "/api/courses", { name: `Smoke course ${run}`, description: "test" });
  courseId = course.data?.id ?? null;
  check(course.status === 200 && /^[A-Z2-9]{6}$/.test(course.data.code) && course.data.retentionDays === 0, "create course with 6-char code, encounters kept until deleted", course);
  const unnamed = await edu.call("PATCH", `/api/courses/${courseId}`, { name: "" });
  check(unnamed.status === 400, "renaming a course to nothing rejected", unnamed);
  const keep = await edu.call("PATCH", `/api/courses/${courseId}`, { retentionDays: 30 });
  check(keep.status === 200 && keep.data.retentionDays === 30 && keep.data.name === `Smoke course ${run}`, "set encounter retention to 30 days, other fields kept", keep);
  const kept = await edu.call("GET", `/api/courses/${courseId}`);
  check(kept.data.course?.retentionDays === 30, "retention days read back", kept.data.course);
  const badKeep = await Promise.all([-1, 3651, 1.5, "soon"].map((d) => edu.call("PUT", `/api/courses/${courseId}`, { retentionDays: d })));
  check(badKeep.every((r) => r.status === 400), "retention outside 0 to 3650 whole days rejected", badKeep.map((r) => r.status));

  const asg = await edu.call("POST", `/api/courses/${courseId}/assignments`, { caseId: kase.data.id, configId: cfg.data.id });
  check(asg.status === 200 && asg.data.length === 1, "assign case to course", asg);
  const asgAgain = await edu.call("POST", `/api/courses/${courseId}/assignments`, { caseId: kase.data.id, configId: cfg.data.id });
  check(asgAgain.status === 409 && asgAgain.data.error === "That case and configuration are already in this course.", "the same case and configuration can't be assigned twice", asgAgain);
  const asg2 = await edu.call("POST", `/api/courses/${courseId}/assignments`, { caseId: kase.data.id, configId: cfgSearch.data.id });
  check(asg2.status === 200 && asg2.data.length === 2, "assign the case again with its other configuration", asg2);
  const menuAsg = list(asg2).find((a) => a.configId === cfg.data.id);
  const searchAsg = list(asg2).find((a) => a.configId === cfgSearch.data.id);

  // ---------- students ----------
  const stuEmail = `stu-${run}@test.local`;
  const s1 = await signup(stu, stuEmail, "Sam Student", "pw-abcdefgh");
  check(s1.status === 200 && s1.data.user?.role === "student" && typeof s1.data.enrolledCourseId === "string", "student signup joins a course", s1);
  const demoId = s1.data.enrolledCourseId;
  const demoAgain = await stu.call("POST", "/api/courses/enroll", { code: "medsim" });
  check(demoAgain.status === 200 && demoAgain.data.id === demoId, "the course joined at sign-up is the demo course (MEDSIM)", demoAgain);
  check((await stu.call("GET", "/api/library/profiles")).status === 403, "student cannot read library");
  check((await stu.call("GET", `/api/courses/${courseId}`)).status === 404, "student cannot see course before joining");
  const en = await stu.call("POST", "/api/courses/enroll", { code: course.data.code.toLowerCase() });
  check(en.status === 200 && en.data.id === courseId, "student joins with course code (case-insensitive)", en);
  const cview = await stu.call("GET", `/api/courses/${courseId}`);
  check(
    cview.status === 200 && cview.data.role === "student" && cview.data.course.code === "" && cview.data.course.retentionDays === undefined && cview.data.assignments[0]?.chiefComplaint,
    "student course view hides code and settings, shows chief complaint",
    cview,
  );
  check((await stu.call("GET", `/api/courses/${courseId}/roster`)).status === 403, "student cannot see roster");

  const otherEmail = `oth-${run}@test.local`;
  const code = course.data.code;
  const s2 = await signup(other, otherEmail, "Olly", "pw-zzzzzzzz", { joinCode: `${code.slice(0, 3)}-${code.slice(3)}`.toLowerCase() });
  check(s2.status === 200 && s2.data.enrolledCourseId === courseId, "student who signs up with a join code lands in that course", s2);
  const ollyCourses = await other.call("GET", "/api/courses");
  check(list(ollyCourses).length === 1 && ollyCourses.data[0].id === courseId, "a join code takes the place of the demo course", ollyCourses);

  // ---------- text encounter, tests from a menu (live AI) ----------
  const start = await stu.call("POST", "/api/encounters", { assignmentId: menuAsg?.id, mode: "text", language: "en-US" });
  check(start.status === 200 && start.data.id, "start encounter", start);
  const encId = start.data.id;
  const enc0 = await stu.call("GET", `/api/encounters/${encId}`);
  const brief = enc0.data.brief ?? {};
  const briefStr = JSON.stringify(brief);
  check(enc0.status === 200 && brief.testOrdering === "menu" && brief.tests?.length === 4, "brief lists orderable tests when the configuration uses a menu", brief);
  check(!briefStr.includes("Acute appendicitis") && !briefStr.includes("WBC 14.2") && !briefStr.includes(UNSEEN) && !brief.briefResults, "brief hides diagnosis and test results", brief);

  const lines = ["Hello, my name is Sam, I'm a medical student. What brings you in today?", "Do you take any medications?"];
  const m1 = await retryBusy(() => sse(stu, `/api/encounters/${encId}/message`, { text: lines[0] }));
  check(m1.status === 200 && m1.done?.message?.role === "patient" && m1.streamed.length > 0, "patient reply streams", m1);
  check(m1.status === 200 && !m1.streamed.includes("[emotion"), "emotion tag stripped from stream", m1.streamed);
  const m2 = await retryBusy(() => sse(stu, `/api/encounters/${encId}/message`, { text: lines[1] }));
  check(m2.done?.message?.text?.length > 0, "second reply", m2);

  const order = (id, b) => stu.call("POST", `/api/encounters/${id}/orders`, b);
  const o1 = await order(encId, { query: "CBC" });
  check(o1.status === 200 && o1.data.order?.result === "WBC 14.2" && !o1.data.repeated, "order test by abbreviation (CBC)", o1);
  const oMenu = await order(encId, { testId: brief.tests?.find((t) => t.name === "Lipase")?.id });
  check(oMenu.status === 200 && oMenu.data.order?.testId === "t3" && oMenu.data.order.result === "Normal", "order a test from the menu", oMenu);
  const o1again = await order(encId, { query: "complete blood count" });
  check(o1again.status === 200 && o1again.data.repeated === true && o1again.data.order?.t === o1.data.order?.t, "ordering a test again returns the first result", o1again);
  const o2 = await order(encId, { query: "MRI of the knee" });
  check(o2.status === 200 && o2.data.order?.testId === "" && !o2.data.repeated, "a test the case lacks gets a 'not in the case file' result", o2);
  const o2again = await order(encId, { query: "MRI of the knee" });
  check(o2again.status === 200 && o2again.data.repeated === true && o2again.data.order?.t === o2.data.order?.t, "asking twice for a test the case lacks returns the first answer", o2again);
  const tr = await stu.call("POST", `/api/encounters/${encId}/transcript`, { doctor: "Injected line", patient: "Injected reply" });
  check(tr.status === 400, "transcript lines are refused for a text encounter", tr);
  const p1 = await stu.call("PATCH", `/api/encounters/${encId}`, { notepad: "RLQ pain", tasksDone: [0, 1] });
  check(p1.status === 200, "autosave notepad and tasks", p1);
  const msgs = (await stu.call("GET", `/api/encounters/${encId}`)).data.messages ?? [];
  check(msgs.filter((m) => m.role === "exam").length === 3 && !msgs.some((m) => m.text?.includes("Injected")), "the transcript holds each order once and nothing injected", msgs);
  check((await client().call("GET", `/api/encounters/${encId}`)).status === 401, "signed-out user cannot read encounter");
  check((await other.call("GET", `/api/encounters/${encId}`)).status === 404, "another student cannot read the encounter");
  check((await other.call("POST", `/api/encounters/${encId}/orders`, { query: "CT" })).status === 404, "another student cannot order on it");

  // Two "End" clicks at once: one grades, the other waits (409) or gets the same feedback. Never two gradings.
  const endBody = { diagnosis: "Appendicitis", note: "S: RLQ pain. O: WBC 14. A: appendicitis. P: surgery consult." };
  const ends = await Promise.all([0, 1].map(() => retryBusy(() => stu.call("POST", `/api/encounters/${encId}/end`, endBody))));
  const end = ends.find((r) => r.status === 200 && r.data.feedback) ?? ends[0];
  const twin = ends.find((r) => r !== end);
  check(end.status === 200 && end.data.status === "done" && end.data.feedback, "end encounter returns feedback", end);
  const fb = end.data.feedback;
  check(
    twin.status === 409 ? twin.data.error === "This encounter is already being graded. Check again in a minute." : twin.status === 200 && JSON.stringify(twin.data.feedback) === JSON.stringify(fb),
    `a second end at the same moment waits or gets the same feedback (${twin.status})`,
    twin,
  );
  const endAgain = await stu.call("POST", `/api/encounters/${encId}/end`, { diagnosis: "Something else" });
  check(endAgain.status === 200 && JSON.stringify(endAgain.data.feedback) === JSON.stringify(fb) && endAgain.data.diagnosis === "Appendicitis", "ending again returns the same feedback, never a second grading", endAgain);

  check(fb?.correctDiagnosis === "Acute appendicitis", "feedback reveals correct diagnosis", fb);
  check(fb?.rubric?.length === 2 && fb.rubric.every((r) => ["Needs improvement", "Developing", "Proficient", "Not assessed"].includes(r.level)), "rubric scored with the configured levels", fb?.rubric);
  check(JSON.stringify(fb?.testsReview?.missedExpected) === JSON.stringify(["CT abdomen and pelvis with contrast"]), "tests review: missed expected test computed", fb?.testsReview);
  check(fb?.testsReview?.orderedExpected?.includes("Complete blood count"), "tests review: ordered expected test", fb?.testsReview);
  const said = ` ${normText(lines.join(" \n "))} `;
  const quotes = fb?.rubric?.flatMap((r) => r.evidence) ?? [];
  check(quotes.length > 0 && quotes.every((e) => e.verified === true && said.includes(` ${normText(e.quote)} `)), `evidence quotes are the student's own words (${quotes.length})`, quotes);
  check(quotes.every((e) => e.kind === "praise" || e.kind === "improve"), "every quote is marked as praise or as something to improve", quotes);
  check(["supported", "partly", "unsupported"].includes(fb?.diagnosisSupport), `diagnosis support judged (${fb?.diagnosisSupport})`, fb);
  check(typeof fb?.provider === "string" && fb.provider !== "none", `feedback names its grader (${fb?.provider})`, fb?.provider);
  check((await sse(stu, `/api/encounters/${encId}/message`, { text: "hi" })).status === 409, "cannot message after end");

  // ---------- typed test orders, nothing said (no AI) ----------
  const start2 = await stu.call("POST", "/api/encounters", { assignmentId: searchAsg?.id, mode: "text", language: "en-US" });
  const encId2 = start2.data.id;
  const brief2 = (await stu.call("GET", `/api/encounters/${encId2}`)).data.brief ?? {};
  check(start2.status === 200 && brief2.testOrdering === "search" && brief2.tests?.length === 0 && !JSON.stringify(brief2).includes("Lipase"), "brief names no tests when tests are ordered by typing", brief2);
  const typed = await order(encId2, { query: "lipase" });
  check(typed.status === 200 && typed.data.order?.testId === "t3" && typed.data.order.result === "Normal", "order a test by typing its name", typed);
  const typedCt = await order(encId2, { query: "CT abdomen" });
  check(typedCt.status === 200 && typedCt.data.order?.testId === "t2" && typedCt.data.order.result === "Inflamed appendix 11 mm", "a typed short name finds the case's test", typedCt);
  const quiet = await stu.call("POST", `/api/encounters/${encId2}/end`, { diagnosis: "", note: "" });
  check(quiet.status === 200 && quiet.data.status === "done" && /nothing to grade/i.test(quiet.data.feedback?.summary ?? ""), "ending without talking gives feedback without grading", quiet);
  const quietAgain = await stu.call("POST", `/api/encounters/${encId2}/end`, {});
  check(quietAgain.status === 200 && JSON.stringify(quietAgain.data.feedback) === JSON.stringify(quiet.data.feedback), "ending it again changes nothing", quietAgain);

  // ---------- encounter lists ----------
  const mine = list(await stu.call("GET", "/api/encounters"));
  const sum1 = mine.find((e) => e.id === encId);
  const sum2 = mine.find((e) => e.id === encId2);
  check(sum1?.status === "done" && sum1.doctorTurns === 2 && sum1.gradedBy === fb?.provider, "encounter list counts what the student said and names the grader", sum1);
  check(sum2?.doctorTurns === 0 && sum2.gradedBy === undefined, "an attempt without talking shows 0 turns and no grader", sum2);
  const courseList = await edu.call("GET", `/api/courses/${courseId}/encounters`);
  const row1 = list(courseList).find((e) => e.id === encId);
  check(list(courseList).length === 2 && row1?.studentName === "Sam Student" && row1.doctorTurns === 2 && row1.gradedBy === fb?.provider, "educator sees course encounters with turns and grader", courseList);
  const eview = await edu.call("GET", `/api/encounters/${encId}`);
  check(eview.status === 200 && eview.data.studentName === "Sam Student", "educator opens student encounter", eview);
  const cm = await edu.call("POST", `/api/encounters/${encId}/comments`, { messageIdx: 0, body: "Nice intro!" });
  check(cm.status === 200, "educator comments on a message", cm);
  const notes = await stu.call("GET", "/api/me/notifications");
  check(notes.data.length === 1 && notes.data[0].read === 0, "student notified of comment", notes);
  const roster = list(await edu.call("GET", `/api/courses/${courseId}/roster`));
  check(roster.length === 2 && roster.find((r) => r.id === s1.data.user?.id)?.encounters === 2, "roster lists both students with encounter counts", roster);

  // ---------- passwords and sessions ----------
  const rc = await edu.call("POST", `/api/courses/${courseId}/roster/${s1.data.user?.id}/reset-code`);
  check(rc.status === 200 && rc.data.code.length === 8, "educator issues reset code", rc);
  const samSession = stu.cookie;
  const reset = await client().call("POST", "/api/auth/reset", { email: stuEmail, code: rc.data.code, clientHash: await clientHash(stuEmail, "new-password-1") });
  check(reset.status === 200, "student resets password with code", reset);
  if (reset.status === 200) accounts.set(stuEmail, "new-password-1");
  check((await client(samSession).call("GET", "/api/encounters")).status === 401, "a reset ends the student's other sessions");
  check((await signin(stu, stuEmail, "new-password-1")).status === 200, "sign in with new password");
  check((await signin(client(), stuEmail, "pw-abcdefgh")).status === 401, "old password rejected");

  const ollyPhone = client();
  check((await signin(ollyPhone, otherEmail, "pw-zzzzzzzz")).status === 200, "second student signs in on another device");
  const newHash = await clientHash(otherEmail, "pw-yyyyyyyy");
  const wrongPw = await other.call("POST", "/api/auth/password", { currentHash: await clientHash(otherEmail, "not-my-password"), newHash });
  check(wrongPw.status === 403 && (await other.call("GET", "/api/auth/me")).data.user?.email === otherEmail, "a wrong current password is refused and the student stays signed in", wrongPw);
  const changed = await other.call("POST", "/api/auth/password", { currentHash: await clientHash(otherEmail, "pw-zzzzzzzz"), newHash });
  check(changed.status === 200, "student changes password", changed);
  if (changed.status === 200) accounts.set(otherEmail, "pw-yyyyyyyy");
  check((await other.call("GET", "/api/auth/me")).data.user?.email === otherEmail, "this device stays signed in after the change");
  check((await ollyPhone.call("GET", "/api/encounters")).status === 401, "the change signs out the other device");
  check((await signin(client(), otherEmail, "pw-yyyyyyyy")).status === 200 && (await signin(client(), otherEmail, "pw-zzzzzzzz")).status === 401, "new password works, the old one doesn't");

  const ollyCookie = other.cookie;
  const out = await other.call("POST", "/api/auth/signout");
  check(out.status === 200 && (await client(ollyCookie).call("GET", "/api/encounters")).status === 401, "sign-out ends the session (the old cookie no longer works)", out);
  check((await signin(other, otherEmail, "pw-yyyyyyyy")).status === 200, "sign back in");

  // ---------- the demo course switch (admin) ----------
  const demoAsg = (await stu.call("GET", `/api/courses/${demoId}`)).data.assignments?.[0]?.id;
  const lateEmail = `late-${run}@test.local`;
  try {
    const off = await admin.call("PUT", "/api/admin/settings", { demoCourseOpen: false });
    check(off.status === 200 && off.data.demoCourseOpen === false, "admin closes the demo course", off);
    check((await edu.call("GET", "/api/admin/capacity")).data.demoCourseOpen === false, "capacity shows the demo course closed");
    const s3 = await signup(late, lateEmail, "Lee Late", "pw-latelate");
    check(s3.status === 200 && s3.data.enrolledCourseId === null, "sign-up joins no course while the demo course is closed", s3);
    const shut = await late.call("POST", "/api/courses/enroll", { code: "MEDSIM" });
    check(shut.status === 403 && shut.data.error === "The demo course is closed.", "joining the closed demo course refused", shut);
    check((await stu.call("POST", "/api/encounters", { assignmentId: demoAsg, mode: "text", language: "en-US" })).status === 403, "no new demo encounters while it is closed");
    check((await admin.call("PUT", "/api/admin/settings", { demoCourseOpen: "no" })).status === 400, "the demo switch takes only true or false");
  } finally {
    const on = await admin.call("PUT", "/api/admin/settings", { demoCourseOpen: true });
    check(on.status === 200 && on.data.demoCourseOpen === true, "admin reopens the demo course", on);
  }
  const demo = await late.call("POST", "/api/courses/enroll", { code: "MEDSIM" });
  check(demo.status === 200 && demo.data.id === demoId, "anyone can join the demo course MEDSIM", demo);
  const demoView = await late.call("GET", `/api/courses/${demoId}`);
  check(demoView.data.assignments?.length === 5, `demo course has 5 practice cases (${demoView.data.assignments?.length})`, demoView);

  const toggle = await edu.call("POST", `/api/courses/${courseId}/toggle-enrollment`);
  check(toggle.data.enrollmentOpen === false, "close enrollment");
  check((await late.call("POST", "/api/courses/enroll", { code: course.data.code })).status === 403, "closed course rejects joins");
  // 20 join attempts an hour per student (the three above count too); codes with 0 or 1 never exist.
  const tries = [];
  for (let i = 0; i < 25 && tries.at(-1)?.status !== 429; i++) tries.push(await late.call("POST", "/api/courses/enroll", { code: `QQ${String(i).padStart(4, "0")}` }));
  const limited = tries.at(-1);
  check(
    limited?.status === 429 && limited.headers.get("retry-after") === "3600" && tries.slice(0, -1).every((r) => r.status === 404),
    `course joins are limited (429 with Retry-After after ${tries.length} more wrong codes)`,
    { status: limited?.status, retryAfter: limited?.headers.get("retry-after"), statuses: tries.map((r) => r.status) },
  );

  // ---------- playground ----------
  const play = await edu.call("POST", "/api/library/cases/seed-case-fatigue/playground", { mode: "text", language: "es-MX" });
  check(play.status === 200, "educator playground on a public case", play);
  const review = await edu.call("POST", "/api/library/cases/seed-case-results/playground", { mode: "text", language: "en-US" });
  const reviewBrief = review.status === 200 ? (await edu.call("GET", `/api/encounters/${review.data.id}`)).data.brief : null;
  check(reviewBrief?.briefResults?.length > 0 && reviewBrief.tests?.length === 0, "results the configuration puts on the brief are listed there", reviewBrief);

  const badKeySave = await edu.call("PUT", `/api/courses/${courseId}/ai-key`, { provider: "gemini", key: "short" });
  check(badKeySave.status === 400, "invalid course key rejected", badKeySave);

  // ---------- privacy: download my data ----------
  const exp = await stu.call("GET", "/api/me/export");
  const dump = exp.data && typeof exp.data === "object" ? exp.data : null;
  check(
    exp.status === 200 &&
      /^application\/json/.test(exp.headers.get("content-type") ?? "") &&
      /^attachment; filename="med-student-practice-ai-data-\d{4}-\d{2}-\d{2}\.json"$/.test(exp.headers.get("content-disposition") ?? ""),
    "data download is a JSON attachment",
    exp.headers.get("content-disposition"),
  );
  check(
    dump?.account?.email === stuEmail && dump.account.hasOwnAiKey === false && dump.encounters?.length === 2 && dump.encounters.some((e) => e.messages?.length === 7 && e.feedback?.rubric),
    "data download holds the account and both encounters",
    dump && { account: dump.account, encounters: dump.encounters?.length },
  );
  const leaked = keysOf(dump).filter((k) => /pw_|password|salt|hash|snapshot|_enc$/i.test(k));
  check(dump && !leaked.length && !JSON.stringify(dump).includes(UNSEEN), "data download has no password data and no hidden case details", leaked);

  // ---------- deleting: courses, then accounts ----------
  const busyDelete = await deleteAccount(edu, eduEmail, eduPw);
  check(busyDelete.status === 409 && /archive or hand over/i.test(busyDelete.data.error), "an educator with an active course of students can't delete the account yet", busyDelete);
  const early = await edu.call("DELETE", `/api/courses/${courseId}`);
  check(early.status === 409 && early.data.error === "Archive the course first.", "an active course can't be deleted", early);
  const demoDel = await admin.call("DELETE", `/api/courses/${demoId}`);
  check(demoDel.status === 409 && /demo course/i.test(demoDel.data.error), "the demo course can't be deleted", demoDel);
  const arch = await edu.call("POST", `/api/courses/${courseId}/archive`);
  check(arch.data.archived === true, "archive the course", arch);
  const del = await edu.call("DELETE", `/api/courses/${courseId}`);
  check(del.status === 200 && (await edu.call("GET", `/api/courses/${courseId}`)).status === 404, "delete the archived course", del);
  if (del.status === 200) courseId = null;
  const stillMine = list(await stu.call("GET", "/api/encounters")).filter((e) => [encId, encId2].includes(e.id));
  check(stillMine.length === 2 && stillMine.every((e) => e.courseName === null), "students keep their encounters after the course is deleted", stillMine);

  const wrongDel = await deleteAccount(stu, stuEmail, "not-it-at-all");
  check(wrongDel.status === 403 && (await stu.call("GET", "/api/auth/me")).data.user?.email === stuEmail, "deleting an account needs the right password", wrongDel);
  const samCookie = stu.cookie;
  const gone = await deleteAccount(stu, stuEmail, accounts.get(stuEmail));
  check(gone.status === 200, "student deletes the account", gone);
  if (gone.status === 200) accounts.delete(stuEmail);
  check((await client(samCookie).call("GET", "/api/auth/me")).data.user === null, "the deleted account's session no longer works");
  check((await client().call("POST", "/api/auth/check", { email: stuEmail, role: "student" })).data.emailAvailable === true, "the deleted account's email is free again");
  for (const [c, email] of [
    [other, otherEmail],
    [late, lateEmail],
  ]) {
    const res = await deleteAccount(c, email, accounts.get(email));
    check(res.status === 200, `student deletes the account (${email.split("-")[0]})`, res);
    if (res.status === 200) accounts.delete(email);
  }

  check((await edu.call("DELETE", `/api/library/cases/${kase.data.id}`)).status === 200, "delete the case once no course uses it");
  const itemsGone = [
    await edu.call("DELETE", `/api/library/profiles/${prof.data.id}`),
    await edu.call("DELETE", `/api/library/configurations/${cfg.data.id}`),
    await edu.call("DELETE", `/api/library/configurations/${cfgSearch.data.id}`),
  ];
  check(itemsGone.every((r) => r.status === 200), "delete the profile and both configurations", itemsGone.map((r) => r.status));
  const eduGone = await deleteAccount(edu, eduEmail, eduPw);
  check(eduGone.status === 200, "educator deletes the account", eduGone);
  if (eduGone.status === 200) accounts.delete(eduEmail);
} catch (err) {
  failures++;
  console.log(`FAIL  the walkthrough stopped: ${err?.stack ?? err}`);
} finally {
  // Whatever happened above: demo course open, test course and accounts gone.
  try {
    await admin.call("PUT", "/api/admin/settings", { demoCourseOpen: true });
    if (courseId) {
      const c = await admin.call("GET", `/api/courses/${courseId}`);
      if (c.status === 200 && !c.data.course.archived) await admin.call("POST", `/api/courses/${courseId}/archive`);
      if (c.status === 200) await admin.call("DELETE", `/api/courses/${courseId}`);
    }
    for (const [email, password] of accounts) {
      const c = client();
      if ((await signin(c, email, password)).status === 200) await deleteAccount(c, email, password);
      console.log(`      cleaned up ${email}`);
    }
  } catch (err) {
    console.log(`FAIL  cleanup: ${err?.message ?? err}`);
    failures++;
  }
}

console.log(failures ? `\n${failures} check(s) FAILED` : "\nAll checks passed");
process.exit(failures ? 1 : 0);
