// End-to-end tests in real Google Chrome with a fake microphone that "speaks" tests/fixtures/doctor.wav.
// Usage: node tests/e2e.mjs [baseUrl] [--only=public,text,progress,settings,keyboard,timer,session,educator,join,admin,voice,emotive,screens]
// Needs: the dev server running, Google Chrome installed, a Google key in .dev.vars, the admin test account.
// Live AI calls per full run: text 3 (two patient replies and grading), voice and emotive a few each. Everything else uses none.
// Screenshots go to tests/screens/: NN-page.png at 1280 px light, plus -dark, -phone (390 px) and -phone-dark for the main pages.
import { chromium } from "playwright-core";
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync } from "node:fs";
import { ADMIN_EMAIL, ADMIN_PASSWORD, ensureTestAdmin } from "./test-admin.mjs";
import { fileURLToPath } from "node:url";

const BASE = process.argv.find((a) => a.startsWith("http")) ?? "http://127.0.0.1:5173";
const only = (process.argv.find((a) => a.startsWith("--only=")) ?? "").slice(7).split(",").filter(Boolean);
const want = (...keys) => !only.length || keys.some((k) => only.includes(k));
const WAV = fileURLToPath(new URL("./fixtures/doctor.wav", import.meta.url));
const SHOTS = fileURLToPath(new URL("./screens/", import.meta.url));
mkdirSync(SHOTS, { recursive: true });
// Failure screenshots from an earlier run would be mistaken for this run's.
for (const f of readdirSync(SHOTS)) if (f.startsWith("FAIL-")) rmSync(SHOTS + f);

const PASSWORD = "E2e-test-pass-1!";
const DEMO_CASE = "Cough and fever";

const results = [];
const consoleErrors = [];
let current = null; // last page used, for failure screenshots
async function test(name, fn) {
  const t0 = Date.now();
  try {
    await fn();
    results.push({ name, ok: true });
    console.log(`PASS  ${name}  (${((Date.now() - t0) / 1000).toFixed(1)}s)`);
  } catch (e) {
    results.push({ name, ok: false, err: e.message });
    console.log(`FAIL  ${name}  -> ${e.message.split("\n")[0].slice(0, 300)}`);
    if (current && !current.isClosed()) await current.screenshot({ path: `${SHOTS}FAIL-${name.replace(/\W+/g, "-").slice(0, 40)}.png`, fullPage: true }).catch(() => undefined);
  }
}
const expect = (cond, msg) => {
  if (!cond) throw new Error(msg);
};

// Google Chrome on a Mac; elsewhere (e.g. a Linux cloud machine) set CHROME_PATH, or install Playwright's
// own Chromium with: npx playwright@1.64.1 install --with-deps chromium
const MAC_CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const browser = await chromium.launch({
  executablePath: process.env.CHROME_PATH || (existsSync(MAC_CHROME) ? MAC_CHROME : undefined),
  headless: true,
  args: ["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream", `--use-file-for-fake-audio-capture=${WAV}`, "--autoplay-policy=no-user-gesture-required"],
});

// Headless Chrome on macOS never answers a real getUserMedia call, so the microphone is replaced by a
// stream that plays the doctor recording once (1.5 s after the mic opens), then silence. Everything
// after the stream (AudioWorklet capture, speech detection, transcription, Live) runs for real. The
// browser's built-in speech recognition is hidden so the app uses its own pipeline.
const WAV_B64 = readFileSync(WAV).toString("base64");
function fakeMic(b64) {
  Object.defineProperty(window, "webkitSpeechRecognition", { value: undefined, configurable: true });
  Object.defineProperty(window, "SpeechRecognition", { value: undefined, configurable: true });
  navigator.mediaDevices.getUserMedia = async () => {
    const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
    const ac = new AudioContext();
    const buf = await ac.decodeAudioData(bytes.buffer);
    const dest = ac.createMediaStreamDestination();
    const src = ac.createBufferSource();
    src.buffer = buf;
    src.connect(dest);
    src.start(ac.currentTime + 1.5);
    return dest.stream;
  };
}

const PHONE = { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true };
async function newPage(opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, permissions: ["microphone"], ...opts });
  await ctx.addInitScript(fakeMic, WAV_B64);
  const page = await ctx.newPage();
  current = page;
  page.on("console", (m) => {
    // 4xx responses are expected in some tests (a session that ended, an unknown join code).
    if (m.type() === "error" && !/favicon|Failed to load resource: the server responded with a status of 4\d\d/.test(m.text())) consoleErrors.push(`${page.url()} :: ${m.text().slice(0, 200)}`);
  });
  page.on("pageerror", (e) => consoleErrors.push(`${page.url()} :: pageerror ${e.message.slice(0, 200)}`));
  return page;
}
/** Waits for web fonts, spinners and transitions so screenshots show the finished page. */
async function settle(page) {
  await page.evaluate(() => document.fonts.ready).catch(() => undefined);
  await page.waitForFunction(() => !document.querySelector(".spinner"), null, { timeout: 10000 }).catch(() => undefined);
  await page.waitForTimeout(400);
}
const shot = async (page, name) => {
  await settle(page);
  await page.screenshot({ path: `${SHOTS}${name}.png`, fullPage: true });
};
const overflowOf = (page) => page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
const bodyText = (page) => page.locator("body").innerText();

// ---------- dark mode and phone layouts ----------
const VARIANTS = [
  ["dark", { colorScheme: "dark" }],
  ["phone", PHONE],
  ["phone-dark", { ...PHONE, colorScheme: "dark" }],
];
const layoutChecks = [];
/** Opens `path` in dark mode, at 390 px and at 390 px dark, records any sideways scroll and saves a screenshot of each. */
async function layoutShots(file, path, { state, ready } = {}) {
  if (!want("screens")) return;
  const prev = current;
  for (const [variant, opts] of VARIANTS) {
    const page = await newPage({ ...opts, ...(state ? { storageState: state } : {}) });
    try {
      await page.goto(BASE + path);
      await (ready ? ready(page) : page.locator("main h1").first().waitFor());
      await settle(page);
      layoutChecks.push({ name: `${file}-${variant}`, overflow: await overflowOf(page) });
      await shot(page, `${file}-${variant}`);
    } catch (e) {
      layoutChecks.push({ name: `${file}-${variant}`, error: e.message.split("\n")[0] });
    } finally {
      await page.context().close();
    }
  }
  current = prev;
}

// ---------- flows ----------
const uniqueEmail = (name) => `${name.toLowerCase().replace(/\W/g, "")}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}@test.local`;

/** Fills the one-screen sign-up form (already open) as a student and submits it. */
async function fillSignUp(page, name) {
  const email = uniqueEmail(name);
  await page.getByLabel("Full name").fill(name);
  await page.getByLabel(/^Email/).fill(email);
  await page.getByLabel(/^Password/).fill(PASSWORD);
  await page.getByLabel("Confirm password").fill(PASSWORD);
  await page.getByRole("checkbox", { name: /I understand that my conversations/ }).check();
  await page.getByRole("button", { name: "Create account" }).click();
  return email;
}

/** Signs up a new student, who is enrolled in the demo course and lands on it. Returns the email and course path. */
async function signUpStudent(page, name) {
  await page.goto(`${BASE}/signup`);
  current = page;
  const email = await fillSignUp(page, name);
  await page.waitForURL(/\/courses\/[^/]+$/, { timeout: 20000 });
  await page.getByRole("heading", { level: 1, name: "Demo course" }).waitFor();
  return { email, coursePath: new URL(page.url()).pathname };
}

async function signIn(page, email, password) {
  await page.getByLabel(/^Email/).fill(email);
  await page.getByLabel(/^Password/).fill(password);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
}

/** The case card whose heading is exactly `caseName` ("Cough and fever" is not "Cough and fever: follow-up visit"). */
const caseCard = (page, caseName) => page.locator(".case-card").filter({ has: page.getByRole("heading", { name: caseName, exact: true }) });

/** From the course page: opens the case, picks the mode, starts, checks the pre-brief and starts the conversation. */
async function startEncounter(page, caseName, mode, { beforeBegin } = {}) {
  const card = caseCard(page, caseName);
  await card.first().waitFor();
  expect((await card.count()) === 1, `expected one card titled exactly "${caseName}", found ${await card.count()}`);
  await card.getByRole("button", { name: `Start ${caseName}`, exact: true }).click();
  const dialog = page.getByRole("dialog", { name: caseName });
  await dialog.waitFor();
  if (mode !== "text") await dialog.getByRole("radio", { name: mode === "voice" ? "Voice" : "Emotive voice", exact: true }).click();
  await dialog.getByRole("button", { name: "Start encounter" }).click();
  await page.waitForURL(/\/encounter\/[^/]+$/, { timeout: 20000 });
  await page.getByRole("heading", { name: "Door note" }).waitFor();
  expect(await page.getByRole("heading", { name: "Door note" }).isVisible(), "door note not visible on the pre-brief");
  if (beforeBegin) await beforeBegin();
  await page.getByRole("button", { name: "Start conversation" }).click();
  await page.locator(".composer").waitFor();
}

const patientBubbles = (page) => page.locator(".msg.patient:not(.streaming)");
async function sendText(page, text) {
  await page.waitForFunction(() => !document.querySelector(".msg.streaming"), null, { timeout: 60000 });
  const before = await patientBubbles(page).count();
  await page.getByLabel("Your message to the patient").fill(text);
  await page.keyboard.press("Enter");
  // The reply streams into a temporary bubble; wait until it has turned into a finished message.
  await page.waitForFunction((n) => document.querySelectorAll(".msg.patient:not(.streaming)").length > n && !document.querySelector(".msg.streaming"), before, { timeout: 60000 });
  return (await patientBubbles(page).last().innerText()).replace(/^[^\n]*\n/, "");
}

async function orderTest(page, name) {
  const field = page.getByLabel("Order an exam or test");
  await field.fill(name);
  await page.locator("form").filter({ has: field }).getByRole("button", { name: "Order", exact: true }).click();
}

async function endEncounter(page, diagnosis) {
  await page.getByRole("button", { name: "End encounter" }).click();
  const dialog = page.getByRole("dialog");
  const dx = dialog.getByLabel("Your most likely diagnosis");
  if (diagnosis && (await dx.isVisible().catch(() => false))) await dx.fill(diagnosis);
  await dialog.getByRole("button", { name: "End and get feedback" }).click();
  await page.waitForURL(/\/feedback$/, { timeout: 120000 });
  await page.getByRole("heading", { name: "Skill by skill" }).waitFor({ timeout: 60000 });
}

/** The shared student for the student tests, signed up on first use. */
let student = null;
async function getStudent() {
  if (student) return student;
  const page = await newPage();
  const { email, coursePath } = await signUpStudent(page, "Evan Endtoend");
  student = { page, email, coursePath, practiced: false };
  return student;
}
const studentState = () => student.page.context().storageState();

/** The test admin, signed in once. */
let admin = null;
async function getAdmin() {
  if (admin) return admin;
  await ensureTestAdmin(BASE);
  const page = await newPage({ permissions: ["microphone", "clipboard-read", "clipboard-write"] });
  await page.goto(`${BASE}/signin`);
  await signIn(page, ADMIN_EMAIL, ADMIN_PASSWORD);
  await page.waitForURL(/\/educator$/, { timeout: 20000 });
  admin = { page, course: null };
  return admin;
}

/** Creates a course as the admin, adds the demo case and reads its code. */
async function createCourse() {
  const { page } = await getAdmin();
  current = page;
  await page.goto(`${BASE}/educator`);
  await page.getByRole("button", { name: "New course" }).click();
  const dialog = page.getByRole("dialog");
  const name = `Clinical skills ${Date.now().toString(36).slice(-4).toUpperCase()}`;
  await dialog.getByLabel("Name").fill(name);
  await dialog.getByRole("button", { name: "Create course" }).click();
  await page.waitForURL(/\/educator\/courses\/[^/?]+/);
  const id = new URL(page.url()).pathname.split("/").pop();
  const code = (await page.locator(".code").first().innerText()).trim();
  expect(/^[A-Z2-9]{6}$/.test(code), `bad course code ${code}`);
  await page.getByRole("button", { name: "Add case" }).click();
  const add = page.getByRole("dialog");
  await add.locator("select").first().selectOption("seed-case-cough");
  await add.locator("#add-case-config").waitFor();
  await add.getByRole("button", { name: "Add to course" }).click();
  await add.waitFor({ state: "detached" });
  await caseCard(page, DEMO_CASE).waitFor();
  admin.course = { id, code, name };
  return admin.course;
}

// ---------- public pages ----------
if (want("public")) {
  await test("landing page: name, Dartmouth credit, disclaimer, privacy link in the footer", async () => {
    const page = await newPage();
    await page.goto(BASE);
    await page.getByRole("heading", { level: 1 }).waitFor();
    expect((await page.title()).includes("Med Student Practice AI"), "title missing app name");
    const body = await bodyText(page);
    expect(/heavily inspired by dartmouth/i.test(body), "no Dartmouth credit");
    expect(/not affiliated/i.test(body), "no affiliation disclaimer");
    expect(!/[–—]/.test(body), "em or en dash in the landing copy");
    // The credit names Dartmouth's AI Patient Actor; the product itself never takes that name.
    expect(!/AI Patient Actor/.test(`${await page.title()} ${await page.locator("header").first().innerText()}`), "the product is called AI Patient Actor");
    await shot(page, "01-landing");
    await page.locator("footer").getByRole("link", { name: "Privacy and your data" }).click();
    await page.waitForURL(/\/privacy$/);
    await page.getByRole("heading", { level: 1 }).waitFor();
    expect(!/[–—]/.test(await bodyText(page)), "em or en dash on the privacy page");
    await shot(page, "25-privacy");
    await page.goto(`${BASE}/signin`);
    await page.getByRole("button", { name: "Sign in", exact: true }).waitFor();
    await shot(page, "24-signin");
    await page.context().close();
  });
  await layoutShots("01-landing", "/");
  await layoutShots("02-signup", "/signup");
}

// ---------- student ----------
if (want("text", "progress", "settings", "keyboard", "voice", "emotive", "screens")) {
  await test("one-screen sign-up enrolls a new student in the demo course", async () => {
    const page = await newPage();
    await page.goto(`${BASE}/signup`);
    await page.getByRole("heading", { level: 1, name: "Create your account" }).waitFor();
    for (const label of ["Full name", "Confirm password"]) expect(await page.getByLabel(label).isVisible(), `no "${label}" field`);
    expect(!/[–—]/.test(await bodyText(page)), "em or en dash on the sign-up page");
    await shot(page, "02-signup");
    // Submitting empty points at the first problem instead of failing silently.
    await page.getByRole("button", { name: "Create account" }).click();
    await page.locator('[aria-invalid="true"]').first().waitFor();
    await page.context().close();

    const s = await getStudent();
    current = s.page;
    const cards = s.page.locator(".case-card");
    expect((await cards.count()) >= 4, `demo course shows ${await cards.count()} cases`);
    expect((await caseCard(s.page, DEMO_CASE).count()) === 1, "exact heading match for the demo case failed");
    expect((await caseCard(s.page, "Cough and fever: follow-up visit").count()) === 1, "follow-up case missing");
    const badge = (await caseCard(s.page, DEMO_CASE).locator(".badge").first().innerText()).trim();
    expect(badge.length > 0, "case card has no configuration badge");
    await shot(s.page, "03-course");
  });
}

let encounterPath = null;
let feedbackPath = null;
if (want("text")) {
  await test("text encounter: two patient replies, a test order, a diagnosis and feedback", async () => {
    const s = await getStudent();
    const page = s.page;
    current = page;
    await page.goto(BASE + s.coursePath);
    await caseCard(page, DEMO_CASE).waitFor();
    await startEncounter(page, DEMO_CASE, "text", {
      beforeBegin: async () => {
        await shot(page, "05-prebrief");
      },
    });
    encounterPath = new URL(page.url()).pathname;
    const r1 = await sendText(page, "Hello Mr. Bell, I'm Evan, a medical student. What brings you in today?");
    expect(/cough|fever|week|breath|sick|unwell|chest/i.test(r1), `first reply off-case: ${r1}`);
    const r2 = await sendText(page, "Do you smoke at all?");
    expect(r2.length > 5, "empty second reply");
    s.practiced = true;

    await page.getByRole("tab", { name: /^Exams/ }).click();
    await orderTest(page, "chest x-ray");
    const result = page.locator(".test-result").filter({ hasText: /consolidation/i });
    await result.first().waitFor({ timeout: 15000 });
    await page.locator(".chat .record").filter({ hasText: /consolidation/i }).first().waitFor();
    await orderTest(page, "chest x-ray");
    await page.getByText(/^Already ordered/).waitFor({ timeout: 10000 });
    expect((await page.locator(".chat .record").count()) === 1, "a repeated order added a second result");

    const bubbles = await page.locator(".chat .msg, .chat .record").allInnerTexts();
    expect(!bubbles.some((t) => t.includes("*")), `raw asterisks in a bubble: ${bubbles.find((t) => t.includes("*"))}`);
    await shot(page, "06-encounter-text");
    await layoutShots("06-encounter-text", encounterPath, { state: await studentState(), ready: (p) => p.locator(".msg.patient").first().waitFor() });

    await page.getByRole("button", { name: "End encounter" }).click();
    await page.getByRole("dialog").getByLabel("Your most likely diagnosis").waitFor();
    await shot(page, "07-end-encounter");
    await page.keyboard.press("Escape");
    await endEncounter(page, "Community-acquired pneumonia");
    feedbackPath = new URL(page.url()).pathname;
    const main = await page.locator("main").innerText();
    expect(/\b(Correct|Partly correct|Not correct)\b/.test(main), "diagnosis verdict missing");
    expect(/Supported by what you gathered|Partly supported|Not supported by what you gathered/.test(main), "diagnosis support line missing");
    expect(/What went well/.test(main) && /Focus next time/.test(main), "summary sections missing");
    expect(/Well done|Try differently/.test(main), "no quotes tagged Well done or Try differently");
    expect(!/—/.test(await bodyText(page)), "em dash on the feedback page");
    await shot(page, "08-feedback-text");
    await layoutShots("08-feedback-text", feedbackPath, { state: await studentState(), ready: (p) => p.getByRole("heading", { name: "Skill by skill" }).waitFor({ timeout: 20000 }) });
  });
}

if (want("text", "progress", "screens")) {
  await test("progress page: Next up and practice stats", async () => {
    const s = await getStudent();
    const page = s.page;
    current = page;
    await page.goto(`${BASE}/history`);
    await page.getByRole("heading", { name: "How you're doing" }).waitFor();
    await page.getByRole("heading", { name: "Next up" }).waitFor();
    if (s.practiced) {
      await page.locator(".stats").first().waitFor();
      const stats = await page.locator(".stats").first().innerText();
      expect(/Cases? completed/.test(stats) && /this week/.test(stats), `stats missing: ${stats}`);
    }
    await shot(page, "09-progress");
    await layoutShots("09-progress", "/history", { state: await studentState(), ready: (p) => p.getByRole("heading", { name: "Next up" }).waitFor() });
    await page.goto(`${BASE}/home`);
    await page.getByRole("heading", { level: 1 }).waitFor();
    await shot(page, "04-student-home");
    await layoutShots("03-course", s.coursePath, { state: await studentState(), ready: (p) => p.locator(".case-card").first().waitFor() });
  });
}

if (want("settings")) {
  await test("settings: Download my data link", async () => {
    const s = await getStudent();
    const page = s.page;
    current = page;
    await page.goto(`${BASE}/settings`);
    const link = page.getByRole("link", { name: "Download my data" });
    await link.waitFor();
    expect((await link.getAttribute("href")) === "/api/me/export", "export link points somewhere else");
    const res = await page.request.get(`${BASE}/api/me/export`);
    expect(res.ok() && (await res.text()).includes(s.email), `the export does not hold this account (${res.status()})`);
    await shot(page, "10-settings");
  });
}

if (want("keyboard")) {
  await test("keyboard: the start modal traps focus and Escape closes it", async () => {
    const s = await getStudent();
    const page = s.page;
    current = page;
    await page.goto(BASE + s.coursePath);
    const start = caseCard(page, DEMO_CASE).getByRole("button", { name: `Start ${DEMO_CASE}`, exact: true });
    await start.focus();
    await page.keyboard.press("Enter");
    const dialog = page.getByRole("dialog", { name: DEMO_CASE });
    await dialog.waitFor();
    const inDialog = () => page.evaluate(() => Boolean(document.activeElement?.closest('[role="dialog"]')));
    expect(await inDialog(), "focus did not move into the dialog");
    for (let i = 0; i < 14; i++) {
      await page.keyboard.press("Tab");
      expect(await inDialog(), `Tab ${i + 1} left the dialog`);
    }
    for (let i = 0; i < 4; i++) {
      await page.keyboard.press("Shift+Tab");
      expect(await inDialog(), `Shift+Tab ${i + 1} left the dialog`);
    }
    await shot(page, "11-start-modal");
    await page.keyboard.press("Escape");
    await dialog.waitFor({ state: "detached" });
    expect(await page.evaluate(() => document.activeElement?.getAttribute("aria-label")) === `Start ${DEMO_CASE}`, "focus did not return to the Start button");
  });
}

if (want("timer")) {
  await test("time limit: warning, time is up, end without talking (fake clock)", async () => {
    const page = await newPage();
    await page.clock.install();
    await signUpStudent(page, "Tina Timer");
    await startEncounter(page, DEMO_CASE, "text", {
      beforeBegin: async () => expect(/15 minutes/.test(await page.locator(".kv").first().innerText()), "pre-brief does not show the 15 minute limit"),
    });
    await page.clock.fastForward("13:30");
    await page.locator(".sr-only", { hasText: /two minutes left/i }).waitFor({ state: "attached" });
    await page.clock.fastForward("02:00");
    const dialog = page.getByRole("dialog", { name: "Time is up" });
    await dialog.waitFor();
    await shot(page, "12-time-up");
    await dialog.getByRole("button", { name: "End and get feedback" }).click();
    await dialog.getByText("End without talking?").waitFor();
    await dialog.getByRole("button", { name: "End anyway" }).click();
    await page.waitForURL(/\/feedback$/, { timeout: 30000 });
    await page.getByText(/No conversation took place/).waitFor();
    await page.context().close();
  });
}

if (want("session")) {
  await test("session expiry: a signed-out request returns to sign-in with next", async () => {
    const page = await newPage();
    const { email } = await signUpStudent(page, "Sam Session");
    await page.context().clearCookies();
    await page.getByRole("navigation", { name: "Main" }).getByRole("link", { name: /^Progress/ }).click();
    await page.waitForURL(/\/signin\?next=%2Fhistory/, { timeout: 15000 });
    await page.getByText("Your session ended. Sign in again.").waitFor();
    await shot(page, "26-session-ended");
    await signIn(page, email, PASSWORD);
    await page.waitForURL(/\/history$/);
    await page.getByRole("heading", { name: "How you're doing" }).waitFor();
    await page.context().close();
  });
}

// ---------- educator ----------
if (want("educator", "join", "screens")) {
  await test("educator: sign in, create a course, add a case, copy the code", async () => {
    const { page } = await getAdmin();
    current = page;
    await page.getByRole("heading", { level: 1 }).waitFor();
    await shot(page, "13-educator-home");
    const course = await createCourse();
    await page.getByRole("button", { name: "Copy code" }).click();
    await page.getByText("Copied", { exact: true }).waitFor();
    expect((await page.evaluate(() => navigator.clipboard.readText())) === course.code, "clipboard does not hold the course code");
    await shot(page, "14-educator-course");
    await layoutShots("14-educator-course", new URL(page.url()).pathname, { state: await page.context().storageState(), ready: (p) => p.locator(".code").first().waitFor() });
  });
}

if (want("educator", "screens")) {
  await test("educator: results page with labeled filters", async () => {
    const { page } = await getAdmin();
    current = page;
    await page.goto(`${BASE}/educator/courses/seed-course-demo`);
    await page.getByRole("tab", { name: "Results" }).click();
    await page.getByRole("heading", { name: /Skill levels|No encounters yet/ }).first().waitFor({ timeout: 15000 });
    if (await page.getByText("No encounters yet").isVisible()) throw new Error("the demo course has no results to show");
    for (const [label, id] of [["Case", "results-case"], ["Student", "results-student"]]) {
      const control = page.getByLabel(label, { exact: true });
      expect((await control.getAttribute("id")) === id, `"${label}" does not label #${id}`);
      expect(await page.locator(`label[for="${id}"]`).isVisible(), `the "${label}" label is not visible`);
    }
    await page.getByRole("heading", { name: "Skill levels" }).waitFor();
    await shot(page, "15-educator-results");
  });

  await test("educator: library and editors", async () => {
    const { page } = await getAdmin();
    current = page;
    for (const [path, file, ready] of [
      ["/educator/library", "16-library", (p) => p.locator(".case-card").first().waitFor()],
      ["/educator/cases/seed-case-cough", "17-case-editor", (p) => p.getByRole("heading", { level: 1, name: "Edit case" }).waitFor()],
      ["/educator/profiles/seed-pro-pneumonia", "18-profile-editor", (p) => p.getByText("Expressions students will see").waitFor()],
      ["/educator/configs/seed-cfg-osce", "19-config-editor", (p) => p.getByRole("heading", { name: "Rubric" }).waitFor()],
    ]) {
      await page.goto(BASE + path);
      await ready(page);
      expect((await overflowOf(page)) <= 1, `${path} scrolls sideways`);
      await shot(page, file);
    }
  });
}

if (want("admin", "educator")) {
  await test("admin: capacity and the demo course switch", async () => {
    const { page } = await getAdmin();
    current = page;
    await page.goto(`${BASE}/admin`);
    await page.getByRole("heading", { name: "Platform status" }).waitFor();
    await page.getByRole("heading", { name: "Capacity" }).waitFor();
    const sw = page.getByRole("switch", { name: /Demo course open to anyone/ });
    await sw.waitFor();
    expect(await sw.isChecked(), "the demo course is closed, so new students can't practice");
    await shot(page, "20-admin");
  });
}

if (want("join")) {
  await test("join link: a signed-out visitor signs up and lands on that course", async () => {
    const course = admin?.course ?? (await createCourse());
    const page = await newPage();
    await page.goto(`${BASE}/join/${course.code}`);
    await page.getByRole("heading", { name: `Join course ${course.code}` }).waitFor();
    await shot(page, "21-join-invite");
    await page.locator("main").getByRole("link", { name: "Sign up", exact: true }).click();
    await page.getByRole("heading", { name: "Create an account to join" }).waitFor();
    expect(await page.getByText(`Joining course ${course.code}`).first().isVisible(), "sign-up does not say which course");
    await shot(page, "22-join-signup");
    await fillSignUp(page, "Jo Joiner");
    await page.waitForURL(new RegExp(`/courses/${course.id}$`), { timeout: 20000 });
    await page.getByRole("heading", { level: 1, name: course.name }).waitFor();
    await caseCard(page, DEMO_CASE).waitFor();
    await shot(page, "23-join-course");
    await page.context().close();
  });
}

// ---------- voice ----------
if (want("voice")) {
  await test("voice encounter: fake mic speech is recognized, patient answers in natural voice", async () => {
    const s = await getStudent();
    const page = s.page;
    current = page;
    await page.goto(BASE + s.coursePath);
    await startEncounter(page, "Tired all the time", "voice");
    const sawSpeaking = page.waitForFunction(() => /is speaking/.test(document.querySelector(".stage")?.textContent ?? ""), null, { timeout: 60000 }).then(() => true).catch(() => false);
    await page.waitForFunction(() => document.querySelectorAll(".msg.patient:not(.streaming)").length > 0, null, { timeout: 60000 });
    const doctor = await page.locator(".msg.doctor").first().innerText();
    expect(/lee|doctor|brings you/i.test(doctor), `speech not recognized: ${doctor}`);
    expect(await sawSpeaking, "patient never spoke aloud");
    const notice = await page.locator(".chat .notice").allInnerTexts();
    expect(!notice.some((n) => /device's voice/.test(n)), "fell back to robotic device voice");
    await shot(page, "27-encounter-voice");
    await page.waitForTimeout(3000);
    await endEncounter(page, "Hypothyroidism");
    await page.getByRole("heading", { name: "How you sounded" }).waitFor({ timeout: 20000 });
    await shot(page, "28-feedback-voice");
  });
}

if (want("emotive")) {
  await test("emotive voice: live speech-to-speech turn completes and is saved", async () => {
    const s = await getStudent();
    const page = s.page;
    current = page;
    await page.goto(BASE + s.coursePath);
    await startEncounter(page, "Sudden headache", "emotive");
    await page.waitForFunction(() => /Listening/.test(document.querySelector(".stage")?.textContent ?? ""), null, { timeout: 30000 });
    await page.waitForFunction(() => document.querySelectorAll(".msg.patient:not(.streaming)").length > 0, null, { timeout: 60000 });
    const reply = await page.locator(".msg.patient").first().innerText();
    expect(reply.length > 10, "no patient transcript");
    await shot(page, "29-encounter-emotive");
    await endEncounter(page, "Subarachnoid hemorrhage");
    await shot(page, "30-feedback-emotive");
  });
}

// ---------- layouts ----------
if (want("screens")) {
  await test("dark mode and 390 px layouts have no horizontal scroll", async () => {
    // Without the text test there is no live encounter or feedback yet: show a started one instead.
    if (!encounterPath && student) {
      const page = await newPage({ storageState: await studentState() });
      await page.goto(BASE + student.coursePath);
      await startEncounter(page, DEMO_CASE, "text");
      await page.getByRole("tab", { name: /^Exams/ }).click();
      await orderTest(page, "chest x-ray");
      await page.locator(".chat .record").first().waitFor();
      await layoutShots("06-encounter-text", new URL(page.url()).pathname, { ready: (p) => p.locator(".chat .record").first().waitFor(), state: await page.context().storageState() });
      await page.context().close();
    }
    const failed = layoutChecks.filter((c) => c.error || c.overflow > 1);
    expect(layoutChecks.length >= 12, `only ${layoutChecks.length} layouts checked`);
    expect(!failed.length, failed.map((c) => `${c.name}: ${c.error ?? `${c.overflow}px sideways`}`).join(" | "));
  });
}

await test("no console errors across the run", async () => {
  expect(consoleErrors.length === 0, consoleErrors.slice(0, 5).join(" | "));
});

await browser.close();
const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed. Screenshots in tests/screens/`);
process.exit(failed.length ? 1 : 0);
