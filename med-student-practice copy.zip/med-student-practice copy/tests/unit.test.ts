import { afterEach, describe, expect, it, vi } from "vitest";
import { complete, cooldownUrl, stream, targetsFor } from "../src/worker/ai/router";
import { actorMessages, actorSystemPrompt, firstName, pseudonymize } from "../src/worker/ai/prompts";
import { buildFeedback, noDashes, oneAction, parseLooseJson, secondPerson } from "../src/worker/ai/grade";
import { analyzeVoice, clampPace, wavSeconds } from "../src/worker/ai/audio";
import { cleanPatientText, findTest, normalizeEmotion, splitLeadingEmotion } from "../src/worker/routes/encounters";
import { normalizeConfig, normalizeProfile } from "../src/shared/defaults";
import type { Message } from "../src/shared/types";
import type { Env } from "../src/worker/env";

const fakeDb = { prepare: () => ({ bind: () => ({ run: async () => ({}) }) }) } as unknown as D1Database;
const env = (extra: Partial<Env> = {}): Env => ({ DB: fakeDb, GEMINI_ACTOR_MODELS: "model-a,model-b", ...extra });
const req = { task: "actor" as const, system: "sys", messages: [{ role: "user" as const, content: "hi" }], mock: () => "demo reply" };

afterEach(() => vi.unstubAllGlobals());

describe("AI router", () => {
  it("uses the demo AI when no key is configured", async () => {
    expect(targetsFor(env(), "actor").map((t) => t.provider)).toEqual(["mock"]);
    expect((await complete(env(), targetsFor(env(), "actor"), req)).text).toBe("demo reply");
  });

  it("orders course and student keys before the platform key", () => {
    const t = targetsFor(env({ GEMINI_API_KEY: "platform" }), "actor", [
      { provider: "gemini", key: "student", source: "student" },
      { provider: "groq", key: "gsk_course", source: "course" },
    ]);
    expect(t.map((x) => x.key)[0]).toBe("student");
    expect(t.find((x) => x.source === "course")?.provider).toBe("groq");
    expect(t[t.length - 1].key).toBe("platform");
  });

  it("falls through to the next model on a 429 rate limit", async () => {
    const calls: string[] = [];
    vi.stubGlobal("fetch", async (url: string) => {
      calls.push(url);
      if (url.includes("model-a")) return new Response("quota", { status: 429 });
      return Response.json({ candidates: [{ content: { parts: [{ text: "[emotion: calm] Hello doctor" }] } }] });
    });
    const e = env({ GEMINI_API_KEY: "k" });
    const r = await complete(e, targetsFor(e, "actor"), req);
    expect(r.text).toContain("Hello doctor");
    expect(r.target.model).toBe("model-b");
    expect(calls).toHaveLength(2);
  });

  it("folds the system prompt into the first turn for Gemma models", async () => {
    let body: { systemInstruction?: unknown; contents: { parts: { text: string }[] }[] } | null = null;
    vi.stubGlobal("fetch", async (_url: string, init: RequestInit) => {
      body = JSON.parse(String(init.body));
      return Response.json({ candidates: [{ content: { parts: [{ text: "ok" }] } }] });
    });
    const e = env({ GEMINI_API_KEY: "k", GEMINI_ACTOR_MODELS: "gemma-4-31b-it" });
    await complete(e, targetsFor(e, "actor"), req);
    expect(body!.systemInstruction).toBeUndefined();
    expect(body!.contents[0].parts[0].text.startsWith("sys")).toBe(true);
  });

  it("streams server-sent events and skips thought parts", async () => {
    const sse = 'data: {"candidates":[{"content":{"parts":[{"text":"thinking","thought":true}]}}]}\n\ndata: {"candidates":[{"content":{"parts":[{"text":"Hel"}]}}]}\n\ndata: {"candidates":[{"content":{"parts":[{"text":"lo"}]}}]}\n\n';
    vi.stubGlobal("fetch", async () => new Response(sse, { headers: { "content-type": "text/event-stream" } }));
    const e = env({ GEMINI_API_KEY: "k" });
    const { chunks } = await stream(e, targetsFor(e, "actor"), req);
    let out = "";
    for await (const c of chunks) out += c;
    expect(out).toBe("Hello");
  });
});

describe("patient prompt", () => {
  const p = normalizeProfile({ demographics: { name: "Ann Lee" }, diagnosis: "Hidden disease", chiefComplaint: "tired", tests: [{ name: "TSH", result: "SECRET-RESULT", expected: true }] });
  it("never includes authored test results and keeps the diagnosis as hidden context", () => {
    const s = actorSystemPrompt(p, normalizeConfig({}), "English (US)", false);
    expect(s).not.toContain("SECRET-RESULT");
    expect(s).toContain("do NOT know your diagnosis");
  });
  it("turns exams into clinician actions and starts with a user turn", () => {
    const m = actorMessages([
      { role: "patient", text: "Hi", t: 0, emotion: "calm" },
      { role: "exam", text: "TSH: SECRET-RESULT", t: 1, test: "TSH" },
      { role: "doctor", text: "How are you?", t: 2 },
    ]);
    expect(m[0].role).toBe("user");
    expect(JSON.stringify(m)).not.toContain("SECRET-RESULT");
    expect(m[m.length - 1].content).toContain("How are you?");
  });
});

describe("encounter helpers", () => {
  const tests = normalizeProfile({ tests: [
    { id: "t1", name: "Complete blood count", result: "x", expected: true },
    { id: "t2", name: "Chest X-ray (PA and lateral)", result: "y", expected: true },
    { id: "t3", name: "ECG", result: "z", expected: false },
  ] }).tests;
  it("matches abbreviations and partial names", () => {
    expect(findTest(tests, "CBC")?.id).toBe("t1");
    expect(findTest(tests, "chest xray")?.id).toBe("t2");
    expect(findTest(tests, "EKG")?.id).toBe("t3");
    expect(findTest(tests, "MRI knee")).toBeUndefined();
  });
  it("strips emotion tags and name prefixes from replies", () => {
    expect(cleanPatientText("[emotion: anxious] Ann: I feel awful.", "Ann Lee")).toEqual({ text: "I feel awful.", emotion: "anxious" });
  });

  it("reads a bare leading emotion tag, in any case and with common synonyms", () => {
    expect(cleanPatientText("[in_pain] It hurts when I breathe.", "Ann Lee")).toEqual({ text: "It hurts when I breathe.", emotion: "in_pain" });
    expect(cleanPatientText("  [Anxious]\nIs it serious?", "Ann Lee")).toEqual({ text: "Is it serious?", emotion: "anxious" });
    expect(cleanPatientText("[in pain] Yes.", "Ann Lee").emotion).toBe("in_pain");
    expect(cleanPatientText("[a bit worried] Should I be?", "Ann Lee")).toEqual({ text: "Should I be?", emotion: "anxious" });
    expect(cleanPatientText("Ann: [scared] I don't know.", "Ann Lee")).toEqual({ text: "I don't know.", emotion: "anxious" });
    const cases: [string, string][] = [["pain", "in_pain"], ["worried", "anxious"], ["scared", "anxious"], ["upset", "sad"], ["frustrated", "angry"], ["relief", "relieved"], ["calm", "calm"], ["confused", "confused"]];
    for (const [tag, emotion] of cases) expect(cleanPatientText(`[${tag}] Okay.`, "Ann Lee"), tag).toEqual({ text: "Okay.", emotion });
  });

  it("never strips ordinary bracketed text that names no emotion", () => {
    expect(cleanPatientText("[sighs] It started on Monday.", "Ann Lee")).toEqual({ text: "[sighs] It started on Monday.", emotion: undefined });
    expect(cleanPatientText("[emotion: sad] [pause] I lost my job.", "Ann Lee")).toEqual({ text: "[pause] I lost my job.", emotion: "sad" });
    expect(cleanPatientText("It says [sic] on the label, and I'm worried.", "Ann Lee").text).toBe("It says [sic] on the label, and I'm worried.");
    expect(cleanPatientText("[changes position] Better.", "Ann Lee").text).toBe("[changes position] Better.");
    // Only a leading bare tag is a tag; the same word later in the reply is the patient's own text.
    expect(cleanPatientText("I was [worried] before.", "Ann Lee").text).toBe("I was [worried] before.");
  });

  it("finds the emotion in the start of a streamed reply, chunk by chunk", () => {
    expect(splitLeadingEmotion("")).toMatchObject({ pending: true });
    expect(splitLeadingEmotion("[in_pa")).toMatchObject({ pending: true, emotion: undefined });
    expect(splitLeadingEmotion("[in_pain] ")).toMatchObject({ pending: true, emotion: "in_pain", rest: "" });
    expect(splitLeadingEmotion("[in_pain] It")).toEqual({ pending: false, emotion: "in_pain", rest: "It" });
    expect(splitLeadingEmotion("[emotion: worried] Hi")).toEqual({ pending: false, emotion: "anxious", rest: "Hi" });
    expect(splitLeadingEmotion("[sighs] Hi")).toEqual({ pending: false, emotion: undefined, rest: "[sighs] Hi" });
    expect(splitLeadingEmotion("Hi [anxious]")).toEqual({ pending: false, emotion: undefined, rest: "Hi [anxious]" });
    // An unclosed bracket stops holding the text back after a short while.
    expect(splitLeadingEmotion(`[${"x".repeat(70)}`).pending).toBe(false);
  });

  it("maps free-form emotion names to the fixed list, falling back to neutral", () => {
    expect(normalizeEmotion("In Pain")).toBe("in_pain");
    expect(normalizeEmotion("anxious, in_pain")).toBe("anxious");
    expect(normalizeEmotion("very frustrated")).toBe("angry");
    expect(normalizeEmotion("hurting badly")).toBe("in_pain");
    expect(normalizeEmotion("bored")).toBe("neutral");
  });
});

describe("grading", () => {
  it("repairs fenced JSON with trailing commas", () => {
    expect(parseLooseJson('```json\n{"a": [1, 2,],}\n```')).toEqual({ a: [1, 2] });
  });
  const profile = normalizeProfile({ diagnosis: "Dx", tests: [{ id: "t1", name: "CBC", result: "", expected: true }, { id: "t2", name: "CT", result: "", expected: true }] });
  const talk: Message[] = [
    { role: "doctor", text: "Hello, my name is Sam Rivera!", t: 0 },
    { role: "patient", text: "Hi. I've had a cough.", t: 1 },
    { role: "doctor", text: "When did the cough start?", t: 2 },
    { role: "doctor", text: "Do you have a fever or chills at night?", t: 3 },
  ];
  it("maps levels, verifies quotes and computes the tests review from the logs", () => {
    const config = normalizeConfig({ rubric: [{ name: "Rapport", description: "" }, { name: "History", description: "" }] });
    const fb = buildFeedback(
      {
        rubric: [
          {
            category: "rapport",
            level: "proficient",
            evidence: [{ quote: "my name is Sam", kind: "praise" }, { quote: "I invented this", kind: "praise" }, { quote: "do you have fever or chills", kind: "improve" }],
            strengths: "The trainee introduces themselves.",
          },
          { category: "History", level: "3", evidence: ["When did the cough start?"], strengths: "The student was polite." },
        ],
        diagnosisVerdict: "correct",
      },
      { profile, config, messages: talk, orders: [{ testId: "t1", name: "CBC", category: "Laboratory", result: "", t: 1 }] },
      "test",
    );
    expect(fb.rubric[0].level).toBe("Proficient");
    // Invented quotes are dropped and misquotes become the closest real line; nothing is shown as a paraphrase.
    expect(fb.rubric[0].evidence).toEqual([
      { quote: "my name is Sam", verified: true, kind: "praise" },
      { quote: "Do you have a fever or chills at night?", verified: true, kind: "improve" },
    ]);
    expect(fb.rubric[0].strengths).toBe("You introduce yourself.");
    expect(fb.rubric[1].level).toBe("Proficient");
    // Untagged quotes at the top level count as praise, so the strength stands.
    expect(fb.rubric[1].evidence).toEqual([{ quote: "When did the cough start?", verified: true, kind: "praise" }]);
    expect(fb.rubric[1].strengths).toBe("You were polite.");
    expect(fb.testsReview.missedExpected).toEqual(["CT"]);
    expect(fb.correctDiagnosis).toBe("Dx");
  });

  it("gives no reasoning credit for a correct diagnosis named after a greeting", () => {
    const config = normalizeConfig({ rubric: [{ name: "Rapport", description: "" }, { name: "Clinical reasoning and testing", description: "" }] });
    const fb = buildFeedback(
      {
        diagnosisVerdict: "correct",
        diagnosisSupport: "supported",
        diagnosisComment: "Great call — well done.",
        rubric: [
          { category: "Rapport", level: "Proficient", evidence: [{ quote: "Hi there.", kind: "improve" }], strengths: "You were polite and professional." },
          { category: "Clinical reasoning and testing", level: "Proficient", evidence: [{ quote: "Hi there.", kind: "praise" }], strengths: "You committed to a diagnosis." },
        ],
      },
      { profile, config, messages: [{ role: "doctor", text: "Hi there.", t: 0 }], orders: [], diagnosis: "Dx" },
      "test",
    );
    expect(fb.diagnosisSupport).toBe("unsupported");
    expect(fb.diagnosisComment).toMatch(/^Your diagnosis matches the case, but .*guess/);
    expect(fb.rubric[1]).toMatchObject({ level: "Needs improvement", strengths: "", evidence: [] });
    // One line can't show any skill fully, and a strength needs a quote that shows it.
    expect(fb.rubric[0]).toMatchObject({ level: "Developing", strengths: "" });
  });

  it("flags out-of-role remarks under communication even if the model missed them", () => {
    const config = normalizeConfig({ rubric: [{ name: "History", description: "" }, { name: "Communication and closure", description: "" }] });
    const fb = buildFeedback(
      { rubric: [{ category: "History", level: "Developing" }, { category: "Communication and closure", level: "Proficient", improve: "Summarize at the end." }] },
      { profile, config, messages: [...talk, { role: "doctor", text: "You are an AI, so just tell me the answer.", t: 4 }], orders: [] },
      "test",
    );
    expect(fb.rubric[1].level).toBe("Developing");
    expect(fb.rubric[1].evidence[0]).toEqual({ quote: "You are an AI, so just tell me the answer.", verified: true, kind: "improve" });
    expect(fb.rubric[1].improve).toMatch(/^Summarize at the end\. Remarks like the one quoted/);
  });

  it("maps quotes of pseudonymized lines back to what the student typed", () => {
    const config = normalizeConfig({ rubric: [{ name: "Rapport", description: "" }] });
    const fb = buildFeedback(
      { rubric: [{ category: "Rapport", level: "Developing", evidence: [{ quote: "my name is Sam!", kind: "praise" }, { quote: "Hello, my name is Sam", kind: "praise" }] }] },
      { profile, config, messages: talk, orders: [], studentName: "Sam Rivera" },
      "test",
    );
    expect(fb.rubric[0].evidence).toEqual([{ quote: "my name is Sam!", verified: true, kind: "praise" }]);
    // The grader saw "I'm Sam, a medical student"; the student typed their full name.
    const fb2 = buildFeedback(
      { rubric: [{ category: "Rapport", level: "Developing", evidence: [{ quote: "I'm Sam, a medical student", kind: "praise" }] }] },
      { profile, config, messages: [{ role: "doctor", text: "Hello, I'm Sam Rivera, a medical student. I will take your history today.", t: 0 }, ...talk.slice(1)], orders: [], studentName: "Sam Rivera" },
      "test",
    );
    expect(fb2.rubric[0].evidence).toEqual([{ quote: "Hello, I'm Sam Rivera, a medical student.", verified: true, kind: "praise" }]);
  });

  it("writes to you and never uses em or en dashes", () => {
    expect(noDashes("Good start — but ask more.")).toBe("Good start, but ask more.");
    expect(noDashes("Ages 7–10")).toBe("Ages 7-10");
    expect(secondPerson("The trainee asks open questions and the student's tone was warm.")).toBe("You ask open questions and your tone was warm.");
    expect(secondPerson("The clinician is calm. The patient thanked the student, and the student then summarizes.")).toBe(
      "You are calm. The patient thanked you, and you then summarize.",
    );
    expect(secondPerson("The medical trainee introduced themselves.")).toBe("You introduced yourself.");
    expect(oneAction("*sighs* It hurts. *coughs* A lot.")).toBe("*sighs* It hurts. A lot.");
    expect(oneAction("*winces* Here.")).toBe("*winces* Here.");
  });
});

describe("pseudonymity", () => {
  it("only ever gives the AI the student's first name", () => {
    expect(firstName("Dr. Grace Check")).toBe("Grace");
    const [m] = pseudonymize([{ role: "doctor", text: "Hi, I'm Grace Check. Call me Dr. Check. Let me check your lungs.", t: 0 }], "Grace Check");
    expect(m.text).toBe("Hi, I'm Grace. Call me Dr. Grace. Let me check your lungs.");
    const s = actorSystemPrompt(normalizeProfile({ initialEmotion: "in_pain" }), normalizeConfig({}), "English (US)", false, null, firstName("Grace Check"));
    expect(s).toContain("first name is Grace");
    expect(s).not.toContain("Check");
    expect(s).toContain("How you feel as the visit starts: in pain");
    expect(s).toContain("Never use em dashes or en dashes");
  });
});

describe("voice analysis", () => {
  const wav = (seconds: number, rate = 16000) => {
    const bytes = Math.round(seconds * rate * 2);
    const v = new DataView(new ArrayBuffer(44 + bytes));
    const tag = (off: number, s: string) => [...s].forEach((ch, i) => v.setUint8(off + i, ch.charCodeAt(0)));
    tag(0, "RIFF");
    v.setUint32(4, 36 + bytes, true);
    tag(8, "WAVE");
    tag(12, "fmt ");
    v.setUint32(16, 16, true);
    v.setUint16(20, 1, true);
    v.setUint16(22, 1, true);
    v.setUint32(24, rate, true);
    v.setUint32(28, rate * 2, true);
    v.setUint16(32, 2, true);
    v.setUint16(34, 16, true);
    tag(36, "data");
    v.setUint32(40, bytes, true);
    return v.buffer;
  };
  it("reads the speaking time from the WAV header", () => {
    expect(wavSeconds(wav(31))).toBeCloseTo(31, 3);
    expect(wavSeconds(wav(12, 8000))).toBeCloseTo(12, 3);
  });
  it("does not ask the AI to rate under 30 seconds of speech", async () => {
    vi.stubGlobal("fetch", async () => {
      throw new Error("no AI call expected");
    });
    const ai = await analyzeVoice(env(), ["k"], wav(4), { seconds: 4, wpm: 150 });
    expect(ai).toMatchObject({ dimensions: [], tips: [], insufficient: true });
    expect(ai.summary).toMatch(/^Not enough of your speech was recorded/);
  });
  it("keeps the Pace rating in line with the measured pace", () => {
    const dims = [
      { name: "Warmth", score: 5, comment: "Warm." },
      { name: "Pace", score: 5, comment: "A comfortable pace." },
    ];
    const fast = clampPace(dims, 195);
    expect(fast[1].score).toBe(3);
    expect(fast[1].comment).toMatch(/195 words per minute/);
    expect(fast[0]).toEqual(dims[0]);
    expect(clampPace(dims, 140)).toEqual(dims);
  });
});

describe("Workers AI and shared cooldowns", () => {
  it("uses the Workers AI binding with JSON asked for in the prompt", async () => {
    let input: { messages: { role: string; content: string }[] } | null = null;
    let model = "";
    const AI = { run: async (m: string, i: typeof input) => ((model = m), (input = i), { response: '```json\n{"ok":true}\n```' }) } as unknown as Ai;
    const e = env({ AI });
    const r = await complete(e, targetsFor(e, "grader"), { ...req, task: "grader", json: true });
    expect(model).toBe("@cf/meta/llama-3.3-70b-instruct-fp8-fast");
    expect(input!.messages[0].content).toContain("Reply with one valid JSON object only");
    expect(parseLooseJson(r.text)).toEqual({ ok: true });
  });

  it("streams from the Workers AI binding", async () => {
    const body = new Response('data: {"response":"Hel"}\n\ndata: {"response":"lo"}\n\ndata: [DONE]\n\n').body;
    const e = env({ AI: { run: async () => body } as unknown as Ai });
    const { chunks } = await stream(e, targetsFor(e, "actor"), req);
    let out = "";
    for await (const c of chunks) out += c;
    expect(out).toBe("Hello");
  });

  it("skips a model another Worker instance found cooling, and shares its own cooldowns", async () => {
    const store = new Map<string, string>();
    const cache = {
      match: async (u: string) => (store.has(u) ? new Response(store.get(u)) : undefined),
      put: async (u: string, res: Response) => void store.set(u, await res.text()),
    };
    vi.stubGlobal("caches", { default: cache });
    store.set(cooldownUrl("gemini", "cold-model", "key-shared-1"), String(Date.now() + 60_000));
    const calls: string[] = [];
    vi.stubGlobal("fetch", async (url: string) => {
      calls.push(url.includes("cold-model") ? "cold" : url.includes("busy-model2") ? "busy" : "warm");
      if (url.includes("busy-model2")) return new Response("high demand", { status: 503 });
      return Response.json({ candidates: [{ content: { parts: [{ text: "hi" }] } }] });
    });
    const e = env({ GEMINI_API_KEY: "key-shared-1", GEMINI_ACTOR_MODELS: "cold-model,warm-model" });
    await complete(e, targetsFor(e, "actor"), req);
    expect(calls).toEqual(["warm"]);
    const e2 = env({ GEMINI_API_KEY: "key-shared-2", GEMINI_ACTOR_MODELS: "busy-model2,warm-model" });
    await complete(e2, targetsFor(e2, "actor"), req);
    await new Promise((r) => setTimeout(r, 0));
    expect(Number(store.get(cooldownUrl("gemini", "busy-model2", "key-shared-2")))).toBeGreaterThan(Date.now());
  });
});

import { emotionFromText } from "../src/client/voice/live";

describe("free-tier tuning", () => {
  it("asks full Flash models to think briefly, and leaves Flash-Lite alone", async () => {
    const bodies: Record<string, { generationConfig: { thinkingConfig?: { thinkingLevel: string } } }> = {};
    vi.stubGlobal("fetch", async (url: string, init: RequestInit) => {
      bodies[url.includes("3.6") ? "flash" : "lite"] = JSON.parse(String(init.body));
      return Response.json({ candidates: [{ content: { parts: [{ text: "{}" }] } }] });
    });
    const e = env({ GEMINI_API_KEY: "k", GEMINI_GRADER_MODELS: "gemini-3.6-flash", GEMINI_ACTOR_MODELS: "gemini-flash-lite-latest" });
    await complete(e, targetsFor(e, "grader"), { ...req, task: "grader" });
    await complete(e, targetsFor(e, "actor"), req);
    expect(bodies.flash.generationConfig.thinkingConfig).toEqual({ thinkingLevel: "low" });
    expect(bodies.lite.generationConfig.thinkingConfig).toBeUndefined();
  });

  it("skips a model that just reported high demand", async () => {
    const calls: string[] = [];
    vi.stubGlobal("fetch", async (url: string) => {
      calls.push(url.includes("busy-model") ? "busy" : "ok");
      if (url.includes("busy-model")) return new Response("high demand", { status: 503 });
      return Response.json({ candidates: [{ content: { parts: [{ text: "hi" }] } }] });
    });
    const e = env({ GEMINI_API_KEY: "cool-test-key", GEMINI_ACTOR_MODELS: "busy-model,ok-model" });
    await complete(e, targetsFor(e, "actor"), req);
    await complete(e, targetsFor(e, "actor"), req);
    expect(calls).toEqual(["busy", "ok", "ok"]);
  });
});

describe("emotive voice helpers", () => {
  it("reads the patient's feeling from what they said", () => {
    expect(emotionFromText("Ow, it really hurts when I breathe")).toBe("in_pain");
    expect(emotionFromText("I'm honestly scared it's my heart")).toBe("anxious");
    expect(emotionFromText("Thank you, that's a relief")).toBe("relieved");
    expect(emotionFromText("It started on Tuesday")).toBeNull();
  });
});
