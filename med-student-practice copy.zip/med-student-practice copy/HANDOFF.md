# Handoff: where the work stands and what to do next

Read this first if you are a new Claude Code session (cloud or local) picking up this project.

## The owner's goal

- App name **Med Student Practice AI**, with "Heavily inspired by Dartmouth's AI Patient Actor" credit throughout and the line "Independent project, not affiliated with or endorsed by Dartmouth College."
- Patient voices must sound human (done: Gemini TTS with emotional delivery, Gemini Live for emotive voice).
- The design must not look AI-generated: follow `DESIGN.md` (single forest accent on white or black, Newsreader headings plus the system font, no gradients, no beige or purple, no emoji icons, no em dashes, sentence case, generous space, left-aligned asymmetric layouts, Apple HIG principles).
- **Done means:** all tests pass AND five separate grader agents (doctor/teacher, student, head designer, human tester, AI CEO) each score the app **90 or higher** with **no launch blockers** listed (the owner lowered the bar from 95 to 90 on Oct 30 so the work fits their plan's usage limits; see "Passing bar" in `docs/review/REVIEW_BRIEF.md`). Then give the owner direct, free deployment instructions (`npm run launch`, Cloudflare Workers + D1, works instantly).

## Where it stands

Round 1 grades: doctor 80, student 79, head designer 79, human tester 74, AI CEO 71. Every finding, with file and line hints, is in `docs/review/FINDINGS_ROUND1.md`.

Fixes run in two waves of parallel workstreams that own disjoint files.

**Wave 1** (work orders: `docs/review/wave1-workflow.js`, the `TASKS` array):

| Workstream | State |
|---|---|
| auth-security | Done and verified: session versions (sign-out really ends sessions), sign-in/sign-up/reset throttling (`src/worker/limits.ts`), optional Turnstile and allowed email domains, `POST /api/auth/check`, join codes at sign-up with auto-enroll (`enrolledCourseId`), env `SESSION_SECRET`/`ENC_KEY`, `POST /api/auth/password`, `GET /api/me/export`, `DELETE /api/me` (`src/worker/account.ts`), `getSetting`/`setSetting` in `db.ts`, demo course switch key `demo_course_open`. |
| ai-grading | Partial |
| seed-content | Partial |
| course-api | Partial (`GET /api/health` works) |
| design-system | Partial |
| deploy-capacity | Partial |

The partial workstreams were cut off by a usage limit. Their edits are committed in `79bd527`. Compare with the pre-wave state using `git diff d677951 79bd527 -- <files>`, treat the diff as a draft, verify it and finish each work order. If you can use the Workflow tool, run `docs/review/wave1-workflow.js` (it already skips auth-security and tells each worker to build on the draft). Typecheck is clean at `79bd527`. One unit test fails after the level rename (see "Tests" below).

**Wave 2** has not started. Run it after wave 1, using the real names of what the design-system worker built. Check `src/client/ui.tsx`, `src/client/components/Visuals.tsx`, `src/client/styles.css` and `DESIGN.md` for: FieldError, useFlash, useBack, useUnsavedChanges, confirmDiscard, Modal `closable`, LevelBar, Sparkline, Stat, `.action`, `.field-error`, `.editor-section`, `.test-row`, `.levelbar`, `.row-menu`, `.stat`, `.page.form`, and the phone table and encounter classes.

The three wave 2 workstreams are below.

### F. Student flows

Files: `src/client/pages/Public.tsx`, `src/client/pages/Student.tsx`, new `src/client/pages/Privacy.tsx`, routes in `src/client/App.tsx`.

1. **One-screen sign-up.**
   - Fields: role (Student or Educator), name, email, password, confirm, educator key (only for Educator), consent.
   - Errors appear inline next to each field (`aria-invalid`, `aria-describedby`).
   - Call `POST /api/auth/check` when the email field loses focus and before submit.
   - Reject whitespace-only passwords.
   - Show the `emailDomains` hint.
   - Add the Turnstile widget when `/api/auth/me` returns `turnstileSiteKey`, and send `turnstileToken`.
2. **`/join/:code` route.**
   - Carry `joinCode` through sign-up.
   - For a student who is already signed in, call `POST /api/courses/enroll`.
   - After sign-up, go to `/courses/<enrolledCourseId>`.
3. **Sign-in honors `?next=`.**
4. **`/privacy` page.**
   - Content: what is stored, what goes to Google's free tier (it may be used to improve Google products), that only first names go to the AI, export and delete, retention.
   - Link it from the footer and from the sign-up consent.
5. **Home and Progress pages.**
   - `skillSummary` skips attempts where `doctorTurns === 0` and attempts graded all "Not assessed".
   - Encounter table rows must be keyboard reachable: put a real `<Link>` in the case cell.
   - Show results as "2 Developing, 4 Needs improvement" instead of "0 of 6 skills at top level".
   - Use the responsive tables on phones.
   - Add a "Next up" card (weakest skill plus a suggested case), a cases-completed Stat and a per-skill Sparkline.
   - Never show "No encounters yet" when loading failed.
6. **Course page.** Each case card shows its configuration as a visible tag.
7. **Settings.** Add "Download my data" (`/api/me/export`), "Change password", and "Delete my account and data" (password confirm, then sign out).
8. **Back buttons** use `useBack(fallback)`.

### G. Encounter and feedback

Files: `src/client/pages/Encounter.tsx`, `src/client/pages/Feedback.tsx`, new `src/shared/testCatalog.ts`, the orders route in `src/worker/routes/encounters.ts`, and `src/client/voice/speaker.ts` notices.

1. **Search-first test ordering** (`testOrdering: "search"`).
   - Typing field with a datalist built from a generic catalogue of about 150 common exams and tests, with synonyms (for example "CXR").
   - The server matches the typed name to the case's tests by normalized name and synonym.
   - An unmatched test gets a neutral "not part of this case's file" result and is recorded once, never duplicated.
   - In "menu" mode, show the case's tests as `.test-row` rows with a trailing "Order".
2. **PreBrief.** Show the door note, and `briefResults` when present. The face starts at `brief.initialEmotion`.
3. **Time limit.** When `timeLimitMin > 0`, in every mode: a countdown, a 2-minute warning, and the End modal opens at 0.
4. **End modal.**
   - Placeholder "Your leading diagnosis".
   - A blank diagnosis needs confirmation.
   - Ending with no messages asks "End without talking? This attempt won't count toward your progress."
   - `Modal closable={false}` while grading.
5. **Actions.** Render `*actions*` as `<em className="action">` in chat bubbles and the feedback transcript. Never show raw asterisks or em dashes.
6. **Encounter screen cleanup.**
   - Remove the duplicate patient header from the sidebar.
   - The composer auto-grows and has no resize grip.
   - The tasks tab becomes "Checklist" (the student's own); done items dim with `var(--label-3)`.
   - `aria-live` announces only finished messages.
7. **Phone layout.** Compact head, a 40px avatar, and the chat gets at least 60% of the screen.
8. **Voice fallback.** Say plainly when the natural voice has fallen back to the device voice.
9. **Feedback page.**
   - Diagnosis support is shown next to the verdict.
   - Meter and badge share one right-aligned cell, and the table stacks on phones.
   - "What went well" hides empty strengths.
   - Quotes are labeled by `kind`.
   - Voice feedback shows the "not enough speech" message.
   - Meta line uses " · " separators; the eyebrow is the configuration name only.
   - `useBack`.
   - Labeled comment boxes ("Comment on message 3").
   - Small "Graded by <model>" line.

### H. Educator

Files: `src/client/pages/educator/*.tsx`, `src/client/components/ListEditor.tsx`.

1. **Course results.**
   - Each encounter shows its diagnosis verdict, level counts, duration and graded-by.
   - A LevelBar per rubric category, grouped by configuration.
   - A "Show unfinished attempts" toggle, off by default.
   - In-progress rows are not dead ends.
2. **Students tab.** Per-row actions in a compact menu, with confirm on Remove. Emails truncate.
3. **CSV export.** Prefix any cell starting with `= + - @`, tab or CR with `'`.
4. **Course settings.**
   - Inline validation errors and a "Saved" flash.
   - Retention days.
   - Copy code and copy join link (`<origin>/join/<code>`) show "Copied".
   - Archive asks for confirmation; Delete only works on an archived course.
   - A capacity summary from `GET /api/admin/capacity`.
5. **Admin page.** Use badges instead of the missing `.pill`, add the capacity panel, and add the demo course switch (`PUT /api/admin/settings {demoCourseOpen}`).
6. **Profile editor.**
   - `.editor-section` instead of cards, with sentence-case headings.
   - Door note and starting mood fields.
   - Test rows: a 140px name column and a full-width, auto-growing result.
   - A read-only style for public templates.
   - The "Auto" chip instead of the conic-gradient swatches.
   - An unsaved-changes guard, and server validation messages shown to the educator.
7. **Config editor.**
   - Per-level descriptors for each rubric category.
   - `testOrdering` and `showResultsInBrief` toggles.
   - `.page.form` instead of the inline `maxWidth`.
   - An unsaved-changes guard and server validation messages.
8. **Layout.** One left edge everywhere, and 48px between Library groups.

## Tests

- **Unit:** `tests/unit.test.ts` "maps levels, verifies quotes and computes the tests review from the logs" fails after the level rename. Fix it.
- **`tests/smoke.mjs`:**
  - Students are auto-enrolled in the demo course at sign-up.
  - Sign-out now ends every session of that user.
  - `/transcript` only works for emotive encounters.
  - `/end` is atomic.
  - Add checks for health, capacity, export, delete, check and password.
- **`tests/e2e.mjs`:** update for the one-screen sign-up, landing on the course page, typed test orders (type "chest x-ray"), the countdown, the End modal confirmations, keyboard checks (modal focus, table rows) and phone and dark screenshots.
- **`tests/grader-check.mjs`** (new, written by the AI worker) checks that a guesser is not rewarded. Run it.
- Delete the throwaway `tests/_aw1_api.mjs`.

Run everything:

```bash
npm run typecheck && npx vitest run
node tests/smoke.mjs
node tests/voice-check.mjs tests/fixtures/doctor.wav
node tests/tts-check.mjs
node tests/e2e.mjs
node tests/grader-check.mjs
```

## Re-grade

Spawn five independent grader agents, one per role, each given `docs/review/REVIEW_BRIEF.md` and the same output format (SCORE, VERDICT, BLOCKERS, TOP ISSUES, WHAT 90+ NEEDS, NICE TO HAVE):

1. **Doctor and clinical skills educator.** Clinical realism, test results, feedback fairness, educator workflow, faithfulness to Dartmouth's design. One graded text encounter in which they try to trip the patient up.
2. **Second-year medical student.** Speed to first practice, clarity at each step, usefulness of the feedback, motivation from progress.
3. **Head of design.** The design brief above, every screenshot in light, dark and phone, a grep of the source for violations.
4. **QA human tester.** Validation, navigation, keyboard and screen reader use, session expiry, educator create/edit/delete flows, security basics, console errors.
5. **AI CEO.** Value proposition, free-tier capacity for a class of 100, robustness, one-command deploy, privacy and abuse protection.

Save each round's findings as `docs/review/FINDINGS_ROUND<n>.md`. Fix every blocker and whatever keeps a grader below 90, retest, and re-grade until all five reach 90 with no blockers. Collect the graders' NICE TO HAVE items in `docs/review/LATER.md` as optional follow-ups; don't spend rounds on them.

## Setup on a fresh machine (for example a cloud session)

1. Run `npm ci` (if platform-specific packages complain, use `npm install`). This needs Node 20 or newer.
2. Create `.dev.vars` from `.dev.vars.example`:
   - Set `GEMINI_API_KEY` from the environment variable of the same name (never commit it).
   - Set `EDUCATOR_ACCESS_KEY` to any random string.
   - Set `ADMIN_EMAILS=admin@test.local`.
3. Run `npm run dev` (http://127.0.0.1:5173). The first request migrates and seeds the local D1.
4. For browser tests, run `npx playwright@1.64.1 install --with-deps chromium`. `tests/e2e.mjs` uses Google Chrome on a Mac, `CHROME_PATH`, or Playwright's Chromium. The local test admin is created on demand by `tests/test-admin.mjs`.
5. The environment needs network access to `generativelanguage.googleapis.com` (the AI), the npm registry, the Playwright browser download and Google Fonts.

## Rules that matter

- **Free Google quota:**
  - `gemini-3.6-flash` allows about 20 free requests a day; Flash-Lite allows far more.
  - Keep live AI use small. Graders get at most 2 short encounters each and 1 graded ending.
  - Do not loop the e2e, fidelity or grader-check scripts.
- **Cloudflare free plan:** 10 ms CPU per request. Never base64-encode large audio in the Worker; long clips use the Files API.
- **Secrets:** never commit `.dev.vars` or `.launch.json`, and never print keys or passwords.
- **UI copy:** sentence case, no em dashes, never call this product "AI Patient Actor".

## Gotchas already learned

- **zsh:** `$m:generateContent` is parsed as a zsh modifier. Write `${m}:generateContent`.
- **macOS:**
  - Headless Chrome never answers `getUserMedia`, so `tests/e2e.mjs` swaps in a scripted fake microphone (`fakeMic`).
  - Claude Code's macOS sandbox blocks audio, so on a Mac run the e2e voice tests with the sandbox off.
  - Linux is fine.
- **Local IP limits:** requests without a `CF-Connecting-IP` header are not IP rate-limited, so local tests are never blocked. Production always is.
- **Dev server:** it stops when the desktop session that started it ends. Restart it with `npm run dev`.

## Finish

1. Commit and push.
2. The owner deploys from their own computer: `npm install`, then copy `.dev.vars.example` to `.dev.vars` and add their Google key, then `npm run launch`. This needs a browser once for the free Cloudflare login. Keep the launch steps in `README.md` exact and current.
3. Remind the owner to rotate the Google key, since it was pasted into a chat once.
