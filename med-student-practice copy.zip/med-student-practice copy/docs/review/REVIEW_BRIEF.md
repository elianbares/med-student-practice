# Review brief: Med Student Practice AI

## What it is
A free web app, "heavily inspired by Dartmouth's AI Patient Actor" (Dartmouth Geisel School of Medicine, Thesen et al., Medical Science Educator 2024/2025). Medical students interview AI-simulated patients by text, voice (speech recognition + natural Gemini TTS voice) or emotive voice (Gemini Live speech-to-speech), order exams/tests (educator-authored results), give a diagnosis and SOAP note, and get instant rubric-based feedback with quotes. Educators build patient profiles, configurations (tasks, rubric), cases and courses (join codes, roster, results, comments, CSV). Admin page shows AI status/usage.

Stack: Cloudflare Workers (Hono API) + D1 + React 19 SPA (Vite). AI: Google Gemini free tier with model fallback. Avatars: DiceBear Avataaars with 9 emotions. Deploys free with `npm run launch` (scripts/launch.mjs).

The owner asked for: name "Med Student Practice AI" with "heavily inspired by Dartmouth" credit throughout; human-sounding voices; a design that does not look AI-generated (no beige/cream, no purple/teal-orange gradients, two paired fonts, no em dashes or emoji icons, no decorative clutter, a locked DESIGN.md style system, generous negative space, asymmetric left-aligned layouts, Apple HIG principles: purpose, agency, responsibility, familiarity, flexibility, simplicity, craft, delight); full function; free hosting that works instantly.

## Where things are (project root = the working directory)
- `DESIGN.md`: the style system. `README.md`: overview and launch steps. `BLUEPRINT.md`: original research and plan, including how Dartmouth's product works.
- Source: `src/client` (React pages in `src/client/pages`, styles in `src/client/styles.css`), `src/worker` (API, AI router `src/worker/ai/router.ts`, prompts `src/worker/ai/prompts.ts`, seed cases `src/worker/seed.ts`), `src/shared`.
- Screenshots of every main screen from the real-Chrome test run: `tests/screens/*.png` (01 landing, 02 dark/phone variants, 03-04 student home, 05-07 text encounter and feedback, 08-09 voice, 10-11 emotive voice, 12 progress, 13-18 educator screens). Open them with the Read tool.
- Tests: `tests/e2e.mjs` (Playwright, real Chrome), `tests/smoke.mjs` (API), `tests/voice-check.mjs`, `tests/tts-check.mjs`, `tests/fidelity.mjs`, `tests/unit.test.ts`.

## Latest results (all passing)
- e2e 9/9: landing credit and disclaimer, sign-up wizard, text encounter with real AI replies, exam ordering, diagnosis and feedback; voice encounter (fake mic speech recognized, patient answered in the natural Gemini voice, no fallback to the robotic device voice); emotive Live voice turn saved; progress page; educator creates course and adds case; dark mode and phone layouts with no horizontal scroll; zero console errors.
- smoke API walkthrough: all checks passed. Voice checks 9/9 (Live token, Live patient stays in case and doesn't reveal diagnosis, speech-to-text, AI voice analysis, grading). TTS check 4/4 voices (about 2 to 3 s). Unit 14/14. Typecheck clean. Production build and Cloudflare dry-run upload pass (worker 204 KB, client 172 KB gzipped).
- Patient fidelity eval (virtual clinician + AI judge) earlier scored 1.00 on all 4 cases.

## Using the live app yourself
The dev server is running at http://127.0.0.1:5173. You can:
- Call the API with curl (state-changing requests need header `x-requested-with: apa`; auth is a cookie from `POST /api/auth/signin` or signup). Read `src/worker/auth.ts` and `src/client/api.ts` for shapes. Passwords are hashed client-side first (see `src/client/pages/Public.tsx` / `src/client/api.ts`), so the browser path is easiest.
- Drive real Chrome with Playwright: write a script inside the project's `tests/` folder named `tests/_review_<yourrole>.mjs` (so `playwright-core` resolves), copy the browser setup from the top of `tests/e2e.mjs` (it uses Google Chrome on a Mac, CHROME_PATH, or Playwright's own Chromium; headless), and DELETE your script when done. Do not use the microphone/voice flows yourself (the sandbox blocks audio); rely on the screenshots and test results for voice.
- Create your own student account through the sign-up page (any fake email like reviewer-<role>-<random>@test.local). The local test admin/educator account is defined in `tests/test-admin.mjs` (ensureTestAdmin creates it when missing); never print credentials in your report.

## Rules
- Read-only review: do NOT edit, create or delete project files (except your own temporary `tests/_review_*.mjs`, which you must delete).
- The AI runs on a free Google quota. Keep live AI use small: at most 2 short text encounters (under 8 messages each) and at most 1 graded ending. Do not run tests/e2e.mjs, fidelity.mjs or voice-check.mjs.
- Be brutally honest but calibrated. Score what a real user in your role would experience. Every deduction must name a concrete, fixable issue with where it is (screen/screenshot name or file:line).

## Passing bar
The app passes when all five graders score 90 or more, no grader lists a blocker, and all tests pass. A blocker is anything that must not ship: a broken core flow (sign-up, joining a course, an encounter, feedback, educator authoring), lost or leaked data, a security hole, a crash, or clinically wrong content. Score as you normally would; the bar does not change how you score.

## Output format (your final message)
SCORE: <0-100>
VERDICT: one sentence.
BLOCKERS: each launch blocker with exact reproduction steps and location, or "none".
TOP ISSUES (most impactful first, max 10): each line = [points it costs] issue -> exact fix, with location.
WHAT 90+ NEEDS: if you scored below 90, the shortest list of changes that would make you give 90 or more.
NICE TO HAVE: what would lift your score to 95 or more (kept as optional follow-ups, not required to pass).
